# GROOV Ads: Command Center

Run every client's paid ads from here: Meta, Google and TikTok.
**Open a Claude Code session in this folder.** `CLAUDE.md` loads automatically and sets the guardrails: every live change needs approval, new ads are created paused, and every change is logged.

- `SYSTEM.md`: how the system fits together and what's set up (start here)
- `learnings/`: what works and what doesn't, kept by Claude
- `accounts/registry.json`: all clients and their ad-account IDs
- `clients/<client>/`: brief, changelog, creatives
- `launches/`: campaign specs awaiting approval
- `reports/`: performance snapshots
- `command-center/`: dashboards. Run `python3 fetch_windsor.py && python3 build_all.py`, then open `html/index.html`

Confidential. Treat it like `Clients/` and `Reports/`.

## About this repository
This repo holds code, docs and config only. **Real client data is never committed** (see `.gitignore`):
- **Left out on purpose:** `dashboard/sample/` (real September ad data), `command-center/source` and `creatives`, `screenshots`, the `clients/`, `launches/` and `reports/` working folders, and every generated file (`node_modules`, `dist-hermes`, the zips).
- **Where the private data lives:** on Finn's Mac, and inside the zip that Hermes installs from.
- **Tests:** `npm test` in `dashboard/` needs `dashboard/sample/` as its reference data. On a fresh clone without it, most tests can't run. Run the suite where the data is (Finn's Mac, or Hermes's installed package, which carries its own copy).
- **Generated client data files:** run `npm run build:static` in `dashboard/` after cloning. It rebuilds `public/data/registry.js` and `learnings.js` from `accounts/` and `learnings/`.

