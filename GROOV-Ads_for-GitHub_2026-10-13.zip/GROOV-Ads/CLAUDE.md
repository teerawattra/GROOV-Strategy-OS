# GROOV Ads: operating rules for Claude

This folder is GROOV Strategy's ad command center. Sessions started here read and run ads across every client account.

## Start of every session
1. Read `SYSTEM.md` for the map, the current **Status** and known gaps. Update its Status table whenever something gets set up or breaks.
2. Read `learnings/PLAYBOOK.md` before analysing an account, writing a launch spec or recommending a change. Cite rules by their L-number.
3. For a specific client, also read `clients/<client>/brief.md` and the most recent part of `changelog.md`.

## Learning log (Claude owns it)
- Add an entry to `learnings/LOG.md` after every analysis, finished test, or live change whose result is now visible: what was seen, exact numbers and IDs, the sample, and the confidence level. Use the format at the top of the file and the next L-number.
- Then update `learnings/PLAYBOOK.md`: add or adjust the rule and cite the entry.
- Confidence: **Observation** (seen once) → **Tested** (a deliberate comparison of at least 2 weeks with at least 20 results per arm, or at least 2 accounts) → **Proven** (at least 3 accounts or at least 3 months, and Finn has confirmed). Never present an Observation to a client as a fact.
- When new evidence contradicts a rule, mark the old entry `Superseded by L-NNN` and rewrite the rule. Never delete history.
- Learnings judged on messages or lead actions say nothing about lead quality until CRM or booking data backs them up. Say so in the entry.
- Never put client-confidential detail beyond ad performance into learnings. Brand assets stay in `Clients/`.

## Source of truth
- `accounts/registry.json` maps each client to its Meta, Google and TikTok account IDs. Resolve a client name through it before you touch an account. If an account is missing or shows up in a live pull but not here, update the registry first.
- The `Clients/<name>/` folders one level up hold brand assets. They are **confidential**, like `Reports/`. Nothing from them or from `data/` goes into Website builds or anything sent outside GROOV.

## Tools
- **Meta Ads MCP** (`ads_*` tools): reads and writes for Meta accounts where `meta_mcp: true`. Accounts with `meta_mcp: false` are read-only via Windsor.
- **Windsor.ai MCP**: reads across Meta, Google Ads and TikTok (`get_data`). Its writes (`execute_action`) also cover these platforms.
- **Higgsfield / Canva**: creative production. Finished creatives go in `clients/<client>/creatives/`.
- Existing creative library: `../Output/Ad Creatives/` (built by `build_creatives.py`). Leave it where it is.

## Hard rules for live changes
1. **Read, propose, confirm, then write.** Before any create, update, activate, pause or budget change, show the exact change (account, entity, before → after, daily/lifetime THB) and wait for Finn's explicit yes in chat. A yes covers only that one change.
2. **New campaigns, ad sets and ads are created PAUSED.** Activate them only after a separate confirmation.
3. **Log every live change** in `clients/<client>/changelog.md` straight away: date (ICT), platform, entity ID, what changed, why, who approved it.
4. Budgets are in **THB**. Meta's minimum daily budget is ฿33.81 per ad set.
5. Never delete campaigns, audiences or creatives. Pause them instead.
6. Ad-account billing and payment methods are off-limits. Flag problems such as `IN_GRACE_PERIOD` to Finn.

## Folder map
| Path | What lives there |
|---|---|
| `SYSTEM.md` | architecture, status, known gaps (read first) |
| `learnings/` | `PLAYBOOK.md` (current rules) and `LOG.md` (evidence), both written by Claude |
| `accounts/registry.json` | client → account IDs (all platforms) |
| `clients/<client>/` | `brief.md` (goals, KPIs, budget, ad-spend rate), `changelog.md`, `creatives/` |
| `launches/` | one spec file per campaign before it goes live (`_templates/launch-spec.md`) |
| `reports/` | performance snapshots and client reports, `YYYY-MM-DD_<scope>.md` |
| `dashboard/` | **the GROOV Ads Command Center**: `SPEC.md` (features), `DATA_CONTRACT.md` (3 Sheets → JSON), `DEPLOY.md` (Netlify + Google login), `public/` (frontend), `lib/` + `netlify/` (API, jobs) |
| `command-center/` | older Hermes static build, live Windsor artifact, creative library seed (see below) |
| `data/raw/` | raw JSON pulls (dated filenames; disposable) |
| `scripts/` | pull and build scripts |
| `_templates/` | brief, launch spec, changelog |

## Dashboard rules (`dashboard/`)
- The data contract (`dashboard/DATA_CONTRACT.md`) and the spec (`dashboard/SPEC.md`) are authoritative. Change code and docs in the same edit.
- Run `npm test` in `dashboard/` before and after any change. The parity check must keep passing, or be updated with a written reason.
- Learnings feed the dashboard: when a playbook rule can be checked automatically, add it to `learnings/rules.json` (with its L-number), then run `npm run build:static`.
- Never deploy `public/data/sample.js` (real client numbers). The build already strips it.

## Command Center (older static dashboards)
Ported from Hermes's reference package, which is kept untouched in `_reference/hermes-package/`.
```
cd command-center
python3 fetch_windsor.py   # read-only Windsor REST pull → source/*.json (needs MCP_WINDSOR_API_KEY in Ads/.env)
python3 build_all.py       # account dashboards + html/index.html (the Command Center)
```
- Periods come from `period.py`: the latest 7 completed Bangkok days vs the 7 before. Today is never included. To rebuild a past window, set `GROOV_PERIOD_END=YYYY-MM-DD`. For example, `2026-09-20` reproduces Hermes's frozen build: 21 accounts and ฿91,303.10.
- Every Command Center card links to `html/<platform>/<slug>.html`, keyed by platform + account ID, and each page links back. Builders publish their links through `*-manifest.json`.
- Preserve the Hermes design and logic: the dark monitor style, objective-aware KPIs (Lead generation is classified before Messages), equal-period comparisons, campaign → ad set → ad hierarchy, and the four decisions (Immediate Action, Watch Out, Ready to Scale, No Touching), each with Evidence/Why/Action.
- The dashboard pipeline is **strictly read-only**. Fetch and build never call `execute_action`, `create_custom_field` or `list_actions`. Never paste the Windsor key into chat, code or HTML.
- Metric meaning: messaging conversations are not qualified leads. Platform lead actions are not verified leads, appointments or sales. Overlapping events are never added up as unique people. A missing denominator renders as "—", never as ฿0. GROOV Production stays in totals, and its earlier 10 spam conversations count as zero qualified.
- Expired creative URLs show a declared placeholder. Never substitute an image.
- Preview: the sandboxed preview server can't read ~/Desktop, so rsync `command-center/html/` to the scratchpad and serve that (launch.json `ads-command-center`, port 8170).

### Live artifact (Refresh button)
- https://claude.ai/artifact/XevgwCgEGLku1RHUCqrwSy is a separate artifact from the older React "GROOV Ads Command Center". The source is `command-center/live/index.html`: Hermes's logic ported to the browser.
- It pulls Windsor `get_data` through the page's `mcp` capability (read-only, nothing else declared). It loads when opened, and Refresh forces a fresh pull.
- Creatives come from `command-center/creatives/` and are published as files. Meta/TikTok CDN images can't load inside an artifact, so an ad missing from the library shows a blank card that states the reason.
- **Creative sync** (run when new ads launch):
  1. Get fresh links: TikTok via Windsor `video_thumbnail_url`, written to `creatives/fresh-urls.json`, or Meta via the `Output/Ad Creatives` pull.
  2. `python3 creatives.py && python3 build_live.py`
  3. Republish `live/index.html` with the new `creatives/...jpg` files plus `creatives/index.json`. Keep each publish to 255 files or fewer.
- Local test harness: serve `live/` with `mock.js`, which replays `source/*.json`, and set `window.__GROOV_TODAY__="2026-09-21"`. The result must equal Hermes: 21 accounts, 3/10/2/6, ฿91,303.10.

## Conventions
- Campaign naming follows what the accounts already use: `<KOL/angle>_<CLIENT>_<OBJ>_<DDMMYY>`, for example `Kอินดี้_5YEN_AWN_110926`. OBJ is one of AWN (awareness), ENG, TRF, MSG, LEAD or SALES.
- Dates are ICT (UTC+7). Pricing and ad-spend rates are in `../PRICING-MASTER.md`.
