// Login page logic (public). An external file, not an inline script, so the site's Content-Security-Policy can
// forbid inline scripts everywhere.
//
// 1. Already signed in (GET /api/session = 200)? Go to the dashboard.
// 2. GET /api/config for the Google OAuth client id, load Google Identity Services, render the button.
// 3. The button returns an ID token ("credential"): POST it to /api/session, which verifies it, checks the
//    allow-list and sets the session cookie. Success -> "/"; failure -> the server's human-readable reason.
(function () {
  'use strict';

  var GSI_SRC = 'https://accounts.google.com/gsi/client';
  var LOOP_KEY = 'groov.login.redirectedAt';
  var statusEl = document.getElementById('status');
  var errorEl = document.getElementById('error');
  var buttonEl = document.getElementById('gsi-button');

  function setStatus(text) {
    statusEl.textContent = text || '';
  }

  function showError(text) {
    errorEl.textContent = text || '';
    errorEl.hidden = !text;
  }

  function request(url, options) {
    var init = Object.assign({ credentials: 'same-origin', cache: 'no-store', headers: { accept: 'application/json' } }, options || {});
    return fetch(url, init).then(function (res) {
      return res.json().catch(function () { return null; }).then(function (body) { return { res: res, body: body }; });
    });
  }

  // A redirect loop (the dashboard keeps sending a signed-in user back here) means the edge function cannot
  // read the session settings. Remember the last redirect for 20 s and explain instead of looping.
  function recentlyRedirected() {
    try {
      var t = Number(sessionStorage.getItem(LOOP_KEY));
      return t > 0 && Date.now() - t < 20000;
    } catch (e) {
      return false;
    }
  }

  function openDashboard(email) {
    setStatus('Signed in as ' + email + '. Opening the dashboard…');
    try { sessionStorage.setItem(LOOP_KEY, String(Date.now())); } catch (e) { /* private mode */ }
    window.location.replace('/');
  }

  function onCredential(response) {
    showError('');
    setStatus('Checking your account…');
    request('/api/session', {
      method: 'POST',
      headers: { 'content-type': 'application/json', accept: 'application/json' },
      body: JSON.stringify({ credential: response && response.credential }),
    }).then(function (r) {
      if (r.res.ok && r.body && r.body.email) {
        openDashboard(r.body.email);
        return;
      }
      setStatus('');
      showError((r.body && r.body.error) || 'Sign-in failed (HTTP ' + r.res.status + '). Please try again.');
    }).catch(function () {
      setStatus('');
      showError("Couldn't reach the server. Check your connection and try again.");
    });
  }

  function loadGsi() {
    return new Promise(function (resolve, reject) {
      if (window.google && window.google.accounts && window.google.accounts.id) { resolve(); return; }
      var script = document.createElement('script');
      var timer = setTimeout(function () { reject(new Error('timeout')); }, 15000);
      script.src = GSI_SRC;
      script.async = true;
      script.onload = function () { clearTimeout(timer); resolve(); };
      script.onerror = function () { clearTimeout(timer); reject(new Error('load failed')); };
      document.head.appendChild(script);
    });
  }

  function renderButton(clientId) {
    window.google.accounts.id.initialize({
      client_id: clientId,
      callback: onCredential,
      ux_mode: 'popup',
      auto_select: false,
      cancel_on_tap_outside: true,
      itp_support: true,
      context: 'signin',
    });
    var width = Math.round(Math.min(320, Math.max(220, buttonEl.clientWidth || 280)));
    window.google.accounts.id.renderButton(buttonEl, {
      type: 'standard', theme: 'outline', size: 'large', shape: 'pill', text: 'signin_with', logo_alignment: 'left', width: width,
    });
    setStatus('');
  }

  function start() {
    if (new URLSearchParams(window.location.search).get('signed_out') === '1') setStatus('You have signed out.');

    request('/api/session').then(function (r) {
      if (r.res.ok && r.body && r.body.email) {
        if (!recentlyRedirected()) {
          openDashboard(r.body.email);
          return null;
        }
        showError('You are signed in as ' + r.body.email + ', but the dashboard sent you back here. Ask Finn to check that SESSION_SECRET, ALLOWED_DOMAINS and ALLOWED_EMAILS are available to Edge Functions in Netlify (scope: All scopes) and redeploy.');
      }
      return request('/api/config');
    }).then(function (r) {
      if (r === null) return null;
      var clientId = r && r.res.ok && r.body ? r.body.google_client_id : null;
      if (!clientId) {
        setStatus('');
        showError("Sign-in isn't set up yet: the server has no Google client id (GOOGLE_CLIENT_ID). Ask Finn.");
        return null;
      }
      return loadGsi().then(function () { renderButton(clientId); }, function () {
        setStatus('');
        showError("Couldn't load Google sign-in. Check your connection (or an ad blocker), then reload the page.");
      });
    }).catch(function () {
      setStatus('');
      showError("Couldn't reach the server. Check your connection and reload the page.");
    });
  }

  start();
})();
