/* GROOV Ads Command Center · sidebar.js
 * ------------------------------------------------------------------------------------------
 * Role: everything the user can adjust (SPEC §3) and the sticky top bar (SPEC §2).
 *   - state defaults, sanitising and persistence (localStorage key 'groov.cc.v1')
 *   - sidebar HTML: brand + data pill, navigation (+ client list), period, compare, filters,
 *     decision rules, footer
 *   - top bar HTML: breadcrumb, "period vs compare", removable filter chips, filter count, Refresh
 *   - the click / change handlers for those controls (registered on GROOV.actions)
 *   - the module switcher (top of the sidebar) when window.GROOV_MODULES (data/modules.js) enables
 *     more than one module; hidden while only "ads" is enabled (the default)
 * Public API (window.GROOV.sidebar):
 *   KEY, defaults(), sanitize(obj), load(), save(state)
 *   render(ctx) -> sidebar HTML      renderClientList(ctx) -> <li> list HTML      topbar(ctx) -> HTML
 *   activeFilterChips(state, reg)    [{k, v, label}]
 *   modules(raw) -> enabled modules [{id, label, route}]   moduleSwitcher(ctx) -> HTML ('' for one module)
 * ctx = { state, snap, meta, mode, reg, ds, session, build, badge, loading, error, routeLabel, modules? }
 *   session.mode (VPS server): 'tailscale' -> "Signed in via Tailscale as …", no Sign out; 'none' -> local test
 */
(function (root) {
  'use strict';
  var G = root.GROOV = root.GROOV || {};
  var U = G.util, D = G.data, E = G.engine, M = G.model, UI = G.ui;
  var S = G.sidebar = {};
  var A = G.actions = G.actions || {};
  var esc = U.esc;

  S.KEY = 'groov.cc.v1';

  /* =========================================================================================
   * State
   * ======================================================================================= */
  S.defaults = function () {
    return {
      v: 1,
      route: { page: 'overview', slug: null, params: {} },
      period: { preset: '7d', from: null, to: null },
      compare: 'prev',
      filters: { platforms: [], verticals: [], objectives: [], decisions: [], owners: [], activeOnly: false, minSpend: 0, starredOnly: false },
      rules: Object.assign({}, E.DEFAULT_RULES),
      pinned: [],
      reviewed: {},
      snoozed: {},
      ui: {
        collapsed: false, rulesOpen: false, clientsOpen: true, clientSearch: '', sorts: {},
        actionsTab: 'all', creativesTab: 'winners', creativesSort: 'spend', creativesLimit: 48,
        clientPlatform: 'all', trendMode: 'platform', showSuperseded: false,
        trendGran: 'auto', trendSplit: 'total' // KPI trend charts: Daily / Weekly override, expanded-chart split
      }
    };
  };
  function obj(v) { return v && typeof v === 'object' && !Array.isArray(v) ? v : {}; }
  /** Merge anything (localStorage, hash) onto defaults, dropping unknown or malformed values. */
  S.sanitize = function (raw) {
    var d = S.defaults(), r = obj(raw);
    var p = obj(r.period);
    if (D.PRESET_IDS.indexOf(p.preset) >= 0) d.period.preset = p.preset;
    if (U.isIso(p.from)) d.period.from = p.from;
    if (U.isIso(p.to)) d.period.to = p.to;
    if (D.COMPARE_IDS.indexOf(r.compare) >= 0) d.compare = r.compare;
    d.filters = M.normFilters(r.filters);
    d.rules = E.rulesFrom(r.rules);
    d.pinned = Array.isArray(r.pinned) ? U.uniq(r.pinned.filter(function (s) { return typeof s === 'string' && s; })) : [];
    var rv = obj(r.reviewed), sn = obj(r.snoozed);
    Object.keys(rv).forEach(function (k) { if (rv[k]) d.reviewed[k] = 1; });
    Object.keys(sn).forEach(function (k) { if (U.isIso(sn[k])) d.snoozed[k] = sn[k]; });
    var ui = obj(r.ui);
    Object.keys(d.ui).forEach(function (k) {
      if (ui[k] === undefined) return;
      if (typeof d.ui[k] === typeof ui[k] && !(typeof d.ui[k] === 'object' && Array.isArray(ui[k]))) d.ui[k] = ui[k];
    });
    d.ui.clientSearch = '';
    if (['all', 'meta', 'tiktok', 'google'].indexOf(d.ui.clientPlatform) < 0) d.ui.clientPlatform = 'all';
    if (!(d.ui.creativesLimit > 0)) d.ui.creativesLimit = 48;
    if (['auto', 'daily', 'weekly'].indexOf(d.ui.trendGran) < 0) d.ui.trendGran = 'auto';
    if (['total', 'platform', 'campaigns', 'adsets'].indexOf(d.ui.trendSplit) < 0) d.ui.trendSplit = 'total';
    return d;
  };
  S.load = function () {
    var raw = null;
    try { raw = JSON.parse(root.localStorage.getItem(S.KEY) || 'null'); } catch (e) { raw = null; }
    return S.sanitize(raw);
  };
  /** Persist everything except the route (the hash holds it) and transient UI bits. Prunes old marks. */
  S.save = function (st) {
    var today = U.bangkokToday(), cutoff = U.addDays(today, -120);
    var reviewed = {};
    Object.keys(st.reviewed || {}).forEach(function (k) {
      var at = k.slice(k.lastIndexOf('@') + 1);
      if (!U.isIso(at) || at >= cutoff) reviewed[k] = 1;
    });
    var snoozed = {};
    Object.keys(st.snoozed || {}).forEach(function (k) { if (st.snoozed[k] >= today) snoozed[k] = st.snoozed[k]; });
    var ui = Object.assign({}, st.ui);
    delete ui.clientSearch;
    var out = { v: 1, period: st.period, compare: st.compare, filters: st.filters, rules: st.rules, pinned: st.pinned,
      reviewed: reviewed, snoozed: snoozed, ui: ui };
    try { root.localStorage.setItem(S.KEY, JSON.stringify(out)); } catch (e) { /* private mode / quota: settings stay per tab */ }
  };

  /* =========================================================================================
   * Icons (inline SVG, currentColor)
   * ======================================================================================= */
  var IC = {
    overview: '<path d="M3 13h8V3H3zM13 21h8V11h-8zM3 21h8v-6H3zM13 3v6h8V3z"/>',
    actions: '<path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/>',
    clients: '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
    creatives: '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/>',
    playbook: '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>',
    data: '<path d="M22 12h-4l-3 9L9 3l-3 9H2"/>',
    collapse: '<path d="M15 18l-6-6 6-6"/>',
    expand: '<path d="M9 18l6-6-6-6"/>',
    refresh: '<path d="M21 12a9 9 0 1 1-3-6.7"/><path d="M21 3v6h-6"/>',
    menu: '<path d="M3 6h18M3 12h18M3 18h18"/>',
    close: '<path d="M18 6L6 18M6 6l12 12"/>'
  };
  S.icon = function (name, cls) {
    return '<svg class="ic ' + (cls || '') + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (IC[name] || '') + '</svg>';
  };

  /* =========================================================================================
   * Sidebar
   * ======================================================================================= */
  function freshness(meta, mode) {
    var T = meta && meta.data_through;
    if (!U.isIso(T)) return { cls: 'red', text: 'No data yet', age: null };
    var age = U.diffDays(T, U.bangkokToday());
    var cls = age >= 4 ? 'red' : age >= 2 ? 'amber' : 'green';
    return { cls: cls, age: age, text: 'Data through ' + U.fmtDay(T) };
  }
  function chip(act, v, label, on, extra) {
    return '<button type="button" class="chip' + (on ? ' on' : '') + '" aria-pressed="' + !!on + '" data-act="' + act + '" data-v="' + esc(v) + '"' +
      (extra || '') + '>' + label + '</button>';
  }
  function navItem(page, label, href, cur, extra) {
    var on = cur === page;
    return '<a class="nav-i' + (on ? ' on' : '') + '" href="' + href + '"' + (on ? ' aria-current="page"' : '') + ' data-tip-rail="' + esc(label) + '">' +
      S.icon(page) + '<span class="nav-t">' + esc(label) + '</span>' + (extra || '') + '</a>';
  }

  /* ---------- modules (data/modules.js: {modules: [{id, label, enabled, route}]}) ---------- */
  var ADS_PAGES = ['overview', 'actions', 'client', 'creatives', 'playbook', 'data'];
  /** Enabled modules, cleaned: valid unique ids, labels, and in-app routes only ("#/…"; anything else -> "#/<id>"). */
  S.modules = function (raw) {
    var list = Array.isArray(raw) ? raw : raw && Array.isArray(raw.modules) ? raw.modules : [];
    var out = [], seen = {};
    list.forEach(function (m) {
      if (!m || typeof m !== 'object' || m.enabled !== true) return;
      var id = typeof m.id === 'string' ? m.id.trim() : '';
      if (!/^[a-z][a-z0-9_-]{0,31}$/.test(id) || seen[id]) return;
      seen[id] = true;
      var route = typeof m.route === 'string' && /^#\/[A-Za-z0-9_\-\/]*$/.test(m.route.trim()) ? m.route.trim() : '#/' + id;
      out.push({ id: id, label: typeof m.label === 'string' && m.label.trim() ? m.label.trim() : id, route: route });
    });
    return out;
  };
  /** Compact switcher between modules (Ads, KOL, Content, CRM); '' while only one is enabled. */
  S.moduleSwitcher = function (ctx) {
    var mods = S.modules(ctx.modules !== undefined ? ctx.modules : root.GROOV_MODULES);
    if (mods.length < 2) return '';
    var page = ctx.state && ctx.state.route ? ctx.state.route.page : 'overview';
    var cur = ADS_PAGES.indexOf(page) >= 0 ? 'ads' : null; // other modules mark their own pages (MODULES.md)
    return '<nav class="sb-mods chips" aria-label="Modules">' + mods.map(function (m) {
      var on = m.id === cur;
      return '<a class="chip' + (on ? ' on' : '') + '" href="' + esc(m.route) + '"' + (on ? ' aria-current="true"' : '') + '>' + esc(m.label) + '</a>';
    }).join('') + '</nav>';
  };

  S.render = function (ctx) {
    var st = ctx.state, meta = ctx.meta, mode = ctx.mode, F = M.normFilters(st.filters);
    var fr = freshness(meta, mode);
    var page = st.route.page;
    var out = [];
    out.push(S.moduleSwitcher(ctx));
    // The brand block (logo, collapse, close) is static in index.html so the logo never re-renders;
    // syncChrome() keeps its buttons in step with the state.
    out.push('<div class="sb-title"><b>Ads Command Center</b><span class="pill ' + fr.cls + '" data-tip="' +
      esc(fr.age === null ? 'No data loaded' : (meta.data_through ? 'Latest complete day in every Sheet: ' + U.fmtDate(meta.data_through) + (fr.age !== null ? ' (' + fr.age + ' ' + U.plural(fr.age, 'day') + ' ago)' : '') : '')) +
      '"><i></i>' + esc(fr.text) + (mode ? ' · ' + (mode === 'sample' ? 'Sample' : 'Live') : '') + '</span></div>');

    // Navigation
    var badge = ctx.badge || 0;
    var nClients = ctx.snap ? ctx.snap.clients.length : 0;
    out.push('<nav class="sb-nav" aria-label="Pages">');
    out.push(navItem('overview', 'Overview', '#/overview', page));
    out.push(navItem('actions', 'Action queue', '#/actions', page, badge ? '<b class="badge" aria-label="' + badge + ' unreviewed Immediate and Watch items">' + badge + '</b>' : ''));
    out.push('<div class="nav-g">' +
      '<button type="button" class="nav-i' + (page === 'client' ? ' on' : '') + '" data-act="clients-toggle" aria-expanded="' + !!st.ui.clientsOpen + '" aria-controls="sb-clients" data-tip-rail="Clients">' +
      S.icon('clients') + '<span class="nav-t">Clients</span><span class="cnt">' + nClients + '</span><span class="car" aria-hidden="true">' + (st.ui.clientsOpen ? '▾' : '▸') + '</span></button>' +
      '<div class="sb-clients" id="sb-clients"' + (st.ui.clientsOpen ? '' : ' hidden') + '>' +
      '<input type="search" id="client-search" class="inp" placeholder="Search clients" aria-label="Search clients" value="' + esc(st.ui.clientSearch || '') + '" data-input="client-search">' +
      '<ul class="cl" id="sb-client-list">' + S.renderClientList(ctx) + '</ul></div></div>');
    out.push(navItem('creatives', 'Creatives', '#/creatives', page));
    out.push(navItem('playbook', 'Playbook', '#/playbook', page));
    out.push(navItem('data', 'Data health', '#/data', page));
    out.push('</nav>');

    // Period
    var P = ctx.snap ? ctx.snap.P : null;
    out.push('<section class="sb-sec" aria-labelledby="sb-h-period"><h3 id="sb-h-period">Period</h3><div class="chips">' +
      D.PRESETS.map(function (p) { return chip('preset', p.id, esc(p.label), st.period.preset === p.id); }).join('') + '</div>');
    if (st.period.preset === 'custom' && meta) {
      var cf = P && P.cur ? P.cur.from : (st.period.from || meta.history_from), ct = P && P.cur ? P.cur.to : (st.period.to || meta.data_through);
      out.push('<div class="dates"><label>From<input type="date" class="inp" data-change="custom-from" min="' + esc(meta.history_from) + '" max="' + esc(meta.data_through) +
        '" value="' + esc(cf) + '"></label><label>To<input type="date" class="inp" data-change="custom-to" min="' + esc(meta.history_from) + '" max="' + esc(meta.data_through) +
        '" value="' + esc(ct) + '"></label></div>');
    }
    if (P) out.push('<p class="sb-note">' + esc(P.label) + (P.clipped ? ' (history starts ' + esc(U.fmtDay(P.H)) + ')' : '') + '</p>');
    out.push('</section>');

    // Compare
    out.push('<section class="sb-sec" aria-labelledby="sb-h-cmp"><h3 id="sb-h-cmp">Compare</h3><div class="chips">' +
      D.COMPARES.map(function (c) { return chip('compare', c.id, esc(c.label), st.compare === c.id); }).join('') + '</div>' +
      (P && P.cmp ? '<p class="sb-note">' + esc(P.cmpLabel) + (P.noBaseline ? ' · no baseline' : '') + '</p>' : '') + '</section>');

    // Filters
    var nF = S.activeFilterChips(st, ctx.reg).length;
    var verticals = (ctx.reg ? ctx.reg.verticals.slice() : []);
    if (ctx.ds && ctx.ds.clients.some(function (c) { return c.unmapped && c.accounts.length; }) && verticals.indexOf('Unmapped') < 0) verticals.push('Unmapped');
    out.push('<section class="sb-sec" aria-labelledby="sb-h-f"><h3 id="sb-h-f">Filters' + (nF ? ' <span class="cnt">' + nF + '</span>' : '') + '</h3>');
    out.push('<div class="fgroup"><span class="fl">Platforms</span><div class="chips">' + D.PLATFORMS.map(function (p) {
      return chip('filter', p, '<i class="pdot ' + p + '" aria-hidden="true"></i>' + esc(D.PLATFORM_LABEL[p]), F.platforms.indexOf(p) >= 0, ' data-k="platforms"');
    }).join('') + '</div></div>');
    out.push('<div class="fgroup"><span class="fl">Verticals</span><div class="chips">' + verticals.map(function (v) {
      return chip('filter', v, esc(v), F.verticals.indexOf(v) >= 0, ' data-k="verticals"');
    }).join('') + '</div></div>');
    out.push('<div class="fgroup"><span class="fl">Objectives</span><div class="chips">' + E.OBJECTIVES.map(function (o) {
      return chip('filter', o, esc(o), F.objectives.indexOf(o) >= 0, ' data-k="objectives"');
    }).join('') + '</div></div>');
    out.push('<div class="fgroup"><span class="fl">Decisions <small>(hide rows, not totals)</small></span><div class="chips">' + ['Immediate', 'Watch', 'Scale', 'Hold'].map(function (d) {
      return chip('filter', d, '<i class="ddot ' + E.CLS[M.SHORT_TO_LONG[d]] + '" aria-hidden="true"></i>' + esc(d), F.decisions.indexOf(d) >= 0, ' data-k="decisions"');
    }).join('') + '</div></div>');
    out.push('<div class="fgroup"><span class="fl">Delivery</span><div class="chips">' + chip('active-only', '0', 'All', !F.activeOnly) + chip('active-only', '1', 'Active only', F.activeOnly) + '</div></div>');
    out.push('<div class="fgroup"><label class="fl" for="min-spend">Min spend (฿)</label><input id="min-spend" type="number" min="0" step="100" inputmode="numeric" class="inp" data-change="min-spend" value="' +
      (F.minSpend || '') + '" placeholder="0"></div>');
    if (ctx.reg && ctx.reg.hasOwner) {
      out.push('<div class="fgroup"><span class="fl">Owner</span><div class="chips">' + ctx.reg.owners.map(function (o) {
        return chip('filter', o, esc(o), F.owners.indexOf(o) >= 0, ' data-k="owners"');
      }).join('') + '</div></div>');
    }
    out.push('<div class="fgroup"><div class="chips">' + chip('starred', '1', '★ Starred only', F.starredOnly) + '</div></div>');
    out.push('<button type="button" class="btn ghost sm" data-act="reset-filters"' + (nF ? '' : ' disabled') + '>Reset filters</button></section>');

    // Decision rules
    var modified = E.rulesModified(st.rules);
    out.push('<section class="sb-sec"><button type="button" class="sec-t" data-act="rules-toggle" aria-expanded="' + !!st.ui.rulesOpen + '" aria-controls="sb-rules">Decision rules' +
      (modified ? ' <i class="moddot" data-tip="Some rules differ from the Hermes defaults" aria-label="modified"></i>' : '') + '<span class="car" aria-hidden="true">' + (st.ui.rulesOpen ? '▾' : '▸') + '</span></button>' +
      '<div id="sb-rules"' + (st.ui.rulesOpen ? '' : ' hidden') + '>');
    E.RULE_DEFS.forEach(function (r) {
      var v = st.rules[r.key], def = E.DEFAULT_RULES[r.key];
      out.push('<label class="rule' + (+v !== def ? ' mod' : '') + '"><span>' + esc(r.label) + '</span><span class="rin">' + (r.unit === '฿' ? '<i>฿</i>' : '') +
        '<input type="number" class="inp" min="' + r.min + '" step="' + r.step + '" data-change="rule" data-k="' + r.key + '" value="' + esc(v) + '" aria-label="' + esc(r.label) + '">' +
        (r.unit && r.unit !== '฿' ? '<i>' + esc(r.unit) + '</i>' : '') + '</span><small>Hermes ' + esc(r.unit === '฿' ? '฿' + def : def + (r.unit || '')) + '</small></label>');
    });
    out.push('<button type="button" class="btn ghost sm" data-act="rules-reset"' + (modified ? '' : ' disabled') + '>Reset to Hermes defaults</button></div></section>');

    // Footer
    out.push('<footer class="sb-foot">');
    if (mode === 'live') {
      var sess = ctx.session, via = sess && (sess.mode === 'tailscale' || sess.mode === 'none') ? sess.mode : null;
      if (via === 'tailscale') {
        // VPS server: Tailscale vouches for every request, so there is nothing to sign out of.
        out.push('<div class="who"><span>Signed in via Tailscale as ' + esc(sess.email || sess.name || 'your Tailscale account') + '</span></div>');
      } else if (via === 'none') {
        out.push('<div class="who"><span class="muted">Local test mode · no sign-in</span></div>');
      } else {
        out.push('<div class="who">' + (sess && sess.email ? '<span>' + esc(sess.email) + '</span>' : '<span class="muted">Signed in</span>') +
          '<button type="button" class="btn ghost sm" data-act="signout">Sign out</button></div>');
      }
      if (sess && sess.owner === true) {
        out.push('<button type="button" class="btn ghost sm" data-act="data-refresh" data-tip="' +
          (via ? 'Ask the server to re-pull the last days from Windsor now (owner only)' : 'Ask the backend to re-pull the three Sheets now (owner only)') + '">Refresh data now</button>');
      }
    }
    if (ctx.notice) out.push('<p class="sb-notice" role="status">' + esc(ctx.notice) + '</p>');
    out.push('<span class="ro">Read-only · no ad changes</span><small class="muted">Build ' + esc(ctx.build || '') + '</small></footer>');
    return out.join('');
  };

  /** Update the static brand-block buttons (collapse icon + label, close icon). */
  S.syncChrome = function (st) {
    if (typeof document === 'undefined') return;
    var col = document.querySelector('.sb-col'), cls = document.querySelector('.sb-close');
    if (col) {
      var want = st.ui.collapsed ? 'expand' : 'collapse';
      if (col.getAttribute('data-icon') !== want) { col.innerHTML = S.icon(want); col.setAttribute('data-icon', want); }
      col.setAttribute('aria-label', (st.ui.collapsed ? 'Expand' : 'Collapse') + ' sidebar');
      col.setAttribute('aria-expanded', String(!st.ui.collapsed));
    }
    if (cls && !cls.firstChild) cls.innerHTML = S.icon('close');
  };

  /** Client list: pinned first, then by current spend; clients outside the filters are greyed. */
  S.renderClientList = function (ctx) {
    var st = ctx.state, snap = ctx.snap, ds = ctx.ds;
    if (!ds) return '<li class="muted small">Loading…</li>';
    var q = String(st.ui.clientSearch || '').toLowerCase().trim();
    var pinned = st.pinned || [];
    var cur = st.route.page === 'client' ? st.route.slug : null;
    var list = ds.clients.filter(function (c) { return c.accounts.length || !c.unmapped; }).map(function (c) {
      var row = snap ? snap.clientBySlug.get(c.slug) : null;
      return { c: c, row: row, spend: row ? row.cur.spend : -1, pin: pinned.indexOf(c.slug) >= 0 };
    });
    list.sort(function (a, b) {
      return (b.pin - a.pin) || (b.spend - a.spend) || U.cmpText(a.c.name, b.c.name);
    });
    if (q) list = list.filter(function (x) { return x.c.name.toLowerCase().indexOf(q) >= 0; });
    if (!list.length) return '<li class="muted small">No client matches “' + esc(q) + '”.</li>';
    return list.map(function (x) {
      var on = cur === x.c.slug;
      var dot = x.row ? UI.ddot(x.row.decision) : '<i class="ddot none" aria-hidden="true"></i>';
      var spend = x.row ? U.money(x.row.cur.spend) : U.DASH;
      return '<li class="' + (x.row ? '' : 'out') + (on ? ' on' : '') + '"><a href="#/client/' + encodeURIComponent(x.c.slug) + '"' + (on ? ' aria-current="page"' : '') + '>' +
        dot + '<span class="nm">' + esc(x.c.name) + '</span><span class="sp num">' + esc(spend) + '</span></a>' +
        '<button type="button" class="pin' + (x.pin ? ' on' : '') + '" data-act="pin" data-v="' + esc(x.c.slug) + '" aria-pressed="' + x.pin + '" aria-label="' +
        (x.pin ? 'Unpin ' : 'Pin ') + esc(x.c.name) + '">' + (x.pin ? '★' : '☆') + '</button></li>';
    }).join('');
  };

  /* =========================================================================================
   * Top bar
   * ======================================================================================= */
  S.activeFilterChips = function (st, reg) {
    var F = M.normFilters(st.filters), out = [];
    F.platforms.forEach(function (v) { out.push({ k: 'platforms', v: v, label: D.PLATFORM_LABEL[v] }); });
    F.verticals.forEach(function (v) { out.push({ k: 'verticals', v: v, label: v }); });
    F.objectives.forEach(function (v) { out.push({ k: 'objectives', v: v, label: v }); });
    F.decisions.forEach(function (v) { out.push({ k: 'decisions', v: v, label: v, row: true }); });
    F.owners.forEach(function (v) { out.push({ k: 'owners', v: v, label: 'Owner: ' + v }); });
    if (F.activeOnly) out.push({ k: 'activeOnly', v: '1', label: 'Active only', row: true });
    if (F.minSpend > 0) out.push({ k: 'minSpend', v: String(F.minSpend), label: 'Min ' + U.money(F.minSpend), row: true });
    if (F.starredOnly) out.push({ k: 'starredOnly', v: '1', label: '★ Starred only' });
    return out;
  };

  S.topbar = function (ctx) {
    var st = ctx.state, snap = ctx.snap, P = snap ? snap.P : null;
    var chips = S.activeFilterChips(st, ctx.reg);
    var out = ['<div class="tb-row">'];
    out.push('<button type="button" class="tb-menu" data-act="drawer" aria-label="Open menu" aria-controls="sidebar" aria-expanded="false">' + S.icon('menu') + '</button>');
    out.push('<nav class="crumbs" aria-label="Breadcrumb">' + (ctx.crumbs || []).map(function (c, i, all) {
      return i < all.length - 1 && c.href ? '<a href="' + esc(c.href) + '">' + esc(c.label) + '</a><span class="sep" aria-hidden="true">›</span>' : '<span aria-current="page">' + esc(c.label) + '</span>';
    }).join('') + '</nav>');
    if (P) {
      out.push('<div class="tb-period"><b>' + esc(P.label) + '</b>' + (P.cmp ? ' <span class="vs">vs</span> ' + esc(P.cmpLabel) + (P.noBaseline ? ' <span class="warnt">no baseline</span>' : '') :
        ' <span class="vs">· comparison off</span>') + '</div>');
    }
    out.push('<div class="tb-right">' + (chips.length ? '<span class="fcount">' + chips.length + ' ' + U.plural(chips.length, 'filter') + '</span>' : '') +
      '<button type="button" class="btn copper refresh" data-act="refresh"' + (ctx.loading ? ' disabled aria-busy="true"' : '') + '>' + S.icon('refresh', ctx.loading ? 'spin' : '') +
      '<span>' + (ctx.loading ? 'Loading…' : 'Refresh') + '</span></button></div>');
    out.push('</div>');
    if (chips.length) {
      out.push('<div class="tb-chips">' + chips.map(function (c) {
        return '<button type="button" class="fchip' + (c.row ? ' row' : '') + '" data-act="rm-filter" data-k="' + esc(c.k) + '" data-v="' + esc(c.v) + '" aria-label="Remove filter ' + esc(c.label) + '">' +
          esc(c.label) + ' <span aria-hidden="true">×</span></button>';
      }).join('') + '<button type="button" class="fchip clear" data-act="reset-filters">Clear all</button></div>');
    }
    var notes = [];
    if (P && P.noBaseline) notes.push(P.reason + ' Without a baseline, decisions can only flag spend with zero results.');
    if (P && P.cmp === null) notes.push('Comparison is off: decisions can only flag spend with zero results.');
    if (P && P.clipped) notes.push('History starts ' + U.fmtDate(P.H) + ', so this ' + (D.PRESETS.filter(function (x) { return x.id === P.preset; })[0] || {}).label + ' view covers ' + P.label + ' only.');
    if (P && !P.cur) notes.push('No data in ' + U.rangeLabel(P.nominal.from, P.nominal.to) + ': history covers ' + U.rangeLabel(P.H, P.T) + '.');
    if (P && P.cmp && !P.noBaseline && P.unequal) notes.push('The comparison has ' + P.cmpLen + ' days and the period ' + P.len + ' (the previous month or quarter is shorter).');
    if (P && P.cmp && !P.noBaseline && P.overlap) notes.push('The comparison overlaps the current period.');
    if (snap && snap.rowFiltersActive) notes.push('Row filters (Decisions, Active only, Min spend) hide rows but totals ignore them.');
    var html = notes.map(function (n) { return '<p>' + esc(n) + '</p>'; });
    if (ctx.error) html.push('<p class="err">⚠ ' + esc(ctx.error) + ' <button type="button" class="btn ghost xs" data-act="refresh">Retry</button></p>');
    if (html.length) out.push('<div class="tb-notes">' + html.join('') + '</div>');
    return out.join('');
  };

  /* =========================================================================================
   * Handlers (dispatched by app.js from data-act / data-change / data-input attributes)
   * ======================================================================================= */
  function app() { return G.app; }
  function toggleIn(list, v) {
    var i = list.indexOf(v);
    if (i >= 0) list.splice(i, 1); else list.push(v);
  }
  A.preset = function (el) {
    app().update(function (st) {
      st.period.preset = el.getAttribute('data-v');
      if (st.period.preset === 'custom' && !st.period.from) {
        var P = app().periods();
        if (P && P.cur) { st.period.from = P.cur.from; st.period.to = P.cur.to; }
      }
    });
  };
  A['custom-from'] = function (el) {
    var v = el.value;
    if (!U.isIso(v)) return;
    app().update(function (st) { st.period.preset = 'custom'; st.period.from = v; if (st.period.to && st.period.to < v) st.period.to = v; });
  };
  A['custom-to'] = function (el) {
    var v = el.value;
    if (!U.isIso(v)) return;
    app().update(function (st) { st.period.preset = 'custom'; st.period.to = v; if (st.period.from && st.period.from > v) st.period.from = v; });
  };
  A.compare = function (el) { app().update(function (st) { st.compare = el.getAttribute('data-v'); }); };
  A.filter = function (el) {
    var k = el.getAttribute('data-k'), v = el.getAttribute('data-v');
    app().update(function (st) { if (Array.isArray(st.filters[k])) toggleIn(st.filters[k], v); });
  };
  A['active-only'] = function (el) { app().update(function (st) { st.filters.activeOnly = el.getAttribute('data-v') === '1'; }); };
  A.starred = function () { app().update(function (st) { st.filters.starredOnly = !st.filters.starredOnly; }); };
  A['min-spend'] = function (el) {
    var v = +el.value;
    app().update(function (st) { st.filters.minSpend = U.isNum(v) && v > 0 ? v : 0; });
  };
  A['reset-filters'] = function () {
    app().update(function (st) { st.filters = S.defaults().filters; });
  };
  A['rm-filter'] = function (el) {
    var k = el.getAttribute('data-k'), v = el.getAttribute('data-v');
    app().update(function (st) {
      if (Array.isArray(st.filters[k])) { var i = st.filters[k].indexOf(v); if (i >= 0) st.filters[k].splice(i, 1); }
      else if (k === 'activeOnly' || k === 'starredOnly') st.filters[k] = false;
      else if (k === 'minSpend') st.filters.minSpend = 0;
    });
  };
  A.pin = function (el) {
    var slug = el.getAttribute('data-v');
    app().update(function (st) { toggleIn(st.pinned, slug); });
  };
  A['clients-toggle'] = function () {
    if (app().state.ui.collapsed && !app().isMobile()) { app().update(function (st) { st.ui.collapsed = false; st.ui.clientsOpen = true; }); return; }
    app().update(function (st) { st.ui.clientsOpen = !st.ui.clientsOpen; }, { viewOnly: false, noView: true });
  };
  A['rules-toggle'] = function () { app().update(function (st) { st.ui.rulesOpen = !st.ui.rulesOpen; }, { noView: true }); };
  A.rule = function (el) {
    var k = el.getAttribute('data-k'), v = +el.value;
    app().update(function (st) { st.rules[k] = U.isNum(v) && v >= 0 ? v : E.DEFAULT_RULES[k]; });
  };
  A['rules-reset'] = function () { app().update(function (st) { st.rules = Object.assign({}, E.DEFAULT_RULES); }); };
  A.collapse = function () { app().update(function (st) { st.ui.collapsed = !st.ui.collapsed; }, { noView: true }); setTimeout(G.charts.redraw, 260); };
  A['client-search'] = function (el) {
    app().state.ui.clientSearch = el.value;
    var ul = document.getElementById('sb-client-list');
    if (ul) ul.innerHTML = S.renderClientList(app().ctx());
  };
})(typeof window !== 'undefined' ? window : this);
