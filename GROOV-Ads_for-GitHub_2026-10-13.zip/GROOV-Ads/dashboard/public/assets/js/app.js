/* GROOV Ads Command Center · app.js
 * ------------------------------------------------------------------------------------------
 * Role: router, state store, boot and re-render. Loaded last.
 *
 *  Boot:    registry + learnings -> state (localStorage, then URL hash) -> mode (sample when
 *           GROOV_SAMPLE exists and the page is file:/localhost; sample.js is injected locally
 *           only) -> /api/meta -> periods -> /api/rows once for the needed range -> render.
 *  Routes:  #/overview  #/actions  #/client/<slug>  #/creatives  #/playbook  #/data
 *           Key state is mirrored after "?" (p, from, to, c, pl, vt, ob, dc, act, min, own, star,
 *           plus page params tab, check, cl, cp, l, and as = the open ad set panel on any page), so a
 *           copied link opens the same view. Route changes push history (Back/Forward work); state
 *           changes replace the entry. Opening an ad set panel pushes one, so Back closes it.
 *  Render:  sidebar + top bar + ONLY the current view, then the ad set panel (#sheet) when `as`
 *           is set; the snapshot is memoized by state key.
 *  Data:    rows once for the needed windows; monthly lazily; breakdowns (/api/breakdowns, or
 *           GROOV_SAMPLE.breakdowns) lazily the first time an ad set panel or the client
 *           "Where results happen" section renders: same queued fetch / merge / error + Retry.
 *  Events:  delegated. Elements declare data-act (click), data-change (change), data-input
 *           (input), tr[data-row-act] (row click); handlers live on window.GROOV.actions
 *           (sidebar.js and the views add theirs). Esc closes the drawer, then an open KPI
 *           chart, then the ad set panel.
 * Public API (window.GROOV.app): state, ctx(), update(fn, opts), go(hash), render(), periods(),
 *           isMobile(), loadMonthly(), loadBreakdowns(), retryBreakdowns(), expanded(tableId)
 */
(function (root) {
  'use strict';
  var G = root.GROOV = root.GROOV || {};
  var U = G.util, D = G.data, E = G.engine, M = G.model, C = G.charts, UI = G.ui, S = G.sidebar;
  var A = G.actions = G.actions || {};
  var V = G.views = G.views || {};
  var app = G.app = {};

  G.BUILD = '2026-10-12';
  var PAGES = ['overview', 'actions', 'client', 'creatives', 'playbook', 'data'];
  var PAGE_LABEL = { overview: 'Overview', actions: 'Action queue', client: 'Client', creatives: 'Creatives', playbook: 'Playbook', data: 'Data health' };

  var reg = null, learn = null, src = null, mode = null; // 'sample' | 'live' once detected
  var loading = false, error = null, booted = false, monthlyLoading = false, monthlyError = null, notice = null;
  var bdLoading = false, bdError = null; // breakdowns: bdError = { key (windows), msg }
  var expanded = new Map();
  var lastHash = null, sheetKey = null;
  app.state = null;

  /* =========================================================================================
   * Hash <-> state
   * ======================================================================================= */
  function parseHash(h) {
    h = String(h || '').replace(/^#/, '');
    var q = '', i = h.indexOf('?');
    if (i >= 0) { q = h.slice(i + 1); h = h.slice(0, i); }
    var parts = h.replace(/^\/+/, '').split('/').filter(Boolean);
    var page = PAGES.indexOf(parts[0]) >= 0 ? parts[0] : 'overview';
    var slug = null;
    if (page === 'client') { try { slug = decodeURIComponent(parts.slice(1).join('/')); } catch (e) { slug = parts.slice(1).join('/'); } }
    var params = {};
    q.split('&').forEach(function (kv) {
      if (!kv) return;
      var j = kv.indexOf('='), k = j < 0 ? kv : kv.slice(0, j), v = j < 0 ? '' : kv.slice(j + 1);
      try { params[decodeURIComponent(k)] = decodeURIComponent(v.replace(/\+/g, ' ')); } catch (e) { /* skip malformed */ }
    });
    return { page: page, slug: page === 'client' ? slug : null, params: params };
  }
  app.parseHash = parseHash;
  var list = function (v) { return v ? v.split(',').filter(Boolean) : []; };

  /** Apply URL params onto state. Only keys present in the URL override the stored defaults. */
  function applyParams(st, p) {
    if (p.p && D.PRESET_IDS.indexOf(p.p) >= 0) st.period.preset = p.p;
    if (U.isIso(p.from)) st.period.from = p.from;
    if (U.isIso(p.to)) st.period.to = p.to;
    if (p.c && D.COMPARE_IDS.indexOf(p.c) >= 0) st.compare = p.c;
    var f = st.filters;
    if ('pl' in p) f.platforms = list(p.pl);
    if ('vt' in p) f.verticals = list(p.vt);
    if ('ob' in p) f.objectives = list(p.ob);
    if ('dc' in p) f.decisions = list(p.dc);
    if ('own' in p) f.owners = list(p.own);
    if ('act' in p) f.activeOnly = p.act === '1';
    if ('min' in p) f.minSpend = +p.min > 0 ? +p.min : 0;
    if ('star' in p) f.starredOnly = p.star === '1';
    st.filters = M.normFilters(f);
    if (p.tab && st.route.page === 'actions') st.ui.actionsTab = p.tab;
    if (p.tab && st.route.page === 'creatives') st.ui.creativesTab = p.tab;
    if (p.sort && st.route.page === 'creatives') st.ui.creativesSort = p.sort;
    if (p.cp && ['all', 'meta', 'tiktok', 'google'].indexOf(p.cp) >= 0) st.ui.clientPlatform = p.cp;
  }
  function buildHash(st) {
    var r = st.route, path = '#/' + r.page + (r.page === 'client' && r.slug ? '/' + encodeURIComponent(r.slug) : '');
    var F = M.normFilters(st.filters), q = [];
    var add = function (k, v) { q.push(k + '=' + encodeURIComponent(v).replace(/%2C/g, ',')); };
    add('p', st.period.preset);
    if (st.period.preset === 'custom') {
      var P = app.periods();
      if (P && P.cur) { add('from', P.cur.from); add('to', P.cur.to); }
      else { if (st.period.from) add('from', st.period.from); if (st.period.to) add('to', st.period.to); }
    }
    add('c', st.compare);
    if (F.platforms.length) add('pl', F.platforms.join(','));
    if (F.verticals.length) add('vt', F.verticals.join(','));
    if (F.objectives.length) add('ob', F.objectives.join(','));
    if (F.decisions.length) add('dc', F.decisions.join(','));
    if (F.owners.length) add('own', F.owners.join(','));
    if (F.activeOnly) add('act', '1');
    if (F.minSpend > 0) add('min', String(F.minSpend));
    if (F.starredOnly) add('star', '1');
    var rp = r.params || {};
    if (r.page === 'actions') { add('tab', st.ui.actionsTab); if (rp.check) add('check', rp.check); }
    if (r.page === 'creatives') { add('tab', st.ui.creativesTab); if (rp.cl) add('cl', rp.cl); if (st.ui.creativesTab === 'all') add('sort', st.ui.creativesSort); }
    if (r.page === 'client' && st.ui.clientPlatform !== 'all') add('cp', st.ui.clientPlatform);
    if (r.page === 'playbook' && rp.l) add('l', rp.l);
    if (rp.as) add('as', rp.as); // the open ad set panel
    return path + '?' + q.join('&');
  }
  app.buildHash = function () { return buildHash(app.state); };
  function syncHash(push) {
    var h = buildHash(app.state);
    if (h === location.hash) { lastHash = h; return; }
    lastHash = h;
    try {
      if (push) history.pushState(null, '', h);
      else history.replaceState(null, '', h);
    } catch (e) { if (push) location.hash = h; }
  }

  /* =========================================================================================
   * Context
   * ======================================================================================= */
  app.periods = function () {
    var meta = src && src.meta;
    return meta ? D.periods(meta, app.state.period, app.state.compare) : null;
  };
  app.isMobile = function () { return !!(root.matchMedia && root.matchMedia('(max-width: 899px)').matches); };
  app.expanded = function (id) {
    if (!expanded.has(id)) expanded.set(id, new Set());
    return expanded.get(id);
  };
  app.ctx = function () {
    var st = app.state;
    var snap = null, buckets = null, snapError = null;
    if (src && src.meta && src.ds) {
      try {
        snap = M.snapshot({ ds: src.ds, meta: src.meta, reg: reg, learn: learn, state: st });
        buckets = M.actionBuckets(snap, st);
      } catch (e) {
        snap = null; buckets = null;
        snapError = 'The numbers could not be computed: ' + (e && e.message ? e.message : e);
        if (root.console) console.error(e);
      }
    }
    var bdNeed = snap ? D.bdRanges(snap.P) : [];
    var bdReady = !!(src && src.bd && src.coversBreakdowns && src.coversBreakdowns(bdNeed));
    return {
      state: st, mode: mode, src: src, meta: src ? src.meta : null, ds: src ? src.ds : null, reg: reg, learn: learn,
      snap: snap, buckets: buckets, badge: buckets ? buckets.badge : 0, build: G.BUILD, loading: loading, error: error,
      session: src ? src.session : null, monthly: src ? src.monthly : null, monthlyLoading: monthlyLoading, monthlyError: monthlyError, app: app,
      notice: notice, snapError: snapError,
      bd: src ? src.bd : null, bdReady: bdReady, bdLoading: bdLoading,
      bdError: bdError && !bdReady && bdError.key === JSON.stringify(bdNeed) ? bdError.msg : null
    };
  };

  /* =========================================================================================
   * Data
   * ======================================================================================= */
  function ensureData() {
    if (!src || !src.meta) return Promise.resolve(false);
    var P = app.periods();
    return src.ensureRanges(D.neededRanges(src.meta, P, { pacing: reg.hasBudget }));
  }
  function loadAll(force) {
    loading = true; error = null; bdError = null;
    render();
    if (force) { src.reset(); M.clearMemo(); }
    return src.loadMeta().then(function () {
      if (mode === 'live' && !src.session) src.loadSession().then(function () { renderSidebar(); }).catch(function () { /* footer shows "Signed in" */ });
      return ensureData();
    }).then(function () {
      loading = false;
      if (!booted) { booted = true; syncHash(false); }
      render();
    }).catch(function (e) {
      loading = false;
      if (e && e.status === 401) return; // redirecting to /login.html
      error = (e && e.message ? e.message : 'Could not load data.') + (src.ds ? ' Showing the last data that loaded.' : '');
      render();
    });
  }
  app.loadMonthly = function () {
    if (!src || src.monthly || monthlyLoading) return;
    monthlyLoading = true; monthlyError = null;
    src.loadMonthly().then(function () { monthlyLoading = false; render(); }).catch(function (e) {
      monthlyLoading = false; monthlyError = (e && e.message) || 'Monthly history could not load.'; render();
    });
  };
  /**
   * Breakdowns for the current and comparison windows (SPEC §6), loaded the first time a panel needs
   * them and again only for windows not loaded yet. A failed window is not retried automatically
   * (Retry does that); the data already loaded stays available.
   */
  app.loadBreakdowns = function () {
    if (!src || !src.meta || !src.ensureBreakdowns || bdLoading) return;
    var P = app.periods();
    if (!P || !P.cur) return;
    var need = D.bdRanges(P), key = JSON.stringify(need);
    if (src.coversBreakdowns(need)) return;
    if (bdError && bdError.key === key) return;
    bdLoading = true;
    src.ensureBreakdowns(need).then(function () { bdLoading = false; bdError = null; render(); }).catch(function (e) {
      bdLoading = false;
      if (e && e.status === 401) return; // redirecting to /login.html
      bdError = { key: key, msg: (e && e.message) || 'Breakdowns could not load.' };
      render();
    });
  };
  app.retryBreakdowns = function () { bdError = null; app.loadBreakdowns(); render(); };
  /** Sample mode: inject data/sample.js (local only) and wait; never fetch() local files. */
  function loadSampleScript(cacheBust) {
    return new Promise(function (resolve) {
      if (!D.isLocal(root.location)) return resolve();
      if (root.GROOV_SAMPLE && !cacheBust) return resolve();
      var s = document.createElement('script');
      s.src = 'data/sample.js' + (cacheBust ? '?t=' + Date.now() : '');
      s.onload = s.onerror = function () { resolve(); };
      document.head.appendChild(s);
    });
  }

  /* =========================================================================================
   * State updates and navigation
   * ======================================================================================= */
  /**
   * fn(state) mutates a working copy. opts: { push (new history entry), noView (sidebar only),
   * keepScroll }.
   */
  app.update = function (fn, opts) {
    opts = opts || {};
    var search = app.state.ui.clientSearch;
    fn(app.state);
    app.state = S.sanitize(app.state);
    app.state.ui.clientSearch = search;
    S.save(app.state);
    if (opts.noView) { applyShellClasses(); renderSidebar(); return; }
    syncHash(!!opts.push);
    requestData();
    render();
  };
  /** Fetch rows only when the new state needs dates that are not loaded yet (live mode). */
  function requestData() {
    if (!src || !src.meta) return;
    var P = app.periods(), need = D.neededRanges(src.meta, P, { pacing: reg.hasBudget });
    if (src.covers(need)) return;
    loading = true;
    src.ensureRanges(need).then(function () { loading = false; error = null; render(); }).catch(function (e) {
      loading = false;
      if (e && e.status === 401) return;
      error = ((e && e.message) || 'Could not load data.') + (src.ds ? ' Showing the last data that loaded.' : '');
      render();
    });
  }
  // sanitize() drops the route; keep it across updates
  var sanitize0 = S.sanitize;
  S.sanitize = function (raw) {
    var d = sanitize0(raw);
    if (raw && raw.route) d.route = { page: raw.route.page, slug: raw.route.slug || null, params: raw.route.params || {} };
    return d;
  };
  app.go = function (hash) {
    closeDrawer();
    if (hash === location.hash) return;
    location.hash = hash; // fires hashchange -> onHash
  };
  function onHash() {
    if (location.hash === lastHash) return;
    var r = parseHash(location.hash);
    var prevPage = app.state.route.page, prevSlug = app.state.route.slug;
    app.state.route = { page: r.page, slug: r.slug, params: r.params };
    // The client platform switch belongs to one client: a different client starts on "All".
    if (r.page === 'client' && r.slug !== prevSlug && !r.params.cp) app.state.ui.clientPlatform = 'all';
    applyParams(app.state, r.params);
    S.save(app.state);
    closeDrawer();
    UI.hideTip();
    var pageChanged = prevPage !== r.page || prevSlug !== r.slug;
    if (pageChanged) { expanded.clear(); }
    requestData();
    render();
    syncHash(false);
    if (pageChanged) root.scrollTo(0, 0);
  }

  /* =========================================================================================
   * Rendering
   * ======================================================================================= */
  function $(id) { return document.getElementById(id); }
  function crumbsFor(ctx) {
    var r = ctx.state.route, out = [{ label: 'Overview', href: '#/overview' }];
    if (r.page === 'overview') return out;
    if (r.page === 'client') {
      var c = ctx.ds && ctx.ds.bySlug.has(r.slug) ? ctx.ds.clients[ctx.ds.bySlug.get(r.slug)] : null;
      out.push({ label: c ? c.name : (ctx.ds ? 'Unknown client' : 'Client') });
      return out;
    }
    out.push({ label: PAGE_LABEL[r.page] });
    return out;
  }
  function applyShellClasses() {
    var b = document.body;
    b.classList.toggle('sb-collapsed', !!app.state.ui.collapsed);
    b.classList.toggle('is-sample', mode === 'sample');
  }
  function renderSidebar(ctx) {
    ctx = ctx || app.ctx();
    var sb = $('sb-body');
    if (sb) sb.innerHTML = S.render(ctx);
    S.syncChrome(app.state);
  }
  function focusKey(el) {
    if (!el || el === document.body) return null;
    if (el.id) return { id: el.id };
    var act = el.getAttribute && (el.getAttribute('data-act') || el.getAttribute('data-change') || el.getAttribute('data-input'));
    if (!act) return null;
    return { act: act, v: el.getAttribute('data-v'), k: el.getAttribute('data-k'), tab: el.getAttribute('data-tab'), col: el.getAttribute('data-col'), key: el.getAttribute('data-key') };
  }
  function restoreFocus(fk, sel) {
    if (!fk) return;
    var el = null;
    if (fk.id) el = document.getElementById(fk.id);
    else {
      var q = '[data-act="' + fk.act + '"],[data-change="' + fk.act + '"],[data-input="' + fk.act + '"]';
      var cands = document.querySelectorAll(q);
      for (var i = 0; i < cands.length; i++) {
        var c = cands[i];
        if ((fk.v === null || c.getAttribute('data-v') === fk.v) && (fk.k === null || c.getAttribute('data-k') === fk.k) &&
          (fk.tab === null || c.getAttribute('data-tab') === fk.tab) && (fk.col === null || c.getAttribute('data-col') === fk.col) &&
          (fk.key === null || c.getAttribute('data-key') === fk.key)) { el = c; break; }
      }
    }
    if (el && el.focus) {
      try { el.focus({ preventScroll: true }); } catch (e) { el.focus(); }
      if (sel && el.setSelectionRange) { try { el.setSelectionRange(sel[0], sel[1]); } catch (e) { /* number inputs */ } }
    }
  }
  function render() {
    if (!app.state) return;
    var ctx = app.ctx();
    ctx.crumbs = crumbsFor(ctx);
    var ae = document.activeElement, fk = focusKey(ae), sel = null;
    if (ae && ae.selectionStart !== undefined) { try { sel = [ae.selectionStart, ae.selectionEnd]; } catch (e) { sel = null; } }
    applyShellClasses();
    var banner = $('sample-banner');
    if (banner) {
      banner.hidden = mode !== 'sample';
      if (mode === 'sample' && ctx.meta) banner.textContent = 'SAMPLE DATA: Hermes snapshot ' + U.rangeLabel(ctx.meta.history_from, ctx.meta.data_through) + ' · not live';
    }
    renderSidebar(ctx);
    $('topbar').innerHTML = S.topbar(ctx);
    var view = $('view');
    C.reset(); UI.resetTables();
    var page = ctx.state.route.page;
    var html;
    if (ctx.snapError) {
      html = errorPage(ctx.snapError);
    } else if (!ctx.meta || !ctx.ds) {
      html = error ? errorPage(error) : loadingPage();
    } else {
      try { html = (V[page] || V.overview).render(ctx); }
      catch (e) {
        html = errorPage('This page could not be drawn: ' + (e && e.message ? e.message : e));
        if (root.console) console.error(e);
      }
    }
    view.innerHTML = html;
    view.classList.toggle('stale', !!loading && !!ctx.ds);
    C.drawAll(view);
    if (ctx.snap && V[page] && V[page].after) { try { V[page].after(ctx, view); } catch (e) { /* cosmetic only */ } }
    var prevSheet = sheetKey;
    sheetKey = renderSheet(ctx);
    restoreFocus(fk, sel);
    if (V.adset && V.adset.afterRender) { try { V.adset.afterRender(prevSheet, sheetKey); } catch (e) { /* focus only */ } }
    var t = page === 'client' && ctx.crumbs[1] ? ctx.crumbs[1].label : PAGE_LABEL[page];
    document.title = t + ' · GROOV Ads Command Center';
  }
  app.render = render;
  /** The ad set panel (route param `as`), drawn over the page; keeps its scroll position across re-renders. */
  function renderSheet(ctx) {
    var el = $('sheet');
    if (!el) return null;
    var key = ctx.snap && !ctx.snapError && V.adset ? V.adset.key(ctx) : null, html = '';
    if (key) {
      try { html = V.adset.sheet(ctx); } catch (e) { html = ''; if (root.console) console.error(e); }
    }
    var body = el.querySelector('.ss-b'), top = body && key && key === sheetKey ? body.scrollTop : 0;
    el.innerHTML = html;
    document.body.classList.toggle('sheet-open', !!html);
    if (!html) return null;
    C.drawAll(el);
    var nb = el.querySelector('.ss-b');
    if (nb && top) nb.scrollTop = top;
    return key;
  }
  function loadingPage() {
    return '<div class="page"><div class="skel"></div><div class="skel"></div><div class="skel short"></div><p class="muted">Loading ' +
      (mode === 'sample' ? 'the sample snapshot' : 'ad data') + '…</p></div>';
  }
  function errorPage(msg) {
    return '<div class="page"><section class="panel err-panel" role="alert"><h2>Data could not load</h2><p>' + U.esc(msg) +
      '</p><button type="button" class="btn copper" data-act="retry">Retry</button></section></div>';
  }

  /* =========================================================================================
   * Drawer (under 900px) and events
   * ======================================================================================= */
  function openDrawer() {
    document.body.classList.add('drawer-open');
    var b = document.querySelector('.tb-menu');
    if (b) b.setAttribute('aria-expanded', 'true');
    var first = document.querySelector('#sidebar a, #sidebar button');
    if (first) first.focus();
  }
  function closeDrawer() {
    if (!document.body.classList.contains('drawer-open')) return;
    document.body.classList.remove('drawer-open');
    var b = document.querySelector('.tb-menu');
    if (b) b.setAttribute('aria-expanded', 'false');
  }
  A.drawer = function () { if (document.body.classList.contains('drawer-open')) closeDrawer(); else openDrawer(); };
  A['drawer-close'] = closeDrawer;
  A.retry = function () { loadAll(true); };
  A.refresh = function () {
    if (loading) return;
    loading = true; error = null; bdError = null; render();
    if (mode === 'sample') {
      loadSampleScript(true).then(function () { src = D.createSource('sample', root, reg); loading = false; M.clearMemo(); loadAll(false); });
      return;
    }
    if (!src.ds) { loading = false; loadAll(true); return; }
    src.refresh(function (meta) {
      return D.neededRanges(meta, D.periods(meta, app.state.period, app.state.compare), { pacing: reg.hasBudget });
    }).then(function () {
      loading = false; M.clearMemo(); render();
      if (app.state.route.page === 'client') app.loadMonthly();
    }).catch(function (e) {
      loading = false;
      if (e && e.status === 401) return;
      error = ((e && e.message) || 'Refresh failed.') + ' Showing the last data that loaded.';
      render();
    });
  };
  A.signout = function () {
    src.signOut().then(function () { root.location.href = '/login.html?signed_out=1'; });
  };
  /** Owner only: POST /api/refresh (202) asks the backend to re-pull the Sheets now. */
  A['data-refresh'] = function () {
    if (!src || !src.startRefresh) return;
    notice = 'Starting a data refresh…'; renderSidebar();
    src.startRefresh().then(function () {
      notice = 'Refresh started — data updates in a few minutes. Press Refresh then to load it.';
      renderSidebar(); render();
    }).catch(function (e) {
      if (e && e.status === 401) return;
      notice = 'Could not start a refresh: ' + ((e && e.message) || 'request failed') + '.';
      renderSidebar();
    });
  };
  A['tbl-sort'] = function (el) {
    var id = el.getAttribute('data-tbl'), col = el.getAttribute('data-col');
    var def = UI.tableDef(id);
    app.update(function (st) {
      var cur = st.ui.sorts[id] || (def && def.sort) || {};
      var dir = cur.key === col ? (cur.dir === 'asc' ? 'desc' : 'asc') : (def && def.textCols && def.textCols.indexOf(col) >= 0 ? 'asc' : 'desc');
      st.ui.sorts = Object.assign({}, st.ui.sorts);
      st.ui.sorts[id] = { key: col, dir: dir };
    });
  };
  A['tbl-toggle'] = function (el) {
    var set = app.expanded(el.getAttribute('data-tbl')), key = el.getAttribute('data-key');
    if (set.has(key)) set.delete(key); else set.add(key);
    render();
  };
  A['tbl-expand-all'] = function (el) {
    var id = el.getAttribute('data-tbl'), def = UI.tableDef(id);
    if (!def) return;
    var set = app.expanded(id);
    var walk = function (rows) { rows.forEach(function (r) { var kids = def.children ? def.children(r) : []; if (kids && kids.length) { set.add(def.rowKey(r)); walk(kids); } }); };
    walk(def.rows);
    render();
  };
  A['tbl-collapse-all'] = function (el) { app.expanded(el.getAttribute('data-tbl')).clear(); render(); };
  A['tbl-csv'] = function (el) {
    var id = el.getAttribute('data-tbl'), def = UI.tableDef(id), rows = UI.tableCsv(id);
    if (!rows) return;
    UI.download(UI.csvName(def.csvName || id, app.ctx().snap ? app.ctx().snap.P : null), U.csv(rows));
  };
  A.tab = function (el) {
    var group = el.getAttribute('data-group'), tab = el.getAttribute('data-tab');
    app.update(function (st) { st.ui[group + 'Tab'] = tab; });
  };

  function onClick(ev) {
    var t = ev.target;
    if (!t || !t.closest) return;
    var el = t.closest('[data-act]');
    if (el && !el.disabled) {
      var fn = A[el.getAttribute('data-act')];
      if (fn) { ev.preventDefault(); fn(el, ev); return; }
    }
    var tra = t.closest('tr[data-row-act]');
    if (tra && !t.closest('a,button,input,select,label,summary')) {
      var fr = A[tra.getAttribute('data-row-act')];
      if (fr) { fr(tra, ev); return; }
    }
    var tr = t.closest('tr[data-href]');
    if (tr && !t.closest('a,button,input,select,label,summary')) { app.go(tr.getAttribute('data-href')); return; }
    if (t.closest('#drawer-backdrop')) { closeDrawer(); return; }
    var a = t.closest('a[href^="#/"]');
    if (a && document.body.classList.contains('drawer-open')) closeDrawer();
  }
  function onChange(ev) {
    var el = ev.target && ev.target.closest ? ev.target.closest('[data-change]') : null;
    if (!el) return;
    var fn = A[el.getAttribute('data-change')];
    if (fn) fn(el, ev);
  }
  var inputTimers = {};
  function onInput(ev) {
    var el = ev.target && ev.target.closest ? ev.target.closest('[data-input]') : null;
    if (!el) return;
    var name = el.getAttribute('data-input'), fn = A[name];
    if (!fn) return;
    clearTimeout(inputTimers[name]);
    inputTimers[name] = setTimeout(function () { fn(el, ev); }, 120);
  }
  /** Esc closes the innermost thing: the drawer, then an open KPI chart, then the ad set panel. */
  function onKey(ev) {
    if (ev.key !== 'Escape') return;
    if (document.body.classList.contains('drawer-open')) { closeDrawer(); var b = document.querySelector('.tb-menu'); if (b) b.focus(); return; }
    if (V.trend && V.trend.closeOpen && V.trend.closeOpen()) return;
    if (sheetKey && V.adset && V.adset.close) V.adset.close();
  }
  /** Never show a broken image: swap in the blank tile with the reason. */
  function onImgError(ev) {
    var img = ev.target;
    if (!img || img.tagName !== 'IMG' || !img.hasAttribute('data-fallback')) return;
    var div = document.createElement('div');
    div.className = 'blank';
    div.setAttribute('role', 'img');
    div.setAttribute('aria-label', 'Image file missing');
    var inner = document.createElement('div');
    var b = document.createElement('b'); b.textContent = 'Image file missing';
    var s = document.createElement('span'); s.textContent = img.getAttribute('data-fallback');
    inner.appendChild(b); inner.appendChild(s); div.appendChild(inner);
    if (img.parentNode) img.parentNode.replaceChild(div, img);
  }

  /* =========================================================================================
   * Boot
   * ======================================================================================= */
  app.boot = function () {
    reg = D.indexRegistry(root.GROOV_REGISTRY);
    learn = root.GROOV_LEARNINGS || {};
    app.state = S.load();
    var r = parseHash(location.hash);
    app.state.route = { page: r.page, slug: r.slug, params: r.params };
    applyParams(app.state, r.params);
    UI.initTips();
    document.addEventListener('click', onClick);
    document.addEventListener('change', onChange);
    document.addEventListener('input', onInput);
    document.addEventListener('keydown', onKey);
    document.addEventListener('error', onImgError, true);
    root.addEventListener('hashchange', onHash);
    root.addEventListener('popstate', onHash);
    root.addEventListener('resize', U.debounce(function () {
      if (!app.isMobile()) closeDrawer();
      C.redraw();
    }, 150));
    render();
    loadSampleScript(false).then(function () {
      mode = D.detectMode(root);
      src = D.createSource(mode, root, reg);
      return loadAll(false);
    });
  };

  if (typeof document !== 'undefined' && document.getElementById && document.getElementById('view')) {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', app.boot);
    else app.boot();
  }
})(typeof window !== 'undefined' ? window : this);
