/* GROOV Ads Command Center · util.js
 * ------------------------------------------------------------------------------------------
 * Role: small, DOM-free helpers shared by every other file. Loaded first. Safe to load in a
 * Node `vm` context with a fake `window` (the engine tests do exactly that).
 *
 * Public API (window.GROOV.util):
 *   esc(v)                     HTML-escape any value; null/undefined -> ''. Use for EVERY name.
 *   isNum(v)                   finite number?
 *   ratio(a, b)                a / b, or null when b is 0 / missing ("no denominator", shown as —)
 *   pctChange(cur, prev)       % change, or null when prev is 0 / missing
 *   money(v, {exact, signed})  ฿ with separators: 2 decimals under ฿100, else 0 (exact -> always 2)
 *   int(v), count(v)           integers / counts (count keeps 1 decimal for fractional Google conversions)
 *   pct(v, digits)             v is already in percent units: 1.523 -> "1.52%"
 *   ratioX(v)                  "2.31×"
 *   deltaText(p)               "+12%" / "−8%" / "—" (true minus sign)
 *   compact(v)                 axis ticks: 950, 1.2k, 3.4M
 *   dayNum / isoDay / addDays / diffDays / addMonths / monthStart / monthEnd / quarterStart /
 *   quarterEnd / daysInMonth   ISO-date arithmetic in UTC (dates are Bangkok calendar days)
 *   bangkokToday()             today's date in Asia/Bangkok (window.__GROOV_TODAY__ overrides, for tests)
 *   fmtDate, fmtDay, rangeLabel, monthLabel, weekday
 *   slugify(s)                 URL slug that keeps Thai letters and combining marks
 *   plural(n, one, many), median(list), cmpText(a, b), clamp(v, lo, hi)
 *   csv(rows)                  RFC-4180 CSV with a BOM (Excel + Thai) and formula-injection guard
 *   debounce(fn, ms)
 * Never returns "NaN", "Infinity", "undefined" or "null" from a formatter: missing -> "—".
 */
(function (root) {
  'use strict';
  var G = root.GROOV = root.GROOV || {};
  var U = G.util = {};

  var DASH = '—';
  var MINUS = '−';
  U.DASH = DASH;

  /* ---------- escaping ---------- */
  var ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;', '`': '&#96;' };
  U.esc = function (v) {
    if (v === null || v === undefined) return '';
    return String(v).replace(/[&<>"'`]/g, function (c) { return ESC[c]; });
  };

  /* ---------- null-safe arithmetic ---------- */
  U.isNum = function (v) { return typeof v === 'number' && isFinite(v); };
  U.ratio = function (a, b) {
    return U.isNum(a) && U.isNum(b) && b !== 0 ? a / b : null;
  };
  U.pctChange = function (cur, prev) {
    return U.isNum(cur) && U.isNum(prev) && prev !== 0 ? (cur / prev - 1) * 100 : null;
  };
  U.clamp = function (v, lo, hi) { return Math.min(hi, Math.max(lo, v)); };
  U.sum = function (list, pick) {
    var t = 0;
    for (var i = 0; i < list.length; i++) { var v = pick ? pick(list[i]) : list[i]; if (U.isNum(v)) t += v; }
    return t;
  };

  /* ---------- number formatting ---------- */
  // Intl.NumberFormat is cached per digit count: toLocaleString() builds a new formatter on every
  // call and dominated render time on large tables.
  var NF = {};
  function sep(v, digits) {
    var f = NF[digits];
    if (!f) {
      try { f = NF[digits] = new Intl.NumberFormat('en-US', { minimumFractionDigits: digits, maximumFractionDigits: digits }); }
      catch (e) { return v.toFixed(digits); }
    }
    return f.format(v);
  }
  U.money = function (v, opt) {
    if (!U.isNum(v)) return DASH;
    opt = opt || {};
    var a = Math.abs(v);
    if (a === 0 && !opt.exact) return '฿0';
    var digits = opt.exact ? 2 : (a < 100 ? 2 : 0);
    var body = '฿' + sep(a, digits);
    if (v < 0 && Math.round(a * 100) !== 0) return MINUS + body;
    if (opt.signed && v > 0) return '+' + body;
    return body;
  };
  /** Money for configured values (benchmark bounds, budgets): whole numbers print without ".00". */
  U.moneyRound = function (v) {
    if (!U.isNum(v)) return DASH;
    return Math.abs(v - Math.round(v)) < 1e-9 ? (v < 0 ? MINUS : '') + '฿' + sep(Math.abs(Math.round(v)), 0) : U.money(v);
  };
  U.int = function (v) {
    if (!U.isNum(v)) return DASH;
    var r = Math.round(v);
    return (r < 0 ? MINUS : '') + sep(Math.abs(r), 0);
  };
  /** Counts: integers stay integers; fractional values (Google conversions) keep one decimal. */
  U.count = function (v) {
    if (!U.isNum(v)) return DASH;
    if (Math.abs(v - Math.round(v)) < 1e-9) return U.int(v);
    return (v < 0 ? MINUS : '') + sep(Math.abs(v), 1);
  };
  /** v is already a percentage (1.5 means 1.5%). */
  U.pct = function (v, digits) {
    if (!U.isNum(v)) return DASH;
    var a = Math.abs(v);
    var d = digits !== undefined ? digits : (a < 10 ? 2 : a < 100 ? 1 : 0);
    return (v < 0 && a >= Math.pow(10, -d) / 2 ? MINUS : '') + sep(a, d) + '%';
  };
  U.ratioX = function (v, digits) {
    if (!U.isNum(v)) return DASH;
    return sep(v, digits === undefined ? 2 : digits) + '×';
  };
  /** Signed percentage change. null -> "—". */
  U.deltaText = function (p) {
    if (!U.isNum(p)) return DASH;
    var a = Math.abs(p);
    var d = a > 0 && a < 1 ? 1 : 0;
    var s = sep(a, d);
    if (s === '0' || s === '0.0') return '0%';
    return (p > 0 ? '+' : MINUS) + s + '%';
  };
  U.compact = function (v) {
    if (!U.isNum(v)) return DASH;
    var a = Math.abs(v), s;
    if (a >= 1e6) s = trim(a / 1e6) + 'M';
    else if (a >= 1e3) s = trim(a / 1e3) + 'k';
    else if (a >= 10 || a === 0) s = String(Math.round(a));
    else s = trim(a);
    return (v < 0 ? MINUS : '') + s;
  };
  function trim(x) { return (Math.round(x * 10) / 10).toString(); }

  /* ---------- dates (ISO YYYY-MM-DD, UTC arithmetic on Bangkok calendar days) ---------- */
  var DAY = 86400000;
  var MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  var WD = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  U.MONTHS = MON;
  U.isIso = function (s) { return typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s); };
  U.dayNum = function (iso) {
    var y = +iso.slice(0, 4), m = +iso.slice(5, 7), d = +iso.slice(8, 10);
    return Math.round(Date.UTC(y, m - 1, d) / DAY);
  };
  U.isoDay = function (n) { return new Date(n * DAY).toISOString().slice(0, 10); };
  U.addDays = function (iso, n) { return U.isoDay(U.dayNum(iso) + n); };
  /** Days from a to b (b − a). */
  U.diffDays = function (a, b) { return U.dayNum(b) - U.dayNum(a); };
  U.daysInMonthOf = function (y, m) { return new Date(Date.UTC(y, m, 0)).getUTCDate(); }; // m is 1-based
  U.daysInMonth = function (iso) { return U.daysInMonthOf(+iso.slice(0, 4), +iso.slice(5, 7)); };
  U.monthStart = function (iso) { return iso.slice(0, 8) + '01'; };
  U.monthEnd = function (iso) { return iso.slice(0, 8) + String(U.daysInMonth(iso)).padStart(2, '0'); };
  /** Shift by whole months, clamping the day to the target month's length (31 Mar − 1 month = 28 Feb). */
  U.addMonths = function (iso, n) {
    var y = +iso.slice(0, 4), m = +iso.slice(5, 7) - 1 + n, d = +iso.slice(8, 10);
    y += Math.floor(m / 12); m = ((m % 12) + 12) % 12;
    var dim = U.daysInMonthOf(y, m + 1);
    return y + '-' + String(m + 1).padStart(2, '0') + '-' + String(Math.min(d, dim)).padStart(2, '0');
  };
  U.quarterStart = function (iso) {
    var m = +iso.slice(5, 7), qm = Math.floor((m - 1) / 3) * 3 + 1;
    return iso.slice(0, 5) + String(qm).padStart(2, '0') + '-01';
  };
  U.quarterEnd = function (iso) { return U.addDays(U.addMonths(U.quarterStart(iso), 3), -1); };
  U.minIso = function (a, b) { return !a ? b : !b ? a : (a < b ? a : b); };
  U.maxIso = function (a, b) { return !a ? b : !b ? a : (a > b ? a : b); };
  U.dateRange = function (a, b) {
    var out = [], n0 = U.dayNum(a), n1 = U.dayNum(b);
    for (var n = n0; n <= n1; n++) out.push(U.isoDay(n));
    return out;
  };
  U.bangkokToday = function () {
    if (root.__GROOV_TODAY__ && U.isIso(root.__GROOV_TODAY__)) return root.__GROOV_TODAY__;
    try {
      return new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Bangkok', year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date());
    } catch (e) {
      return new Date(Date.now() + 7 * 3600000).toISOString().slice(0, 10);
    }
  };
  U.fmtDate = function (iso) {
    if (!U.isIso(iso)) return DASH;
    return +iso.slice(8, 10) + ' ' + MON[+iso.slice(5, 7) - 1] + ' ' + iso.slice(0, 4);
  };
  U.fmtDay = function (iso) {
    if (!U.isIso(iso)) return DASH;
    return +iso.slice(8, 10) + ' ' + MON[+iso.slice(5, 7) - 1];
  };
  U.weekday = function (iso) { return U.isIso(iso) ? WD[new Date(U.dayNum(iso) * DAY).getUTCDay()] : ''; };
  /** "14–20 Sep 2026", "28 Aug–3 Sep 2026", "28 Dec 2025–3 Jan 2026". */
  U.rangeLabel = function (a, b, withYear) {
    if (!U.isIso(a) || !U.isIso(b)) return DASH;
    withYear = withYear !== false;
    var ya = a.slice(0, 4), yb = b.slice(0, 4), ma = +a.slice(5, 7), mb = +b.slice(5, 7), da = +a.slice(8, 10), db = +b.slice(8, 10);
    var yr = withYear ? ' ' + yb : '';
    if (a === b) return da + ' ' + MON[mb - 1] + yr;
    if (ya === yb && ma === mb) return da + '–' + db + ' ' + MON[mb - 1] + yr;
    if (ya === yb) return da + ' ' + MON[ma - 1] + '–' + db + ' ' + MON[mb - 1] + yr;
    return da + ' ' + MON[ma - 1] + ' ' + ya + '–' + db + ' ' + MON[mb - 1] + ' ' + yb;
  };
  U.monthLabel = function (ym) {
    if (typeof ym !== 'string' || !/^\d{4}-\d{2}$/.test(ym)) return DASH;
    return MON[+ym.slice(5, 7) - 1] + ' ' + ym.slice(0, 4);
  };

  /* ---------- strings ---------- */
  /** Slug for hash routes. Keeps Thai letters AND combining marks (vowel signs / tone marks are \p{M}). */
  U.slugify = function (s) {
    var t = String(s === null || s === undefined ? '' : s).normalize('NFKC').toLowerCase()
      .replace(/&/g, ' and ').replace(/['’`]/g, '');
    try {
      t = t.replace(/[^\p{L}\p{M}\p{N}]+/gu, '-');
    } catch (e) { // very old engines without Unicode property escapes
      t = t.replace(/[\s!-,./:-@[-^{-~]+/g, '-');
    }
    t = t.replace(/^-+|-+$/g, '');
    return t || 'client';
  };
  U.plural = function (n, one, many) { return n === 1 ? one : (many || one + 's'); };
  var collator = (typeof Intl !== 'undefined' && Intl.Collator) ? new Intl.Collator('en', { sensitivity: 'base', numeric: true }) : null;
  U.cmpText = function (a, b) {
    a = a === null || a === undefined ? '' : String(a); b = b === null || b === undefined ? '' : String(b);
    return collator ? collator.compare(a, b) : (a < b ? -1 : a > b ? 1 : 0);
  };
  U.median = function (list) {
    var v = list.filter(U.isNum).slice().sort(function (a, b) { return a - b; });
    if (!v.length) return null;
    var h = v.length >> 1;
    return v.length % 2 ? v[h] : (v[h - 1] + v[h]) / 2;
  };
  U.uniq = function (list) {
    var seen = Object.create(null), out = [];
    for (var i = 0; i < list.length; i++) { var k = list[i]; if (!seen[k]) { seen[k] = 1; out.push(k); } }
    return out;
  };
  U.eqi = function (a, b) { return String(a || '').toLowerCase() === String(b || '').toLowerCase(); };
  /** Only http(s) links from data are ever rendered as hrefs (never javascript:, data:, …). */
  U.safeUrl = function (u) {
    var s = String(u === null || u === undefined ? '' : u).trim();
    return /^https?:\/\//i.test(s) ? s : null;
  };

  /* ---------- CSV ---------- */
  /** rows: array of arrays. Numbers are written raw (rounded to 4 dp), text is quoted when needed. */
  U.csv = function (rows) {
    return '﻿' + rows.map(function (r) {
      return r.map(function (c) {
        if (c === null || c === undefined) return '';
        if (typeof c === 'number') return U.isNum(c) ? String(Math.round(c * 10000) / 10000) : '';
        var s = String(c);
        if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; // keep spreadsheet apps from running text as a formula
        return /[",\n\r]/.test(s) || /^\s|\s$/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
      }).join(',');
    }).join('\r\n') + '\r\n';
  };

  /* ---------- misc ---------- */
  U.debounce = function (fn, ms) {
    var t = null;
    return function () {
      var args = arguments, self = this;
      if (t) clearTimeout(t);
      t = setTimeout(function () { t = null; fn.apply(self, args); }, ms);
    };
  };
  /** Short stable hash (FNV-1a) for memo keys. */
  U.hash = function (s) {
    var h = 0x811c9dc5;
    s = String(s);
    for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193); }
    return (h >>> 0).toString(36);
  };
})(typeof window !== 'undefined' ? window : this);
