/* GROOV Ads Command Center · model.js
 * ------------------------------------------------------------------------------------------
 * Role: the "view model". Turns (dataset + registry + learnings + sidebar state) into one
 * memoized snapshot that every view reads. Pure (no DOM), so the Node tests run it directly.
 *
 * Public API (window.GROOV.model):
 *   normFilters(f)              sanitised filter object (sidebar §3.5)
 *   snapshot(ctx)               ctx = { ds, meta, reg, learn, state } -> Snapshot (memoized by state key)
 *   rowFilter(F)                predicate for the row filters (Decisions, Active only, Min spend).
 *                               Row filters hide rows but NEVER change totals (SPEC §3.5).
 *   rowFiltersActive(F)
 *   clientDetail(snap, ctx, slug, platform)   everything the client view needs (campaign tree, groups…)
 *   monthlyFor(monthly, slug, opts)           monthly history rows + quarter totals for one client
 *   parity(snap)                account-level decisions over ALL delivering campaigns (Hermes check)
 *   actionBuckets(snap, state)  split action items into open / reviewed / snoozed (per browser)
 *   KPI, kpiValue, trendData, trendValues, trendSplit, trendDir   KPI trend lines (SPEC §4.7): series
 *                               from summed numerators / denominators per bucket, memoized per state
 *   bdBlock, bdSentence, whereResults, resultShare, bdReach   where results happen (SPEC §4.8)
 *
 * Snapshot (all money in THB, all aggregates are plain metric objects, see data.js):
 *   P (periods), rules, F (filters), A/B (current / comparison aggregates; B null without baseline)
 *   camps[] CampRow (present in either period; .inScope), campByIdx[], adsets[], ads[]
 *   clients[] ClientRow (in scope, present), clientBySlug, accounts[] (in scope)
 *   totals {cur, cmp}, byPlatform, byVertical, daily {...}
 *   checks [{check, hits[], unsupported[]}], delivery[], actions[] (ranked), counts (clients by decision)
 *   portfolio Map(vertical|type|platform -> {median, n, values})
 * Definitions follow SPEC §5/§5b; honesty rules (never sum result types, n beside ratios) are enforced
 * here by grouping results by engine.resultType().
 */
(function (root) {
  'use strict';
  var G = root.GROOV = root.GROOV || {};
  var U = G.util, D = G.data, E = G.engine;
  var M = G.model = {};

  var SHORTS = ['Immediate', 'Watch', 'Scale', 'Hold'];
  var LONG = { Immediate: 'Immediate Action', Watch: 'Watch Out', Scale: 'Ready to Scale', Hold: 'No Touching' };
  M.SHORT_TO_LONG = LONG;

  M.normFilters = function (f) {
    f = f || {};
    var arr = function (v, allowed) {
      var a = Array.isArray(v) ? v.map(String) : [];
      return allowed ? a.filter(function (x) { return allowed.indexOf(x) >= 0; }) : a;
    };
    var min = +f.minSpend;
    return {
      platforms: arr(f.platforms, D.PLATFORMS), verticals: arr(f.verticals), objectives: arr(f.objectives, E.OBJECTIVES),
      decisions: arr(f.decisions, SHORTS), owners: arr(f.owners), activeOnly: !!f.activeOnly,
      minSpend: U.isNum(min) && min > 0 ? min : 0, starredOnly: !!f.starredOnly
    };
  };
  M.rowFiltersActive = function (F) { return !!(F.decisions.length || F.activeOnly || F.minSpend > 0); };
  M.scopeFiltersActive = function (F) {
    return !!(F.platforms.length || F.verticals.length || F.objectives.length || F.owners.length || F.starredOnly);
  };
  /** Row filter: decision short names, ACTIVE status, current spend ≥ min. */
  M.rowFilter = function (F) {
    return function (row) {
      if (F.decisions.length) {
        var d = row.decision && typeof row.decision === 'object' ? row.decision.label : row.decision;
        if (!d || F.decisions.indexOf(E.SHORT[d]) < 0) return false;
      }
      if (F.activeOnly && row.status !== 'ACTIVE') return false;
      if (F.minSpend > 0 && !((row.cur ? row.cur.spend : row.spend) >= F.minSpend)) return false;
      return true;
    };
  };

  function delivered(o) { return o.spend > 0 || o.impressions > 0; }

  /* ---------- formatting helpers for evidence (kept here so views and CSV agree) ---------- */
  function fmtHermes(kind, label, v, isCost, lower) {
    if (kind === 'ratio') return U.isNum(v) && v > 0 ? U.ratioX(v) : 'Not tracked';
    if (isCost) return v ? U.money(v) : U.DASH;
    if (label === 'Impressions per ฿') return U.isNum(v) ? U.count(Math.round(v * 10) / 10) : U.DASH;
    return U.count(v);
  }
  function fmtRate(label, v) {
    if (label === 'Impressions per ฿') return v ? U.count(Math.round(v * 10) / 10) : U.DASH;
    return v ? U.pct(v * 100) : U.isNum(v) ? '0%' : U.DASH;
  }
  /** Evidence rows for a campaign decision, built from the exact numbers the decision used. */
  M.evidence = function (hm, hp) {
    if (hm.metaConv) {
      return [
        { label: 'Spend', cur: U.money(hm.spend), prev: U.money(hp.spend), delta: E.change(hm.spend, hp.spend), up: 'neutral' },
        { label: 'Purchase value (Meta)', cur: U.money(hm.value), prev: U.money(hp.value), delta: E.change(hm.value, hp.value), up: 'good' },
        { label: 'ROAS', cur: hm.roas > 0 ? U.ratioX(hm.roas) : 'Not tracked', prev: hp.roas > 0 ? U.ratioX(hp.roas) : 'Not tracked', delta: E.change(hm.roas, hp.roas), up: 'good' },
        { label: 'CTR', cur: U.pct(hm.ctr * 100), prev: U.pct(hp.ctr * 100), delta: E.change(hm.ctr, hp.ctr), up: 'good' }
      ];
    }
    var cnt = hm.resultKind === 'count';
    var low = cnt && hm.result_label !== 'Impressions' ? E.lowN(hm.results, hp.results) : false;
    return [
      { label: 'Spend', cur: U.money(hm.spend), prev: U.money(hp.spend), delta: E.change(hm.spend, hp.spend), up: 'neutral' },
      { label: hm.result_label, cur: fmtHermes(hm.resultKind, hm.result_label, hm.results), prev: fmtHermes(hm.resultKind, hm.result_label, hp.results),
        delta: E.change(hm.results, hp.results), up: 'good', lowN: low, n: cnt && hm.result_label !== 'Impressions' ? hm.results : null },
      { label: hm.cost_label, cur: hm.results ? fmtHermes(hm.resultKind, hm.cost_label, hm.cost_per_result, hm.resultKind !== 'ratio') : U.DASH,
        prev: hp.results ? fmtHermes(hm.resultKind, hm.cost_label, hp.cost_per_result, hm.resultKind !== 'ratio') : U.DASH,
        delta: hm.results && hp.results ? E.change(hm.cost_per_result, hp.cost_per_result) : null, up: hm.lowerBetter ? 'bad' : 'good', lowN: low },
      { label: hm.response_label, cur: fmtRate(hm.response_label, hm.response_rate), prev: fmtRate(hm.response_label, hp.response_rate),
        delta: E.change(hm.response_rate, hp.response_rate), up: 'good', lowN: low }
    ];
  };
  /** Evidence for an ad set / ad / entity-variant campaign, from display KPIs. */
  M.entityEvidence = function (objective, platform, k, kp) {
    var pc = E.primary(objective, platform, k), pp = E.primary(objective, platform, kp);
    var low = pc.n !== null ? E.lowN(pc.n, pp.n) : false;
    var fr = function (p, v) { return p.type === 'Conversions·value' ? U.money(v) : U.count(v); };
    var fc = function (p, v) { return p.costFmt === 'ratio' ? (U.isNum(v) ? U.ratioX(v) : 'Not tracked') : U.money(v); };
    return [
      { label: 'Spend', cur: U.money(k.spend), prev: U.money(kp.spend), delta: U.pctChange(k.spend, kp.spend), up: 'neutral' },
      { label: pc.resultLabel, cur: fr(pc, pc.result), prev: fr(pp, pp.result), delta: U.pctChange(pc.result, pp.result), up: 'good', lowN: low, n: pc.n },
      { label: pc.costLabel, cur: fc(pc, pc.cost), prev: fc(pp, pp.cost), delta: U.pctChange(pc.cost, pp.cost), up: pc.lowerBetter ? 'bad' : 'good', lowN: low },
      // the rate decideEntity judges: link CTR for Traffic, view rate for Engagement, all-click CTR otherwise
      objective === 'Traffic' ? { label: platform === 'meta' ? 'Link CTR' : 'CTR', cur: U.pct(k.link_ctr), prev: U.pct(kp.link_ctr), delta: U.pctChange(k.link_ctr, kp.link_ctr), up: 'good' } :
        objective === 'Engagement' ? { label: 'View rate', cur: U.pct(k.view_rate), prev: U.pct(kp.view_rate), delta: U.pctChange(k.view_rate, kp.view_rate), up: 'good' } :
          { label: 'CTR', cur: U.pct(k.ctr), prev: U.pct(kp.ctr), delta: U.pctChange(k.ctr, kp.ctr), up: 'good' }
    ];
  };

  /** Short headline for an action item built from a campaign decision. */
  function decisionTitle(r) {
    var d = r.decision, hm = r.hm;
    if (d.variant === 'entity') return d.why.split('. ')[0].replace(/\.$/, '');
    if (d.label === 'Immediate Action') {
      return hm.metaConv ? 'No tracked purchase value after ' + U.money(hm.spend) + ' spend' : U.money(hm.spend) + ' spent with zero ' + hm.result_label.toLowerCase();
    }
    if (d.label === 'Ready to Scale') {
      if (hm.metaConv) return 'Purchase ROAS up ' + U.deltaText(d.deltas.results).replace('+', '') + ' (Meta-reported)';
      return hm.cost_label + ' improved ' + U.deltaText(d.deltas.cost).replace('−', '') + ' with ' + hm.result_label.toLowerCase() + ' holding';
    }
    if (d.label === 'Watch Out') return d.why.split('; ')[0].replace(/\s*\(threshold [^)]*\)/, '').replace(/\.$/, '');
    return d.why;
  }

  /* =========================================================================================
   * Snapshot
   * ======================================================================================= */
  var memo = { key: null, val: null };
  M.clearMemo = function () { memo.key = null; memo.val = null; };

  M.snapshot = function (ctx) {
    var ds = ctx.ds, meta = ctx.meta || {}, st = ctx.state || {}, learn = ctx.learn || {};
    var rules = E.rulesFrom(st.rules);
    var P = D.periods(meta, st.period, st.compare);
    var F = M.normFilters(st.filters);
    var pinned = Array.isArray(st.pinned) ? st.pinned.slice().sort() : [];
    var key = [ds.version, P.key, P.preset, JSON.stringify(F), JSON.stringify(rules), F.starredOnly ? pinned.join(',') : ''].join('#');
    if (memo.key === key) return memo.val;
    var snap = build(ds, meta, P, F, rules, pinned, learn);
    snap.key = key;
    memo.key = key; memo.val = snap;
    return snap;
  };

  function build(ds, meta, P, F, rules, pinned, learn) {
    var pinSet = new Set(pinned);
    var A = P.cur ? D.agg(ds, P.cur.from, P.cur.to) : null;
    var B = P.cmp && !P.noBaseline ? D.agg(ds, P.cmp.from, P.cmp.to) : null;
    var periodEnd = P.cur ? P.cur.to : P.T;

    function scopeOK(platform, vertical, objective, client) {
      if (F.platforms.length && F.platforms.indexOf(platform) < 0) return false;
      if (F.verticals.length && F.verticals.indexOf(vertical) < 0) return false;
      if (F.objectives.length && F.objectives.indexOf(objective) < 0) return false;
      if (F.owners.length && F.owners.indexOf(client.owner || '') < 0) return false;
      if (F.starredOnly && !pinSet.has(client.slug)) return false;
      return true;
    }

    /* ---- campaigns ---- */
    var camps = [], campByIdx = new Array(ds.campaigns.length);
    ds.campaigns.forEach(function (c) {
      var cur = A ? D.obj(A.camp, c.i) : D.zero();
      var cmp = B ? D.obj(B.camp, c.i) : D.zero();
      var dCur = delivered(cur), dPrev = delivered(cmp);
      if (!dCur && !dPrev) { campByIdx[c.i] = null; return; }
      var client = ds.clients[c.client] || { name: 'Unknown', slug: 'unknown', vertical: 'Unmapped' };
      var account = ds.accounts[c.account] || null;
      // Classification uses the window being judged: the current period, or the comparison when the
      // campaign only delivered there (Hermes classified on the current-period aggregate).
      var objective = E.classify(c.platform, c.rawObjective, c.name, dCur ? cur : cmp);
      var k = E.kpis(cur), kp = E.kpis(cmp);
      var hm = E.decisionMetrics(c.platform, cur, objective), hp = E.decisionMetrics(c.platform, cmp, objective);
      var decision;
      if (dCur) { decision = E.decideCampaign(hm, hp, rules); decision.variant = 'campaign'; }
      else { decision = E.decideEntity(objective, c.platform, cur, cmp, c.status, rules, null); decision.variant = 'entity'; }
      var row = {
        level: 'campaign', i: c.i, key: c.key, id: c.id, name: c.name, platform: c.platform, account: account,
        client: client, clientSlug: client.slug, vertical: client.vertical, rawObjective: c.rawObjective, channel: c.channel,
        objective: objective, status: c.status, cur: cur, cmp: cmp, k: k, kp: kp, hm: hm, hmp: hp,
        prim: E.primary(objective, c.platform, k), primPrev: E.primary(objective, c.platform, kp),
        delivering: dCur, prevDelivering: dPrev, decision: decision,
        first_date: c.first_date, last_date: c.last_date, isNew: E.isNew(c.first_date, periodEnd, P.H),
        inScope: scopeOK(c.platform, client.vertical, objective, client), flags: [], adsetRows: [], adRows: []
      };
      row.evidence = dCur ? M.evidence(hm, hp) : M.entityEvidence(objective, c.platform, k, kp);
      camps.push(row);
      campByIdx[c.i] = row;
    });

    /* ---- ad sets / ad groups and ads (status-aware entity variant) ---- */
    var adsets = [], ads = [];
    ds.adsets.forEach(function (s) {
      var cr = campByIdx[s.campaign];
      if (!cr) return;
      var cur = A ? D.obj(A.adset, s.i) : D.zero(), cmp = B ? D.obj(B.adset, s.i) : D.zero();
      if (!delivered(cur) && !delivered(cmp)) return;
      var k = E.kpis(cur), kp = E.kpis(cmp);
      var row = {
        level: 'adset', i: s.i, key: s.key, id: s.id, name: s.name, platform: cr.platform, campaign: cr, client: cr.client,
        clientSlug: cr.clientSlug, objective: cr.objective, status: s.status, cur: cur, cmp: cmp, k: k, kp: kp,
        prim: E.primary(cr.objective, cr.platform, k), primPrev: E.primary(cr.objective, cr.platform, kp),
        delivering: delivered(cur), decision: E.decideEntity(cr.objective, cr.platform, cur, cmp, s.status, rules, null),
        first_date: s.first_date, last_date: s.last_date, isNew: E.isNew(s.first_date, periodEnd, P.H), inScope: cr.inScope, flags: [], adRows: []
      };
      row.decision.variant = 'entity';
      row.evidence = M.entityEvidence(cr.objective, cr.platform, k, kp);
      adsets.push(row);
      cr.adsetRows.push(row);
    });
    var adsetByIdx = new Map();
    adsets.forEach(function (r) { adsetByIdx.set(r.i, r); });
    ds.ads.forEach(function (a) {
      var cr = campByIdx[a.campaign];
      if (!cr) return;
      var cur = A ? D.obj(A.ad, a.i) : D.zero(), cmp = B ? D.obj(B.ad, a.i) : D.zero();
      if (!delivered(cur) && !delivered(cmp)) return;
      var k = E.kpis(cur), kp = E.kpis(cmp);
      var adset = adsetByIdx.get(a.adset) || null;
      var isNew = E.isNew(a.first_date, periodEnd, P.H);
      var row = {
        level: 'ad', i: a.i, key: a.key, id: a.id, name: a.name, platform: cr.platform, campaign: cr, adset: adset,
        adsetName: a.adset >= 0 && ds.adsets[a.adset] ? ds.adsets[a.adset].name : null,
        client: cr.client, clientSlug: cr.clientSlug, objective: cr.objective, status: a.status, rawStatus: a.raw_status,
        cur: cur, cmp: cmp, k: k, kp: kp, prim: E.primary(cr.objective, cr.platform, k), primPrev: E.primary(cr.objective, cr.platform, kp),
        delivering: delivered(cur), decision: E.decideEntity(cr.objective, cr.platform, cur, cmp, a.status, rules, a.raw_status),
        first_date: a.first_date, last_date: a.last_date, isNew: isNew, live: E.liveDays(a.first_date, periodEnd, P.H),
        image: a.image, image_reason: a.image_reason, preview: a.preview, inScope: cr.inScope, flags: []
      };
      row.decision.variant = 'entity';
      row.evidence = M.entityEvidence(cr.objective, cr.platform, k, kp);
      // Fatigue and loser flags are suppressed while an ad is new (learning).
      row.fatigue = isNew ? null : E.fatigue(k, kp, cr.objective, cr.platform);
      ads.push(row);
      cr.adRows.push(row);
      if (adset) adset.adRows.push(row);
    });

    /* ---- clients, accounts (in scope) ---- */
    var scoped = camps.filter(function (r) { return r.inScope; });
    var clientMap = new Map(), accountMap = new Map();
    scoped.forEach(function (r) {
      var cr = clientMap.get(r.clientSlug);
      if (!cr) {
        cr = { client: r.client, slug: r.clientSlug, name: r.client.name, vertical: r.vertical, unmapped: !!r.client.unmapped,
          owner: r.client.owner || null, camps: [], accounts: [] };
        clientMap.set(r.clientSlug, cr);
      }
      cr.camps.push(r);
      var akey = r.platform + '::' + (r.account ? r.account.id : '?');
      var ar = accountMap.get(akey);
      if (!ar) {
        ar = { key: akey, platform: r.platform, id: r.account ? r.account.id : '', name: r.account ? r.account.name : 'Unknown account',
          clientSlug: r.clientSlug, client: r.client, camps: [] };
        accountMap.set(akey, ar);
        cr.accounts.push(ar);
      }
      ar.camps.push(r);
    });
    var clients = [], accounts = [];
    clientMap.forEach(function (cr) { finishGroup(cr, A, B); clients.push(cr); });
    accountMap.forEach(function (ar) { finishGroup(ar, A, B); accounts.push(ar); });

    /* ---- totals, mix, daily ---- */
    var totals = { cur: D.sumObjs(clients.map(function (c) { return c.cur; })), cmp: D.sumObjs(clients.map(function (c) { return c.cmp; })) };
    totals.k = E.kpis(totals.cur); totals.kp = E.kpis(totals.cmp);
    var byPlatform = {}, byVertical = {};
    scoped.forEach(function (r) {
      var p = byPlatform[r.platform] || (byPlatform[r.platform] = { cur: D.zero(), cmp: D.zero() });
      D.addInto(p.cur, r.cur); D.addInto(p.cmp, r.cmp);
      var v = byVertical[r.vertical] || (byVertical[r.vertical] = { cur: D.zero(), cmp: D.zero() });
      D.addInto(v.cur, r.cur); D.addInto(v.cmp, r.cmp);
    });
    var scopedIdx = scoped.map(function (r) { return r.i; });
    var daily = { days: A ? A.days : [], byPlatform: {}, total: [], cmpDays: B ? B.days : [], cmpTotal: null, kpi: {} };
    if (A) {
      D.PLATFORMS.forEach(function (p) {
        daily.byPlatform[p] = D.series(A, scoped.filter(function (r) { return r.platform === p; }).map(function (r) { return r.i; }), 'spend');
      });
      daily.total = D.series(A, scopedIdx, 'spend');
      ['spend', 'impressions', 'link_clicks', 'messages', 'leads', 'conversions'].forEach(function (m) { daily.kpi[m] = D.series(A, scopedIdx, m); });
    }
    if (B) daily.cmpTotal = D.series(B, scopedIdx, 'spend');

    /* ---- playbook checks ---- */
    var checks = evaluateChecks(learn, clients, scoped, ads);
    checks.forEach(function (cr) {
      cr.hits.forEach(function (h) {
        h.clientRow.flags.push(h);
        if (h.campaignRow) h.campaignRow.flags.push(h);
        if (h.adRow) h.adRow.flags.push(h);
      });
    });

    /* ---- delivery integrity ---- */
    var delivery = deliveryItems(ds, P, A, scoped, campByIdx);

    /* ---- pacing ---- */
    clients.forEach(function (cr) { cr.pacing = pacingFor(ds, P, F, cr); });

    /* ---- action items ---- */
    var actions = buildActions(scoped, checks, delivery);

    /* ---- decision counts (clients by worst decision) ---- */
    var counts = {};
    E.DECISIONS.forEach(function (d) { counts[d] = 0; });
    clients.forEach(function (c) { if (c.decision) counts[c.decision]++; });

    var snap = {
      P: P, F: F, rules: rules, A: A, B: B, periodEnd: periodEnd,
      camps: camps, campByIdx: campByIdx, scoped: scoped, adsets: adsets, ads: ads,
      clients: clients, clientBySlug: clientMap, accounts: accounts,
      totals: totals, byPlatform: byPlatform, byVertical: byVertical, daily: daily,
      checks: checks, delivery: delivery, actions: actions, counts: counts,
      rowFiltersActive: M.rowFiltersActive(F), scopeFiltersActive: M.scopeFiltersActive(F)
    };
    snap.portfolio = portfolioMedians(camps);
    return snap;
  }

  /** Fill totals, KPIs, decision, primary result and spend sparkline for a client or account group. */
  function finishGroup(g, A, B) {
    g.cur = D.sumObjs(g.camps.map(function (r) { return r.cur; }));
    g.cmp = D.sumObjs(g.camps.map(function (r) { return r.cmp; }));
    g.k = E.kpis(g.cur); g.kp = E.kpis(g.cmp);
    g.decision = E.mostSevere(g.camps.filter(function (r) { return r.delivering; }).map(function (r) { return r.decision.label; }));
    g.platforms = U.uniq(g.camps.map(function (r) { return r.platform; }));
    g.platforms.sort(function (a, b) { return D.PLATFORMS.indexOf(a) - D.PLATFORMS.indexOf(b); });
    g.status = g.camps.some(function (r) { return r.status === 'ACTIVE'; }) ? 'ACTIVE' : 'PAUSED';
    g.primary = M.primaryOf(g.camps);
    g.spark = A ? D.series(A, g.camps.map(function (r) { return r.i; }), 'spend') : [];
    g.flags = [];
  }

  /**
   * Primary result of a group of campaigns: the result TYPE with the most spend in the current period
   * (comparison spend breaks ties / covers groups that only delivered before). Only that type's
   * campaigns are summed, so different result types are never added together.
   */
  M.primaryOf = function (rows) {
    var by = new Map();
    rows.forEach(function (r) {
      var t = r.prim.type;
      var g = by.get(t);
      if (!g) { g = { type: t, objective: r.objective, rows: [], spend: 0, prevSpend: 0, platforms: [] }; by.set(t, g); }
      g.rows.push(r); g.spend += r.cur.spend; g.prevSpend += r.cmp.spend;
      if (g.platforms.indexOf(r.platform) < 0) g.platforms.push(r.platform);
    });
    var best = null;
    by.forEach(function (g) {
      if (!best || g.spend > best.spend || (g.spend === best.spend && g.prevSpend > best.prevSpend)) best = g;
    });
    if (!best) return null;
    var cur = D.sumObjs(best.rows.map(function (r) { return r.cur; })), cmp = D.sumObjs(best.rows.map(function (r) { return r.cmp; }));
    var plat = best.type === 'Conversions·value' ? 'meta' : (best.platforms.indexOf('meta') >= 0 ? 'meta' : best.platforms[0]);
    var k = E.kpis(cur), kp = E.kpis(cmp);
    var pc = E.primary(best.objective, plat, k), pp = E.primary(best.objective, plat, kp);
    return {
      type: best.type, objective: best.objective, platforms: best.platforms, rows: best.rows, cur: cur, cmp: cmp, k: k, kp: kp,
      resultLabel: pc.resultLabel, costLabel: pc.costLabel, costFmt: pc.costFmt, lowerBetter: pc.lowerBetter,
      result: pc.result, resultPrev: pp.result, cost: pc.cost, costPrev: pp.cost, n: pc.n, nPrev: pp.n,
      dResult: U.pctChange(pc.result, pp.result), dCost: U.pctChange(pc.cost, pp.cost),
      lowN: pc.n !== null && pc.n !== undefined ? E.lowN(pc.n, pp.n) : false,
      share: best.spend
    };
  };

  /* ---------- playbook checks ---------- */
  function evaluateChecks(learn, clients, scoped, ads) {
    var list = learn && learn.rules && Array.isArray(learn.rules.checks) ? learn.rules.checks : [];
    return list.map(function (chk) {
      var scope = chk.scope || {}, when = chk.when || {};
      var out = { check: chk, hits: [], unsupported: [], legacy: [] };
      var vOK = function (v) { return !scope.verticals || !scope.verticals.length || scope.verticals.some(function (x) { return U.eqi(x, v); }); };
      var pOK = function (p) { return !scope.platforms || !scope.platforms.length || scope.platforms.some(function (x) { return U.eqi(x, p); }); };
      var oOK = function (o) { return !scope.objectives || !scope.objectives.length || scope.objectives.indexOf(o) >= 0; };
      var clientRowOf = new Map();
      clients.forEach(function (c) { clientRowOf.set(c.slug, c); });
      function ctxOf(agg, names, objective, platform) {
        var k = E.kpis(agg), p = E.primary(objective, platform, k);
        return { k: k, prim: p, spend: agg.spend, scopeSpend: agg.spend, ctrAll: k.ctr, linkCtr: k.link_ctr,
          cpr: p.lowerBetter ? p.cost : null, freq: k.freq, names: names };
      }
      function test(ctx) {
        var r = E.checkPredicates(when, ctx);
        if (r.unsupported.length) out.unsupported = r.unsupported;
        if (r.legacy.length) out.legacy = r.legacy;
        return r.ok;
      }
      var level = chk.level || 'campaign';
      if (level === 'client') {
        clients.forEach(function (cr) {
          if (!vOK(cr.vertical)) return;
          var sc = cr.camps.filter(function (r) { return r.delivering && pOK(r.platform) && oOK(r.objective); });
          if (!sc.length) return;
          var agg = D.sumObjs(sc.map(function (r) { return r.cur; }));
          var c = ctxOf(agg, sc.map(function (r) { return r.name; }), sc[0].objective, sc[0].platform);
          if (test(c)) out.hits.push({ check: chk, level: level, key: 'client:' + cr.slug, clientRow: cr, campaignRow: null, adRow: null,
            name: cr.name, spend: agg.spend, k: c.k, prim: c.prim, camps: sc });
        });
      } else if (level === 'ad') {
        ads.forEach(function (a) {
          if (!a.inScope || !a.delivering) return;
          var cr = clientRowOf.get(a.clientSlug);
          if (!cr || !vOK(cr.vertical) || !pOK(a.platform) || !oOK(a.objective)) return;
          var c = ctxOf(a.cur, [a.campaign.name], a.objective, a.platform);
          if (test(c)) out.hits.push({ check: chk, level: level, key: a.key, clientRow: cr, campaignRow: a.campaign, adRow: a,
            name: a.name, spend: a.cur.spend, k: c.k, prim: c.prim, camps: [a.campaign] });
        });
      } else { // campaign
        scoped.forEach(function (r) {
          if (!r.delivering) return;
          var cr = clientRowOf.get(r.clientSlug);
          if (!cr || !vOK(cr.vertical) || !pOK(r.platform) || !oOK(r.objective)) return;
          var c = ctxOf(r.cur, [r.name], r.objective, r.platform);
          if (test(c)) out.hits.push({ check: chk, level: 'campaign', key: r.key, clientRow: cr, campaignRow: r, adRow: null,
            name: r.name, spend: r.cur.spend, k: c.k, prim: c.prim, camps: [r] });
        });
      }
      out.hits.sort(function (a, b) { return b.spend - a.spend; });
      return out;
    });
  }

  /* ---------- delivery integrity ---------- */
  function deliveryItems(ds, P, A, scoped, campByIdx) {
    var out = [];
    if (!P.cur) return out;
    var end = P.cur.to;
    var wFrom = U.addDays(end, -9);
    var from = wFrom < P.H ? P.H : wFrom;
    if (ds.minDate && from < ds.minDate) from = ds.minDate;
    var W = D.agg(ds, from, end);
    var last3From = U.addDays(end, -2), priorTo = U.addDays(end, -3);
    var priorDays = Math.max(0, Math.min(7, U.diffDays(from > wFrom ? from : wFrom, priorTo) + 1));
    scoped.forEach(function (r) {
      var last3 = 0, prior7 = 0;
      for (var d = 0; d < W.nDays; d++) {
        var iso = W.days[d], v = W.campDay[(r.i * W.nDays + d) * D.NM + D.MI.spend];
        if (iso >= last3From) last3 += v; else if (iso <= priorTo) prior7 += v;
      }
      var spentBefore = prior7 > 0 || (r.cur.spend - last3) > 0.005;
      E.deliverySignals({ status: r.status, last3: last3, prior7: prior7, priorDays: priorDays, lastDate: r.last_date,
        periodEnd: end, spentBefore: spentBefore }).forEach(function (s) {
        out.push({ type: s.type, title: s.title, why: s.why, action: s.action, row: r, level: 'campaign', key: s.type + ':' + r.key,
          spend: r.cur.spend, avg3: s.avg3, avg7: s.avg7 });
      });
    });
    // Disapproved ads (status from the latest exported row) under campaigns in scope.
    ds.ads.forEach(function (a) {
      if (a.status !== 'DISAPPROVED') return;
      var cr = campByIdx[a.campaign];
      if (!cr || !cr.inScope) return;
      var spend = A ? A.ad[a.i * D.NM + D.MI.spend] : 0;
      out.push({ type: 'disapproved', title: 'Disapproved ad', row: cr, level: 'ad', ad: a, key: 'disapproved:' + a.key, spend: spend,
        why: 'Ad "' + a.name + '" is DISAPPROVED' + (a.last_date ? ' (last delivery ' + U.fmtDate(a.last_date) + ')' : ' and never delivered') + '.',
        action: 'Open the ad in the platform, read the rejection reason, then edit and resubmit or replace it.' });
    });
    return out;
  }

  /* ---------- pacing (only when the registry has a budget) ---------- */
  function pacingFor(ds, P, F, cr) {
    var budget = cr.client && cr.client.budget;
    if (!budget) return null;
    var plats = F.platforms.length ? F.platforms : D.PLATFORMS;
    var total = 0;
    plats.forEach(function (p) { var v = +budget[p]; if (U.isNum(v) && v > 0) total += v; });
    if (!(total > 0)) return null;
    var T = P.T, ms = U.monthStart(T);
    var mFrom = ms < P.H ? P.H : ms;
    var l7From = U.addDays(T, -6);
    if (l7From < P.H) l7From = P.H;
    // Pacing covers the client's whole spend on the budgeted platforms, whatever the objective filter.
    var idx = (cr.client.campaigns || []).filter(function (i) { return plats.indexOf(ds.campaigns[i].platform) >= 0; });
    var MT = D.agg(ds, mFrom, T), L7 = D.agg(ds, l7From, T);
    var mtd = 0, l7 = 0;
    idx.forEach(function (i) { mtd += MT.camp[i * D.NM]; l7 += L7.camp[i * D.NM]; });
    var l7Days = U.diffDays(l7From, T) + 1;
    var pc = E.pacing({ budget: total, mtd: mtd, avg7: l7Days > 0 ? l7 / l7Days : 0, elapsed: +T.slice(8, 10), dim: U.daysInMonth(T) });
    if (pc) pc.partial = mFrom !== ms;
    return pc;
  }

  /**
   * The numbers a playbook hit was judged on, in the order the check's `when` lists them (plus spend
   * and the primary result for context). Shared by the action queue, client view and playbook page.
   */
  M.checkEvidence = function (check, hit) {
    var k = hit.k, p = hit.prim, when = (check && check.when) || {}, out = [], seen = {};
    var add = function (key, item) { if (!seen[key]) { seen[key] = 1; out.push(item); } };
    add('spend', { label: 'Spend', cur: U.money(hit.spend), prev: null, delta: null, up: 'neutral' });
    Object.keys(when).forEach(function (key) {
      if (key === 'ctr_all_lt' || key === 'ctr_all_gt') add('ctr', { label: 'CTR (all clicks)', cur: U.pct(k.ctr), prev: null, delta: null, up: 'good' });
      else if (key === 'link_ctr_lt' || key === 'link_ctr_gt' || key === 'ctr_lt' || key === 'ctr_gt') {
        add('link', { label: 'Link CTR', cur: k.linkKnown ? U.pct(k.link_ctr) : U.DASH, prev: null, delta: null, up: 'good', note: k.linkKnown ? null : 'link clicks not reported' });
      } else if (key === 'cpr_gt' && p) add('cpr', { label: p.costLabel, cur: p.costFmt === 'ratio' ? U.ratioX(p.cost) : U.money(p.cost), prev: null, delta: null, up: 'bad' });
      else if (key === 'frequency_gt') add('freq', { label: 'Avg daily frequency', cur: U.ratioX(k.freq), prev: null, delta: null, up: 'neutral' });
    });
    if (p && p.type !== 'Awareness') add('res', { label: p.type === 'Conversions·value' ? 'Purchase value' : p.resultLabel,
      cur: p.type === 'Conversions·value' ? U.money(p.result) : U.count(p.result), prev: null, delta: null, up: 'good', n: p.n });
    return out;
  };
  /** One-line summary of what a hit was judged on (client view, playbook page). */
  M.checkMetricText = function (check, hit) {
    return M.checkEvidence(check, hit).filter(function (e) { return e.label !== 'Spend'; })
      .map(function (e) { return e.label + ' ' + e.cur; }).join(' · ');
  };

  /* ---------- action queue ---------- */
  var LEVEL_LABEL = { 1: 'Immediate Action', 2: 'Playbook Watch Out', 3: 'Watch Out', 4: 'Delivery issue', 5: 'Opportunity' };
  M.LEVEL_LABEL = LEVEL_LABEL;
  function buildActions(scoped, checks, delivery) {
    var items = [];
    var plat = function (p) { return D.PLATFORM_LABEL[p] || p; };
    scoped.forEach(function (r) {
      var lab = r.decision.label;
      if (lab === 'No Touching') return;
      var level = lab === 'Immediate Action' ? 1 : lab === 'Watch Out' ? 3 : 5;
      items.push({
        key: 'dec:' + r.key + ':' + E.SHORT[lab], level: level, levelLabel: LEVEL_LABEL[level], decision: lab,
        tags: level === 1 ? ['fix'] : level === 3 ? ['watch'] : ['opp'],
        source: 'engine', sourceLabel: 'Decision engine', title: decisionTitle(r), why: r.decision.why, action: r.decision.action,
        clientSlug: r.clientSlug, clientName: r.client.name, platform: r.platform, row: r, status: r.status,
        path: [r.client.name, plat(r.platform), r.name], spend: r.cur.spend, evidence: r.evidence, objective: r.objective
      });
    });
    checks.forEach(function (c) {
      var sev = c.check.severity || 'Watch Out';
      var level = sev === 'Immediate Action' ? 1 : (sev === 'Opportunity' || sev === 'Ready to Scale') ? 5 : 2;
      var decision = level === 1 ? 'Immediate Action' : level === 5 ? 'Ready to Scale' : 'Watch Out';
      c.hits.forEach(function (h) {
        var path = [h.clientRow.name];
        if (h.campaignRow) path.push(plat(h.campaignRow.platform), h.campaignRow.name);
        if (h.adRow) path.push(h.adRow.name);
        var row = h.adRow || h.campaignRow || null;
        items.push({
          key: 'chk:' + c.check.id + ':' + h.key, level: level, levelLabel: level === 2 ? 'Playbook Watch Out' : LEVEL_LABEL[level], decision: decision,
          tags: (level === 1 ? ['fix'] : level === 5 ? ['opp'] : ['watch']).concat(['playbook']),
          source: 'playbook', sourceLabel: c.check.source || c.check.id, checkId: c.check.id, title: c.check.title || c.check.id,
          why: c.check.message || '', action: c.check.action || '', clientSlug: h.clientRow.slug, clientName: h.clientRow.name,
          platform: h.campaignRow ? h.campaignRow.platform : null, row: row, status: row ? row.status : h.clientRow.status,
          path: path, spend: h.spend, hit: h, evidence: M.checkEvidence(c.check, h)
        });
      });
    });
    delivery.forEach(function (d) {
      var r = d.row;
      var path = [r.client.name, plat(r.platform), r.name];
      if (d.ad) path.push(d.ad.name);
      items.push({
        key: 'del:' + d.key, level: 4, levelLabel: LEVEL_LABEL[4], decision: null, tags: ['fix'],
        source: 'delivery', sourceLabel: 'Delivery check', title: d.title, why: d.why, action: d.action,
        clientSlug: r.clientSlug, clientName: r.client.name, platform: r.platform, row: r, status: d.ad ? d.ad.status : r.status,
        path: path, spend: d.spend,
        evidence: d.type === 'disapproved' ? [{ label: 'Spend this period', cur: U.money(d.spend), prev: null, delta: null, up: 'neutral' }] : [
          { label: 'Last 3 days', cur: U.money(d.avg3) + '/day', prev: null, delta: null, up: 'neutral' },
          { label: 'Prior 7 days', cur: U.money(d.avg7) + '/day', prev: null, delta: null, up: 'neutral' },
          { label: 'Last delivery', cur: U.fmtDate(r.last_date), prev: null, delta: null, up: 'neutral' }
        ]
      });
    });
    items.sort(function (a, b) { return a.level - b.level || b.spend - a.spend || U.cmpText(a.title, b.title); });
    return items;
  }

  /**
   * Split items by per-browser review state. A review is remembered per item AND period end; a snooze
   * hides an item until its date. Returns { open, reviewed, snoozed, badge } (badge = unreviewed
   * Immediate Action + Watch Out items, including playbook Watch Out).
   */
  M.actionBuckets = function (snap, state, today) {
    var reviewed = (state && state.reviewed) || {}, snoozed = (state && state.snoozed) || {};
    var end = snap.periodEnd;
    var out = { open: [], reviewed: [], snoozed: [], badge: 0 };
    today = today || U.bangkokToday();
    snap.actions.forEach(function (it) {
      var until = snoozed[it.key];
      if (until && until >= today) { out.snoozed.push(it); return; }
      if (reviewed[it.key + '@' + end]) { out.reviewed.push(it); return; }
      out.open.push(it);
      if (it.level <= 3) out.badge++;
    });
    return out;
  };

  /* ---------- portfolio medians (all clients, ignoring sidebar filters) ---------- */
  function portfolioMedians(camps) {
    var per = new Map();
    camps.forEach(function (r) {
      if (!r.delivering || r.prim.type === 'Conversions·value') return;
      var key = r.vertical + '|' + r.prim.type + '|' + r.platform + '|' + r.clientSlug;
      var g = per.get(key);
      if (!g) { g = { vertical: r.vertical, type: r.prim.type, objective: r.objective, platform: r.platform, slug: r.clientSlug, name: r.client.name, agg: D.zero() }; per.set(key, g); }
      D.addInto(g.agg, r.cur);
    });
    var groups = new Map();
    per.forEach(function (g) {
      var k = E.kpis(g.agg), p = E.primary(g.objective, g.platform, k);
      var count = g.type === 'Awareness' ? k.impressions : p.n;
      if (!(count >= 5) || !U.isNum(p.cost)) return;
      var key = g.vertical + '|' + g.type + '|' + g.platform;
      var x = groups.get(key);
      if (!x) { x = { vertical: g.vertical, type: g.type, platform: g.platform, costLabel: p.costLabel, values: [] }; groups.set(key, x); }
      x.values.push({ slug: g.slug, name: g.name, value: p.cost, n: count });
    });
    groups.forEach(function (x) { x.median = U.median(x.values.map(function (v) { return v.value; })); x.n = x.values.length; });
    return groups;
  }
  M.portfolioFor = function (snap, vertical, type, platform) {
    return snap.portfolio.get(vertical + '|' + type + '|' + platform) || null;
  };

  /* ---------- parity (Hermes account-level decisions; ignores sidebar filters) ---------- */
  M.parity = function (snap) {
    var acc = new Map();
    snap.camps.forEach(function (r) {
      if (!r.delivering) return;
      var key = r.platform + '::' + (r.account ? r.account.id : '?');
      var a = acc.get(key);
      if (!a) { a = { key: key, platform: r.platform, name: r.account ? r.account.name : '?', decisions: [], spend: 0, campaigns: 0 }; acc.set(key, a); }
      a.decisions.push(r.decision.label); a.spend += r.cur.spend; a.campaigns++;
    });
    var list = [], counts = {}, total = 0;
    E.DECISIONS.forEach(function (d) { counts[d] = 0; });
    acc.forEach(function (a) { a.decision = E.mostSevere(a.decisions); counts[a.decision]++; total += a.spend; list.push(a); });
    return { accounts: list, counts: counts, total: total };
  };

  /* =========================================================================================
   * Client detail (client view)
   * ======================================================================================= */
  /**
   * platform: 'all' | 'meta' | 'tiktok' | 'google' (client view switch; changes only that view).
   * Returns null when the client is unknown. Uses only campaigns in sidebar scope.
   */
  M.clientDetail = function (snap, ds, slug, platform) {
    var idx = ds.bySlug.get(slug);
    if (idx === undefined) return null;
    var client = ds.clients[idx];
    var all = snap.camps.filter(function (r) { return r.clientSlug === slug; });
    var inScope = all.filter(function (r) { return r.inScope; });
    var camps = inScope.filter(function (r) { return platform === 'all' || !platform || r.platform === platform; });
    var g = { client: client, slug: slug, name: client.name, vertical: client.vertical, camps: camps, accounts: [] };
    finishGroup(g, snap.A, snap.B);
    var cr = snap.clientBySlug.get(slug) || null;
    g.flags = cr ? cr.flags.filter(function (h) { return !h.campaignRow || platform === 'all' || !platform || h.campaignRow.platform === platform; }) : [];
    g.pacing = cr ? cr.pacing : null;
    g.hiddenByScope = all.length - inScope.length;
    g.allCount = all.length;
    // Objective groups ordered by spend share (current period).
    var groups = new Map();
    camps.forEach(function (r) {
      var t = r.prim.type;
      var x = groups.get(t);
      if (!x) { x = { type: t, objective: r.objective, rows: [], platforms: [] }; groups.set(t, x); }
      x.rows.push(r);
      if (x.platforms.indexOf(r.platform) < 0) x.platforms.push(r.platform);
    });
    g.groups = [];
    groups.forEach(function (x) {
      x.cur = D.sumObjs(x.rows.map(function (r) { return r.cur; }));
      x.cmp = D.sumObjs(x.rows.map(function (r) { return r.cmp; }));
      x.k = E.kpis(x.cur); x.kp = E.kpis(x.cmp);
      x.share = g.cur.spend > 0 ? x.cur.spend / g.cur.spend : 0;
      x.platform = x.type === 'Conversions·value' ? 'meta' : (x.platforms.length === 1 ? x.platforms[0] : (x.platforms.indexOf('meta') >= 0 ? 'meta' : x.platforms[0]));
      x.bridge = E.cprBridge(x.objective, x.cur, x.cmp);
      x.perPlatform = x.platforms.map(function (p) {
        var rows = x.rows.filter(function (r) { return r.platform === p; });
        var cur = D.sumObjs(rows.map(function (r) { return r.cur; })), cmp = D.sumObjs(rows.map(function (r) { return r.cmp; }));
        return { platform: p, cur: cur, cmp: cmp, k: E.kpis(cur), kp: E.kpis(cmp), portfolio: M.portfolioFor(snap, client.vertical, x.type, p) };
      });
      g.groups.push(x);
    });
    g.groups.sort(function (a, b) { return b.cur.spend - a.cur.spend || b.cmp.spend - a.cmp.spend; });
    g.ads = snap.ads.filter(function (a) { return a.clientSlug === slug && a.inScope && (platform === 'all' || !platform || a.platform === platform); });
    g.pipeline = E.creativePipeline(g.ads.map(function (a) {
      return { first_date: a.first_date, spend: a.cur.spend, delivering: a.delivering };
    }), snap.periodEnd, snap.P.H);
    g.byPlatform = {};
    camps.forEach(function (r) { var p = g.byPlatform[r.platform] || (g.byPlatform[r.platform] = D.zero()); D.addInto(p, r.cur); });
    return g;
  };

  /** Daily series for the client trends: by platform or by the top 5 campaigns by spend. */
  M.trendSeries = function (snap, detail, mode) {
    var A = snap.A;
    if (!A || !detail) return { days: [], series: [] };
    var prim = detail.primary;
    var typeRows = prim ? prim.rows.filter(function (r) { return detail.camps.indexOf(r) >= 0; }) : [];
    var groups = [];
    if (mode === 'campaigns') {
      detail.camps.slice().sort(function (a, b) { return b.cur.spend - a.cur.spend; }).slice(0, 5).forEach(function (r, i) {
        groups.push({ key: r.key, label: r.name, color: 'var(--s' + (i + 1) + ')', all: [r], typed: prim && r.prim.type === prim.type ? [r] : [] });
      });
    } else {
      D.PLATFORMS.forEach(function (p) {
        var rows = detail.camps.filter(function (r) { return r.platform === p; });
        if (!rows.length) return;
        groups.push({ key: p, label: D.PLATFORM_LABEL[p], color: 'var(--' + p + ')', all: rows, typed: typeRows.filter(function (r) { return r.platform === p; }) });
      });
    }
    var series = groups.map(function (g) {
      var spend = D.series(A, g.all.map(function (r) { return r.i; }), 'spend');
      var objs = D.seriesObj(A, g.typed.map(function (r) { return r.i; }));
      var results = [], costs = [];
      objs.forEach(function (o) {
        if (!g.typed.length || !prim) { results.push(null); costs.push(null); return; }
        var p = E.primary(prim.objective, prim.type === 'Conversions·value' ? 'meta' : g.typed[0].platform, E.kpis(o));
        results.push(U.isNum(p.result) ? p.result : null);
        costs.push(U.isNum(p.cost) && (p.n === null || p.n > 0) ? p.cost : null);
      });
      return { key: g.key, label: g.label, color: g.color, spend: spend, results: results, costs: costs, hasTyped: g.typed.length > 0 };
    });
    return { days: A.days, series: series, prim: prim };
  };

  /* =========================================================================================
   * Monthly history (client view): last 6 months, quarter totals, MTD flag
   * ======================================================================================= */
  M.monthlyFor = function (monthly, slug, opts) {
    opts = opts || {};
    var rows = monthly.rows.filter(function (r) {
      return r.camp.clientSlug === slug && (!opts.platforms || !opts.platforms.length || opts.platforms.indexOf(r.camp.platform) >= 0);
    });
    var months = monthly.months.slice().sort();
    if (opts.historyFrom) months = months.filter(function (m) { return m >= opts.historyFrom.slice(0, 7); });
    months = months.slice(-6);
    var byMonth = months.map(function (m) {
      var list = rows.filter(function (r) { return r.month === m; });
      var spend = 0, byType = new Map();
      list.forEach(function (r) {
        spend += r.m.spend;
        var objective = E.classify(r.camp.platform, r.camp.rawObjective, r.camp.name, r.m);
        var t = E.resultType(objective, r.camp.platform);
        var x = byType.get(t);
        if (!x) { x = { type: t, objective: objective, platform: r.camp.platform, agg: D.zero(), spend: 0 }; byType.set(t, x); }
        D.addInto(x.agg, r.m); x.spend += r.m.spend;
      });
      var best = null;
      byType.forEach(function (x) { if (!best || x.spend > best.spend) best = x; });
      var prim = best ? E.primary(best.objective, best.platform, E.kpis(best.agg)) : null;
      return { month: m, spend: spend, prim: prim, type: best ? best.type : null,
        mtd: !!opts.dataThrough && m === opts.dataThrough.slice(0, 7) && opts.dataThrough !== U.monthEnd(opts.dataThrough) };
    });
    byMonth.forEach(function (r, i) {
      var p = i > 0 ? byMonth[i - 1] : null;
      r.dSpend = p && !r.mtd ? U.pctChange(r.spend, p.spend) : null;
      r.dCost = p && !r.mtd && r.prim && p.prim && r.type === p.type ? U.pctChange(r.prim.cost, p.prim.cost) : null;
    });
    var quarters = new Map();
    byMonth.forEach(function (r) {
      var q = r.month.slice(0, 4) + ' Q' + (Math.floor((+r.month.slice(5, 7) - 1) / 3) + 1);
      var x = quarters.get(q) || { quarter: q, spend: 0, months: 0, partial: false };
      x.spend += r.spend; x.months++; if (r.mtd) x.partial = true;
      quarters.set(q, x);
    });
    var qs = [];
    quarters.forEach(function (x) { if (x.months < 3) x.partial = true; qs.push(x); });
    return { months: byMonth, quarters: qs };
  };

  /* =========================================================================================
   * KPI trend lines (SPEC §4.7)
   * One definition per tile KPI. A bucket's value (day or week) comes from the bucket's SUMMED
   * metrics, never from averaging daily ratios: cost per conversation = Σ spend ÷ Σ conversations,
   * CTR = Σ clicks ÷ Σ impressions. No denominator = null = a gap in the line (never ฿0, never ∞).
   *   get(o, k, days)  o: summed metric object, k: engine.kpis(o), days: days in the bucket
   *   fmt   'money' | 'int' | 'count' | 'pct' | 'ratio'       good  'up' | 'down' | 'neutral'
   *   kind  'count' (sums: splits rank by the KPI itself) | 'ratio' (splits rank by spend)
   *   n(o)  result count beside the KPI (sample-size honesty, "low n")
   *   cost  the objective whose cost per result this is (benchmark band, registry target line)
   *   gate(o)  false = "Not tracked" for the whole period (no line, no Δ)
   *   formula / gap   how a point is computed / what a gap means (chart notes)
   * ======================================================================================= */
  function linkOK(o) { return !(o.clicks > 0 && o.link_clicks === 0); }
  function valueOf(o) { return (o.conv_value || 0) + (o.roas_value || 0); }
  var nMsg = function (o) { return o.messages; }, nLead = function (o) { return o.leads; }, nConv = function (o) { return o.conversions; };
  var nView = function (o) { return o.video_views; }, nLink = function (o) { return linkOK(o) ? o.link_clicks : null; };
  M.KPI = {
    spend: { label: 'Spend', fmt: 'money', good: 'neutral', kind: 'count', get: function (o) { return o.spend; }, formula: 'spend' },
    impressions: { label: 'Impressions', fmt: 'int', good: 'up', kind: 'count', get: function (o) { return o.impressions; }, formula: 'impressions' },
    link_clicks: { label: 'Link clicks', fmt: 'int', good: 'up', kind: 'count', get: function (o) { return o.link_clicks; }, formula: 'Meta link clicks + TikTok and Google clicks' },
    messages: { label: 'Conversations', fmt: 'count', good: 'up', kind: 'count', get: nMsg, n: nMsg, formula: 'messaging conversations (platform-reported)' },
    leads: { label: 'Leads', fmt: 'count', good: 'up', kind: 'count', get: nLead, n: nLead, formula: 'lead actions (platform-reported)' },
    conversions: { label: 'Conversions', fmt: 'count', good: 'up', kind: 'count', get: nConv, n: nConv, formula: 'conversions (platform-reported)' },
    link_ctr: { label: 'Link CTR', fmt: 'pct', good: 'up', kind: 'ratio', get: function (o, k) { return k.link_ctr; }, formula: 'link clicks ÷ impressions', gap: 'no impressions, or link clicks not reported' },
    ctr: { label: 'CTR', fmt: 'pct', good: 'up', kind: 'ratio', get: function (o, k) { return k.ctr; }, formula: 'all clicks ÷ impressions', gap: 'no impressions' },
    cpm: { label: 'CPM', fmt: 'money', good: 'down', kind: 'ratio', get: function (o, k) { return k.cpm; }, formula: 'spend ÷ impressions × 1,000', gap: 'no impressions' },
    cpmsg: { label: 'Cost per conversation', fmt: 'money', good: 'down', kind: 'ratio', get: function (o, k) { return k.cpmsg; }, n: nMsg, cost: 'Messages',
      formula: 'spend ÷ conversations', gap: 'no conversations' },
    chat_rate: { label: 'Click-to-conversation', fmt: 'pct', good: 'up', kind: 'ratio', get: function (o, k) { return k.chat_rate; }, n: nMsg,
      formula: 'conversations ÷ link clicks', gap: 'no link clicks reported' },
    cpl: { label: 'CPL', fmt: 'money', good: 'down', kind: 'ratio', get: function (o, k) { return k.cpl; }, n: nLead, cost: 'Lead generation', formula: 'spend ÷ leads', gap: 'no leads' },
    lead_rate: { label: 'Lead rate', fmt: 'pct', good: 'up', kind: 'ratio', get: function (o, k) { return k.lead_rate; }, n: nLead, formula: 'leads ÷ link clicks', gap: 'no link clicks reported' },
    cpm_aw: { label: 'CPM', fmt: 'money', good: 'down', kind: 'ratio', get: function (o, k) { return k.cpm; }, cost: 'Awareness', formula: 'spend ÷ impressions × 1,000', gap: 'no impressions' },
    freq: { label: 'Avg daily frequency', fmt: 'ratio', good: 'neutral', kind: 'ratio', get: function (o, k) { return k.freq; },
      formula: 'impressions ÷ Σ daily reach (not unique reach)', gap: 'no reach reported' },
    reach_day: { label: 'Reach/day', fmt: 'int', good: 'up', kind: 'ratio', get: function (o, k, days) { return days > 0 ? o.reach / days : null; },
      formula: 'Σ daily reach ÷ days (not unique reach)' },
    link_clicks_t: { label: 'Link clicks', fmt: 'int', good: 'up', kind: 'count', get: nLink, n: nLink, formula: 'link clicks', gap: 'link clicks not reported' },
    cpc: { label: 'CPC', fmt: 'money', good: 'down', kind: 'ratio', get: function (o, k) { return k.cpc_link; }, n: nLink, cost: 'Traffic',
      formula: 'spend ÷ link clicks', gap: 'no link clicks' },
    video_views: { label: 'Video views (3s)', fmt: 'int', good: 'up', kind: 'count', get: nView, n: nView, formula: '3-second video views' },
    cpv: { label: 'Cost per view', fmt: 'money', good: 'down', kind: 'ratio', get: function (o, k) { return k.cpv; }, n: nView, cost: 'Engagement',
      formula: 'spend ÷ 3-second views', gap: 'no views' },
    view_rate: { label: 'View rate', fmt: 'pct', good: 'up', kind: 'ratio', get: function (o, k) { return k.view_rate; }, n: nView, formula: '3-second views ÷ impressions', gap: 'no impressions' },
    value: { label: 'Purchase value', fmt: 'money', good: 'up', kind: 'count', get: valueOf, formula: 'Meta-reported purchase value' },
    conv_value: { label: 'Conversion value', fmt: 'money', good: 'up', kind: 'count', get: valueOf, gate: function (o) { return valueOf(o) > 0; },
      formula: 'reported conversion value' },
    roas: { label: 'ROAS', fmt: 'ratio', good: 'up', kind: 'ratio', get: function (o) { return o.spend > 0 ? valueOf(o) / o.spend : null; },
      gate: function (o) { return valueOf(o) > 0; }, formula: 'purchase value ÷ spend', gap: 'no spend' },
    cpa: { label: 'CPA', fmt: 'money', good: 'down', kind: 'ratio', get: function (o, k) { return k.cpa; }, n: nConv, cost: 'Conversions', formula: 'spend ÷ conversions', gap: 'no conversions' }
  };
  Object.keys(M.KPI).forEach(function (id) { M.KPI[id].id = id; });

  /** The KPI for a whole period: one bucket of `days` days (equals what the tile shows). */
  M.kpiValue = function (kpi, o, days) {
    if (!o) return null;
    if (kpi.gate && !kpi.gate(o)) return null;
    var v = kpi.get(o, E.kpis(o), days);
    return U.isNum(v) ? v : null;
  };

  /**
   * End-marker colour: the direction of the tile's own change vs the comparison (period totals),
   * judged like the Δ chip: 'good' | 'bad' | 'neutral' (spend, or under 0.5%) | 'muted' (no baseline
   * or low n).
   */
  M.trendDir = function (kpi, cur, prev, lowN) {
    var p = U.pctChange(cur, prev);
    if (!U.isNum(p) || lowN) return 'muted';
    if (kpi.good === 'neutral' || Math.abs(p) < 0.5) return 'neutral';
    return (kpi.good === 'down' ? p < 0 : p > 0) ? 'good' : 'bad';
  };

  function sumDayLists(lists, nDays) {
    if (lists.length === 1) return lists[0];
    var out = [];
    for (var d = 0; d < nDays; d++) {
      var o = D.zero();
      for (var i = 0; i < lists.length; i++) D.addInto(o, lists[i][d]);
      out.push(o);
    }
    return out;
  }
  function provIndex(buckets, P) {
    if (!P || !P.provisional) return -1;
    for (var i = 0; i < buckets.length; i++) if (buckets[i].to >= P.provisional.from) return i;
    return -1;
  }
  /**
   * Bucketed metric sums for a trend scope, computed once per state (memoized on the snapshot).
   *   scope: { key, camps: [CampRow] } (campaign × day cube) or { key, adsets: [AdsetRow] } (ad set scan)
   * Returns { gran, buckets, days, cmpDays, cur: [{o, days}], cmp: [{o, days}|null] | null, provIdx }
   * The comparison is aligned by day number: bucket i covers the same day indexes in both periods.
   */
  M.trendData = function (snap, ds, scope, gran) {
    var memo = snap.trendMemo || (snap.trendMemo = new Map());
    var key = scope.key + '#' + gran;
    var hit = memo.get(key);
    if (hit) return hit;
    var A = snap.A, B = snap.B;
    var days = A ? A.days : [], cmpDays = B ? B.days : [];
    var buckets = D.buckets(days, gran);
    var curObjs = [], cmpObjs = null;
    if (scope.adsets) {
      var si = scope.adsets.map(function (r) { return r.i; });
      if (A) curObjs = sumDayLists(D.adsetDays(ds, A.from, A.to, si), A.nDays);
      if (B) cmpObjs = sumDayLists(D.adsetDays(ds, B.from, B.to, si), B.nDays);
    } else {
      var ci = (scope.camps || []).map(function (r) { return r.i; });
      if (A) curObjs = D.seriesObj(A, ci);
      if (B) cmpObjs = D.seriesObj(B, ci);
    }
    var res = { gran: gran, buckets: buckets, days: days, cmpDays: cmpDays, cur: D.bucketSums(curObjs, buckets),
      cmp: cmpObjs ? D.bucketSums(cmpObjs, buckets) : null, provIdx: provIndex(buckets, snap.P) };
    memo.set(key, res);
    return res;
  };
  /** One KPI over trendData buckets: { cur: [v|null], cmp: [v|null] | null, nCur, nCmp, tracked }. */
  M.trendValues = function (td, kpi) {
    var val = function (b) {
      if (!b) return null;
      var k = b.k || (b.k = E.kpis(b.o));
      var v = kpi.get(b.o, k, b.days);
      return U.isNum(v) ? v : null;
    };
    var cnt = function (b) { if (!b || !kpi.n) return null; var v = kpi.n(b.o); return U.isNum(v) ? v : null; };
    var tot = function (list) { var t = D.zero(); (list || []).forEach(function (b) { if (b) D.addInto(t, b.o); }); return t; };
    var trackedCur = !kpi.gate || kpi.gate(tot(td.cur)), trackedCmp = !td.cmp || !kpi.gate || kpi.gate(tot(td.cmp));
    return {
      cur: td.cur.map(function (b) { return trackedCur ? val(b) : null; }),
      cmp: td.cmp ? td.cmp.map(function (b) { return trackedCmp ? val(b) : null; }) : null,
      nCur: td.cur.map(cnt), nCmp: td.cmp ? td.cmp.map(cnt) : null, tracked: trackedCur
    };
  };
  M.TREND_SPLITS = ['total', 'platform', 'campaigns', 'adsets'];
  M.TREND_SPLIT_LABEL = { total: 'Total', platform: 'By platform', campaigns: 'Top 5 campaigns', adsets: 'Top 5 ad sets' };
  /**
   * Series for the expanded chart (SPEC §4.7): 'total' | 'platform' | 'campaigns' | 'adsets'.
   * Top 5 rank by the KPI itself for counts and by spend for ratios and costs (current period);
   * entities with nothing in the current period are left out. Repeated names get their campaign
   * (or platform) added, then the id's last 4 digits, so two "Broad 5 km" ad sets never look alike.
   * Ad set scopes (one ad set) only have 'total'.
   * Returns { mode, rankBy, series: [{ key, label, color, td, values: {cur, cmp, nCur, nCmp} }] }
   */
  M.trendSplit = function (snap, ds, scope, kpi, gran, mode) {
    var out = { mode: mode, rankBy: kpi.kind === 'count' ? kpi.label : 'spend', series: [] };
    var mk = function (key, label, color, sc) {
      var td = M.trendData(snap, ds, sc, gran);
      out.series.push({ key: key, label: label, color: color, td: td, values: M.trendValues(td, kpi) });
    };
    var weight = function (r) {
      var v = kpi.kind === 'count' ? M.kpiValue(kpi, r.cur, snap.P.curLen || 1) : r.cur.spend;
      return U.isNum(v) ? v : 0;
    };
    var top5 = function (rows) {
      return rows.map(function (r) { return { r: r, w: weight(r) }; }).filter(function (x) { return x.w > 0; })
        .sort(function (a, b) { return b.w - a.w || b.r.cur.spend - a.r.cur.spend; }).slice(0, 5).map(function (x) { return x.r; });
    };
    var camps = scope.camps || [];
    if (mode === 'platform' && !scope.adsets) {
      D.PLATFORMS.forEach(function (p) {
        var rows = camps.filter(function (r) { return r.platform === p; });
        if (rows.length) mk(p, D.PLATFORM_LABEL[p], 'var(--' + p + ')', { key: scope.key + '|pl:' + p, camps: rows });
      });
    } else if (mode === 'campaigns' && !scope.adsets) {
      var tc = top5(camps);
      var cl = labelsFor(tc, function (r) { return (scope.multiClient ? r.client.name + ' · ' : '') + r.name; }, function (r) { return r.platform !== 'meta' ? D.PLATFORM_LABEL[r.platform] : null; });
      tc.forEach(function (r, i) { mk(r.key, cl[i], 'var(--s' + (i + 1) + ')', { key: 'c:' + r.key, camps: [r] }); });
    } else if (mode === 'adsets' && !scope.adsets) {
      var sets = [];
      camps.forEach(function (r) { (r.adsetRows || []).forEach(function (a) { sets.push(a); }); });
      var ts = top5(sets);
      var sl = labelsFor(ts, function (a) { return (scope.multiClient ? a.client.name + ' · ' : '') + a.name; }, function (a) { return a.campaign.name; });
      ts.forEach(function (a, i) { mk(a.key, sl[i], 'var(--s' + (i + 1) + ')', { key: 'as:' + a.key, adsets: [a] }); });
    } else {
      out.mode = 'total';
      mk('total', kpi.label, 'var(--copper)', scope);
    }
    return out;
  };
  /** Distinct labels: add the context (campaign / platform), then the id's last 4 digits, on repeats. */
  function labelsFor(rows, base, ctxOf) {
    var labels = rows.map(base);
    var dup = function (l) { var c = {}; l.forEach(function (x) { c[x] = (c[x] || 0) + 1; }); return c; };
    var c1 = dup(labels);
    labels = labels.map(function (l, i) { var cx = ctxOf(rows[i]); return c1[l] > 1 && cx ? l + ' · ' + cx : l; });
    var c2 = dup(labels);
    return labels.map(function (l, i) { return c2[l] > 1 ? l + ' #' + String(rows[i].id).slice(-4) : l; });
  }

  /* =========================================================================================
   * Where results happen (SPEC §4.8): placement and audience splits inside Meta ad sets
   * ======================================================================================= */
  M.BD_OTHER_MAX = 0.02;    // placements under 2% of the block's spend with 0 results fold into "Other placements"
  M.BD_UNKNOWN_MIN = 0.01;  // the Unknown age row / gender column shows only from 1% of the block's spend
  function bdZero() { return D.bdObj(null, 0); }
  function bdAdd(t, o) { D.BD_METRICS.forEach(function (k) { t[k] += o[k] || 0; }); return t; }
  function ptsDelta(a, b) { return U.isNum(a) && U.isNum(b) ? (a - b) * 100 : null; }
  function bdResults(o, res) {
    if (res.sharesOnly) return null;
    if (res.key === 'link_clicks' && !linkOK(o)) return null; // clicks without link clicks = not reported
    return o[res.key];
  }
  function bdTotals(objs, res) {
    var t = { spend: 0, imp: 0, results: res.sharesOnly ? null : 0 };
    objs.forEach(function (o) {
      t.spend += o.spend; t.imp += o.impressions;
      if (!res.sharesOnly) { var r = bdResults(o, res); if (U.isNum(r)) t.results += r; }
    });
    return t;
  }
  /** One share row: spend / results / impressions shares of the block, cost, rates, tag, Δ in points. */
  function shareRow(key, label, o, tot, res, prevO, ptot) {
    var k = E.kpis(o), results = bdResults(o, res);
    var spendShare = tot.spend > 0 ? o.spend / tot.spend : null;
    var resShare = res.sharesOnly || !U.isNum(results) ? null : (tot.results > 0 ? results / tot.results : null);
    var row = {
      key: key, label: label, o: o, spend: o.spend, imp: o.impressions, results: results,
      spendShare: spendShare, resShare: resShare, impShare: tot.imp > 0 ? o.impressions / tot.imp : null,
      cpr: res.sharesOnly ? k.cpm : (U.isNum(results) && results > 0 ? o.spend / results * res.per : null),
      linkCtr: k.link_ctr, linkKnown: k.linkKnown, cpm: k.cpm,
      tag: res.sharesOnly ? null : E.bdTag(spendShare, resShare, results, tot.results),
      prev: null, dSpend: null, dRes: null, dImp: null
    };
    if (ptot) {
      var po = prevO || bdZero(), pr = bdResults(po, res);
      var p = {
        spend: po.spend, results: pr, spendShare: ptot.spend > 0 ? po.spend / ptot.spend : null,
        resShare: res.sharesOnly || !U.isNum(pr) ? null : (ptot.results > 0 ? pr / ptot.results : null),
        impShare: ptot.imp > 0 ? po.impressions / ptot.imp : null
      };
      row.prev = p;
      row.dSpend = ptsDelta(row.spendShare, p.spendShare);
      row.dRes = ptsDelta(row.resShare, p.resShare);
      row.dImp = ptsDelta(row.impShare, p.impShare);
    }
    return row;
  }
  /**
   * Which of these ad sets' accounts reported breakdown rows in [from, to] (any kind). An ad set with
   * spend whose account has no rows at all = the account isn't reachable in Windsor (reconnect it);
   * an account with rows but none for this ad set = this ad set simply has no split rows.
   */
  M.bdReach = function (bd, ds, rows, from, to) {
    var accs = new Set();
    D.BD_KINDS.forEach(function (kind) {
      if (!bd.available[kind]) return;
      D.bdAccounts(bd, kind, from, to).forEach(function (a) { accs.add(a); });
      D.bdAgg(bd, kind, from, to).byAdset.forEach(function (arr, i) {   // ad sets without account_id: join through the rows payload
        var a = bd.adsets[i];
        if (!a || a.account_id) return;
        var s = ds.adsetByKey ? ds.adsetByKey.get(a.key) : null;
        if (s === undefined || s === null) return;
        var c = ds.campaigns[ds.adsets[s].campaign], acc = c ? ds.accounts[c.account] : null;
        if (acc) accs.add(D.acctKey(acc.platform, acc.id));
      });
    });
    var unreachable = [], reachable = [];
    rows.forEach(function (r) {
      if (!(r.cur.spend > 0)) return;
      var acc = r.campaign && r.campaign.account;
      var key = acc ? D.acctKey(acc.platform, acc.id) : null;
      (key && accs.has(key) ? reachable : unreachable).push(r);
    });
    return { unreachable: unreachable, reachable: reachable, accounts: accs };
  };
  /**
   * One breakdown block for Meta ad set rows of ONE result type (results are never mixed across
   * objectives). kind 'placement' | 'audience'; res = engine.bdResult(objective).
   * Shares are of the block's breakdown totals, so each column sums to 100%. Coverage = breakdown
   * spend ÷ Sheet 1 spend of the same ad sets (can sit slightly above 100% when the breakdown
   * export is newer than the main data's last days).
   * placement: rows (by spend; "Other placements" folds rows under 2% of spend with 0 results)
   * audience:  cells (age × gender), ages, genders (marginals), grid ages / genders shown, hidden
   */
  M.bdBlock = function (bd, P, rows, kind, res) {
    var keys = rows.map(function (r) { return r.key; });
    var segs = kind === 'placement' ? bd.placements : bd.audiences;
    var cur = D.bdSum(bd, kind, P.cur.from, P.cur.to, keys);
    var prev = P.cmp && !P.noBaseline ? D.bdSum(bd, kind, P.cmp.from, P.cmp.to, keys) : null;
    var objs = segs.map(function (s) { return D.bdObj(cur.seg, s.i); });
    var pObjs = prev ? segs.map(function (s) { return D.bdObj(prev.seg, s.i); }) : null;
    var tot = bdTotals(objs, res), ptot = pObjs ? bdTotals(pObjs, res) : null;
    if (ptot && !(ptot.spend > 0)) ptot = null; // the comparison has no breakdown data: no Δ
    var rowsSpend = U.sum(rows, function (r) { return r.cur.spend; }), prevRowsSpend = U.sum(rows, function (r) { return r.cmp.spend; });
    var block = {
      kind: kind, res: res, sharesOnly: !!res.sharesOnly, total: tot, prevTotal: ptot, hasPrev: !!ptot, cmpWindow: !!prev, withRows: cur.withRows,
      coverage: { cur: rowsSpend > 0 ? tot.spend / rowsSpend : null, prev: ptot && prevRowsSpend > 0 ? ptot.spend / prevRowsSpend : null, rowsSpend: rowsSpend, bdSpend: tot.spend },
      lowN: !res.sharesOnly && tot.results < E.BD_MIN_RESULTS, empty: !(tot.spend > 0)
    };
    var mkRow = function (key, label, o, po) { return shareRow(key, label, o, tot, res, po, ptot); };
    if (kind === 'placement') {
      var list = [];
      segs.forEach(function (s, i) {
        if (!(objs[i].spend > 0)) return;
        var r = mkRow(s.key, s.label, objs[i], pObjs ? pObjs[i] : null);
        r.segIdx = i;
        list.push(r);
      });
      list.sort(function (a, b) { return b.spend - a.spend || U.cmpText(a.label, b.label); });
      var small = list.filter(function (r) { return r.spendShare < M.BD_OTHER_MAX && (res.sharesOnly || !(r.results > 0)); });
      if (small.length >= 2) {
        var o = bdZero(), po = pObjs ? bdZero() : null;
        small.forEach(function (r) { bdAdd(o, r.o); if (po) bdAdd(po, pObjs[r.segIdx]); });
        var other = mkRow('other', 'Other placements', o, po);
        other.children = small;
        other.isOther = true;
        list = list.filter(function (r) { return small.indexOf(r) < 0; }).concat([other]);
      }
      block.rows = list;
      return block;
    }
    // audience: cells, then age and gender marginals (summed over the other dimension)
    var cells = [], byAge = new Map(), byGender = new Map();
    segs.forEach(function (s, i) {
      var o = objs[i], po = pObjs ? pObjs[i] : null;
      if (!(o.spend > 0) && !(po && po.spend > 0)) return;
      var a = byAge.get(s.age) || { o: bdZero(), po: pObjs ? bdZero() : null };
      bdAdd(a.o, o); if (a.po && po) bdAdd(a.po, po); byAge.set(s.age, a);
      var g = byGender.get(s.gender) || { o: bdZero(), po: pObjs ? bdZero() : null };
      bdAdd(g.o, o); if (g.po && po) bdAdd(g.po, po); byGender.set(s.gender, g);
      if (o.spend > 0) {
        var c = mkRow(s.key, M.audienceLabel(s.age, s.gender), o, po);
        c.age = s.age; c.gender = s.gender;
        cells.push(c);
      }
    });
    var hidden = [];
    var ageKeys = D.AGE_ORDER.concat(Array.from(byAge.keys()).filter(function (a) { return D.AGE_ORDER.indexOf(a) < 0; }).sort());
    var ages = ageKeys.filter(function (a) { return byAge.has(a) && byAge.get(a).o.spend > 0; }).map(function (a) {
      var x = byAge.get(a), r = mkRow(a, a === 'Unknown' ? 'Unknown age' : a.replace('-', '–'), x.o, x.po);
      r.age = a;
      return r;
    }).filter(function (r) { if (r.age === 'Unknown' && !(r.spendShare >= M.BD_UNKNOWN_MIN)) { hidden.push(r); return false; } return true; });
    var genders = D.GENDER_ORDER.filter(function (g) { return byGender.has(g) && byGender.get(g).o.spend > 0; }).map(function (g) {
      var x = byGender.get(g), r = mkRow(g, g === 'unknown' ? 'Unknown gender' : D.GENDER_LABEL[g], x.o, x.po);
      r.gender = g;
      return r;
    }).filter(function (r) { if (r.gender === 'unknown' && !(r.spendShare >= M.BD_UNKNOWN_MIN)) { hidden.push(r); return false; } return true; });
    var showAge = new Set(ages.map(function (r) { return r.age; })), showGender = new Set(genders.map(function (r) { return r.gender; }));
    block.cells = cells;
    // heatmap rows: ages with at least one cell in a gender column that is shown
    var gridAges = ages.filter(function (r) { return cells.some(function (c) { return c.age === r.age && showGender.has(c.gender); }); });
    block.grid = { ages: gridAges.map(function (r) { return r.age; }), genders: genders.map(function (r) { return r.gender; }),
      cell: function (age, gender) { for (var i = 0; i < cells.length; i++) if (cells[i].age === age && cells[i].gender === gender) return cells[i]; return null; } };
    block.visibleCells = cells.filter(function (c) { return showAge.has(c.age) && showGender.has(c.gender); });
    block.ages = ages; block.genders = genders; block.hidden = hidden;
    return block;
  };
  /** "Women 25–34", "Men, age unknown", "Unknown gender 18–24". */
  M.audienceLabel = function (age, gender) {
    var g = gender === 'female' ? 'Women' : gender === 'male' ? 'Men' : 'Unknown gender';
    return age === 'Unknown' ? g + ', age unknown' : g + ' ' + String(age).replace('-', '–');
  };
  /** Share as text: whole percent from 1%, one decimal below it ("0.4%"). */
  M.shareText = function (x) {
    if (!U.isNum(x)) return U.DASH;
    var v = x * 100;
    return v > 0 && v < 1 ? U.pct(v, 1) : U.pct(v, 0);
  };
  /** Coverage as text: capped at 100% (a newer breakdown export can sit slightly above). */
  M.coverageText = function (share) {
    if (!U.isNum(share)) return U.DASH;
    var v = Math.min(share, 1) * 100;
    return v >= 99.95 ? '100%' : v <= 0 ? '0%' : U.pct(v, 1);
  };
  M.BD_OVER = 1.005; // above this, say the breakdown is newer than the main data's last days

  /**
   * Plain-language summary from the numbers only (SPEC §4.8): the top placement by spend and the
   * placement that stands out (spending with no results, or the best "Works"), then the audience
   * cell with the most results and the other gender. Empty string when there is nothing to say.
   */
  M.bdSentence = function (pl, au, res) {
    var parts = [], st = M.shareText;
    // whole baht from ฿10 (the sentence is a summary; the tables keep the exact values)
    var bt = function (v) { return U.isNum(v) && v >= 10 ? '฿' + U.int(v) : U.money(v); };
    var cost = function (r) { return res.per === 1000 ? 'CPM ' + bt(r.cpr) : bt(r.cpr) + ' each'; };
    var at = function (r) { return res.per === 1000 ? 'at a ' + bt(r.cpr) + ' CPM' : 'at ' + bt(r.cpr); };
    var cap = function (s) { return s.charAt(0).toUpperCase() + s.slice(1); };
    if (pl && !pl.empty && pl.rows && pl.rows.length) {
      var top = pl.rows[0];
      if (res.sharesOnly) parts.push(top.label + ' took ' + st(top.spendShare) + ' of spend and ' + st(top.impShare) + ' of impressions (CPM ' + bt(top.cpm) + ').');
      else if (top.results > 0) parts.push(top.label + ' took ' + st(top.spendShare) + ' of spend and brought ' + st(top.resShare) + ' of ' + res.word + ' (' + cost(top) + ').');
      else if (top.results === 0) parts.push(top.label + ' took ' + st(top.spendShare) + ' of spend with no ' + res.word + '.');
      if (!res.sharesOnly) {
        var rest = pl.rows.slice(1).filter(function (r) { return !r.isOther; });
        var nores = rest.filter(function (r) { return r.tag && r.tag.lean === 'nores'; })[0];
        var works = rest.filter(function (r) { return r.tag && r.tag.lean === 'works'; }).sort(function (a, b) { return b.resShare - a.resShare; })[0];
        if (nores) parts.push(nores.label + ' took ' + st(nores.spendShare) + ' of spend with no ' + res.word + '.');
        else if (works) parts.push(works.label + ' brought ' + st(works.resShare) + ' of ' + res.word + ' on ' + st(works.spendShare) + ' of spend (' + cost(works) + ').');
      }
    }
    if (au && !au.empty && au.visibleCells && au.visibleCells.length) {
      if (res.sharesOnly) {
        var big = au.visibleCells.slice().sort(function (a, b) { return b.spend - a.spend; })[0];
        parts.push(big.label + ' took ' + st(big.spendShare) + ' of spend and ' + st(big.impShare) + ' of impressions.');
      } else if (au.total.results > 0) {
        var best = au.visibleCells.filter(function (c) { return c.results > 0; }).sort(function (a, b) {
          return b.results - a.results || (a.cpr || 0) - (b.cpr || 0);
        })[0];
        if (best) {
          var s = best.label + ' brought ' + st(best.resShare) + ' of ' + res.word + ' ' + at(best);
          var otherKey = best.gender === 'female' ? 'male' : best.gender === 'male' ? 'female' : null;
          var other = otherKey ? au.genders.filter(function (g) { return g.gender === otherKey; })[0] : null;
          if (other && other.spend > 0) {
            var who = otherKey === 'male' ? 'men' : 'women';
            s += '; ' + who + (other.results > 0 ? ' brought ' + st(other.resShare) + ' ' + at(other) : ' brought none on ' + st(other.spendShare) + ' of spend');
          }
          parts.push(cap(s) + '.');
        }
      }
    }
    var total = pl && !pl.empty ? pl.total.results : au && !au.empty ? au.total.results : null;
    if (parts.length && !res.sharesOnly && U.isNum(total) && total < E.BD_MIN_RESULTS) {
      parts.push('Only ' + U.count(total) + ' ' + res.word + ' in total, so treat these splits as directional.');
    }
    return parts.join(' ');
  };

  /**
   * "% of results" (SPEC §4.8.3): an ad set's share of the client's results for its result type,
   * over the given campaign rows (the client's campaigns in view). Returns fn(row) -> share | null.
   */
  M.resultShare = function (camps) {
    var tot = new Map();
    camps.forEach(function (r) { var v = r.prim.result; if (U.isNum(v)) tot.set(r.prim.type, (tot.get(r.prim.type) || 0) + v); });
    var f = function (row) {
      var t = tot.get(row.prim.type), v = row.prim.result;
      return U.isNum(v) && t > 0 ? v / t : null;
    };
    f.total = function (type) { return tot.has(type) ? tot.get(type) : null; };
    return f;
  };

  /**
   * Client "Where results happen" (SPEC §4.8.2). sel = { type, camp } as last chosen (validated here).
   * Meta only; one result type at a time (default: the type with the most current spend); an
   * optional campaign narrows it. byAdset uses Sheet 1 (no breakdowns needed); placement / audience
   * blocks need bd. Returns { metaRows, types, type, res, camps, camp, adsets, byAdset, placement,
   *   audience, sentence, reach }.
   */
  M.whereResults = function (snap, ds, detail, bd, sel) {
    sel = sel || {};
    var meta = detail.camps.filter(function (r) { return r.platform === 'meta'; });
    var byType = new Map();
    meta.forEach(function (r) {
      var t = r.prim.type, x = byType.get(t);
      if (!x) { x = { type: t, objective: r.objective, spend: 0, prevSpend: 0, camps: [] }; byType.set(t, x); }
      x.spend += r.cur.spend; x.prevSpend += r.cmp.spend; x.camps.push(r);
    });
    var types = [];
    byType.forEach(function (x) { if (x.spend > 0) types.push(x); });
    types.sort(function (a, b) { return b.spend - a.spend || b.prevSpend - a.prevSpend; });
    var totalSpend = U.sum(types, function (x) { return x.spend; });
    types.forEach(function (x) { x.share = totalSpend > 0 ? x.spend / totalSpend : null; });
    var out = { metaRows: meta, types: types, type: null, res: null, camps: [], camp: null, adsets: [], byAdset: null, placement: null, audience: null, sentence: '', reach: null };
    var t = types.filter(function (x) { return x.type === sel.type; })[0] || types[0] || null;
    if (!t) return out;
    out.type = t;
    out.res = E.bdResult(t.objective);
    out.camps = t.camps.filter(function (r) { return r.cur.spend > 0; }).sort(function (a, b) { return b.cur.spend - a.cur.spend; });
    out.camp = sel.camp ? out.camps.filter(function (r) { return r.key === sel.camp; })[0] || null : null;
    (out.camp ? [out.camp] : t.camps).forEach(function (r) { (r.adsetRows || []).forEach(function (a) { out.adsets.push(a); }); });
    out.byAdset = M.adsetShares(out.adsets, t.type);
    if (bd && P_ok(snap.P)) {
      out.reach = M.bdReach(bd, ds, out.adsets, snap.P.cur.from, snap.P.cur.to);
      if (bd.available.placement) out.placement = M.bdBlock(bd, snap.P, out.adsets, 'placement', out.res);
      if (bd.available.audience) out.audience = M.bdBlock(bd, snap.P, out.adsets, 'audience', out.res);
      out.sentence = M.bdSentence(out.placement, out.audience, out.res);
    }
    return out;
  };
  function P_ok(P) { return !!(P && P.cur); }
  /**
   * By ad set (targeting audience), from Sheet 1: each ad set's % of spend vs % of results within
   * one result type (Conversions·value: % of purchase value, no tags: it isn't a count).
   */
  M.adsetShares = function (adsets, type) {
    var valueType = type === 'Conversions·value';
    var live = adsets.filter(function (a) { return a.cur.spend > 0; });
    var tot = { spend: U.sum(live, function (a) { return a.cur.spend; }), results: U.sum(live, function (a) { return U.isNum(a.prim.result) ? a.prim.result : 0; }) };
    var ptot = { spend: U.sum(adsets, function (a) { return a.cmp.spend; }), results: U.sum(adsets, function (a) { return U.isNum(a.primPrev.result) ? a.primPrev.result : 0; }) };
    var rows = live.map(function (a) {
      var results = U.isNum(a.prim.result) ? a.prim.result : null;
      var spendShare = tot.spend > 0 ? a.cur.spend / tot.spend : null, resShare = U.isNum(results) && tot.results > 0 ? results / tot.results : null;
      var ps = ptot.spend > 0 ? a.cmp.spend / ptot.spend : null;
      var pr = U.isNum(a.primPrev.result) && ptot.results > 0 ? a.primPrev.result / ptot.results : null;
      return { row: a, key: a.key, label: a.name, spend: a.cur.spend, results: results, spendShare: spendShare, resShare: resShare, cpr: a.prim.cost,
        tag: valueType ? null : E.bdTag(spendShare, resShare, results, tot.results), dSpend: ptot.spend > 0 ? ptsDelta(spendShare, ps) : null,
        dRes: ptot.results > 0 ? ptsDelta(resShare, pr) : null };
    }).sort(function (a, b) { return b.spend - a.spend; });
    return { rows: rows, total: tot, valueType: valueType, lowN: !valueType && tot.results < E.BD_MIN_RESULTS };
  };
})(typeof window !== 'undefined' ? window : this);
