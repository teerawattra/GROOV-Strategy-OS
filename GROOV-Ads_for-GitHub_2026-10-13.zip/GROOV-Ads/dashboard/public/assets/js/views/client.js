/* GROOV Ads Command Center · views/client.js
 * ------------------------------------------------------------------------------------------
 * Role: one client, the KPIs that matter (SPEC §4.3):
 *   1 header (accounts, worst decision, platform switch) · 2 objective-aware KPI strip with
 *   benchmarks, portfolio medians and the cost-per-result bridge; every tile has its trend line
 *   and opens an expanded chart under its strip (SPEC §4.7, views/trends.js) · 3 what we know
 *   (learning log, context, open questions) · 4 playbook checks · pacing + creative pipeline ·
 *   5 decisions · where results happen (SPEC §4.8, views/adset.js) · 6 trends (small multiples) ·
 *   7 hierarchical campaigns table (ad set rows: "% of results", click opens the ad set panel) ·
 *   8 creative wall · 9 monthly history · 10 notes
 * Public: GROOV.views.client.render(ctx). Handlers: cp (platform switch), trend-mode,
 *   superseded-toggle.
 * The platform switch changes only this view; sidebar filters still apply.
 */
(function (root) {
  'use strict';
  var G = root.GROOV = root.GROOV || {};
  var U = G.util, D = G.data, E = G.engine, M = G.model, C = G.charts, UI = G.ui;
  var V = G.views = G.views || {};
  var A = G.actions = G.actions || {};
  var esc = U.esc;

  function common() { return V.common; }

  V.client = {
    render: function (ctx) {
      var st = ctx.state, snap = ctx.snap, P = snap.P;
      var slug = st.route.slug;
      var cp = st.ui.clientPlatform || 'all';
      var d = M.clientDetail(snap, ctx.ds, slug, cp);
      if (!d) {
        return '<div class="page"><section class="panel"><h1>Client not found</h1><p class="empty">No client matches “' + esc(slug) + '”. <a href="#/overview">Back to the overview</a>.</p></section></div>';
      }
      var out = ['<div class="page client">'];
      out.push(header(ctx, d, cp));
      if (!P.cur) {
        out.push('<section class="panel"><p class="empty">No data in this period.</p></section></div>');
        return out.join('');
      }
      if (!d.camps.length) {
        var why = d.hiddenByScope ? d.hiddenByScope + ' ' + U.plural(d.hiddenByScope, 'campaign') + ' hidden by the sidebar filters. <button type="button" class="btn ghost sm" data-act="reset-filters">Reset filters</button>' :
          (cp !== 'all' ? 'No ' + esc(D.PLATFORM_LABEL[cp]) + ' delivery in this period or the comparison.' : 'No delivery in ' + esc(P.label) + (P.cmp ? ' or ' + esc(P.cmpLabel) : '') + '.');
        out.push('<section class="panel"><p class="empty">' + why + '</p></section>');
        out.push(knowledge(ctx, d));
        out.push('</div>');
        return out.join('');
      }
      out.push(kpiStrip(ctx, d));
      out.push('<div class="grid2">' + knowledge(ctx, d) + '<div class="stack">' + checksPanel(ctx, d) + pacingPanel(ctx, d) + pipelinePanel(ctx, d) + '</div></div>');
      out.push(decisionsPanel(ctx, d));
      out.push(V.adset.where(ctx, d));
      out.push(trends(ctx, d));
      out.push(campaignsTable(ctx, d));
      out.push('<section class="panel"><div class="panel-h"><h2>Creative wall</h2><p>This client only · same tabs and rules as the Creatives page</p></div>' +
        V.creativeWall(ctx, V.creativeAds(ctx, slug).filter(function (a) { return cp === 'all' || a.platform === cp; }), { slug: slug, limitPerGroup: 8 }) + '</section>');
      out.push(monthlyPanel(ctx, d, cp));
      out.push(notesFor(ctx, d));
      out.push('</div>');
      return out.join('');
    }
  };

  /* ---------- 1. header ---------- */
  function header(ctx, d, cp) {
    var snap = ctx.snap, P = snap.P, c = d.client;
    var accts = (c.accounts || []).map(function (ai) { return ctx.ds.accounts[ai]; });
    var seen = {};
    accts.forEach(function (a) { seen[D.acctKey(a.platform, a.id)] = 1; });
    var regOnly = (c.registryAccounts || []).filter(function (a) { return !seen[a.key]; });
    var chips = accts.map(function (a) {
      return '<span class="achip">' + UI.pchip(a.platform) + '<b>' + esc(a.name) + '</b><small class="mono">' + esc(a.id) + '</small></span>';
    }).concat(regOnly.map(function (a) {
      return '<span class="achip off" data-tip="In the registry but no rows in the loaded data">' + UI.pchip(a.platform) + '<b>' + esc(a.name) + '</b><small class="mono">' + esc(a.id) + '</small></span>';
    })).join('');
    var plats = U.uniq(accts.map(function (a) { return a.platform; }));
    plats.sort(function (a, b) { return D.PLATFORMS.indexOf(a) - D.PLATFORMS.indexOf(b); });
    var seg = '<div class="seg" role="group" aria-label="Platform (this view only)">' + ['all'].concat(plats).map(function (p) {
      var on = cp === p;
      return '<button type="button" class="' + (on ? 'on' : '') + '" aria-pressed="' + on + '" data-act="cp" data-v="' + p + '">' + esc(p === 'all' ? 'All' : D.PLATFORM_LABEL[p]) + '</button>';
    }).join('') + '</div>';
    var pin = (ctx.state.pinned || []).indexOf(d.slug) >= 0;
    return '<header class="client-h"><div class="ch-main"><div class="eyebrow">Client' + (c.unmapped ? ' · not in the registry' : '') + '</div>' +
      '<h1>' + esc(c.name) + ' <button type="button" class="pin big' + (pin ? ' on' : '') + '" data-act="pin" data-v="' + esc(d.slug) + '" aria-pressed="' + pin + '" aria-label="' + (pin ? 'Unpin' : 'Pin') + ' this client">' + (pin ? '★' : '☆') + '</button></h1>' +
      '<div class="ch-tags">' + UI.vtag(c.vertical) + (c.owner ? ' <span class="vtag">Owner: ' + esc(c.owner) + '</span>' : '') + '</div>' +
      '<div class="achips">' + (chips || '<span class="muted">No accounts in the loaded data.</span>') + '</div></div>' +
      '<div class="ch-side">' + UI.dbadge(d.decision) + '<div class="ch-period"><b>' + esc(P.label) + '</b>' + (P.cmp ? '<span>vs ' + esc(P.cmpLabel) + (P.noBaseline ? ' · no baseline' : '') + '</span>' : '') + '</div>' +
      seg + (c.unmapped ? '<p class="warnt small">Unmapped: add this account to Ads/accounts/registry.json.</p>' : '') + '</div></header>';
  }

  /* ---------- 2. KPI strip ---------- */
  function k(label, value, delta, o) {
    o = o || {};
    return UI.kpi({ label: esc(label), value: value, delta: delta, sub: o.sub, foot: o.foot, cls: o.cls });
  }
  var SPEND_STRIP = [{ kpi: 'spend', label: 'Spend' }, { kpi: 'impressions', label: 'Impressions' }, { kpi: 'link_ctr', label: 'Link CTR' }, { kpi: 'cpm', label: 'CPM' }];

  /** Spend strip + one strip per objective group. Every tile has its trend line and opens the big chart under its strip. */
  function kpiStrip(ctx, d) {
    var snap = ctx.snap, P = snap.P, cp = ctx.state.ui.clientPlatform || 'all', TR = V.trend;
    var out = ['<section class="panel"><div class="panel-h"><h2>KPIs that matter</h2><p>Objective-aware · every change vs ' + (P.cmp ? esc(P.cmpLabel) : 'no comparison') +
      ' · lines: ' + (TR.gran(ctx) === 'weekly' ? 'weekly' : 'daily') + ', dashed = comparison by day number · click a tile for its chart</p></div>'];
    // Spend first, with share by platform
    var tot = d.cur.spend;
    var shareBar = '<div class="sharebar" aria-hidden="true">' + D.PLATFORMS.filter(function (p) { return d.byPlatform[p] && d.byPlatform[p].spend > 0; }).map(function (p) {
      return '<i style="width:' + (d.byPlatform[p].spend / tot * 100).toFixed(1) + '%;background:var(--' + p + ')"></i>';
    }).join('') + '</div>';
    var shareTxt = D.PLATFORMS.filter(function (p) { return d.byPlatform[p] && d.byPlatform[p].spend > 0; }).map(function (p) {
      return esc(D.PLATFORM_LABEL[p]) + ' ' + esc(U.pct(d.byPlatform[p].spend / tot * 100, 0));
    }).join(' · ');
    var scope = { id: 'cs', key: 'cl:' + d.slug + ':' + cp, title: d.name + (cp !== 'all' ? ' · ' + (D.PLATFORM_LABEL[cp] || cp) : ''), camps: d.camps, cur: d.cur, cmp: d.cmp,
      client: d.client, vertical: d.vertical, splits: M.TREND_SPLITS, items: SPEND_STRIP };
    out.push('<div class="kstrip">' + SPEND_STRIP.map(function (it) {
      if (it.kpi === 'spend') {
        return TR.kpiTile(ctx, scope, it, { value: '<span data-tip="' + esc(U.money(d.cur.spend, { exact: true })) + '">' + esc(U.money(d.cur.spend)) + '</span>',
          sub: tot > 0 ? shareBar + '<small>' + shareTxt + '</small>' : '', cls: 'spend' });
      }
      if (it.kpi === 'link_ctr') return TR.kpiTile(ctx, scope, it, { value: common().linkCtrCell(d.k) });
      return TR.kpiTile(ctx, scope, it);
    }).join('') + '</div>' + TR.panel(ctx, scope));
    d.groups.forEach(function (g) { out.push(groupBlock(ctx, d, g, cp)); });
    if (P.provisional) out.push('<p class="prov-note">Includes provisional days ' + esc(U.rangeLabel(P.provisional.from, P.provisional.to)) + ' (shaded on every line): late conversions can still change these numbers.</p>');
    out.push('</section>');
    return out.join('');
  }

  /** One objective group: the KPIs that matter for it (views/trends.js TILES), with foots for benchmarks and medians. */
  function groupBlock(ctx, d, g, cp) {
    var snap = ctx.snap, kc = g.k, TR = V.trend;
    var plats = g.platforms.map(UI.pchip).join('');
    var foots = {};
    if (g.type === 'Messages') foots.cpmsg = benchFoot(common().benchFor(ctx.learn, 'Messages', d.vertical, g.platforms), kc.cpmsg) + medianFoot(g, kc.cpmsg);
    else if (g.type === 'Lead generation') foots.cpl = benchFoot(common().benchFor(ctx.learn, 'Lead generation', d.vertical, g.platforms), kc.cpl) + medianFoot(g, kc.cpl);
    else if (g.type === 'Awareness') {
      foots.cpm_aw = g.perPlatform.map(function (pp) {
        var b = common().benchFor(ctx.learn, 'Awareness', d.vertical, [pp.platform]);
        return b ? '<div>' + UI.pchip(pp.platform) + ' ' + esc(U.money(pp.k.cpm)) + ' ' + benchFoot(b, pp.k.cpm, true) + '</div>' : '';
      }).join('') + medianFoot(g, kc.cpm);
    } else if (g.type === 'Traffic') foots.cpc = medianFoot(g, kc.cpc_link);
    else if (g.type === 'Engagement') foots.cpv = medianFoot(g, kc.cpv);
    else if (g.type === 'Conversions') foots.cpa = medianFoot(g, kc.cpa);
    var title = E.TYPE_LABEL[g.type] || g.type;
    var items = TR.TILES[g.type] || [];
    var scope = { id: 'cg-' + U.slugify(g.type), key: 'cl:' + d.slug + ':' + cp + ':' + g.type, title: d.name + ' · ' + title, camps: g.rows, cur: g.cur, cmp: g.cmp,
      type: g.type, objective: g.objective, platforms: g.platforms, client: d.client, vertical: d.vertical, splits: M.TREND_SPLITS, items: items };
    var tiles = items.map(function (it) { return TR.kpiTile(ctx, scope, it, { foot: foots[it.kpi] || '' }); });
    var target = common().targetFor(d.client, g.objective, g.type);
    var tgt = '';
    if (target) {
      var pc = E.primary(g.objective, g.platform, kc);
      tgt = '<p class="tgt">Target ' + esc(pc.costLabel) + ' ' + esc(U.moneyRound(target)) + ' (registry): ' + (common().targetTick(pc.cost, target, pc.lowerBetter) || U.DASH) + '</p>';
    }
    return '<div class="ogroup"><h3 class="og-h">' + esc(title) + ' <span class="muted">' + esc(U.pct(g.share * 100, 0)) + ' of spend · ' + g.rows.length + ' ' +
      U.plural(g.rows.length, 'campaign') + '</span> ' + plats + '</h3><div class="kstrip">' + tiles.join('') + '</div>' + TR.panel(ctx, scope) + tgt + bridge(g, snap) + '</div>';
  }
  function benchFoot(b, value, inline) {
    if (!b) return '';
    var range = +b.low === +b.high ? U.moneyRound(+b.low) : U.moneyRound(+b.low) + '–' + U.moneyRound(+b.high);
    var lab = (E.benchIsTarget(b) ? 'Target ' : 'Observed ') + range;
    var bar = G.charts.rangeBar({ low: +b.low, high: +b.high, value: value });
    return '<div class="bench">' + (inline ? '' : bar) + '<span>' + esc(lab) + ' · ' + UI.lchip(b.source, b.label) + ' · ' + UI.confBadge(b.confidence) + ' ' +
      G.views.common.benchTick(value, b) + '</span></div>';
  }
  function medianFoot(g, value) {
    var bits = g.perPlatform.filter(function (pp) { return pp.portfolio && pp.portfolio.n >= 2; }).map(function (pp) {
      return UI.pchip(pp.platform) + ' ' + esc(U.money(pp.portfolio.median)) + ' <small>(' + pp.portfolio.n + ' clients)</small>';
    });
    if (!bits.length) return '';
    return '<div class="median"><span class="muted">Portfolio median, this period:</span> ' + bits.join(' ') + '</div>';
  }
  function bridge(g, snap) {
    if (g.type !== 'Messages' && g.type !== 'Lead generation') return '';
    if (!snap.B) return '';
    var b = g.bridge;
    if (!b.ok) return '<p class="bridge na">Cost-per-result bridge: ' + esc(b.reason || 'not available') + '</p>';
    var max = Math.max.apply(null, b.drivers.map(function (x) { return Math.abs(x.contribution); }).concat([Math.abs(b.total), 1]));
    var bars = b.drivers.map(function (x) {
      var w = Math.abs(x.contribution) / max * 50;
      var bad = x.contribution > 0;
      return '<div class="br-r"><span class="br-l">' + esc(x.label) + ' <b>' + esc(U.deltaText(x.change)) + '</b></span><span class="br-b"><i class="' + (bad ? 'bad' : 'good') + '" style="' +
        (bad ? 'left:50%' : 'right:50%') + ';width:' + w.toFixed(1) + '%"></i></span><span class="br-v">' + esc((x.contribution >= 0 ? '+' : '−') + Math.abs(x.contribution).toFixed(0) + ' pts') + '</span></div>';
    }).join('');
    var lead = esc(b.label) + ' ' + esc(U.deltaText(b.total)) + ', driven by: ' + b.drivers.map(function (x) { return esc(x.label + ' ' + U.deltaText(x.change)); }).join(' · ');
    return '<div class="bridge"><p><b>Cost-per-result bridge.</b> ' + lead + (b.offset ? ' (the drivers offset each other)' : '') + '</p>' + bars +
      '<p class="muted small">Contributions are logarithmic shares of the total change, so they add up to it. Positive points raise the cost.</p></div>';
  }

  /* ---------- 3. what we know ---------- */
  function knowledge(ctx, d) {
    var L = ctx.learn || {}, log = Array.isArray(L.log) ? L.log : [], st = ctx.state;
    var name = d.client.name, vert = d.vertical;
    var mine = log.filter(function (e) { return (e.clients || []).some(function (c) { return U.eqi(c, name); }); });
    var vertE = log.filter(function (e) { return mine.indexOf(e) < 0 && (e.verticals || []).some(function (v) { return U.eqi(v, vert); }); });
    var isOld = function (e) { return /^(Superseded|Rejected)/i.test(String(e.status || '')); };
    var showOld = st.ui.showSuperseded;
    var old = mine.concat(vertE).filter(isOld);
    var entry = function (e) {
      return '<li class="log' + (isOld(e) ? ' old' : '') + '"><div class="log-h">' + UI.lchip(e.id) + ' <small class="muted">' + esc(U.fmtDate(e.date)) + '</small> ' + UI.confBadge(e.confidence) +
        (isOld(e) ? ' <span class="vtag">' + esc(e.status) + '</span>' : '') + '</div><b>' + UI.mdInline(e.title) + '</b>' + (e.next ? '<p><em>Next</em> ' + UI.mdInline(e.next) + '</p>' : '') + '</li>';
    };
    var list = function (arr) { return arr.filter(function (e) { return showOld || !isOld(e); }).map(entry).join(''); };
    var objs = d.groups ? d.groups.map(function (g) { return g.objective; }) : [];
    var context = (L.rules && Array.isArray(L.rules.context) ? L.rules.context : []).filter(function (c) {
      return (c.verticals || []).some(function (v) { return U.eqi(v, vert); }) || (c.objectives || []).some(function (o) { return objs.indexOf(o) >= 0; });
    });
    var ids = mine.concat(vertE).map(function (e) { return e.id; });
    var qs = (L.playbook && Array.isArray(L.playbook.open_questions) ? L.playbook.open_questions : []).filter(function (q) {
      var t = String(q).toLowerCase();
      return (vert && vert !== 'Unmapped' && t.indexOf(String(vert).toLowerCase()) >= 0) || t.indexOf(name.toLowerCase()) >= 0 ||
        ids.some(function (id) { return t.indexOf(id.toLowerCase()) >= 0; });
    });
    var out = ['<section class="panel know"><div class="panel-h"><h2>What we know</h2><p>From the learning log · Observation = seen once, not a promise</p></div>'];
    var a = list(mine), b = list(vertE);
    if (a) out.push('<h3 class="sub-h">About ' + esc(name) + '</h3><ul class="logs">' + a + '</ul>');
    if (b) out.push('<h3 class="sub-h">' + esc(vert) + ' vertical</h3><ul class="logs">' + b + '</ul>');
    if (!a && !b) out.push('<p class="muted">No log entry names this client or its vertical yet.</p>');
    if (old.length) out.push('<button type="button" class="btn ghost xs" data-act="superseded-toggle">' + (showOld ? 'Hide' : 'Show') + ' superseded / rejected (' + old.length + ')</button>');
    if (context.length) out.push('<h3 class="sub-h">Context</h3><ul class="ctxl">' + context.map(function (c) { return '<li>' + esc(c.text) + ' ' + UI.lchip(c.source) + '</li>'; }).join('') + '</ul>');
    if (qs.length) out.push('<h3 class="sub-h">To test next</h3><ul class="ctxl">' + qs.map(function (q) { return '<li>' + esc(q) + '</li>'; }).join('') + '</ul>');
    out.push('</section>');
    return out.join('');
  }

  /* ---------- 4. playbook checks, pacing, pipeline ---------- */
  function checksPanel(ctx, d) {
    var hits = d.flags || [];
    var body = hits.length ? '<ul class="hits">' + hits.map(function (h) {
      var sev = h.check.severity || 'Watch Out';
      var cls = sev === 'Opportunity' || sev === 'Ready to Scale' ? 'scale' : sev === 'Immediate Action' ? 'imm' : 'watch';
      var target = h.adRow ? h.adRow.name : h.campaignRow ? h.campaignRow.name : 'whole client';
      return '<li><div class="hit-h"><span class="sev ' + cls + '">' + esc(sev) + '</span> ' + UI.lchip(h.check.source, h.check.title) + ' <b>' + esc(h.check.title || h.check.id) + '</b></div>' +
        '<p class="muted small">' + esc(target) + ' · ' + esc(U.money(h.spend)) + ' spend · ' + esc(M.checkMetricText(h.check, h)) + '</p>' +
        '<p>' + esc(h.check.message || '') + '</p><p class="act"><em>Action</em> ' + esc(h.check.action || '') + '</p></li>';
    }).join('') + '</ul>' : '<p class="muted">No playbook rule triggered.</p>';
    return '<section class="panel"><div class="panel-h"><h2>Playbook checks</h2><p>Live checks from rules.json</p></div>' + body + '</section>';
  }
  function pacingPanel(ctx, d) {
    var pc = d.pacing;
    if (!pc) return '';
    return '<section class="panel"><div class="panel-h"><h2>Pacing</h2><p>' + esc(U.monthLabel(ctx.snap.P.T.slice(0, 7))) + ' · projected = MTD + trailing 7-day average × days left</p></div>' +
      '<div class="kstrip">' + k('Budget', esc(U.money(pc.budget)), '') + k('MTD spend', esc(U.money(pc.mtd)), '') +
      k('Projected month-end', esc(U.money(pc.projected)), '', { sub: common().pacingCell(pc) + ' <small>' + esc(pc.label) + '</small>' }) + '</div>' +
      (pc.partial ? '<p class="muted small">History starts after the 1st, so MTD is incomplete.</p>' : '') + '</section>';
  }
  function pipelinePanel(ctx, d) {
    var p = d.pipeline;
    var share = p.knowable ? (p.oldShare === null ? U.DASH : U.pct(p.oldShare * 100, 0)) : U.DASH;
    return '<section class="panel"><div class="panel-h"><h2>Creative pipeline</h2><p>From each ad’s first and last delivery date</p></div><div class="kstrip">' +
      k('Delivering ads', esc(U.int(p.active)), '') + k('Launched in the last 14 days', esc(U.int(p.new14)), '') +
      k('Spend on ads older than 28 days', esc(share), '', { sub: p.knowable ? '' : '<small>Needs 28+ days of history before the period end</small>' }) + '</div>' +
      (p.refreshDue ? '<p class="warnt">Refresh due: ≥ 70% of spend is on ads older than 28 days and nothing launched in 14 days.</p>' : '') + '</section>';
  }

  /* ---------- 5. decisions ---------- */
  function decisionsPanel(ctx, d) {
    var deliv = d.camps.filter(function (r) { return r.delivering; });
    var rest = d.camps.filter(function (r) { return !r.delivering; });
    var counts = E.DECISIONS.map(function (lab) {
      var n = d.camps.filter(function (r) { return r.decision.label === lab; }).length;
      return '<span class="dc ' + E.CLS[lab] + '">' + UI.ddot(lab) + '<b>' + n + '</b> ' + esc(lab) + '</span>';
    }).join('');
    var block = function (lab, title) {
      var rows = d.camps.filter(function (r) { return r.decision.label === lab; }).sort(function (a, b) { return b.cur.spend - a.cur.spend || b.cmp.spend - a.cmp.spend; });
      if (!rows.length) return '';
      return '<h3 class="sub-h">' + esc(title) + ' <span class="muted">· ' + rows.length + '</span></h3><div class="dlist">' + rows.slice(0, 6).map(function (r) {
        return '<article class="ditem ' + E.CLS[lab] + '"><div class="di-h">' + UI.dbadge(lab) + ' <b>' + esc(r.name) + '</b> ' + UI.pchip(r.platform) + ' <span class="otag">' + esc(r.objective) + '</span>' +
          (r.decision.variant === 'entity' ? ' <small class="muted">(no delivery this period: status-aware rule)</small>' : '') + '</div>' + UI.evidence(r.evidence, ctx.snap.P.noBaseline) +
          '<p class="why"><em>Why</em> ' + esc(r.decision.why) + '</p><p class="act"><em>Action</em> ' + esc(r.decision.action) + '</p></article>';
      }).join('') + (rows.length > 6 ? '<p class="muted small">+ ' + (rows.length - 6) + ' more in the campaigns table below.</p>' : '') + '</div>';
    };
    return '<section class="panel"><div class="panel-h"><h2>Decisions</h2><p>' + deliv.length + ' delivering ' + U.plural(deliv.length, 'campaign') +
      (rest.length ? ' · ' + rest.length + ' only in the comparison period' : '') + '</p></div><div class="dcounts">' + counts + '</div>' +
      block('Immediate Action', 'Immediate Action') + block('Watch Out', 'Watch Out') + block('Ready to Scale', 'Opportunities (Ready to Scale)') + '</section>';
  }

  /* ---------- 6. trends ---------- */
  function trends(ctx, d) {
    var mode = ctx.state.ui.trendMode === 'campaigns' ? 'campaigns' : 'platform';
    var T = M.trendSeries(ctx.snap, d, mode);
    var prim = d.primary;
    var P = ctx.snap.P;
    var sw = '<div class="seg" role="group" aria-label="Split trends by">' + [['platform', 'By platform'], ['campaigns', 'Top 5 campaigns']].map(function (x) {
      return '<button type="button" class="' + (mode === x[0] ? 'on' : '') + '" aria-pressed="' + (mode === x[0]) + '" data-act="trend-mode" data-v="' + x[0] + '">' + esc(x[1]) + '</button>';
    }).join('') + '</div>';
    if (!T.series.length) return '';
    var resLabel = prim ? (prim.type === 'Conversions·value' ? 'Purchase value (Meta)' : prim.resultLabel) : 'Results';
    var lineFmt = prim && prim.type === 'Conversions·value' ? 'money' : 'count';
    var costFmt = prim && prim.costFmt === 'ratio' ? 'ratio' : 'money';
    var combo = { type: 'combo', title: 'Daily spend and ' + resLabel, days: T.days, provisional: P.provisional, barLabel: 'Spend (฿)', lineLabel: resLabel, lineFmt: lineFmt,
      bars: T.series.map(function (s) { return { label: s.label, color: s.color, values: s.spend }; }),
      lines: T.series.filter(function (s) { return s.hasTyped; }).map(function (s) { return { label: s.label, color: s.color, values: s.results }; }) };
    var cost = { type: 'lines', title: 'Daily ' + (prim ? prim.costLabel : 'cost per result'), days: T.days, provisional: P.provisional, fmt: costFmt, height: 200,
      emptyText: 'No days with results in this period.', series: T.series.filter(function (s) { return s.hasTyped; }).map(function (s) { return { label: s.label, color: s.color, values: s.costs }; }) };
    var legend = '<div class="legend">' + T.series.map(function (s) { return '<span class="lg"><i class="sw" style="background:' + s.color + '"></i>' + esc(s.label) + '</span>'; }).join('') +
      (P.provisional ? '<span class="lg"><i class="sw prov"></i>Provisional</span>' : '') + '</div>';
    var rows = T.days.map(function (day, i) {
      return '<tr><th scope="row">' + esc(U.fmtDate(day)) + '</th>' + T.series.map(function (s) {
        return '<td class="num">' + esc(U.money(s.spend[i])) + '</td><td class="num">' + esc(s.hasTyped ? (lineFmt === 'money' ? U.money(s.results[i]) : U.count(s.results[i])) : U.DASH) + '</td><td class="num">' +
          esc(s.hasTyped && U.isNum(s.costs[i]) ? (costFmt === 'ratio' ? U.ratioX(s.costs[i]) : U.money(s.costs[i])) : U.DASH) + '</td>';
      }).join('') + '</tr>';
    }).join('');
    var table = '<details class="tview"><summary>Table view</summary><div class="tbl-wrap"><table class="tbl"><thead><tr><th scope="col">Day</th>' + T.series.map(function (s) {
      return '<th scope="col" class="num">' + esc(s.label) + ' spend</th><th scope="col" class="num">' + esc(resLabel) + '</th><th scope="col" class="num">' + esc(prim ? prim.costLabel : 'Cost') + '</th>';
    }).join('') + '</tr></thead><tbody>' + rows + '</tbody></table></div></details>';
    return '<section class="panel"><div class="panel-h"><h2>Trends</h2><p>Current period · primary result: ' + esc(resLabel) + (mode === 'campaigns' ? ' · top 5 campaigns by spend' : '') + '</p>' + sw + '</div>' +
      '<div class="grid2 tight"><div>' + C.slot(combo) + '</div><div><h3 class="sub-h">Daily ' + esc(prim ? prim.costLabel : 'cost per result') + '</h3>' + C.slot(cost) +
      '<p class="muted small">Gaps are days without results: a missing cost is never drawn as ฿0.</p></div></div>' + legend + table + '</section>';
  }

  /* ---------- 7. campaigns table ---------- */
  function campaignsTable(ctx, d) {
    var snap = ctx.snap, st = ctx.state, nb = snap.P.noBaseline, F = snap.F;
    var rf = M.rowFilter(F);
    var keep = function (r) { return rf(r); };
    var top = d.camps.filter(keep);
    // "% of results" (SPEC §4.8.3): an ad set's share of this client's results for its result type
    var share = M.resultShare(d.camps);
    var shareOf = function (r) { return r.level === 'adset' ? share(r) : null; };
    var nameHtml = function (r) {
      var lvl = r.level === 'campaign' ? '' : '<small class="lvl">' + (r.level === 'adset' ? (r.platform === 'meta' ? 'Ad set' : 'Ad group') : 'Ad') + '</small> ';
      var nm = r.level === 'adset' ? '<button type="button" class="en linkb" data-act="adset-open" data-v="' + esc(r.key) + '" data-tip="Open the ' +
        (r.platform === 'meta' ? 'ad set panel: KPI trends, placements and audiences' : 'ad group panel: KPI trends') + '">' + esc(r.name) + '</button>' : '<b class="en">' + esc(r.name) + '</b>';
      return lvl + nm + (r.isNew ? ' ' + UI.newBadge() : '') + (r.level === 'campaign' ? ' ' + UI.pchip(r.platform) : '') +
        (r.first_date === null && r.last_date === null ? ' <small class="muted">never delivered</small>' : '');
    };
    var flagsHtml = function (r) {
      var f = r.flags || [];
      if (!f.length) return '';
      var bySrc = {};
      f.forEach(function (h) { var s = h.check.source || h.check.id; bySrc[s] = (bySrc[s] || 0) + 1; });
      return Object.keys(bySrc).map(function (s) { return UI.lchip(s, bySrc[s] + ' playbook hit' + (bySrc[s] > 1 ? 's' : '')); }).join(' ');
    };
    var cols = [
      { key: 'name', label: 'Campaign ▸ Ad set ▸ Ad', cls: 'wide', sort: function (r) { return r.name; }, html: nameHtml },
      { key: 'status', label: 'Status', sort: function (r) { return r.status; }, html: function (r) { return UI.statusBadge(r.status, r.rawStatus); } },
      { key: 'objective', label: 'Objective', sort: function (r) { return r.objective; }, html: function (r) { return '<span class="otag">' + esc(E.TYPE_LABEL[r.prim.type] || r.objective) + '</span>'; } },
      { key: 'spend', label: 'Spend', num: true, sort: function (r) { return r.cur.spend; }, html: function (r) { return esc(U.money(r.cur.spend)); } },
      { key: 'dspend', label: 'Δ', num: true, sort: function (r) { return U.pctChange(r.cur.spend, r.cmp.spend); }, html: function (r) { return UI.delta(U.pctChange(r.cur.spend, r.cmp.spend), { good: 'neutral', noBaseline: nb }); } },
      { key: 'results', label: 'Results', num: true, sort: function (r) { return r.prim.result; }, html: function (r) {
        return '<span class="v">' + esc(UI.resultText(r.prim, r.prim.result)) + '</span><small class="pl">' + esc(r.prim.type === 'Conversions·value' ? 'value' : r.prim.resultLabel) + '</small>';
      } },
      { key: 'rshare', label: '% of results', num: true, sort: shareOf, title: 'Ad set rows: the share of this client’s results for that objective that came from the ad set (campaigns in view)',
        html: function (r) {
          if (r.level !== 'adset') return '';
          var s = shareOf(r);
          return U.isNum(s) ? '<span class="v">' + esc(M.shareText(s)) + '</span>' : '<span class="na">' + U.DASH + '</span>';
        } },
      { key: 'cost', label: 'Cost/result', num: true, sort: function (r) { return r.prim.cost; }, html: function (r) {
        return esc(UI.costText(r.prim, r.prim.cost)) + (U.isNum(r.prim.n) && r.prim.type !== 'Awareness' ? ' <small class="n">n=' + esc(U.count(r.prim.n)) + '</small>' : '');
      } },
      { key: 'dcost', label: 'Δ', num: true, sort: function (r) { return U.pctChange(r.prim.cost, r.primPrev.cost); }, html: function (r) {
        return UI.delta(U.pctChange(r.prim.cost, r.primPrev.cost), { good: r.prim.lowerBetter ? 'down' : 'up', noBaseline: nb, lowN: r.prim.n !== null && E.lowN(r.prim.n, r.primPrev.n) });
      } },
      { key: 'ctr', label: 'CTR', num: true, sort: function (r) { return r.k.ctr; }, html: function (r) { return esc(U.pct(r.k.ctr)); }, title: 'All clicks ÷ impressions' },
      { key: 'lctr', label: 'Link CTR', num: true, sort: function (r) { return r.k.link_ctr; }, html: function (r) { return common().linkCtrCell(r.k); }, title: 'Link clicks ÷ impressions' },
      { key: 'cpm', label: 'CPM', num: true, sort: function (r) { return r.k.cpm; }, html: function (r) { return esc(U.money(r.k.cpm)); } },
      { key: 'freq', label: 'Freq/day', num: true, sort: function (r) { return r.k.freq; }, html: function (r) { return esc(U.ratioX(r.k.freq)); }, title: 'Impressions ÷ sum of daily reach (average daily frequency)' },
      { key: 'decision', label: 'Decision', sort: function (r) { return E.SEV[r.decision.label]; }, html: function (r) {
        return UI.dbadge(r.decision.label, { why: r.decision.why, action: r.decision.action, evidence: r.evidence, short: true });
      } },
      { key: 'flags', label: 'Flags', sort: function (r) { return (r.flags || []).length; }, html: flagsHtml }
    ];
    var def = {
      id: 'campaigns', caption: 'Campaigns', csvName: 'campaigns-' + d.slug, rows: top, columns: cols, textCols: ['name', 'status', 'objective'],
      children: function (r) {
        if (r.level === 'campaign') {
          var sets = r.adsetRows.filter(keep);
          if (sets.length) return sets;
          return r.adRows.filter(keep);
        }
        if (r.level === 'adset') return r.adRows.filter(keep);
        return [];
      },
      rowKey: function (r) { return r.level + ':' + r.key; },
      rowLabel: function (r) { return r.name; },
      rowClass: function (r) { return (r.status !== 'ACTIVE' ? 'dim ' : '') + 'lv-' + r.level; },
      rowAct: function (r) { return r.level === 'adset' ? { act: 'adset-open', v: r.key } : null; },
      levelName: function (r) { return r.level === 'campaign' ? 'Campaign' : r.level === 'adset' ? 'Ad set / ad group' : 'Ad'; },
      sort: st.ui.sorts.campaigns || { key: 'spend', dir: 'desc' },
      expanded: ctx.app.expanded('campaigns'),
      empty: 'No campaign matches the current filters.',
      csvHeader: ['Name', 'Platform', 'Status', 'Objective', 'Spend', 'Spend (comparison)', 'Spend Δ%', 'Result type', 'Results', 'Results (comparison)', '% of client results (ad sets)',
        'Cost per result', 'Cost per result (comparison)', 'Cost Δ%', 'n', 'CTR %', 'Link CTR %', 'CPM', 'Avg daily frequency', 'Decision', 'Why', 'Action', 'Playbook flags', 'First date', 'Last date'],
      csvRow: function (r) {
        var s = shareOf(r);
        return [r.name, D.PLATFORM_LABEL[r.platform], r.status, r.objective, r.cur.spend, r.cmp.spend, U.pctChange(r.cur.spend, r.cmp.spend), E.TYPE_LABEL[r.prim.type] || r.prim.type,
          r.prim.result, r.primPrev.result, U.isNum(s) ? s * 100 : null, r.prim.cost, r.primPrev.cost, U.pctChange(r.prim.cost, r.primPrev.cost), r.prim.n, r.k.ctr, r.k.link_ctr, r.k.cpm, r.k.freq,
          r.decision.label, r.decision.why, r.decision.action, (r.flags || []).map(function (h) { return h.check.source; }).join(' '), r.first_date || '', r.last_date || ''];
      }
    };
    var hidden = d.camps.length - top.length;
    return '<section class="panel"><div class="panel-h"><h2>Campaigns</h2><p>' + top.length + ' shown' + (hidden ? ' · ' + hidden + ' hidden by row filters' : '') +
      ' · paused items with spend are dimmed · decisions: hover or tap the badge · click an ad set for its panel</p><div class="tools">' +
      '<button type="button" class="btn ghost sm" data-act="tbl-expand-all" data-tbl="campaigns">Expand all</button>' +
      '<button type="button" class="btn ghost sm" data-act="tbl-collapse-all" data-tbl="campaigns">Collapse all</button>' +
      '<button type="button" class="btn ghost sm" data-act="tbl-csv" data-tbl="campaigns">Export CSV</button></div></div>' + UI.table(def) + '</section>';
  }

  /* ---------- 9. monthly history ---------- */
  function monthlyPanel(ctx, d, cp) {
    var head = '<section class="panel"><div class="panel-h"><h2>Monthly history</h2><p>Last 6 months (or since the history start) · reach and frequency are not shown monthly: daily reach can’t be added into unique monthly reach</p></div>';
    if (!ctx.monthly) {
      if (ctx.monthlyError) return head + '<p class="err-t">' + esc(ctx.monthlyError) + ' <button type="button" class="btn ghost sm" data-act="monthly-retry">Retry</button></p></section>';
      G.app.loadMonthly();
      return head + '<div class="skel short"></div></section>';
    }
    var F = ctx.snap.F;
    var plats = cp && cp !== 'all' ? [cp] : (F.platforms.length ? F.platforms : null);
    var H = M.monthlyFor(ctx.monthly, d.slug, { platforms: plats, dataThrough: ctx.meta.data_through, historyFrom: ctx.meta.history_from });
    if (!H.months.length || !H.months.some(function (m) { return m.spend > 0; })) return head + '<p class="muted">No monthly rows for this client.</p></section>';
    var mtdIndex = -1;
    H.months.forEach(function (m, i) { if (m.mtd) mtdIndex = i; });
    var chart = C.slot({ type: 'monthly', title: 'Monthly spend', labels: H.months.map(function (m) { return U.monthLabel(m.month).replace(/ \d{4}$/, ''); }),
      values: H.months.map(function (m) { return m.spend; }), mtdIndex: mtdIndex, height: 190 });
    var rows = H.months.slice().reverse().map(function (m) {
      var p = m.prim;
      return '<tr><th scope="row">' + esc(U.monthLabel(m.month)) + (m.mtd ? ' <span class="vtag">MTD</span>' : '') + '</th><td class="num">' + esc(U.money(m.spend)) + '</td><td class="num">' +
        UI.delta(m.dSpend, { good: 'neutral' }) + '</td><td>' + esc(p ? (E.TYPE_LABEL[m.type] || m.type) : U.DASH) + '</td><td class="num">' + esc(p ? UI.resultText(p, p.result) : U.DASH) +
        '</td><td class="num">' + esc(p ? UI.costText(p, p.cost) : U.DASH) + (p && U.isNum(p.n) ? ' <small class="n">n=' + esc(U.count(p.n)) + '</small>' : '') + '</td><td class="num">' +
        UI.delta(m.dCost, { good: p && !p.lowerBetter ? 'up' : 'down' }) + '</td></tr>';
    }).join('');
    var qs = H.quarters.map(function (q) { return '<span class="q">' + esc(q.quarter) + ' <b>' + esc(U.money(q.spend)) + '</b>' + (q.partial ? ' <small>(partial)</small>' : '') + '</span>'; }).join('');
    return head + '<div class="grid2 tight"><div>' + chart + '<div class="quarters">' + qs + '</div></div><div class="tbl-wrap"><table class="tbl"><thead><tr><th scope="col">Month</th>' +
      '<th scope="col" class="num">Spend</th><th scope="col" class="num">Δ m/m</th><th scope="col">Primary result</th><th scope="col" class="num">Results</th><th scope="col" class="num">Cost/result</th>' +
      '<th scope="col" class="num">Δ</th></tr></thead><tbody>' + rows + '</tbody></table></div></div>' +
      '<p class="muted small">The MTD month has no m/m change (it is incomplete). Cost Δ is shown only when both months have the same primary result type.</p></section>';
  }

  /* ---------- 10. notes ---------- */
  function notesFor(ctx, d) {
    var H = common().HONEST, items = [H.results, H.equal, H.dash, H.lowN, H.reach];
    if (ctx.snap.P.provisional) items.push(H.provisional);
    if (!d.k.linkKnown || d.camps.some(function (r) { return !r.k.linkKnown; })) items.push(H.link);
    if (d.groups.some(function (g) { return g.type === 'Conversions·value'; })) items.push('Meta campaigns classified as Conversions (a sales objective, or purchase ROAS on a campaign that is neither messages nor traffic) are judged on Meta-reported purchase ROAS; the data has no Meta conversion counts.');
    if (d.camps.some(function (r) { return r.platform === 'tiktok'; })) items.push('TikTok ad groups and ads inherit the campaign status in this data.');
    if (d.client.unmapped) items.push('This account is not in the registry, so it has no vertical, benchmarks or budget.');
    items.push('Decisions judge the KPIs on screen with the Hermes rules: Engagement on cost per 3-second view and view rate, Traffic on link CPC and link CTR. Campaigns use equal-period aggregates; ad sets and ads use the status-aware single-account rules.');
    items.push('Trend lines: each day (Monday–Sunday weeks beyond 45 days) is computed from that day’s sums, so a cost per result is spend ÷ results of that day, never an average of ratios; a day without a denominator is a gap. ' +
      'The dashed line is the comparison period aligned by day number; the end marker is green or red when the tile moved the good or bad way.');
    if (d.camps.some(function (r) { return r.platform === 'meta'; })) {
      items.push('Placement and audience splits come from the optional Meta breakdown exports. Shares are of the breakdown totals; “% of results” in the campaigns table uses the main Sheet. ' +
        'Works = share of results ≥ 1.2 × share of spend (≥ 3 results), Weak = ≤ 0.8 ×, Spending, no results = ≥ 10% of spend and none; under 10 results every tag is directional.');
    }
    return common().notes(items);
  }

  /* ---------- handlers ---------- */
  A.cp = function (el) { var v = el.getAttribute('data-v'); G.app.update(function (st) { st.ui.clientPlatform = v; }); };
  A['trend-mode'] = function (el) { var v = el.getAttribute('data-v'); G.app.update(function (st) { st.ui.trendMode = v; }); };
  A['superseded-toggle'] = function () { G.app.update(function (st) { st.ui.showSuperseded = !st.ui.showSuperseded; }); };
  A['monthly-retry'] = function () { G.app.loadMonthly(); };
})(typeof window !== 'undefined' ? window : this);
