/* GROOV Ads Command Center · views/playbook.js
 * ------------------------------------------------------------------------------------------
 * Role: Playbook page (SPEC §4.5): rules by vertical (confidence + evidence L-numbers), live
 * checks from rules.json with hit counts (click -> filtered action queue), benchmarks drawn as a
 * dot plot of every client's current value over the observed range, live portfolio medians,
 * the log timeline (expandable evidence) and open questions.
 * Public: GROOV.views.playbook.render(ctx), .after(ctx, el) (scrolls to ?l=L-NNN), md(text)
 * Learnings are data (window.GROOV_LEARNINGS); nothing here is hard-coded per rule.
 */
(function (root) {
  'use strict';
  var G = root.GROOV = root.GROOV || {};
  var U = G.util, D = G.data, E = G.engine, M = G.model, C = G.charts, UI = G.ui;
  var V = G.views = G.views || {};
  var esc = U.esc;

  /** Minimal, safe markdown for log evidence: escape first, then lists, `code`, **bold**. */
  V.md = function (text) {
    var lines = String(text || '').split(/\r?\n/);
    var out = [], depth = 0;
    var inline = function (s) {
      return esc(s).replace(/`([^`]+)`/g, '<code>$1</code>').replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>');
    };
    lines.forEach(function (ln) {
      var m = /^(\s*)[-*]\s+(.*)$/.exec(ln);
      if (m) {
        var lvl = Math.floor(m[1].length / 2) + 1;
        while (depth < lvl) { out.push('<ul>'); depth++; }
        while (depth > lvl) { out.push('</ul>'); depth--; }
        out.push('<li>' + inline(m[2]) + '</li>');
        return;
      }
      while (depth > 0) { out.push('</ul>'); depth--; }
      if (ln.trim()) out.push('<p>' + inline(ln) + '</p>');
    });
    while (depth > 0) { out.push('</ul>'); depth--; }
    return out.join('');
  };

  function whenText(when) {
    var parts = [];
    Object.keys(when || {}).forEach(function (k) {
      var v = when[k];
      if (k === 'spend_gte') parts.push('spend ≥ ' + U.moneyRound(+v));
      else if (k === 'ctr_all_lt') parts.push('CTR (all clicks) < ' + v + '%');
      else if (k === 'ctr_all_gt') parts.push('CTR (all clicks) > ' + v + '%');
      else if (k === 'link_ctr_lt') parts.push('link CTR < ' + v + '% (never when link clicks are unreported)');
      else if (k === 'link_ctr_gt') parts.push('link CTR > ' + v + '% (never when link clicks are unreported)');
      else if (k === 'ctr_lt') parts.push('link CTR < ' + v + '% (legacy ctr_lt)');
      else if (k === 'ctr_gt') parts.push('link CTR > ' + v + '% (legacy ctr_gt)');
      else if (k === 'cpr_gt') parts.push('cost per result > ' + U.moneyRound(+v));
      else if (k === 'frequency_gt') parts.push('avg daily frequency > ' + v + '×');
      else if (k === 'name_not_contains_any') parts.push('no campaign name contains ' + (Array.isArray(v) ? v : [v]).map(function (s) { return '“' + s + '”'; }).join(', '));
      else if (k === 'min_spend') parts.push('scope spend ≥ ' + U.moneyRound(+v));
      else parts.push(k + ' = ' + JSON.stringify(v) + ' (unsupported)');
    });
    return parts.join(' · ');
  }
  function scopeText(s) {
    s = s || {};
    var p = [];
    if (s.verticals && s.verticals.length) p.push(s.verticals.join(', '));
    if (s.platforms && s.platforms.length) p.push(s.platforms.map(function (x) { return D.PLATFORM_LABEL[x] || x; }).join(', '));
    if (s.objectives && s.objectives.length) p.push(s.objectives.join(', '));
    return p.join(' · ') || 'All';
  }

  V.playbook = {
    render: function (ctx) {
      var L = ctx.learn || {}, snap = ctx.snap;
      var out = ['<div class="page"><header class="page-h"><div><div class="eyebrow">What we’ve learned, checked against live data</div><h1>Playbook</h1></div>' +
        '<div class="scope"><span>Maintained by Claude in Ads/learnings/ · updated after each analysis · Observation = seen once, not a promise.</span>' +
        (L.generated_at ? '<span>Learnings built ' + esc(String(L.generated_at).slice(0, 10)) + '</span>' : '') + '</div></header>'];
      out.push('<div class="grid2">' + rulesPanel(L) + checksPanel(ctx, L) + '</div>');
      out.push(benchPanel(ctx, L));
      out.push('<div class="grid2">' + logPanel(ctx, L) + questionsPanel(L) + '</div>');
      if (L.source_note) out.push('<p class="muted small">' + esc(L.source_note) + '</p>');
      out.push('</div>');
      return out.join('');
    },
    after: function (ctx, el) {
      var l = ctx.state.route.params && ctx.state.route.params.l;
      if (!l || typeof document === 'undefined') return;
      var t = document.getElementById('log-' + l);
      if (t) { t.open = true; t.classList.add('flash'); setTimeout(function () { t.scrollIntoView({ block: 'center' }); }, 30); }
    }
  };

  function rulesPanel(L) {
    var secs = L.playbook && Array.isArray(L.playbook.sections) ? L.playbook.sections : [];
    var body = secs.map(function (s) {
      return '<div class="pb-sec"><h3 class="sub-h">' + esc(s.vertical) + '</h3>' + (s.rules && s.rules.length ? '<ul class="rules">' + s.rules.map(function (r) {
        return '<li>' + UI.confBadge(r.confidence) + ' ' + UI.mdInline(r.rule) + ' ' + (r.evidence || []).map(function (id) { return UI.lchip(id); }).join(' ') + '</li>';
      }).join('') + '</ul>' : '') + (s.note ? '<p class="muted small">' + esc(s.note) + '</p>' : '') + '</div>';
    }).join('');
    return '<section class="panel"><div class="panel-h"><h2>Rules by vertical</h2><p>From PLAYBOOK.md</p></div>' + (body || '<p class="muted">No playbook rules yet.</p>') + '</section>';
  }

  function checksPanel(ctx, L) {
    var snap = ctx.snap;
    var list = snap.checks || [];
    var body = list.map(function (c) {
      var chk = c.check, sev = chk.severity || 'Watch Out';
      var cls = sev === 'Opportunity' || sev === 'Ready to Scale' ? 'scale' : sev === 'Immediate Action' ? 'imm' : 'watch';
      var hits = c.hits.slice(0, 8).map(function (h) {
        var where = h.adRow ? h.clientRow.name + ' › ' + h.campaignRow.name + ' › ' + h.adRow.name : h.campaignRow ? h.clientRow.name + ' › ' + h.campaignRow.name : h.clientRow.name;
        return '<li><a href="#/client/' + encodeURIComponent(h.clientRow.slug) + '">' + esc(where) + '</a> <small class="muted">' + esc(U.money(h.spend)) +
          ' · ' + esc(M.checkMetricText(chk, h)) + '</small></li>';
      }).join('');
      return '<article class="chk"><div class="chk-h"><span class="sev ' + cls + '">' + esc(sev) + '</span> ' + UI.lchip(chk.source) + ' <b>' + esc(chk.title || chk.id) + '</b>' +
        '<a class="hitn" href="#/actions?tab=playbook&check=' + encodeURIComponent(chk.id) + '" data-tip="Open these items in the action queue">' + c.hits.length + ' ' + U.plural(c.hits.length, 'hit') + ' →</a></div>' +
        '<p class="muted small">Level: ' + esc(chk.level || 'campaign') + ' · scope: ' + esc(scopeText(chk.scope)) + ' · when: ' + esc(whenText(chk.when)) + '</p>' +
        (c.unsupported.length ? '<p class="warnt small">Unsupported predicate(s): ' + esc(c.unsupported.join(', ')) + ': this check never fires until the engine supports them.</p>' : '') +
        (c.legacy.length ? '<p class="warnt small">Legacy predicate(s) ' + esc(c.legacy.join(', ')) + ' are read as link CTR; rename them to link_ctr_* or ctr_all_* in rules.json.</p>' : '') +
        '<p>' + esc(chk.message || '') + '</p>' + (hits ? '<ul class="hitlist">' + hits + '</ul>' + (c.hits.length > 8 ? '<p class="muted small">+ ' + (c.hits.length - 8) + ' more</p>' : '') : '') + '</article>';
    }).join('');
    return '<section class="panel"><div class="panel-h"><h2>Live checks</h2><p>rules.json checks against this period, within the sidebar filters</p></div>' +
      (body || '<p class="muted">No checks defined in rules.json.</p>') + '</section>';
  }

  /** Current values for a benchmark: one dot per client (and platform) in scope. */
  function benchPoints(snap, b) {
    var metric = E.BENCH_METRICS[b.metric];
    if (!metric) return [];
    var pts = [];
    snap.clients.forEach(function (cr) {
      if (b.vertical && !U.eqi(cr.vertical, b.vertical)) return;
      var byP = {};
      cr.camps.forEach(function (r) {
        if (!r.delivering) return;
        if (metric.objective && r.objective !== metric.objective) return;
        if (b.objective && r.objective !== b.objective) return;
        if (b.platform && !U.eqi(r.platform, b.platform)) return;
        var x = byP[r.platform] || (byP[r.platform] = D.zero());
        D.addInto(x, r.cur);
      });
      Object.keys(byP).forEach(function (p) {
        var k = E.kpis(byP[p]), v = metric.get(k);
        if (!U.isNum(v)) return;
        var n = metric.objective === 'Messages' ? k.messages : metric.objective === 'Lead generation' ? k.leads : null;
        pts.push({ platform: p, label: cr.name + (b.platform ? '' : ' (' + D.PLATFORM_LABEL[p] + ')'), value: v, sub: (n !== null ? 'n=' + U.count(n) + ' · ' : '') + 'this period', slug: cr.slug });
      });
    });
    pts.sort(function (a, c) { return a.value - c.value; });
    return pts;
  }
  function benchPanel(ctx, L) {
    var snap = ctx.snap;
    var list = L.rules && Array.isArray(L.rules.benchmarks) ? L.rules.benchmarks : [];
    var blocks = list.map(function (b) {
      var metric = E.BENCH_METRICS[b.metric] || { label: b.metric, fmt: 'money' };
      var pts = benchPoints(snap, b);
      var scope = b.vertical ? b.vertical : (b.objective || '') + (b.platform ? ' · ' + (D.PLATFORM_LABEL[b.platform] || b.platform) : '');
      var type = metric.objective || b.objective;
      // Live median beside a vertical range: only when every dot comes from one platform.
      var med = null, pls = U.uniq(pts.map(function (p) { return p.platform; }));
      if (b.vertical && type && pls.length === 1) med = M.portfolioFor(snap, b.vertical, type, pls[0]);
      var spec = { type: 'dots', title: metric.label + ' · ' + scope, low: +b.low, high: +b.high, fmt: metric.fmt, points: pts, median: med ? med.median : null,
        height: 44 + Math.max(1, pts.length) * 26 };
      return '<article class="bench-b"><h3 class="sub-h">' + esc(metric.label) + ' · ' + esc(scope) + '</h3><p class="small">' + esc(b.label || '') + ' ' + UI.lchip(b.source) + ' ' + UI.confBadge(b.confidence) +
        (E.benchIsTarget(b) ? '' : ' <span class="muted">observed range, not a target</span>') + '</p>' +
        (pts.length ? C.slot(spec) : '<p class="muted small">No client in scope has a current value for this metric.</p>') +
        (med && med.n >= 2 ? '<p class="small">Portfolio median, this period: <b>' + esc(U.money(med.median)) + '</b> across ' + med.n + ' clients with ≥ 5 results.</p>' : '') + '</article>';
    }).join('');
    // Live portfolio medians, shown separately from the observed ranges.
    var meds = [];
    snap.portfolio.forEach(function (x) { if (x.n >= 2) meds.push(x); });
    meds.sort(function (a, b) { return U.cmpText(a.vertical + a.type + a.platform, b.vertical + b.type + b.platform); });
    var medTable = meds.length ? '<div class="tbl-wrap"><table class="tbl"><thead><tr><th scope="col">Vertical</th><th scope="col">Result type</th><th scope="col">Platform</th>' +
      '<th scope="col" class="num">Median cost per result</th><th scope="col" class="num">Clients</th><th scope="col">Range</th></tr></thead><tbody>' + meds.map(function (x) {
        var vals = x.values.map(function (v) { return v.value; });
        return '<tr><td>' + esc(x.vertical) + '</td><td>' + esc(E.TYPE_LABEL[x.type] || x.type) + ' <small class="muted">' + esc(x.costLabel) + '</small></td><td>' + UI.pchip(x.platform) + '</td><td class="num">' +
          esc(U.money(x.median)) + '</td><td class="num">' + x.n + '</td><td class="num">' + esc(U.money(Math.min.apply(null, vals)) + '–' + U.money(Math.max.apply(null, vals))) + '</td></tr>';
      }).join('') + '</tbody></table></div>' : '<p class="muted small">Needs at least 2 clients with ≥ 5 results in the same vertical, result type and platform.</p>';
    return '<section class="panel"><div class="panel-h"><h2>Benchmarks</h2><p>Observed ranges from rules.json with every client’s current value · dashed line: live portfolio median</p></div>' +
      (blocks ? '<div class="grid2">' + blocks + '</div>' : '<p class="muted">No benchmarks in rules.json.</p>') +
      '<h3 class="sub-h">Portfolio medians, this period</h3><p class="muted small">Median cost per result per vertical × result type × platform, across clients with ≥ 5 results (all clients, ignoring sidebar filters).</p>' + medTable + '</section>';
  }

  function logPanel(ctx, L) {
    var log = Array.isArray(L.log) ? L.log.slice() : [];
    log.sort(function (a, b) { return String(b.date || '').localeCompare(String(a.date || '')) || String(b.id).localeCompare(String(a.id)); });
    var focus = ctx.state.route.params && ctx.state.route.params.l;
    var body = log.map(function (e) {
      return '<details class="logd" id="log-' + esc(e.id) + '"' + (focus === e.id ? ' open' : '') + '><summary><span class="lid">' + esc(e.id) + '</span> <small class="muted">' + esc(U.fmtDate(e.date)) + '</small> ' +
        UI.confBadge(e.confidence) + (e.status && e.status !== 'Active' ? ' <span class="vtag">' + esc(e.status) + '</span>' : '') + '<b>' + UI.mdInline(e.title) + '</b></summary>' +
        '<div class="logb"><p class="muted small">Scope: ' + esc(e.scope || '') + '</p><h4>' + esc(e.evidence_label || 'Evidence') + '</h4>' + V.md(e.evidence) +
        (e.sample ? '<p><em>Sample</em> ' + UI.mdInline(e.sample) + '</p>' : '') + (e.next ? '<p><em>Next</em> ' + UI.mdInline(e.next) + '</p>' : '') +
        ((e.clients || []).length ? '<p class="small">Clients: ' + e.clients.map(function (c) { return esc(c); }).join(', ') + '</p>' : '') + '</div></details>';
    }).join('');
    return '<section class="panel"><div class="panel-h"><h2>Learning log</h2><p>LOG.md, newest first · expand for the evidence</p></div>' + (body || '<p class="muted">No log entries yet.</p>') + '</section>';
  }
  function questionsPanel(L) {
    var q = L.playbook && Array.isArray(L.playbook.open_questions) ? L.playbook.open_questions : [];
    return '<section class="panel"><div class="panel-h"><h2>Open questions</h2><p>To test next</p></div>' +
      (q.length ? '<ul class="ctxl">' + q.map(function (x) { return '<li>' + esc(x) + '</li>'; }).join('') + '</ul>' : '<p class="muted">None.</p>') + '</section>';
  }
})(typeof window !== 'undefined' ? window : this);
