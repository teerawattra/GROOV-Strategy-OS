/* GROOV Ads Command Center · views/health.js
 * ------------------------------------------------------------------------------------------
 * Role: Data health page (SPEC §4.6): can I trust today's numbers?
 *   - one card per dataset (a Google Sheet on Netlify, a Windsor dataset on the VPS): first/last date, rows, accounts, missing dates in the last 60 days
 *     (calendar strip), duplicates, missing columns, freshness verdict (fresh = last date is
 *     yesterday or the day before, Bangkok; sample mode is never fresh)
 *   - registry match: accounts in the data but not in the registry; registry accounts with no
 *     delivery in the last 30 days
 *   - creative coverage per platform + active ads missing images
 *   - engine notes (unsupported playbook predicates, skipped rows) and definitions
 * Public: GROOV.views.data.render(ctx)
 */
(function (root) {
  'use strict';
  var G = root.GROOV = root.GROOV || {};
  var U = G.util, D = G.data, E = G.engine, UI = G.ui;
  var V = G.views = G.views || {};
  var esc = U.esc;

  function verdict(sheet, mode) {
    if (!sheet || !U.isIso(sheet.last_date)) return { cls: 'red', text: 'No data' };
    if (mode === 'sample') return { cls: 'amber', text: 'Sample snapshot · never counts as fresh' };
    var age = U.diffDays(sheet.last_date, U.bangkokToday());
    if (age <= 2) return { cls: 'green', text: 'Fresh · last date ' + (age <= 1 ? 'yesterday' : 'the day before yesterday') };
    return { cls: age >= 4 ? 'red' : 'amber', text: 'Stale · last date ' + age + ' days ago' };
  }
  function strip(sheet) {
    if (!sheet || !U.isIso(sheet.last_date)) return '';
    var end = sheet.last_date, start = U.addDays(end, -59);
    var miss = new Set(sheet.missing_dates || []);
    var cells = U.dateRange(start, end).map(function (d) {
      var before = U.isIso(sheet.first_date) && d < sheet.first_date;
      var cls = before ? 'pre' : miss.has(d) ? 'miss' : 'ok';
      var t = U.fmtDate(d) + (before ? ': before the first date' : miss.has(d) ? ': no rows' : ': rows present');
      return '<i class="' + cls + '" data-tip="' + esc(t) + '"></i>';
    }).join('');
    return '<div class="cal" role="img" aria-label="Last 60 days: ' + miss.size + ' missing ' + U.plural(miss.size, 'date') + '">' + cells + '</div>' +
      '<div class="cal-l"><span>' + esc(U.fmtDay(start)) + '</span><span>' + esc(U.fmtDay(end)) + '</span></div>';
  }

  V.data = {
    render: function (ctx) {
      var meta = ctx.meta || {}, ds = ctx.ds, snap = ctx.snap, mode = ctx.mode;
      var out = ['<div class="page"><header class="page-h"><div><div class="eyebrow">Can I trust today’s numbers?</div><h1>Data health</h1></div>' +
        '<div class="scope"><b>' + (mode === 'sample' ? 'Sample mode' : 'Live') + '</b><span>data through ' + esc(U.fmtDate(meta.data_through)) + ' · history from ' + esc(U.fmtDate(meta.history_from)) +
        (meta.generated_at ? ' · generated ' + esc(String(meta.generated_at).replace('T', ' ').slice(0, 16)) : '') + '</span></div></header>'];

      // Sheets
      var sheets = meta.sheets || {};
      out.push('<section class="grid3">' + D.PLATFORMS.map(function (p) {
        var s = sheets[p];
        var v = verdict(s, mode);
        if (!s) return '<section class="panel"><h2>' + UI.pchip(p) + ' data</h2><p class="muted">Not reported by /api/meta.</p></section>';
        return '<section class="panel sheet"><div class="panel-h"><h2>' + UI.pchip(p) + ' data</h2><span class="pill ' + v.cls + '"><i></i>' + esc(v.text) + '</span></div>' +
          '<dl class="facts"><div><dt>First date</dt><dd>' + esc(U.fmtDate(s.first_date)) + '</dd></div><div><dt>Last date</dt><dd>' + esc(U.fmtDate(s.last_date)) + '</dd></div>' +
          '<div><dt>Rows</dt><dd>' + esc(U.int(s.rows)) + '</dd></div><div><dt>Accounts</dt><dd>' + esc(U.int(s.accounts)) + '</dd></div>' +
          '<div><dt>Duplicates</dt><dd class="' + (s.duplicates ? 'warnt' : '') + '">' + esc(U.int(s.duplicates || 0)) + '</dd></div>' +
          '<div><dt>Missing columns</dt><dd class="' + ((s.columns_missing || []).length ? 'warnt' : '') + '">' + esc((s.columns_missing || []).length ? s.columns_missing.join(', ') : 'none') + '</dd></div></dl>' +
          '<h3 class="sub-h">Missing dates, last 60 days <span class="muted">· ' + (s.missing_dates || []).length + '</span></h3>' + strip(s) + '</section>';
      }).join('') + '</section>');

      // Registry match
      var unmapped = ds.clients.filter(function (c) { return c.unmapped && c.accounts.length; });
      var T = meta.data_through, from30 = U.addDays(T, -29);
      var winFrom = ds.minDate && ds.minDate > from30 ? ds.minDate : from30;
      var W = D.agg(ds, winFrom < (meta.history_from || winFrom) ? meta.history_from : winFrom, T);
      var delivering = new Set();
      ds.campaigns.forEach(function (c) {
        var o = c.i * D.NM;
        if (W.camp[o + D.MI.spend] > 0 || W.camp[o + D.MI.impressions] > 0) {
          var a = ds.accounts[c.account];
          if (a) delivering.add(D.acctKey(a.platform, a.id));
        }
      });
      var quiet = [];
      ctx.reg.clients.forEach(function (c) {
        c.accounts.forEach(function (a) { if (!delivering.has(a.key)) quiet.push({ client: c.name, a: a }); });
      });
      out.push('<section class="panel"><div class="panel-h"><h2>Registry match</h2><p>Ads/accounts/registry.json vs accounts in the loaded data</p></div><div class="grid2 tight">' +
        '<div><h3 class="sub-h">In the data, not in the registry <span class="muted">· ' + unmapped.length + '</span></h3>' + (unmapped.length ? '<ul class="plain">' + unmapped.map(function (c) {
          var a = ds.accounts[c.accounts[0]];
          var sp = snap && snap.clientBySlug.get(c.slug);
          return '<li>' + UI.pchip(a.platform) + ' <b>' + esc(a.name) + '</b> <small class="mono muted">' + esc(a.id) + '</small>' + (sp ? ' <small>' + esc(U.money(sp.cur.spend)) + ' this period</small>' : '') + '</li>';
        }).join('') + '</ul><p class="muted small">Fix: add these accounts to the right client in the registry (they show as “Unmapped”).</p>' : '<p class="muted">Every account is mapped.</p>') + '</div>' +
        '<div><h3 class="sub-h">Registry accounts with no delivery since ' + esc(U.fmtDay(winFrom)) + ' <span class="muted">· ' + quiet.length + '</span></h3>' +
        (winFrom > from30 ? '<p class="muted small">Loaded data starts ' + esc(U.fmtDate(winFrom)) + ', so this covers fewer than 30 days.</p>' : '') +
        (quiet.length ? '<ul class="plain cols">' + quiet.map(function (x) {
          return '<li>' + UI.pchip(x.a.platform) + ' <b>' + esc(x.a.name) + '</b> <small class="muted">' + esc(x.client) + (x.a.status && x.a.status !== 'ACTIVE' ? ' · ' + esc(x.a.status) : '') + '</small></li>';
        }).join('') + '</ul>' : '<p class="muted">Every registry account delivered.</p>') + '</div></div></section>');

      // Creative coverage
      var cov = meta.creatives || {};
      var activeMissing = snap ? snap.ads.filter(function (a) { return a.delivering && a.status === 'ACTIVE' && !a.image && a.platform !== 'google'; }) : [];
      out.push('<section class="panel"><div class="panel-h"><h2>Creative coverage</h2><p>Images saved by the daily image job</p></div><div class="kstrip">' +
        ['meta', 'tiktok'].map(function (p) {
          var c = cov[p];
          if (!c) return UI.kpi({ label: UI.pchip(p), value: U.DASH, sub: '<small>not reported</small>' });
          return UI.kpi({ label: UI.pchip(p), value: esc(U.int(c.saved)) + ' <small>/ ' + esc(U.int(c.ads)) + ' saved</small>',
            sub: '<small>No image link: ' + esc(U.int(c.no_url)) + ' · not saved: ' + esc(U.int(c.not_saved)) + '</small>' });
        }).join('') + UI.kpi({ label: UI.pchip('google'), value: 'Text ads', sub: '<small>Search ads have no image by design</small>' }) + '</div>' +
        '<h3 class="sub-h">Delivering ACTIVE ads without an image <span class="muted">· ' + activeMissing.length + '</span></h3>' +
        (activeMissing.length ? '<ul class="plain cols">' + activeMissing.sort(function (a, b) { return b.cur.spend - a.cur.spend; }).map(function (a) {
          return '<li>' + UI.pchip(a.platform) + ' <b>' + esc(a.name) + '</b> <small class="muted">' + esc(a.client.name) + ' · ' + esc(U.money(a.cur.spend)) + ' · ' +
            esc(a.image_reason === 'not_saved' ? 'not saved' : 'no image link') + '</small></li>';
        }).join('') + '</ul>' : '<p class="muted">None.</p>') + '</section>');

      // Engine notes
      var notes = [];
      if (ds.skipped) notes.push(ds.skipped + ' fact ' + U.plural(ds.skipped, 'row') + ' referenced an unknown campaign or date and were skipped.');
      (snap ? snap.checks : []).forEach(function (c) {
        if (c.unsupported.length) notes.push('Playbook check ' + c.check.id + ' uses unsupported predicate(s): ' + c.unsupported.join(', ') + '.');
        if (c.legacy.length) notes.push('Playbook check ' + c.check.id + ' uses legacy predicate(s) ' + c.legacy.join(', ') + ' (read as link CTR); rename them in rules.json.');
      });
      var unknownStatus = snap ? snap.ads.filter(function (a) { return a.status === 'UNKNOWN'; }).length : 0;
      if (unknownStatus) notes.push(unknownStatus + ' ' + U.plural(unknownStatus, 'ad') + ' in this period have status UNKNOWN (no status in the export, or an unmapped value such as WITH_ISSUES; the raw value shows in the tooltip).');
      var linkGap = snap ? snap.camps.filter(function (r) { return r.platform === 'meta' && !r.k.linkKnown; }).length : 0;
      if (linkGap) notes.push(linkGap + ' Meta ' + U.plural(linkGap, 'campaign') + ' report clicks but no link clicks this period: link CTR shows “—” and link-based checks do not fire for them.');
      out.push('<section class="panel"><div class="panel-h"><h2>Engine notes</h2></div>' + (notes.length ? '<ul class="plain">' + notes.map(function (n) { return '<li>' + esc(n) + '</li>'; }).join('') + '</ul>' : '<p class="muted">Nothing to report.</p>') + '</section>');

      out.push('<section class="panel"><div class="panel-h"><h2>Definitions</h2></div><dl class="defs">' +
        '<div><dt>Reach</dt><dd>Daily reach, not unique. Frequency here is impressions ÷ the sum of daily reach (average daily frequency).</dd></div>' +
        '<div><dt>Results</dt><dd>Platform-reported: messaging conversations, lead actions and conversions are not qualified leads, bookings or sales.</dd></div>' +
        '<div><dt>Late conversions</dt><dd>The exports re-pull recent days daily, so the last few days can still change: the last 3 days are shaded “provisional”.</dd></div>' +
        '<div><dt>Data through</dt><dd>The latest date present in every non-empty dataset. Presets count back from it, never from today.</dd></div>' +
        '<div><dt>Status</dt><dd>From each entity’s latest exported row. TikTok ad groups and ads inherit the campaign status. An ACTIVE status with no recent delivery is flagged as a delivery issue.</dd></div>' +
        '</dl></section>');
      out.push('</div>');
      return out.join('');
    }
  };
})(typeof window !== 'undefined' ? window : this);
