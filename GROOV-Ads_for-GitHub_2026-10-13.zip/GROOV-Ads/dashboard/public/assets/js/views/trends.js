/* GROOV Ads Command Center · views/trends.js
 * ------------------------------------------------------------------------------------------
 * Role: KPI trend lines (SPEC §4.7), shared by the overview cards, every client KPI tile and the
 * ad set panel.
 *   TILES[type]                       the KPI tiles per result type (labels, sub-lines); client
 *                                     objective groups and the ad set panel use the same list
 *   kpiTile(ctx, scope, item, opts)   one KPI tile: value, Δ and its line chart (current period,
 *                                     dashed comparison aligned by day number, provisional shading,
 *                                     end marker coloured by direction). The chart is a button that
 *                                     covers the whole tile: clicking the tile opens the big chart
 *   panel(ctx, scope)                 the expanded chart under a strip ('' unless one of its tiles is
 *                                     open): axes, Daily / Weekly, split (Total · By platform · Top 5
 *                                     campaigns · Top 5 ad sets), benchmark band and registry target on
 *                                     cost-per-result charts, Table view
 *   gran(ctx), closeOpen()            the granularity in force; Esc closes the open chart
 * scope = { id (strip id, unique on the page), key (memo key: what the numbers cover), title,
 *           camps: [CampRow] | adsets: [AdsetRow], cur / cmp (period totals), type, objective,
 *           platforms, client (registry client, for targets), vertical, multiClient, splits }
 * Values come from summed numerators / denominators per bucket (model.trendData, memoized on the
 * snapshot: one computation per state). Only one tile is expanded at a time
 * (app.expanded('kpi') holds "strip|kpi"; it is cleared when the page changes).
 * Handlers: kpi-open, kpi-close, trend-gran, trend-split.
 */
(function (root) {
  'use strict';
  var G = root.GROOV = root.GROOV || {};
  var U = G.util, D = G.data, E = G.engine, M = G.model, C = G.charts, UI = G.ui;
  var V = G.views = G.views || {};
  var A = G.actions = G.actions || {};
  var esc = U.esc;
  var T = V.trend = {};

  /** Tiles per result type (SPEC §4.3.2). kpi null = no data in the Sheets (no line). */
  T.TILES = {
    'Messages': [{ kpi: 'messages', label: 'Conversations*' }, { kpi: 'cpmsg', label: 'Cost per conversation' },
      { kpi: 'chat_rate', label: 'Click-to-conversation', sub: 'conversations ÷ link clicks' }, { kpi: 'link_ctr', label: 'Link CTR' }, { kpi: 'cpm', label: 'CPM' }],
    'Lead generation': [{ kpi: 'leads', label: 'Leads*' }, { kpi: 'cpl', label: 'CPL' }, { kpi: 'lead_rate', label: 'Lead rate', sub: 'leads ÷ link clicks' },
      { kpi: 'link_ctr', label: 'Link CTR' }, { kpi: 'cpm', label: 'CPM' }],
    'Awareness': [{ kpi: 'impressions', label: 'Impressions' }, { kpi: 'cpm_aw', label: 'CPM' },
      { kpi: 'freq', label: 'Avg daily frequency', sub: 'impressions ÷ Σ daily reach · not unique' }, { kpi: 'reach_day', label: 'Reach/day', sub: 'sum of daily reach ÷ days · not unique' }],
    'Traffic': [{ kpi: 'link_clicks_t', label: 'Link clicks' }, { kpi: 'cpc', label: 'CPC' }, { kpi: 'link_ctr', label: 'Link CTR' }, { kpi: 'cpm', label: 'CPM' }],
    'Engagement': [{ kpi: 'video_views', label: 'Video views (3s)' }, { kpi: 'cpv', label: 'Cost per view' }, { kpi: 'view_rate', label: 'View rate', sub: 'views ÷ impressions' },
      { kpi: 'ctr', label: 'CTR' }],
    'Conversions·value': [{ kpi: null, label: 'Conversions', sub: 'Meta conversion counts are not in the data' }, { kpi: 'value', label: 'Purchase value*' },
      { kpi: 'roas', label: 'ROAS*', sub: 'Meta-reported purchase ROAS' }, { kpi: 'ctr', label: 'CTR' }, { kpi: 'cpm', label: 'CPM' }],
    'Conversions': [{ kpi: 'conversions', label: 'Conversions*' }, { kpi: 'cpa', label: 'CPA' }, { kpi: 'conv_value', label: 'Conversion value*' }, { kpi: 'roas', label: 'ROAS*' },
      { kpi: 'ctr', label: 'CTR', sub: 'clicks ÷ impressions' }]
  };
  var LINK_KPIS = { link_ctr: 1, chat_rate: 1, lead_rate: 1, link_clicks_t: 1, cpc: 1 };
  var DIR_WORD = { good: 'moved the good way', bad: 'moved the bad way', neutral: 'no judgement', muted: 'no baseline or low n' };

  /* ---------- state ---------- */
  /**
   * Granularity in force: the Daily / Weekly choice, else daily up to 45 days. A Weekly choice that
   * would leave fewer than 2 weeks in the period (a 7-day period) falls back to daily: one point is
   * not a line.
   */
  T.gran = function (ctx) {
    var snap = ctx.snap, P = snap.P, o = ctx.state.ui.trendGran;
    var memo = snap.granMemo || (snap.granMemo = {});
    if (memo[o]) return memo[o];
    var g = D.trendGran(P.curLen || 0, o);
    if (g === 'weekly' && o === 'weekly' && (!P.cur || D.buckets(U.dateRange(P.cur.from, P.cur.to), 'weekly').length < 2)) g = D.trendGran(P.curLen || 0, 'auto');
    memo[o] = g;
    return g;
  };
  function openKey(ctx) {
    var set = ctx.app && ctx.app.expanded ? ctx.app.expanded('kpi') : null;
    if (!set || !set.size) return null;
    var k = Array.from(set)[0], i = k.indexOf('|');
    return { strip: k.slice(0, i), kpi: k.slice(i + 1) };
  }
  T.openKey = openKey;
  function isOpen(ctx, strip, kpi) { var o = openKey(ctx); return !!o && o.strip === strip && o.kpi === kpi; }

  /* ---------- labels ---------- */
  function bucketTitle(b, gran) {
    if (gran !== 'weekly') return U.weekday(b.from) + ' ' + U.fmtDate(b.from);
    return 'Week ' + U.rangeLabel(b.from, b.to) + (b.partial ? ' (partial)' : '');
  }
  function bucketShort(b, gran, i) {
    if (gran === 'weekly') return U.fmtDay(b.from);
    var d = +b.from.slice(8, 10);
    return i === 0 || d === 1 ? U.fmtDay(b.from) : String(d);
  }
  /** The comparison days behind bucket b (same day numbers), e.g. "7 Sep" or "7–13 Sep". */
  function cmpTitle(td, b) {
    var cd = td.cmpDays;
    if (!cd || !cd.length || b.i0 >= cd.length) return null;
    var a = cd[b.i0], z = cd[Math.min(b.i1, cd.length - 1)];
    return a === z ? U.fmtDay(a) : U.rangeLabel(a, z, false);
  }
  function tipFmt(kpi) { return kpi.fmt === 'money' ? 'money-exact' : kpi.fmt; }
  function nNote(kpi, n) {
    return kpi.kind === 'ratio' && kpi.n && U.isNum(n) ? ' · n=' + U.count(n) : '';
  }

  /** Tooltip rows for bucket i: every series, the comparison (Total view), partial / provisional notes. */
  function tipRows(td, i, kpi, series, cmp) {
    var b = td.buckets[i], f = tipFmt(kpi);
    var rows = [[bucketTitle(b, td.gran)]];
    series.forEach(function (s) {
      var v = s.values.cur[i];
      var label = s.label + (v === null && kpi.gap ? ' · ' + kpi.gap : '') + nNote(kpi, s.values.nCur[i]);
      if (!cmp && s.values.cmp) label += ' (comparison ' + C.fmtVal(s.values.cmp[i], f) + ')';
      rows.push([s.color, C.fmtVal(v, f), label]);
    });
    if (cmp) {
      var ct = cmpTitle(td, b);
      rows.push(['cmp', C.fmtVal(cmp.cmp[i], f), ct ? 'Comparison · ' + ct + nNote(kpi, cmp.nCmp ? cmp.nCmp[i] : null) : 'Comparison · no matching day']);
    }
    if (b.partial) rows.push(['', '', 'Partial week: ' + b.days + ' of 7 days in the period']);
    if (td.provIdx >= 0 && i >= td.provIdx) rows.push(['', '', 'Provisional: late conversions can still change this']);
    return rows;
  }

  /* ---------- tiles ---------- */
  /** Value text for a tile, from the period totals (the same numbers the line is built from). */
  T.valueHtml = function (kpi, o, v) {
    if (kpi.gate && !kpi.gate(o)) return 'Not tracked';
    var k = E.kpis(o);
    if (LINK_KPIS[kpi.id] && !k.linkKnown) {
      return '<span class="na" data-tip="Link clicks not reported for these rows (clicks exist but link clicks are blank).">' + U.DASH + '</span>';
    }
    var html = esc(C.fmtVal(v, kpi.fmt));
    if (kpi.cost && kpi.n) { var n = kpi.n(o); if (U.isNum(n)) html += ' <small class="n">n=' + esc(U.count(n)) + '</small>'; }
    return html;
  };
  /** The tile's chart button: the mini line + everything needed to open the expanded chart. */
  T.tile = function (ctx, scope, kpi, label, dir) {
    var gran = T.gran(ctx), td = M.trendData(ctx.snap, ctx.ds, scope, gran), tv = M.trendValues(td, kpi);
    var open = isOpen(ctx, scope.id, kpi.id);
    var s = [{ label: 'This period', color: 'var(--copper)', values: tv }];
    var tips = td.buckets.map(function (b, i) { return tipRows(td, i, kpi, s, tv.cmp ? tv : null); });
    var name = String(label).replace(/\*$/, '');
    var spec = { type: 'trend', tag: 'span', height: 40, cur: tv.cur, cmp: tv.cmp, dir: dir, provIdx: td.provIdx, tips: tips,
      title: name + ' by ' + (gran === 'weekly' ? 'week' : 'day') + (tv.cmp ? ', with the comparison period dashed' : '') + '; end marker: ' + DIR_WORD[dir] };
    return {
      open: open,
      html: '<button type="button" class="kpi-hit" data-act="kpi-open" data-k="' + esc(scope.id) + '" data-v="' + esc(kpi.id) + '" aria-expanded="' + open +
        '" aria-controls="kx-' + esc(scope.id) + '" aria-label="' + esc(name + ': ' + (open ? 'hide' : 'show') + ' the trend chart') + '">' + C.slot(spec, 'kpi-tr') + '</button>'
    };
  };
  /**
   * One KPI tile. item = { kpi, label, sub, noTrend }. opts = { value (HTML override), sub (HTML
   * override), foot, cls, vs, noLowN (overview cards), hideDelta }.
   */
  T.kpiTile = function (ctx, scope, item, opts) {
    opts = opts || {};
    var sub = opts.sub !== undefined ? opts.sub : (item.sub ? '<small>' + esc(item.sub) + '</small>' : '');
    if (!item.kpi) return UI.kpi({ label: esc(item.label), value: U.DASH, delta: '', sub: sub, cls: opts.cls });
    var kpi = M.KPI[item.kpi], P = ctx.snap.P;
    var days = P.curLen || 1, pDays = P.cmpLen || days;
    var v = M.kpiValue(kpi, scope.cur, days), pv = ctx.snap.B ? M.kpiValue(kpi, scope.cmp, pDays) : null;
    var lowN = !opts.noLowN && kpi.n ? E.lowN(kpi.n(scope.cur), kpi.n(scope.cmp)) : false;
    var delta = opts.hideDelta ? '' : UI.delta(U.pctChange(v, pv), { good: kpi.good, noBaseline: P.noBaseline, lowN: lowN });
    var tr = item.noTrend ? null : T.tile(ctx, scope, kpi, item.label, M.trendDir(kpi, v, pv, lowN));
    return UI.kpi({ label: esc(item.label), value: opts.value !== undefined ? opts.value : T.valueHtml(kpi, scope.cur, v), delta: delta, vs: opts.vs,
      sub: sub, foot: opts.foot, cls: opts.cls, trend: tr });
  };

  /* ---------- expanded chart ---------- */
  function seg(act, label, items, on) {
    return '<div class="seg" role="group" aria-label="' + esc(label) + '">' + items.map(function (x) {
      var o = x[0] === on;
      return '<button type="button" class="' + (o ? 'on' : '') + '" aria-pressed="' + o + '" data-act="' + act + '" data-v="' + esc(x[0]) + '">' + esc(x[1]) + '</button>';
    }).join('') + '</div>';
  }
  function benchBand(ctx, scope, kpi) {
    if (!kpi.cost || scope.type !== kpi.cost || !V.common || !V.common.benchFor) return null;
    var b = V.common.benchFor(ctx.learn, kpi.cost, scope.vertical, scope.platforms);
    if (!b || !U.isNum(+b.low) || !U.isNum(+b.high)) return null;
    var range = +b.low === +b.high ? U.moneyRound(+b.low) : U.moneyRound(+b.low) + '–' + U.moneyRound(+b.high);
    return { low: +b.low, high: +b.high, b: b, label: (E.benchIsTarget(b) ? 'Target range ' : 'Observed ') + range + ' · ' + (b.source || '') };
  }
  function targetLine(scope, kpi) {
    if (!kpi.cost || scope.type !== kpi.cost || !V.common || !V.common.targetFor) return null;
    var t = V.common.targetFor(scope.client, scope.objective, scope.type);
    return t ? { value: t, label: 'Target ' + U.moneyRound(t) + ' (registry)' } : null;
  }

  T.panel = function (ctx, scope) {
    var o = openKey(ctx);
    if (!o || o.strip !== scope.id) return '';
    var kpi = M.KPI[o.kpi];
    if (!kpi) return '';
    var snap = ctx.snap, P = snap.P, st = ctx.state, gran = T.gran(ctx), override = st.ui.trendGran;
    var splits = scope.splits || ['total'];
    var mode = splits.indexOf(st.ui.trendSplit) >= 0 ? st.ui.trendSplit : 'total';
    var sp = M.trendSplit(snap, ctx.ds, scope, kpi, gran, mode);
    var total = sp.mode === 'total';
    var tdT = M.trendData(snap, ctx.ds, scope, gran), tvT = M.trendValues(tdT, kpi);
    var days = P.curLen || 1, pDays = P.cmpLen || days;
    var v = M.kpiValue(kpi, scope.cur, days), pv = snap.B ? M.kpiValue(kpi, scope.cmp, pDays) : null;
    var lowN = kpi.n && !scope.noLowN ? E.lowN(kpi.n(scope.cur), kpi.n(scope.cmp)) : false;
    var dir = M.trendDir(kpi, v, pv, lowN);
    var band = benchBand(ctx, scope, kpi), target = targetLine(scope, kpi);
    var item = (scope.items || []).filter(function (x) { return x.kpi === kpi.id; })[0];
    var label = String(item ? item.label : kpi.label).replace(/\*$/, '');
    var series = sp.series.map(function (s) { return { label: total ? 'This period' : s.label, color: s.color, values: s.values }; });
    var tips = tdT.buckets.map(function (b, i) { return tipRows(tdT, i, kpi, series, total && tvT.cmp ? tvT : null); });
    var spec = {
      type: 'trendx', height: 290, title: label + ' by ' + (gran === 'weekly' ? 'week' : 'day') + ' · ' + scope.title,
      labels: tdT.buckets.map(function (b, i) { return bucketShort(b, gran, i); }), partial: tdT.buckets.map(function (b) { return b.partial; }),
      series: series.map(function (s) { return { label: s.label, color: s.color, values: s.values.cur }; }), cmp: total ? tvT.cmp : null,
      fmt: kpi.fmt, dir: total ? dir : null, provIdx: tdT.provIdx, band: band, target: target, tips: tips,
      emptyText: !tvT.tracked ? 'Not tracked in this period: no value was reported.' : 'No ' + (gran === 'weekly' ? 'week' : 'day') + ' in this period has a value' + (kpi.gap ? ' (' + kpi.gap + ')' : '') + '.'
    };
    var granSeg = seg('trend-gran', 'Granularity', [['daily', 'Daily'], ['weekly', 'Weekly']], gran) +
      (override === 'daily' || override === 'weekly' ? '<button type="button" class="btn ghost xs" data-act="trend-gran" data-v="auto">Auto</button>' : '');
    var splitSeg = splits.length > 1 ? seg('trend-split', 'Split the chart by', splits.map(function (x) { return [x, M.TREND_SPLIT_LABEL[x]]; }), sp.mode) : '';
    var cmpTxt = P.cmp && !P.noBaseline ? ' vs ' + esc(P.cmpLabel) : P.noBaseline ? ' · no baseline' : ' · comparison off';
    var granTxt = override === 'weekly' && gran !== 'weekly' ? ' (weekly needs at least two weeks in the period)' :
      override === 'daily' || override === 'weekly' ? ' (your choice)' : ' (auto: daily up to 45 days)';
    var head = '<div class="kx-h"><div class="kx-t"><h3>' + esc(label) + ' <span class="muted">· ' + esc(scope.title) + '</span></h3><p class="muted small">' + esc(P.label) + cmpTxt +
      ' · ' + (gran === 'weekly' ? 'weekly (Mon–Sun)' : 'daily') + granTxt + '</p></div>' +
      '<div class="kx-tools">' + granSeg + splitSeg + '<button type="button" class="btn ghost sm" data-act="kpi-close" aria-label="Close the ' + esc(label) + ' chart">Close <span aria-hidden="true">✕</span></button></div></div>';
    // legend
    var lg = [];
    if (total) {
      lg.push('<span class="lg"><i class="lk" style="background:var(--copper)"></i>This period (' + esc(P.label) + ')</span>');
      if (tvT.cmp) lg.push('<span class="lg"><i class="sw dash"></i>Comparison (' + esc(P.cmpLabel) + '), by day number</span>');
      lg.push('<span class="lg"><i class="sw end ' + esc(dir) + '"></i>End marker: ' + esc(DIR_WORD[dir]) + '</span>');
    } else {
      sp.series.forEach(function (s) { lg.push('<span class="lg"><i class="lk" style="background:' + s.color + '"></i>' + esc(s.label) + '</span>'); });
    }
    if (tdT.provIdx >= 0) lg.push('<span class="lg"><i class="sw prov"></i>Provisional</span>');
    if (band) lg.push('<span class="lg"><i class="sw bandk"></i>' + esc(band.label) + ' ' + UI.confBadge(band.b.confidence) + '</span>');
    if (target) lg.push('<span class="lg"><i class="lk tgtk"></i>' + esc(target.label) + '</span>');
    var unit = gran === 'weekly' ? 'week' : 'day';
    var notes = [kpi.kind === 'ratio' ? 'Each point is the ' + unit + '’s ' + esc(kpi.formula || kpi.label) + ', computed from that ' + unit + '’s sums, never an average of daily ratios.' :
      'Each point is the ' + unit + '’s total ' + esc(kpi.formula || kpi.label) + '.'];
    if (kpi.gap) notes.push('Gaps: ' + esc(kpi.gap) + ' (never drawn as ฿0 or ∞).');
    if (gran === 'weekly') notes.push('Weeks run Monday–Sunday; weeks cut by the period’s start or end are labelled “partial”.');
    if (!total) notes.push((sp.series.length ? 'Ranked by ' + esc(sp.rankBy) + ' this period. ' : 'Nothing to rank in this period. ') + 'The dashed comparison line shows in Total.');
    if (lowN && total && snap.B) notes.push('Fewer than 10 results in one of the periods: the change is low n.');
    if (band && band.b && !E.benchIsTarget(band.b)) notes.push('The band is an observed range (' + esc(band.b.source || '') + '), not a target.');
    var tbl = tableView(tdT, kpi, sp, total, tvT, gran);
    return '<section class="kx" id="kx-' + esc(scope.id) + '" role="region" aria-label="' + esc(label + ' trend chart') + '">' + head + C.slot(spec, 'kx-chart') +
      '<div class="legend">' + lg.join('') + '</div><p class="kx-note">' + notes.join(' ') + '</p>' + tbl + '</section>';
  };

  /** "Table view": the exact value of every bucket (and the comparison, Δ and n in Total). */
  function tableView(td, kpi, sp, total, tv, gran) {
    var f = tipFmt(kpi), showN = kpi.kind === 'ratio' && !!kpi.n;
    var head = '<th scope="col">' + (gran === 'weekly' ? 'Week' : 'Day') + '</th>';
    if (total) {
      head += '<th scope="col" class="num">This period</th>' + (showN ? '<th scope="col" class="num">n</th>' : '') +
        (tv.cmp ? '<th scope="col">Comparison days</th><th scope="col" class="num">Comparison</th><th scope="col" class="num">Δ</th>' : '');
    } else {
      sp.series.forEach(function (s) { head += '<th scope="col" class="num">' + esc(s.label) + '</th>'; });
    }
    var rows = td.buckets.map(function (b, i) {
      var lab = (gran === 'weekly' ? U.rangeLabel(b.from, b.to) : U.weekday(b.from) + ' ' + U.fmtDate(b.from)) + (b.partial ? ' (partial, ' + b.days + ' ' + U.plural(b.days, 'day') + ')' : '') +
        (td.provIdx >= 0 && i >= td.provIdx ? ' · provisional' : '');
      var cells = '<th scope="row">' + esc(lab) + '</th>';
      if (total) {
        cells += '<td class="num">' + esc(C.fmtVal(tv.cur[i], f)) + '</td>' + (showN ? '<td class="num">' + esc(U.count(tv.nCur[i])) + '</td>' : '');
        if (tv.cmp) {
          cells += '<td>' + esc(cmpTitle(td, b) || U.DASH) + '</td><td class="num">' + esc(C.fmtVal(tv.cmp[i], f)) + '</td><td class="num">' +
            UI.delta(U.pctChange(tv.cur[i], tv.cmp[i]), { good: kpi.good }) + '</td>';
        }
      } else {
        sp.series.forEach(function (s) { cells += '<td class="num">' + esc(C.fmtVal(s.values.cur[i], f)) + '</td>'; });
      }
      return '<tr>' + cells + '</tr>';
    }).join('');
    return '<details class="tview"><summary>Table view</summary><div class="tbl-wrap"><table class="tbl"><thead><tr>' + head + '</tr></thead><tbody>' + rows + '</tbody></table></div></details>';
  }

  /* ---------- handlers ---------- */
  function focusTile(key) {
    if (!key || typeof document === 'undefined') return;
    var i = key.indexOf('|'), q = function (s) { return root.CSS && CSS.escape ? CSS.escape(s) : s; };
    var b = document.querySelector('.kpi-hit[data-k="' + q(key.slice(0, i)) + '"][data-v="' + q(key.slice(i + 1)) + '"]');
    if (b) { try { b.focus({ preventScroll: true }); } catch (e) { b.focus(); } }
  }
  A['kpi-open'] = function (el) {
    var set = G.app.expanded('kpi'), strip = el.getAttribute('data-k'), key = strip + '|' + el.getAttribute('data-v');
    var was = set.has(key);
    set.clear();
    if (!was) set.add(key);
    G.app.render();
    if (!was && typeof document !== 'undefined') {
      var p = document.getElementById('kx-' + strip);
      if (p && p.scrollIntoView) { try { p.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); } catch (e) { p.scrollIntoView(false); } }
    }
  };
  /** Close the open chart and give focus back to its tile. Returns true when something closed. */
  T.closeOpen = function () {
    var set = G.app.expanded('kpi');
    if (!set.size) return false;
    var key = Array.from(set)[0];
    set.clear();
    G.app.render();
    focusTile(key);
    return true;
  };
  A['kpi-close'] = function () { T.closeOpen(); };
  A['trend-gran'] = function (el) { var v = el.getAttribute('data-v'); G.app.update(function (st) { st.ui.trendGran = v; }); };
  A['trend-split'] = function (el) { var v = el.getAttribute('data-v'); G.app.update(function (st) { st.ui.trendSplit = v; }); };
})(typeof window !== 'undefined' ? window : this);
