/* GROOV Ads Command Center · views/creatives.js
 * ------------------------------------------------------------------------------------------
 * Role: Creatives page (SPEC §4.4) and the reusable creative wall (client view §4.3.8).
 *   Tabs: Winners (lowest cost per primary result within result type; gate ≥ 2,000 impressions,
 *         ≥ 5 results, and spend ≥ 3× target when the registry has a target; directional 5–24,
 *         confident 25+) · Spending, no results · Fatigue risk (2 of 3 worsened) · All (sortable)
 *   Cards: 4:5 image (or a blank tile stating why), platform, status, name, lineage, spend,
 *          result + cost (n), CTR, frequency, decision badge, Preview, "Live N days", New badge.
 * Public: GROOV.views.creatives.render(ctx); .lists(ctx, ads) -> tab lists; .wall(ctx, ads, opts)
 * Images: sample ../../command-center/creatives/<platform>/<ad_id>.jpg · live /img/<platform>/<ad_id>.
 * A failed image is replaced by app.js with a blank tile ("Image file missing"): never a broken icon.
 */
(function (root) {
  'use strict';
  var G = root.GROOV = root.GROOV || {};
  var U = G.util, D = G.data, E = G.engine, M = G.model, UI = G.ui;
  var V = G.views = G.views || {};
  var A = G.actions = G.actions || {};
  var esc = U.esc;

  var REASON = {
    no_url: ['No image', 'The platform supplied no thumbnail for this ad.'],
    not_saved: ['Creative not saved yet', 'Its image link expired before the daily image job stored it.'],
    text_ad: ['Text-only search ad', 'Google search ads have no image creative.']
  };
  var TABS = [{ id: 'winners', label: 'Winners' }, { id: 'zero', label: 'Spending, no results' }, { id: 'fatigue', label: 'Fatigue risk' }, { id: 'all', label: 'All' }];
  var SORTS = [{ id: 'spend', label: 'Spend' }, { id: 'cost', label: 'Cost per result' }, { id: 'ctr', label: 'CTR' }, { id: 'newest', label: 'Newest' }];

  function imgSrc(ctx, a) {
    var id = encodeURIComponent(a.id);
    return ctx.mode === 'sample' ? '../../command-center/creatives/' + a.platform + '/' + id + '.jpg' : '/img/' + a.platform + '/' + id;
  }
  function media(ctx, a) {
    if (a.platform === 'google' || a.image_reason === 'text_ad') return blank(REASON.text_ad);
    if (a.image) {
      return '<img src="' + esc(imgSrc(ctx, a)) + '" alt="Creative: ' + esc(a.name) + '" loading="lazy" decoding="async" data-fallback="The saved creative for this ad could not be loaded.">';
    }
    return blank(REASON[a.image_reason] || REASON.no_url);
  }
  function blank(r) {
    return '<div class="blank" role="img" aria-label="' + esc(r[0]) + '"><div><b>' + esc(r[0]) + '</b><span>' + esc(r[1]) + '</span></div></div>';
  }
  function targetFor(a) {
    var t = a.client && a.client.targets;
    if (!t) return null;
    var v = +t[a.objective];
    return U.isNum(v) && v > 0 ? v : null;
  }

  /** The four tab lists for a set of ad rows (already scope/row/client filtered). */
  V.creativesLists = function (ctx, ads) {
    var rules = ctx.snap.rules;
    var cur = ads.filter(function (a) { return a.delivering; });
    var winners = [];
    var byType = new Map();
    cur.forEach(function (a) {
      var p = a.prim;
      if (!(a.cur.impressions >= 2000)) return;
      if (p.type === 'Conversions·value') { if (!(p.result > 0) || !U.isNum(p.cost)) return; }
      else if (!(U.isNum(p.n) ? p.n >= 5 : p.result >= 5) || !U.isNum(p.cost)) return;
      var tgt = targetFor(a);
      if (tgt && !(a.cur.spend >= 3 * tgt)) return;
      var g = byType.get(p.type) || [];
      g.push(a); byType.set(p.type, g);
    });
    byType.forEach(function (list, type) {
      list.sort(function (x, y) { return x.prim.lowerBetter ? x.prim.cost - y.prim.cost : y.prim.cost - x.prim.cost; });
      winners.push({ type: type, label: E.TYPE_LABEL[type] || type, rows: list });
    });
    winners.sort(function (a, b) { return U.sum(b.rows, function (r) { return r.cur.spend; }) - U.sum(a.rows, function (r) { return r.cur.spend; }); });
    var zero = cur.filter(function (a) {
      if (a.isNew || a.objective === 'Awareness') return false;
      var res = a.prim.type === 'Conversions·value' ? a.k.value : a.prim.result;
      return a.cur.spend >= rules.zeroSpend && res === 0;
    }).sort(function (x, y) { return y.cur.spend - x.cur.spend; });
    var fatigue = cur.filter(function (a) { return a.fatigue && a.fatigue.flag; }).sort(function (x, y) { return y.cur.spend - x.cur.spend; });
    return { winners: winners, winnersCount: winners.reduce(function (s, g) { return s + g.rows.length; }, 0), zero: zero, fatigue: fatigue, all: ads };
  };

  function sortAll(list, key) {
    var l = list.slice();
    if (key === 'cost') l.sort(function (a, b) {
      var ca = U.isNum(a.prim.cost) ? (a.prim.lowerBetter ? a.prim.cost : -a.prim.cost) : Infinity;
      var cb = U.isNum(b.prim.cost) ? (b.prim.lowerBetter ? b.prim.cost : -b.prim.cost) : Infinity;
      return ca - cb;
    });
    else if (key === 'ctr') l.sort(function (a, b) { return (U.isNum(b.k.ctr) ? b.k.ctr : -1) - (U.isNum(a.k.ctr) ? a.k.ctr : -1); });
    else if (key === 'newest') l.sort(function (a, b) { return String(b.first_date || '').localeCompare(String(a.first_date || '')) || b.cur.spend - a.cur.spend; });
    else l.sort(function (a, b) { return b.cur.spend - a.cur.spend || b.cmp.spend - a.cmp.spend; });
    return l;
  }

  /** One creative card. opts: { rank, conf, showFatigue } */
  V.creativeCard = function (ctx, a, opts) {
    opts = opts || {};
    var p = a.prim, k = a.k;
    var live = a.live ? 'Live ' + (a.live.atLeast ? '≥ ' : '') + a.live.days + ' ' + U.plural(a.live.days, 'day') : (a.first_date ? '' : 'Never delivered');
    var stopped = a.last_date && a.last_date < ctx.snap.periodEnd && !a.delivering ? ' · last delivered ' + U.fmtDay(a.last_date) : '';
    var resTxt = p.type === 'Conversions·value' ? U.money(p.result) : U.count(p.result);
    var costTxt = UI.costText(p, p.cost);
    // the ad set name opens the ad set panel (SPEC §4.8: "its name anywhere")
    var lineage = [esc(a.client.name), esc(a.campaign.name)].concat(a.adsetName ? [a.adset ? '<button type="button" class="linkb" data-act="adset-open" data-v="' + esc(a.adset.key) +
      '" data-tip="Open the ' + (a.platform === 'meta' ? 'ad set' : 'ad group') + ' panel">' + esc(a.adsetName) + '</button>' : esc(a.adsetName)] : []).join(' › ');
    var fat = '';
    if (opts.showFatigue && a.fatigue) {
      fat = '<ul class="fsig">' + a.fatigue.signals.map(function (s) {
        return '<li class="' + (s.hit ? 'hit' : '') + '">' + esc(s.label) + ' ' + esc(U.deltaText(s.change)) + ' <small>(' + esc(s.rule) + ')</small></li>';
      }).join('') + (a.fatigue.freqSupport ? '<li class="sup">Avg daily frequency ' + esc(U.ratioX(a.fatigue.freq)) + ' (supporting, ≥ 2.5×)</li>' : '') + '</ul>';
    }
    return '<article class="ccard' + (a.delivering ? '' : ' dim') + '"><div class="cmedia">' + media(ctx, a) +
      '<div class="cbadges">' + UI.pchip(a.platform) + (a.isNew ? UI.newBadge() : '') + (opts.rank ? '<span class="rank">#' + opts.rank + '</span>' : '') + '</div></div>' +
      '<div class="cbody"><div class="crow">' + UI.statusBadge(a.status, a.rawStatus) + '<small class="muted">' + esc(live + stopped) + '</small></div>' +
      '<h3 class="cname-h">' + esc(a.name) + '</h3><p class="lineage">' + lineage + '</p>' +
      '<dl class="cstats"><div><dt>Spend</dt><dd>' + esc(U.money(a.cur.spend)) + '</dd></div>' +
      '<div><dt>' + esc(p.type === 'Conversions·value' ? 'Purchase value' : p.resultLabel) + '</dt><dd>' + esc(resTxt) + '</dd></div>' +
      '<div><dt>' + esc(p.costLabel) + '</dt><dd>' + esc(costTxt) + (U.isNum(p.n) && p.type !== 'Awareness' ? ' <small>n=' + esc(U.count(p.n)) + '</small>' : '') + '</dd></div>' +
      '<div><dt>CTR</dt><dd>' + esc(U.pct(k.ctr)) + '</dd></div>' +
      '<div><dt>Link CTR</dt><dd>' + (k.linkKnown ? esc(U.pct(k.link_ctr)) : '<span data-tip="Link clicks not reported">' + U.DASH + '</span>') + '</dd></div>' +
      '<div><dt data-tip="Impressions ÷ sum of daily reach">Freq/day</dt><dd>' + esc(U.ratioX(k.freq)) + '</dd></div></dl>' +
      (opts.conf ? '<p class="conf-l ' + esc(opts.conf) + '">' + esc(opts.conf) + (p.n === null ? ' (value-based, no count)' : opts.conf === 'directional' ? ' (5–24 results)' : ' (25+ results)') + '</p>' : '') +
      fat + '<div class="cfoot">' + UI.dbadge(a.decision.label, { why: a.decision.why, action: a.decision.action, evidence: a.evidence }) +
      (U.safeUrl(a.preview) ? '<a class="prev" href="' + esc(U.safeUrl(a.preview)) + '" target="_blank" rel="noopener noreferrer">Preview ↗</a>' : '') + '</div></div></article>';
  };

  /** Grid of cards with a "Show more" pager. */
  V.creativeGrid = function (ctx, list, opts) {
    opts = opts || {};
    var limit = opts.limit || ctx.state.ui.creativesLimit || 48;
    var shown = list.slice(0, limit);
    var more = list.length - shown.length;
    return '<div class="cgrid">' + shown.map(function (a, i) {
      var conf = null;
      if (opts.ranked && a.prim.type !== 'Awareness') conf = a.prim.n === null ? 'directional' : E.confidence(a.prim.n);
      return V.creativeCard(ctx, a, { rank: opts.ranked ? i + 1 : null, conf: conf, showFatigue: opts.fatigue });
    }).join('') + '</div>' + (more > 0 ? '<button type="button" class="btn ghost more" data-act="cr-more">Show ' + Math.min(more, 48) + ' more of ' + more + '</button>' : '');
  };

  /** Filter ad rows by sidebar scope + row filters (+ optional client slug). */
  V.creativeAds = function (ctx, slug) {
    var snap = ctx.snap, rf = M.rowFilter(snap.F);
    return snap.ads.filter(function (a) { return a.inScope && (!slug || a.clientSlug === slug) && rf(a); });
  };

  /** Tabbed wall (used by the Creatives page and the client view). */
  V.creativeWall = function (ctx, ads, opts) {
    opts = opts || {};
    var st = ctx.state, tab = st.ui.creativesTab, L = V.creativesLists(ctx, ads);
    var counts = { winners: L.winnersCount, zero: L.zero.length, fatigue: L.fatigue.length, all: L.all.length };
    var out = ['<div class="bar-tools">' + UI.tabs('creatives', TABS.map(function (t) { return { id: t.id, label: t.label, count: counts[t.id] }; }), tab)];
    if (tab === 'all') {
      out.push('<label class="sortsel">Sort <select data-change="cr-sort" class="inp">' + SORTS.map(function (s) {
        return '<option value="' + s.id + '"' + (st.ui.creativesSort === s.id ? ' selected' : '') + '>' + esc(s.label) + '</option>';
      }).join('') + '</select></label>');
    }
    out.push('<button type="button" class="btn ghost sm" data-act="cr-csv" data-slug="' + esc(opts.slug || '') + '">Export CSV</button></div>');
    if (tab === 'winners') {
      out.push('<p class="hint">Lowest cost per primary result, ranked within each result type. Gate: ≥ 2,000 impressions and ≥ 5 results' +
        (ctx.reg.hasTargets ? ', and spend ≥ 3× the client’s target cost per result where one exists' : '') + '. Labels: directional (5–24 results), confident (25+).</p>');
      if (!L.winners.length) out.push('<p class="empty">No ad passes the winner gate for this selection.</p>');
      L.winners.forEach(function (g) {
        out.push('<h3 class="sub-h">' + esc(g.label) + ' <span class="muted">· ' + g.rows.length + '</span></h3>' + V.creativeGrid(ctx, g.rows, { ranked: true, limit: opts.limitPerGroup || 12 }));
      });
    } else if (tab === 'zero') {
      out.push('<p class="hint">Spend ≥ ' + esc(U.money(ctx.snap.rules.zeroSpend)) + ' (the Immediate Action threshold) with zero primary results. Awareness ads and new ads are excluded.</p>');
      out.push(L.zero.length ? V.creativeGrid(ctx, L.zero, {}) : '<p class="empty">No ad is spending without results.</p>');
    } else if (tab === 'fatigue') {
      out.push('<p class="hint">≥ 2,000 impressions in both periods and at least 2 of 3 worsened vs the ad’s own comparison period: link CTR down ≥ 20%, CPM up ≥ 18%, cost per result up ≥ 30%. ' +
        'Frequency ≥ 2.5× (Meta) is supporting evidence only. New ads are exempt.</p>');
      if (!ctx.snap.B) out.push('<p class="empty">Fatigue needs a comparison period with a baseline.</p>');
      else out.push(L.fatigue.length ? V.creativeGrid(ctx, L.fatigue, { fatigue: true }) : '<p class="empty">No ad shows fatigue on 2 of 3 signals.</p>');
    } else {
      out.push(L.all.length ? V.creativeGrid(ctx, sortAll(L.all, st.ui.creativesSort), {}) : '<p class="empty">No ads for this selection.</p>');
    }
    return out.join('');
  };

  V.creatives = {
    render: function (ctx) {
      var snap = ctx.snap, P = snap.P, st = ctx.state;
      var slug = st.route.params && st.route.params.cl;
      var client = slug && ctx.ds.bySlug.has(slug) ? ctx.ds.clients[ctx.ds.bySlug.get(slug)] : null;
      var ads = V.creativeAds(ctx, client ? slug : null);
      var cov = ctx.meta && ctx.meta.creatives;
      var out = ['<div class="page"><header class="page-h"><div><div class="eyebrow">What’s working, with real images</div><h1>Creatives</h1></div>' +
        '<div class="scope"><b>' + esc(P.label) + '</b>' + (P.cmp ? ' vs ' + esc(P.cmpLabel) : '') + '<span>' + ads.length + ' ' + U.plural(ads.length, 'ad') +
        (cov && cov.meta ? ' · images saved: Meta ' + cov.meta.saved + '/' + cov.meta.ads + (cov.tiktok ? ', TikTok ' + cov.tiktok.saved + '/' + cov.tiktok.ads : '') : '') + '</span></div></header>'];
      if (client) out.push('<p class="filter-note">Client: <b>' + esc(client.name) + '</b> <a class="fchip" href="#/creatives">Show all clients <span aria-hidden="true">×</span></a></p>');
      if (!P.cur) { out.push('<section class="panel"><p class="empty">No data in this period.</p></section></div>'); return out.join(''); }
      out.push('<section class="panel">' + V.creativeWall(ctx, ads, { slug: client ? slug : '' }) + '</section>');
      out.push(G.views.common.notes(['Images come from the GROOV creative library; nothing is substituted. A blank tile says why an image is missing.',
        'Google data has no ad-level rows (ad groups only), so Google has no creative cards.', G.views.common.HONEST.results, G.views.common.HONEST.reach]));
      out.push('</div>');
      return out.join('');
    }
  };

  /* ---------- handlers ---------- */
  A['cr-more'] = function () { G.app.update(function (st) { st.ui.creativesLimit = (st.ui.creativesLimit || 48) + 48; }); };
  A['cr-sort'] = function (el) { var v = el.value; G.app.update(function (st) { st.ui.creativesSort = v; }); };
  A['cr-csv'] = function (el) {
    var ctx = G.app.ctx();
    if (!ctx.snap) return;
    var slug = el.getAttribute('data-slug') || (ctx.state.route.page === 'creatives' && ctx.state.route.params ? ctx.state.route.params.cl : null);
    var ads = V.creativeAds(ctx, slug || null);
    var L = V.creativesLists(ctx, ads), tab = ctx.state.ui.creativesTab, list;
    if (tab === 'winners') list = [].concat.apply([], L.winners.map(function (g) { return g.rows; }));
    else if (tab === 'zero') list = L.zero;
    else if (tab === 'fatigue') list = L.fatigue;
    else list = sortAll(L.all, ctx.state.ui.creativesSort);
    var rows = [['Tab', 'Client', 'Platform', 'Campaign', 'Ad set / ad group', 'Ad', 'Ad id', 'Status', 'Objective', 'Spend', 'Result type', 'Result', 'Cost per result', 'n',
      'CTR %', 'Link CTR %', 'Avg daily frequency', 'First date', 'Last date', 'Decision', 'Image', 'Preview']];
    list.forEach(function (a) {
      rows.push([tab, a.client.name, D.PLATFORM_LABEL[a.platform], a.campaign.name, a.adsetName || '', a.name, a.id, a.status, a.objective, a.cur.spend,
        E.TYPE_LABEL[a.prim.type] || a.prim.type, a.prim.result, a.prim.cost, a.prim.n, a.k.ctr, a.k.link_ctr, a.k.freq, a.first_date || '', a.last_date || '',
        a.decision.label, a.image ? 'saved' : (a.image_reason || 'none'), a.preview || '']);
    });
    UI.download(UI.csvName('creatives-' + tab + (slug ? '-' + slug : ''), ctx.snap.P), U.csv(rows));
  };
})(typeof window !== 'undefined' ? window : this);
