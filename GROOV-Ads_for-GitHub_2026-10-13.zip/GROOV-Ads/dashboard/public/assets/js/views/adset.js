/* GROOV Ads Command Center · views/adset.js
 * ------------------------------------------------------------------------------------------
 * Role: where results happen (SPEC §4.8).
 *   sheet(ctx)      the ad set panel (route param `as` = ad set key, so Back closes it and a copied
 *                   link opens it): KPI trend tiles for the ad set's objective, its share of the
 *                   client's results, then By placement and By audience (Meta breakdowns) with a
 *                   sentence generated from the numbers, coverage and low-n notes, Δ vs comparison
 *   where(ctx, d)   the client view section: objective selector (only objectives present, default
 *                   the one with the most spend: result types are never mixed), campaign filter,
 *                   placement + audience aggregated over the client's ad sets, and By ad set
 *                   (targeting audience) from Sheet 1
 *   EMPTY           the exact empty-state copy (SPEC §4.8) when the breakdown Sheets aren't there
 *   key(ctx), close(), afterRender(prevKey, key)   used by app.js (focus, Esc, Back)
 * Breakdowns are Meta-only and load lazily (app.loadBreakdowns) the first time a panel or the
 * section renders. Handlers: adset-open (ad set rows / names), adset-close, wr-type, wr-camp,
 * bd-retry, bd-other (expand "Other placements").
 */
(function (root) {
  'use strict';
  var G = root.GROOV = root.GROOV || {};
  var U = G.util, D = G.data, E = G.engine, M = G.model, UI = G.ui;
  var V = G.views = G.views || {};
  var A = G.actions = G.actions || {};
  var esc = U.esc;
  var S = V.adset = {};

  S.EMPTY = 'Placement and audience splits appear once the two Meta breakdown exports run (see sheets-export.md)';
  S.UNREACHABLE = 'No placement/audience data for this account — it isn’t reachable in Windsor; reconnect it there.';
  var sel = {};          // client slug -> { type, camp } (section choices, this browser tab)
  var pushedKey = null;  // the panel this tab opened with a history entry (close = Back)
  var opener = null;     // { key, scope (id of the opener's nearest ancestor with an id) }: focus returns there

  S.key = function (ctx) {
    var p = ctx && ctx.state && ctx.state.route && ctx.state.route.params;
    return p && typeof p.as === 'string' && p.as ? p.as : null;
  };
  function adsetRow(snap, key) {
    for (var i = 0; i < snap.adsets.length; i++) if (snap.adsets[i].key === key) return snap.adsets[i];
    return null;
  }
  function regClient(ctx, slug) {
    var i = ctx.ds && ctx.ds.bySlug ? ctx.ds.bySlug.get(slug) : undefined;
    return i === undefined ? null : ctx.ds.clients[i];
  }

  /** Breakdown load state for this render: 'ready' | 'loading' | 'error' | 'stale'. Starts the lazy load. */
  function bdState(ctx) {
    if (ctx.bd && ctx.bdReady) return 'ready';
    if (ctx.bdError) return ctx.bd ? 'stale' : 'error';
    if (G.app && G.app.loadBreakdowns) G.app.loadBreakdowns();
    return 'loading';
  }
  function bdNotice(ctx, state) {
    if (state === 'loading') return '<div class="skel short" aria-hidden="true"></div><p class="muted small" role="status">Loading placement and audience splits…</p>';
    if (state === 'error') {
      return '<p class="err-t" role="alert">Placement and audience splits could not load: ' + esc(ctx.bdError) +
        ' <button type="button" class="btn ghost sm" data-act="bd-retry">Retry</button></p>';
    }
    if (state === 'stale') {
      return '<p class="warnt small" role="alert">Splits for this period could not load (' + esc(ctx.bdError) + '). Showing the breakdown data that loaded earlier, which may not cover this period. ' +
        '<button type="button" class="btn ghost xs" data-act="bd-retry">Retry</button></p>';
    }
    return '';
  }

  /* =========================================================================================
   * Shared blocks
   * ======================================================================================= */
  function tagChip(t) {
    if (!t) return '';
    var lean = { works: 'works', weak: 'weak', nores: 'spending with no results' }[t.lean];
    var tip = t.tag === 'directional' ? 'Leans “' + E.BD_TAG_LABEL[t.lean] + '”, but the block has fewer than 10 results, so no tag is stronger than directional.' :
      t.tag === 'works' ? 'Share of results ≥ 1.2 × share of spend, with ≥ 3 results.' : t.tag === 'weak' ? 'Share of results ≤ 0.8 × share of spend.' :
        '≥ 10% of the spend and no results.';
    return '<span class="btag ' + esc(t.tag) + (t.tag === 'directional' ? ' lean-' + esc(t.lean) : '') + '" data-tip="' + esc(tip) + '">' + esc(t.label) +
      (t.tag === 'directional' ? '<span class="sr"> (leans ' + esc(lean) + ')</span>' : '') + '</span>';
  }
  /** Paired bars: % of spend (copper) above % of results (blue), scaled to the block's largest share. */
  function pbar(r, max, so, bare) {
    var w = function (x) { return U.isNum(x) && max > 0 ? Math.max(0, Math.min(100, x / max * 100)).toFixed(1) : '0'; };
    var second = so ? r.impShare : r.resShare;
    var lab = function (x) { return bare ? '' : '<small>' + esc(M.shareText(x)) + '</small>'; };
    return '<span class="pbar' + (bare ? ' bare' : '') + '" aria-hidden="true"><span class="pb"><i class="ps" style="width:' + w(r.spendShare) + '%"></i></span>' + lab(r.spendShare) +
      '<span class="pb"><i class="pr" style="width:' + w(second) + '%"></i></span>' + lab(second) + '</span>';
  }
  function maxShare(rows, so) {
    var m = 0;
    rows.forEach(function (r) { [r.spendShare, so ? r.impShare : r.resShare].forEach(function (x) { if (U.isNum(x) && x > m) m = x; }); });
    return m;
  }
  function pctCell(x, d, hasPrev) { return '<b>' + esc(M.shareText(x)) + '</b>' + (hasPrev ? ' ' + UI.pts(d) : ''); }
  function costText(res, v) { return U.isNum(v) ? U.money(v) : U.DASH; }
  function resText(r) { return r.results === null ? U.DASH : U.count(r.results); }
  function legendBars(res) {
    return '<div class="legend small"><span class="lg"><i class="sw" style="background:var(--copper)"></i>% of spend</span><span class="lg"><i class="sw" style="background:var(--blue)"></i>% of ' +
      esc(res.sharesOnly ? 'impressions' : res.word) + '</span><span class="lg muted">Bars scale to the largest share in the block</span></div>';
  }
  /** "Covers 99.8% of this ad set's spend (comparison 97.1%)", capped at 100%, plus the low-n warning. */
  function coverageNote(block, whose) {
    var c = block.coverage, out = 'Covers ' + M.coverageText(c.cur) + ' of ' + whose + ' spend';
    if (U.isNum(c.prev)) out += ' (comparison: ' + M.coverageText(c.prev) + ')';
    out += '.';
    if ((U.isNum(c.cur) && c.cur > M.BD_OVER) || (U.isNum(c.prev) && c.prev > M.BD_OVER)) out += ' (breakdown data is newer than the main data for the last days)';
    var html = '<p class="cov">' + esc(out);
    if (block.lowN) html += ' <span class="warnt">Fewer than 10 ' + esc(block.res.word) + ' in total (n=' + esc(U.count(block.total.results)) + '): every tag is directional.</span>';
    if (block.cmpWindow && !block.hasPrev) html += ' <span class="muted">The comparison period has no breakdown rows, so no Δ.</span>';
    return html + '</p>';
  }

  /** By placement table (SPEC §4.8.1) with the expandable "Other placements" row. */
  function placementBlock(ctx, block, id, whose) {
    var res = block.res, so = block.sharesOnly, hp = block.hasPrev;
    var head = '<h3 class="sub-h">By placement</h3>' + coverageNote(block, whose);
    if (block.empty) return head + '<p class="muted small">No placement rows for ' + esc(whose.replace(/’s$|s’$/, '')) + ' in ' + esc(ctx.snap.P.label) + '.</p>';
    var max = maxShare(block.rows.concat([].concat.apply([], block.rows.map(function (r) { return r.children || []; }))), so);
    var openSet = ctx.app && ctx.app.expanded ? ctx.app.expanded('bdo') : new Set();
    var otherOpen = openSet.has(id);
    var th = '<th scope="col">Placement</th><th scope="col" class="pbc">% spend vs % ' + esc(so ? 'impr.' : 'results') + '</th><th scope="col" class="num">Spend</th><th scope="col" class="num">% of spend</th>' +
      (so ? '<th scope="col" class="num">Impressions</th><th scope="col" class="num">% of impr.</th>' :
        '<th scope="col" class="num">' + esc(res.label) + '</th><th scope="col" class="num">% of results</th><th scope="col" class="num">' + esc(res.costLabel) + '</th>') +
      '<th scope="col" class="num">Link CTR</th><th scope="col" class="num">CPM</th>';
    var line = function (r, sub) {
      var name = esc(r.label);
      if (r.isOther) {
        name = '<button type="button" class="linkb" data-act="bd-other" data-v="' + esc(id) + '" aria-expanded="' + otherOpen + '">' + (otherOpen ? '▾ ' : '▸ ') +
          'Other placements <small class="muted">(' + r.children.length + ')</small></button>';
      }
      // rows inside "Other placements" carry no tag of their own: each is under 2% of spend with no results by construction
      var cells = '<th scope="row" class="pl-n' + (sub ? ' sub' : '') + '">' + name + (so || sub || !r.tag ? '' : ' ' + tagChip(r.tag)) + '</th><td class="pbc">' + pbar(r, max, so) + '</td><td class="num">' + esc(U.money(r.spend)) + '</td>' +
        '<td class="num">' + pctCell(r.spendShare, r.dSpend, hp) + '</td>';
      if (so) cells += '<td class="num">' + esc(U.int(r.imp)) + '</td><td class="num">' + pctCell(r.impShare, r.dImp, hp) + '</td>';
      else cells += '<td class="num">' + esc(resText(r)) + '</td><td class="num">' + pctCell(r.resShare, r.dRes, hp) + '</td><td class="num">' + esc(costText(res, r.cpr)) + '</td>';
      cells += '<td class="num">' + (r.linkKnown ? esc(U.pct(r.linkCtr)) : '<span class="na" data-tip="Link clicks not reported">' + U.DASH + '</span>') + '</td><td class="num">' + esc(U.money(r.cpm)) + '</td>';
      return '<tr class="' + (sub ? 'sub' : '') + (r.isOther ? ' other' : '') + '">' + cells + '</tr>';
    };
    var body = '';
    block.rows.forEach(function (r) {
      body += line(r, false);
      if (r.isOther && otherOpen) r.children.forEach(function (c) { body += line(c, true); });
    });
    var foot = block.rows.some(function (r) { return r.isOther; }) ? '<p class="muted small">Other placements: each under 2% of spend with no ' + esc(so ? 'tracked results' : res.word) + '.</p>' : '';
    return head + legendBars(res) + '<div class="tbl-wrap bd-wrap"><table class="tbl bdt"><thead><tr>' + th + '</tr></thead><tbody>' + body + '</tbody></table></div>' + foot;
  }

  /** Bar list rows (age / gender): label + tag, paired bars, shares, cost. */
  function barList(rows, max, block) {
    var so = block.sharesOnly, res = block.res, hp = block.hasPrev;
    return '<div class="blist">' + rows.map(function (r) {
      var secondLabel = so ? 'impressions' : res.word, second = so ? r.impShare : r.resShare, secondD = so ? r.dImp : r.dRes;
      var cost = so || res.per === 1000 ? 'CPM ' + U.money(r.cpm) : U.isNum(r.cpr) ? U.money(r.cpr) + ' each' : 'no ' + res.word;
      return '<div class="bl-r"><div class="bl-h"><span class="bl-n">' + esc(r.label) + '</span>' + (so ? '' : tagChip(r.tag)) + '</div>' + pbar(r, max, so, true) +
        '<div class="bl-v"><span>spend <b>' + esc(M.shareText(r.spendShare)) + '</b>' + (hp ? ' ' + UI.pts(r.dSpend) : '') + '</span><span>' + esc(secondLabel) + ' <b>' +
        esc(M.shareText(second)) + '</b>' + (hp ? ' ' + UI.pts(secondD) : '') + '</span><span>' + esc(cost) + '</span></div></div>';
    }).join('') + '</div>';
  }

  /** By audience (SPEC §4.8.1): age × gender heatmap of % of results + age and gender bars. */
  function audienceBlock(ctx, block, whose) {
    var res = block.res, so = block.sharesOnly, hp = block.hasPrev;
    var head = '<h3 class="sub-h">By audience</h3>' + coverageNote(block, whose);
    if (block.empty || !block.grid.ages.length || !block.grid.genders.length) return head + '<p class="muted small">No audience rows for ' + esc(whose.replace(/’s$|s’$/, '')) + ' in ' + esc(ctx.snap.P.label) + '.</p>';
    var shareOf = function (c) { return so ? c.spendShare : c.resShare; };
    var mx = 0;
    block.visibleCells.forEach(function (c) { var s = shareOf(c); if (U.isNum(s) && s > mx) mx = s; });
    var gl = { female: 'Female', male: 'Male', unknown: 'Unknown' };
    var th = '<th scope="col">Age</th>' + block.grid.genders.map(function (g) { return '<th scope="col" class="num">' + esc(gl[g]) + '</th>'; }).join('');
    var rows = block.grid.ages.map(function (age) {
      return '<tr><th scope="row">' + esc(age === 'Unknown' ? 'Unknown' : age.replace('-', '–')) + '</th>' + block.grid.genders.map(function (g) {
        var c = block.grid.cell(age, g);
        if (!c) return '<td class="hc none">' + U.DASH + '</td>';
        var s = shareOf(c), a = U.isNum(s) && mx > 0 ? 0.08 + 0.8 * (s / mx) : 0.04;
        var tip = c.label + ' · spend ' + U.money(c.spend) + ' (' + M.shareText(c.spendShare) + ' of spend)' +
          (so ? ' · ' + U.int(c.imp) + ' impressions (' + M.shareText(c.impShare) + ')' : ' · ' + resText(c) + ' ' + res.word + ' (' + M.shareText(c.resShare) + ') · ' + res.costLabel + ' ' + costText(res, c.cpr));
        return '<td class="hc' + (a > 0.55 ? ' dark' : '') + '" style="background:rgba(114,168,185,' + a.toFixed(3) + ')" data-tip="' + esc(tip) + '"><b>' + esc(M.shareText(s)) + '</b>' +
          (hp ? UI.pts(so ? c.dSpend : c.dRes) : '') + '</td>';
      }).join('') + '</tr>';
    }).join('');
    var maxA = maxShare(block.ages.concat(block.genders), so);
    var hidden = block.hidden.length ? '<p class="muted small">Not shown (under 1% of spend): ' + block.hidden.map(function (h) {
      return esc(h.label) + ' ' + esc(M.shareText(h.spendShare)) + ' of spend' + (so ? '' : ', ' + esc(M.shareText(h.resShare)) + ' of ' + esc(res.word));
    }).join('; ') + '. Shares include them, so the cells shown can sum to a little under 100%.</p>' : '';
    var tv = '<details class="tview"><summary>Table view</summary><div class="tbl-wrap"><table class="tbl"><thead><tr><th scope="col">Audience</th><th scope="col" class="num">Spend</th>' +
      '<th scope="col" class="num">% of spend</th>' + (so ? '<th scope="col" class="num">Impressions</th><th scope="col" class="num">% of impr.</th><th scope="col" class="num">CPM</th>' :
        '<th scope="col" class="num">' + esc(res.label) + '</th><th scope="col" class="num">% of results</th><th scope="col" class="num">' + esc(res.costLabel) + '</th><th scope="col">Tag</th>') +
      '</tr></thead><tbody>' + block.cells.slice().sort(function (a, b) { return D.AGE_ORDER.indexOf(a.age) - D.AGE_ORDER.indexOf(b.age) || D.GENDER_ORDER.indexOf(a.gender) - D.GENDER_ORDER.indexOf(b.gender); }).map(function (c) {
        return '<tr><th scope="row">' + esc(c.label) + '</th><td class="num">' + esc(U.money(c.spend)) + '</td><td class="num">' + esc(M.shareText(c.spendShare)) + '</td>' +
          (so ? '<td class="num">' + esc(U.int(c.imp)) + '</td><td class="num">' + esc(M.shareText(c.impShare)) + '</td><td class="num">' + esc(U.money(c.cpm)) + '</td>' :
            '<td class="num">' + esc(resText(c)) + '</td><td class="num">' + esc(M.shareText(c.resShare)) + '</td><td class="num">' + esc(costText(res, c.cpr)) + '</td><td>' + tagChip(c.tag) + '</td>') + '</tr>';
      }).join('') + '</tbody></table></div></details>';
    return head + '<p class="muted small">Cells: % of ' + esc(so ? 'spend (Conversions ad sets have no result counts by audience)' : res.word) + ', shaded by share; hover a cell for spend and cost.</p>' +
      '<div class="aud"><div class="hm-wrap"><table class="hm"><thead><tr>' + th + '</tr></thead><tbody>' + rows + '</tbody></table></div>' +
      '<div class="aud-bars"><h4 class="mini-h">Age</h4>' + barList(block.ages, maxA, block) + '<h4 class="mini-h">Gender</h4>' + barList(block.genders, maxA, block) + '</div></div>' +
      legendBars(res) + hidden + tv;
  }

  /**
   * The breakdown part of the panel / section, after every honest empty state:
   * not Meta → Meta-only note; Sheets missing → EMPTY; account unreachable → reconnect note.
   */
  function breakdownPart(ctx, rows, res, opts) {
    var state = bdState(ctx), bd = ctx.bd;
    if (state === 'loading' || state === 'error') return bdNotice(ctx, state);
    var notice = bdNotice(ctx, state);
    if (!bd || (!bd.available.placement && !bd.available.audience)) return notice + '<p class="empty bd-empty">' + esc(S.EMPTY) + '</p>';
    var P = ctx.snap.P;
    var reach = M.bdReach(bd, ctx.ds, rows, P.cur.from, P.cur.to);
    if (!reach.accounts.size) {
      // no account has rows in this window: either the exports have not run yet, or they cover other dates
      var lo = U.minIso(bd.placement.minDate, bd.audience.minDate), hi = U.maxIso(bd.placement.maxDate, bd.audience.maxDate);
      if (!lo) return notice + '<p class="empty bd-empty">' + esc(S.EMPTY) + '</p>';
      return notice + '<p class="empty bd-empty">No placement or audience rows in ' + esc(P.label) + ': the breakdown exports cover ' + esc(U.rangeLabel(lo, hi)) + '.</p>';
    }
    if (!reach.reachable.length && reach.unreachable.length) return notice + '<p class="empty bd-empty">' + esc(S.UNREACHABLE) + '</p>';
    var pl = bd.available.placement ? M.bdBlock(bd, P, rows, 'placement', res) : null;
    var au = bd.available.audience ? M.bdBlock(bd, P, rows, 'audience', res) : null;
    var sentence = M.bdSentence(pl, au, res);
    var out = [notice];
    if (sentence) out.push('<p class="bd-sent">' + esc(sentence) + '</p>');
    if (reach.unreachable.length && reach.reachable.length) {
      out.push('<p class="warnt small">' + reach.unreachable.length + ' ' + U.plural(reach.unreachable.length, 'ad set') + ' with spend ' + (reach.unreachable.length === 1 ? 'is' : 'are') +
        ' in an account that isn’t reachable in Windsor, so ' + (reach.unreachable.length === 1 ? 'it is' : 'they are') + ' missing from these splits (reconnect the account there).</p>');
    }
    if (res.sharesOnly) out.push('<p class="muted small">Conversions (Meta ROAS): purchase value isn’t in the breakdown Sheets, so these splits show spend and impression shares only.</p>');
    var whose = opts.whose;
    var plH = pl ? placementBlock(ctx, pl, opts.id, whose) : '<h3 class="sub-h">By placement</h3><p class="muted small">Placement splits appear once the Meta placement breakdown export runs (see sheets-export.md).</p>';
    var auH = au ? audienceBlock(ctx, au, whose) : '<h3 class="sub-h">By audience</h3><p class="muted small">Audience splits appear once the Meta audience breakdown export runs (see sheets-export.md).</p>';
    out.push('<div class="bd-grid"><div class="bd-col">' + plH + '</div><div class="bd-col">' + auH + '</div></div>');
    return out.join('');
  }

  /* =========================================================================================
   * Ad set panel
   * ======================================================================================= */
  var CLOSE_IC = '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M18 6L6 18M6 6l12 12"/></svg>';
  S.sheet = function (ctx) {
    var key = S.key(ctx);
    if (!key || !ctx.snap) return '';
    var snap = ctx.snap, P = snap.P, a = adsetRow(snap, key);
    var head, body;
    if (!a || !P.cur) {
      head = '<div><div class="eyebrow">Ad set</div><h2 id="sheet-h">Ad set not in view</h2></div>';
      body = '<p class="empty">' + (P.cur ? 'This ad set has no delivery in ' + esc(P.label) + (P.cmp ? ' or ' + esc(P.cmpLabel) : '') + '.' : 'No data in this period.') + '</p>';
    } else {
      var lvl = a.platform === 'meta' ? 'Ad set' : 'Ad group';
      var onClient = ctx.state.route.page === 'client' && ctx.state.route.slug === a.clientSlug;
      head = '<div class="sh-main"><div class="eyebrow">' + esc(lvl) + ' · ' + esc(D.PLATFORM_LABEL[a.platform] || a.platform) + '</div><h2 id="sheet-h">' + esc(a.name) + '</h2>' +
        '<p class="path">' + esc(a.client.name) + ' <span aria-hidden="true">›</span> ' + esc(a.campaign.name) + '</p><div class="sh-tags">' + UI.pchip(a.platform) + ' ' +
        UI.statusBadge(a.status) + ' <span class="otag">' + esc(E.TYPE_LABEL[a.prim.type] || a.objective) + '</span> ' +
        UI.dbadge(a.decision.label, { why: a.decision.why, action: a.decision.action, evidence: a.evidence }) + (a.isNew ? ' ' + UI.newBadge() : '') +
        (onClient ? '' : ' <a class="btn ghost xs" href="#/client/' + encodeURIComponent(a.clientSlug) + '">Open client</a>') + '</div>' +
        '<p class="muted small">' + esc(P.label) + (P.cmp ? ' vs ' + esc(P.cmpLabel) + (P.noBaseline ? ' · no baseline' : '') : ' · comparison off') +
        (a.inScope ? '' : ' · <span class="warnt">outside the sidebar filters</span>') + '</p></div>';
      body = adsetBody(ctx, a, onClient);
    }
    return '<div class="ss-back" data-act="adset-close" aria-hidden="true"></div><aside class="ss" role="dialog" aria-modal="true" aria-labelledby="sheet-h" tabindex="-1">' +
      '<header class="ss-h">' + head + '<button type="button" class="ss-x" data-act="adset-close" aria-label="Close the ad set panel">' + CLOSE_IC + '</button></header>' +
      '<div class="ss-b">' + body + '</div></aside>';
  };

  function adsetBody(ctx, a, onClient) {
    var snap = ctx.snap, P = snap.P;
    var client = regClient(ctx, a.clientSlug);
    var items = [{ kpi: 'spend', label: 'Spend' }].concat(V.trend.TILES[a.prim.type] || []);
    var scope = { id: 'as', key: 'as:' + a.key, title: a.name, adsets: [a], cur: a.cur, cmp: a.cmp, type: a.prim.type, objective: a.objective,
      platforms: [a.platform], client: client, vertical: client ? client.vertical : null, splits: ['total'], items: items };
    var tiles = items.map(function (it) { return V.trend.kpiTile(ctx, scope, it, it.kpi === 'spend' ? { cls: 'spend' } : {}); }).join('');
    // the ad set's share of the client's results for this result type (campaigns in view)
    var cp = onClient ? ctx.state.ui.clientPlatform || 'all' : 'all';
    var camps = snap.camps.filter(function (r) { return r.clientSlug === a.clientSlug && r.inScope && (cp === 'all' || r.platform === cp); });
    var rs = M.resultShare(camps), share = rs(a), tot = rs.total(a.prim.type);
    var rw = a.prim.type === 'Conversions·value' ? 'purchase value' : String(a.prim.resultLabel || 'results').toLowerCase();
    var shareLine = U.isNum(share) ? '<p class="sh-share">This ' + (a.platform === 'meta' ? 'ad set' : 'ad group') + ' brought <b>' + esc(M.shareText(share)) + '</b> of ' + esc(a.client.name) + '’s ' + esc(rw) +
      ' this period (' + esc(UI.resultText(a.prim, a.prim.result)) + ' of ' + esc(UI.resultText(a.prim, tot)) + ', ' + esc(E.TYPE_LABEL[a.prim.type] || a.prim.type) + ' campaigns' + (cp !== 'all' ? ', ' + esc(D.PLATFORM_LABEL[cp]) : '') + ').</p>' :
      '<p class="sh-share muted">No ' + esc(rw) + ' for this client’s ' + esc(E.TYPE_LABEL[a.prim.type] || a.prim.type) + ' campaigns this period, so there is no share to show.</p>';
    var out = ['<section class="sh-sec"><h3 class="sub-h">KPI trends</h3><div class="kstrip">' + tiles + '</div>' + V.trend.panel(ctx, scope) +
      (P.provisional ? '<p class="prov-note">Includes provisional days ' + esc(U.rangeLabel(P.provisional.from, P.provisional.to)) + ': late conversions can still change these numbers.</p>' : '') + shareLine + '</section>'];
    var res = E.bdResult(a.objective);
    var bdHtml;
    if (a.platform !== 'meta') bdHtml = '<p class="empty bd-empty">Placement and audience splits are Meta-only: this is a ' + esc(D.PLATFORM_LABEL[a.platform]) + ' ad group.</p>';
    else if (!(a.cur.spend > 0)) bdHtml = '<p class="muted">No spend in ' + esc(P.label) + ', so there is nothing to split.</p>';
    else bdHtml = breakdownPart(ctx, [a], res, { id: 'as:' + a.key, whose: 'this ad set’s' });
    out.push('<section class="sh-sec"><h3 class="sec-h">Where results happen</h3><p class="muted small">Inside this ad set · % of spend vs % of ' + esc(res.sharesOnly ? 'impressions' : res.word) +
      ' · ' + esc(P.label) + '</p>' + bdHtml + '</section>');
    out.push('<p class="muted small sh-foot">Platform-reported results; placement and audience rows come from the optional Meta breakdown exports. Tags: Works = share of results ≥ 1.2 × share of spend (≥ 3 results); Weak = ≤ 0.8 ×; ' +
      'Spending, no results = ≥ 10% of spend and none; under 10 results in total every tag is directional.</p>');
    return out.join('');
  }

  /* =========================================================================================
   * Client view section
   * ======================================================================================= */
  S.where = function (ctx, d) {
    var snap = ctx.snap, P = snap.P, F = snap.F, cp = ctx.state.ui.clientPlatform || 'all';
    var s = sel[d.slug] || {};
    var head = '<section class="panel wr" id="where-results"><div class="panel-h"><h2>Where results happen</h2><p>Meta placements and audiences inside the ad sets · % of spend vs % of results · ' + esc(P.label) + '</p>';
    var metaOff = F.platforms.length && F.platforms.indexOf('meta') < 0;
    if (metaOff || (cp !== 'all' && cp !== 'meta')) {
      return head + '</div><p class="empty bd-empty">Placement and audience splits are Meta-only, and ' + (metaOff ? 'the sidebar Platforms filter excludes Meta' : 'the platform switch is on ' + esc(D.PLATFORM_LABEL[cp])) + '.</p></section>';
    }
    var W = M.whereResults(snap, ctx.ds, d, null, s);
    if (!W.type) return head + '</div><p class="muted">No Meta ad set delivered for this client in ' + esc(P.label) + '.</p></section>';
    var typeSeg = W.types.length > 1 ? '<div class="seg" role="group" aria-label="Objective (results are never mixed)">' + W.types.map(function (x) {
      var on = x === W.type;
      return '<button type="button" class="' + (on ? 'on' : '') + '" aria-pressed="' + on + '" data-act="wr-type" data-v="' + esc(x.type) + '">' + esc(E.TYPE_LABEL[x.type] || x.type) +
        ' <small>' + esc(M.shareText(x.share)) + '</small></button>';
    }).join('') + '</div>' : '<span class="otag">' + esc(E.TYPE_LABEL[W.type.type] || W.type.type) + '</span>';
    var campSel = '<label class="sortsel">Campaign <select class="inp" data-change="wr-camp" aria-label="Campaign filter"><option value="">All ' + W.camps.length + ' ' + U.plural(W.camps.length, 'campaign') + '</option>' +
      W.camps.map(function (r) { return '<option value="' + esc(r.key) + '"' + (W.camp === r ? ' selected' : '') + '>' + esc(r.name) + ' · ' + esc(U.money(r.cur.spend)) + '</option>'; }).join('') + '</select></label>';
    var out = [head + '<div class="tools wr-tools">' + typeSeg + campSel + '</div></div>'];
    var whose = W.camp ? 'this campaign’s' : 'these ad sets’';
    out.push(breakdownPart(ctx, W.adsets, W.res, { id: 'cl:' + d.slug + ':' + W.type.type + ':' + (W.camp ? W.camp.key : 'all'), whose: whose }));
    out.push(byAdsetBlock(ctx, W));
    return out.join('') + '</section>';
  };

  /** By ad set (targeting audience): % of spend vs % of results per ad set, from Sheet 1. */
  function byAdsetBlock(ctx, W) {
    var B = W.byAdset, res = W.res, type = W.type.type, valueType = B.valueType;
    var rf = M.rowFilter(ctx.snap.F), hp = !!ctx.snap.B;
    var shown = B.rows.filter(function (x) { return rf(x.row); });
    var word = valueType ? 'purchase value' : res.word;
    var head = '<h3 class="sub-h">By ad set (targeting audience)</h3><p class="muted small">Each ad set’s % of spend vs % of ' + esc(word) + ' within ' + esc(E.TYPE_LABEL[type] || type) +
      (W.camp ? ' · ' + esc(W.camp.name) : '') + ' · from the main Meta Sheet' + (B.lowN ? ' · <span class="warnt">fewer than 10 ' + esc(word) + ' in total: every tag is directional</span>' : '') +
      (shown.length < B.rows.length ? ' · ' + (B.rows.length - shown.length) + ' hidden by row filters (shares ignore them)' : '') + '</p>';
    if (!B.rows.length) return head + '<p class="muted small">No ad set spent in this period.</p>';
    var max = maxShare(B.rows, false);
    var th = '<th scope="col">Ad set</th><th scope="col" class="pbc">% spend vs % results</th><th scope="col" class="num">Spend</th><th scope="col" class="num">% of spend</th><th scope="col" class="num">' +
      esc(valueType ? 'Purchase value' : res.label) + '</th><th scope="col" class="num">% of ' + esc(valueType ? 'value' : 'results') + '</th><th scope="col" class="num">' + esc(valueType ? 'ROAS' : res.costLabel) + '</th>';
    var body = shown.map(function (x) {
      var a = x.row;
      return '<tr><th scope="row" class="pl-n"><button type="button" class="linkb" data-act="adset-open" data-v="' + esc(a.key) + '">' + esc(a.name) + '</button>' + (x.tag ? ' ' + tagChip(x.tag) : '') +
        (W.camp ? '' : '<small class="muted lineage">' + esc(a.campaign.name) + '</small>') + '</th><td class="pbc">' + pbar(x, max, false) + '</td><td class="num">' + esc(U.money(x.spend)) + '</td>' +
        '<td class="num">' + pctCell(x.spendShare, x.dSpend, hp) + '</td><td class="num">' + esc(UI.resultText(a.prim, x.results)) + '</td><td class="num">' + pctCell(x.resShare, x.dRes, hp) + '</td>' +
        '<td class="num">' + esc(UI.costText(a.prim, x.cpr)) + '</td></tr>';
    }).join('');
    return head + legendBars(valueType ? { word: 'purchase value' } : res) + '<div class="tbl-wrap bd-wrap"><table class="tbl bdt"><thead><tr>' + th + '</tr></thead><tbody>' + body + '</tbody></table></div>';
  }

  /* =========================================================================================
   * Open / close (app.js calls key, close and afterRender)
   * ======================================================================================= */
  S.close = function () {
    var st = G.app.state, key = st && st.route && st.route.params && st.route.params.as;
    if (!key) return false;
    if (pushedKey === key && root.history && root.history.length > 1) { pushedKey = null; root.history.back(); return true; }
    pushedKey = null;
    G.app.update(function (s) { s.route.params = Object.assign({}, s.route.params); delete s.route.params.as; });
    return true;
  };
  /** Focus: into the panel when it opens, back to the ad set name or row when it closes. */
  S.afterRender = function (prevKey, key) {
    if (typeof document === 'undefined' || prevKey === key) return;
    if (key) {
      var x = document.querySelector('#sheet .ss-x');
      if (x) { try { x.focus({ preventScroll: true }); } catch (e) { x.focus(); } }
      return;
    }
    if (!prevKey) return;
    var q = root.CSS && CSS.escape ? CSS.escape(prevKey) : prevKey;
    var area = opener && opener.key === prevKey && opener.scope ? document.getElementById(opener.scope) : null;
    var find = function (r) { return r ? r.querySelector('[data-act="adset-open"][data-v="' + q + '"]') : null; };
    var el = find(area) || find(document);
    opener = null;
    if (el) { try { el.focus({ preventScroll: true }); } catch (e) { el.focus(); } }
  };

  /** Keep Tab inside the open panel (it covers the page; aria-modal). */
  if (typeof document !== 'undefined' && document.addEventListener) {
    document.addEventListener('keydown', function (ev) {
      if (ev.key !== 'Tab') return;
      var sheet = document.querySelector('#sheet .ss');
      if (!sheet) return;
      var list = sheet.querySelectorAll('a[href],button:not([disabled]),select,input,summary,[tabindex]:not([tabindex="-1"])');
      if (!list.length) return;
      var first = list[0], last = list[list.length - 1], a = document.activeElement;
      if (!sheet.contains(a)) { ev.preventDefault(); first.focus(); }
      else if (ev.shiftKey && a === first) { ev.preventDefault(); last.focus(); }
      else if (!ev.shiftKey && a === last) { ev.preventDefault(); first.focus(); }
    });
  }

  A['adset-open'] = function (el) {
    var key = el.getAttribute('data-v');
    if (!key) return;
    pushedKey = key;
    var holder = el.parentNode && el.parentNode.closest ? el.parentNode.closest('[id]') : null;
    opener = { key: key, scope: holder ? holder.id : null };
    if (G.ui && G.ui.hideTip) G.ui.hideTip();
    G.app.update(function (st) { st.route.params = Object.assign({}, st.route.params || {}); st.route.params.as = key; }, { push: true });
  };
  A['adset-close'] = function () { S.close(); };
  A['wr-type'] = function (el) {
    var slug = G.app.state.route.slug, v = el.getAttribute('data-v');
    sel[slug] = { type: v, camp: null };
    G.app.render();
  };
  A['wr-camp'] = function (el) {
    var slug = G.app.state.route.slug, cur = sel[slug] || {};
    var t = cur.type || null;
    if (!t) { // keep the objective in force when the first choice is a campaign
      var b = el.closest ? el.closest('.wr') : null, on = b ? b.querySelector('[data-act="wr-type"].on') : null;
      t = on ? on.getAttribute('data-v') : null;
    }
    sel[slug] = { type: t, camp: el.value || null };
    G.app.render();
  };
  A['bd-retry'] = function () { if (G.app.retryBreakdowns) G.app.retryBreakdowns(); };
  A['bd-other'] = function (el) {
    var set = G.app.expanded('bdo'), id = el.getAttribute('data-v');
    if (set.has(id)) set.delete(id); else set.add(id);
    G.app.render();
  };
})(typeof window !== 'undefined' ? window : this);
