/* GROOV Ads Command Center · views/overview.js
 * ------------------------------------------------------------------------------------------
 * Role: Overview page (SPEC §4.1): KPI cards (each with its trend line, SPEC §4.7; a click opens
 * the expanded chart under the cards), decision summary, daily spend chart, mix, the clients
 * table (main element) and top movers. Reads only the snapshot (model.js).
 * Public: GROOV.views.overview.render(ctx) -> HTML. Shared helpers for other views:
 *   GROOV.views.common.benchTick(...), .notes(...), .clientCostCell(...)
 * Totals ignore row filters (Decisions / Active only / Min spend); the cards say so when active.
 */
(function (root) {
  'use strict';
  var G = root.GROOV = root.GROOV || {};
  var U = G.util, D = G.data, E = G.engine, M = G.model, C = G.charts, UI = G.ui;
  var V = G.views = G.views || {};
  var A = G.actions = G.actions || {};
  var esc = U.esc;
  var common = V.common = V.common || {};

  /* ---------- shared helpers (also used by client / playbook views) ---------- */
  /** Benchmark for a primary result type: cost per message by vertical, CPM by platform for awareness. */
  common.benchFor = function (learn, type, vertical, platforms) {
    var list = learn && learn.rules && learn.rules.benchmarks;
    if (!list || !list.length) return null;
    if (type === 'Messages') return E.matchBenchmarks(list, { metric: 'cost_per_message', vertical: vertical })[0] || null;
    if (type === 'Lead generation') return E.matchBenchmarks(list, { metric: 'cpl', vertical: vertical })[0] || E.matchBenchmarks(list, { metric: 'cost_per_lead', vertical: vertical })[0] || null;
    if (type === 'Awareness' && platforms && platforms.length === 1) return E.matchBenchmarks(list, { metric: 'cpm', objective: 'Awareness', platform: platforms[0] })[0] || null;
    return null;
  };
  common.benchTick = function (value, b) {
    if (!b) return '';
    var pos = E.benchPosition(value, b);
    if (!pos) return '';
    var sym = pos === 'above' ? '▲' : pos === 'below' ? '▼' : '●';
    var word = E.benchIsTarget(b) ? 'target range' : 'observed range';
    var range = +b.low === +b.high ? U.moneyRound(+b.low) : U.moneyRound(+b.low) + '–' + U.moneyRound(+b.high);
    return '<span class="btick ' + pos + '" data-tip="' + esc(pos.charAt(0).toUpperCase() + pos.slice(1) + ' the ' + word + ' ' + range + ' · ' + (b.source || '') + ' · ' + (b.confidence || 'Observation') +
      (E.benchIsTarget(b) ? '' : ' (not a target)')) + '">' + sym + ' ' + esc(pos) + '</span>';
  };
  common.notes = function (items) {
    return '<footer class="notes"><h2 class="sr">Notes</h2><ul>' + items.map(function (t) { return '<li>' + t + '</li>'; }).join('') + '</ul></footer>';
  };
  common.HONEST = {
    results: 'Messages, leads and conversions are <b>platform-reported</b> events: not qualified leads, bookings or sales. Different result types are never added together.',
    dash: 'A missing denominator shows “—”, never ฿0.',
    reach: 'Reach is <b>daily</b> reach; frequency is impressions ÷ the sum of daily reach (average daily frequency), never unique reach.',
    equal: 'Comparisons use equal-length periods counted back from the data-through date.',
    provisional: 'The last 3 days up to the data-through date are <b>provisional</b>: late conversions can still arrive.',
    lowN: 'A change marked “low n” has fewer than 10 results in one of the periods.',
    link: 'Meta leaves link clicks blank on some rows; where clicks exist but no link clicks were reported, link CTR shows “—”.'
  };
  /** Cost-per-result cell: value, Δ (direction-aware), n, benchmark tick. */
  common.costCell = function (prim, opts) {
    if (!prim) return U.DASH;
    opts = opts || {};
    var good = prim.lowerBetter ? 'down' : 'up';
    var html = '<span class="v">' + esc(UI.costText(prim, prim.cost)) + '</span>';
    if (!opts.noDelta) html += ' ' + UI.delta(prim.dCost, { good: good, lowN: prim.lowN, noBaseline: opts.noBaseline });
    if (U.isNum(prim.n)) html += ' <small class="n">n=' + esc(U.count(prim.n)) + '</small>';
    if (opts.bench) html += ' ' + opts.bench;
    if (opts.target) html += ' ' + common.targetTick(prim.cost, opts.target, prim.lowerBetter);
    return html;
  };
  /** "vs target" marker when the registry client has a target cost per result for this objective. */
  common.targetFor = function (client, objective, type) {
    var t = client && client.targets;
    if (!t || type === 'Conversions·value') return null;
    var v = +t[objective];
    return U.isNum(v) && v > 0 ? v : null;
  };
  common.targetTick = function (cost, target, lowerBetter) {
    if (!U.isNum(cost) || !U.isNum(target) || !(target > 0)) return '';
    var d = (cost / target - 1) * 100;
    var good = lowerBetter === false ? d >= 0 : d <= 0;
    return '<span class="ttick ' + (good ? 'good' : 'bad') + '" data-tip="' + esc('Target ' + U.moneyRound(target) + ' per result (registry)') + '">' +
      esc((d > 0 ? '▲ ' : '▼ ') + U.deltaText(d).replace(/^[+−]/, '') + (d > 0 ? ' over' : ' under') + ' target') + '</span>';
  };
  common.resultCell = function (prim, opts) {
    if (!prim) return U.DASH;
    opts = opts || {};
    return '<span class="pl">' + esc(prim.type === 'Conversions·value' ? 'Purchase value (Meta)' : prim.resultLabel) + '</span> <span class="v">' +
      esc(UI.resultText(prim, prim.result)) + '</span> ' + UI.delta(prim.dResult, { good: 'up', lowN: prim.lowN, noBaseline: opts.noBaseline });
  };
  common.linkCtrCell = function (k) {
    if (!k.linkKnown) return '<span class="na" data-tip="Link clicks not reported for these rows (clicks exist but link clicks are blank).">' + U.DASH + '</span>';
    return esc(U.pct(k.link_ctr));
  };
  common.pacingCell = function (pc) {
    if (!pc) return '<span class="muted">' + U.DASH + '</span>';
    var cls = pc.status || 'none';
    return '<span class="pace ' + cls + '" data-tip="' + esc('Budget ' + U.money(pc.budget) + '/month · MTD ' + U.money(pc.mtd) + ' · projected ' + U.money(pc.projected) +
      ' (' + U.pct(pc.ratio * 100, 0) + ' of budget) · ' + pc.label + (pc.partial ? ' · MTD starts at the history start' : '')) + '"><i></i>' +
      esc(pc.early ? 'early' : U.pct(pc.ratio * 100, 0)) + '</span>';
  };

  /* =========================================================================================
   * Overview
   * ======================================================================================= */
  V.overview = {
    render: function (ctx) {
      var snap = ctx.snap, P = snap.P, st = ctx.state;
      var out = ['<div class="page">'];
      var deliveringCamps = snap.scoped.filter(function (r) { return r.delivering; }).length;
      out.push('<header class="page-h"><div><div class="eyebrow">All clients · decision view</div><h1>Overview</h1></div>' +
        '<div class="scope"><b>' + esc(P.label) + '</b>' + (P.cmp ? ' vs ' + esc(P.cmpLabel) + (P.noBaseline ? ' <span class="warnt">no baseline</span>' : '') : ' · comparison off') +
        '<span>' + snap.clients.length + ' ' + U.plural(snap.clients.length, 'client') + ' · ' + deliveringCamps + ' delivering ' + U.plural(deliveringCamps, 'campaign') +
        (snap.scopeFiltersActive ? ' · filtered' : '') + '</span></div></header>');
      if (!P.cur) {
        out.push('<section class="panel"><p class="empty">No data in ' + esc(U.rangeLabel(P.nominal.from, P.nominal.to)) + '. The Sheets cover ' + esc(U.rangeLabel(P.H, P.T)) + '. Pick another period.</p></section></div>');
        return out.join('');
      }
      out.push(kpiCards(ctx));
      out.push(decisionSummary(ctx));
      out.push('<div class="grid2">' + dailyChart(ctx) + mix(ctx) + '</div>');
      out.push(clientsTable(ctx));
      out.push(movers(ctx));
      out.push(common.notes([common.HONEST.results, common.HONEST.equal, common.HONEST.provisional, common.HONEST.reach, common.HONEST.dash,
        'Decisions follow the Hermes rules (sidebar → Decision rules). A client takes the most severe decision among its delivering campaigns.']));
      out.push('</div>');
      return out.join('');
    }
  };

  /** KPI cards (SPEC §4.1.1) with their trend lines (§4.7); a click opens the big chart below them. */
  function kpiCards(ctx) {
    var snap = ctx.snap, t = snap.totals, P = snap.P, nb = P.noBaseline;
    var vs = P.cmp && !nb ? 'vs ' + esc(U.rangeLabel(P.cmp.from, P.cmp.to, false)) : '';
    var per = function (field, plats) {
      return plats.map(function (p) {
        var x = snap.byPlatform[p];
        return x && (x.cur[field] || x.cmp[field]) ? esc(D.PLATFORM_LABEL[p]) + ' ' + esc(U.count(x.cur[field])) : null;
      }).filter(Boolean).join(' · ');
    };
    var cards = [
      { kpi: 'spend', label: 'Spend', value: U.money(t.cur.spend), exact: U.money(t.cur.spend, { exact: true }) },
      { kpi: 'impressions', label: 'Impressions', value: U.int(t.cur.impressions) },
      { kpi: 'link_clicks', label: 'Link clicks', value: U.int(t.cur.link_clicks), foot: 'Meta link clicks · TikTok and Google clicks' },
      { kpi: 'messages', label: 'Messages*', value: U.count(t.cur.messages), foot: per('messages', ['meta', 'tiktok']) },
      { kpi: 'leads', label: 'Leads*', value: U.count(t.cur.leads), foot: per('leads', ['meta', 'tiktok']) },
      { kpi: 'conversions', label: 'Conversions*', value: U.count(t.cur.conversions), foot: per('conversions', ['tiktok', 'google']) + ' · Meta conversion counts are not in the data' }
    ].filter(function (c) { return t.cur[c.kpi] || t.cmp[c.kpi]; });
    var scope = { id: 'ov', key: 'ov', title: 'All clients in view', camps: snap.scoped, cur: t.cur, cmp: t.cmp, multiClient: true, noLowN: true,
      splits: M.TREND_SPLITS, items: cards };
    var html = cards.map(function (c) {
      return V.trend.kpiTile(ctx, scope, c, {
        value: '<span' + (c.exact ? ' data-tip="' + esc(c.exact) + '"' : '') + '>' + esc(c.value) + '</span>', vs: vs, noLowN: true, hideDelta: !P.cmp,
        foot: c.foot ? esc(c.foot) : ''
      });
    }).join('');
    return '<section class="kpis" aria-label="Totals">' + html + '</section>' + V.trend.panel(ctx, scope) +
      '<p class="kfoot">* Platform-reported, not qualified leads or sales. Click a card for its trend chart.' + (snap.rowFiltersActive ? ' <b class="warnt">Totals ignore row filters.</b>' : '') + '</p>';
  }

  function decisionSummary(ctx) {
    var snap = ctx.snap, F = snap.F;
    return '<section class="dsum" aria-label="Clients by worst decision">' + E.DECISIONS.map(function (d) {
      var short = E.SHORT[d], on = F.decisions.indexOf(short) >= 0;
      return '<button type="button" class="dcount ' + E.CLS[d] + (on ? ' on' : '') + '" data-act="filter" data-k="decisions" data-v="' + short + '" aria-pressed="' + on +
        '"><b>' + snap.counts[d] + '</b><span>' + esc(d) + '</span><small>' + U.plural(snap.counts[d], 'client') + '</small></button>';
    }).join('') + '</section>';
  }

  function dailyChart(ctx) {
    var snap = ctx.snap, d = snap.daily, P = snap.P;
    var series = D.PLATFORMS.filter(function (p) { return d.byPlatform[p] && d.byPlatform[p].some(function (v) { return v > 0; }); }).map(function (p) {
      return { key: p, label: D.PLATFORM_LABEL[p], color: 'var(--' + p + ')', values: d.byPlatform[p] };
    });
    var spec = { type: 'stacked', title: 'Daily spend by platform', days: d.days, series: series, height: 250, fmt: 'money', provisional: P.provisional,
      compare: d.cmpTotal ? { values: d.cmpTotal, days: d.cmpDays } : null };
    var legend = series.map(function (s) { return '<span class="lg"><i class="sw" style="background:' + s.color + '"></i>' + esc(s.label) + '</span>'; }).join('') +
      (d.cmpTotal ? '<span class="lg"><i class="sw dash"></i>Comparison total (' + esc(U.rangeLabel(P.cmp.from, P.cmp.to, false)) + '), by day number</span>' : '') +
      (P.provisional ? '<span class="lg"><i class="sw prov"></i>Provisional</span>' : '');
    var rows = d.days.map(function (day, i) {
      return '<tr><th scope="row">' + esc(U.weekday(day) + ' ' + U.fmtDate(day)) + '</th>' + series.map(function (s) { return '<td class="num">' + esc(U.money(s.values[i])) + '</td>'; }).join('') +
        '<td class="num">' + esc(U.money(d.total[i])) + '</td>' + (d.cmpTotal ? '<td class="num">' + esc(U.money(d.cmpTotal[i])) + '</td>' : '') + '</tr>';
    }).join('');
    var table = '<details class="tview"><summary>Table view</summary><div class="tbl-wrap"><table class="tbl"><thead><tr><th scope="col">Day</th>' +
      series.map(function (s) { return '<th scope="col" class="num">' + esc(s.label) + '</th>'; }).join('') + '<th scope="col" class="num">Total</th>' +
      (d.cmpTotal ? '<th scope="col" class="num">Comparison</th>' : '') + '</tr></thead><tbody>' + rows + '</tbody></table></div></details>';
    return '<section class="panel"><div class="panel-h"><h2>Daily spend</h2><p>Bars by platform · dashed line: comparison period aligned by day number</p></div>' +
      (series.length ? C.slot(spec) + '<div class="legend">' + legend + '</div>' + table : '<p class="empty">No spend in this period for the current filters.</p>') + '</section>';
  }

  function hbar(label, value, total, color, prev) {
    var share = total > 0 ? value / total * 100 : 0;
    return '<div class="hb"><div class="hb-t"><span>' + label + '</span><b>' + esc(U.money(value)) + '</b><small>' + esc(U.pct(share, 1)) + '</small>' +
      (prev !== undefined ? UI.delta(U.pctChange(value, prev), { good: 'neutral' }) : '') + '</div><div class="hb-b"><i style="width:' + share.toFixed(1) + '%;background:' + color + '"></i></div></div>';
  }
  function mix(ctx) {
    var snap = ctx.snap, tot = snap.totals.cur.spend;
    var plats = D.PLATFORMS.filter(function (p) { return snap.byPlatform[p] && (snap.byPlatform[p].cur.spend || snap.byPlatform[p].cmp.spend); });
    var verts = Object.keys(snap.byVertical).sort(function (a, b) { return snap.byVertical[b].cur.spend - snap.byVertical[a].cur.spend; });
    var hasCmp = !!snap.B;
    return '<section class="panel"><div class="panel-h"><h2>Mix</h2><p>Share of spend this period</p></div>' +
      '<h3 class="sub-h">By platform</h3>' + (plats.length ? plats.map(function (p) {
        return hbar(UI.pchip(p), snap.byPlatform[p].cur.spend, tot, 'var(--' + p + ')', hasCmp ? snap.byPlatform[p].cmp.spend : undefined);
      }).join('') : '<p class="muted">No spend.</p>') +
      '<h3 class="sub-h">By vertical</h3>' + (verts.length ? verts.map(function (v) {
        return hbar(esc(v), snap.byVertical[v].cur.spend, tot, 'var(--copper)', hasCmp ? snap.byVertical[v].cmp.spend : undefined);
      }).join('') : '<p class="muted">No spend.</p>') + '</section>';
  }

  function clientsTable(ctx) {
    var snap = ctx.snap, st = ctx.state, P = snap.P, nb = P.noBaseline;
    var rf = M.rowFilter(snap.F);
    var total = snap.totals.cur.spend;
    var rows = snap.clients.filter(rf);
    var hasPacing = snap.clients.some(function (c) { return c.pacing; });
    var benchOf = function (r) { return r.primary ? common.benchFor(ctx.learn, r.primary.type, r.vertical, r.primary.platforms) : null; };
    var cols = [
      { key: 'decision', label: 'Decision', sort: function (r) { return (E.SEV[r.decision] || 0) * 1e13 + r.cur.spend; },
        html: function (r) { return UI.ddot(r.decision) + '<span class="sr">' + esc(r.decision || 'No delivery') + '</span>'; } },
      { key: 'client', label: 'Client', sort: function (r) { return r.name; }, cls: 'wide',
        html: function (r) {
          if (r.isAccount) return UI.pchip(r.platform) + ' <span class="an">' + esc(r.name) + '</span> <small class="muted mono">' + esc(r.id) + '</small>';
          return '<a class="cname" href="#/client/' + encodeURIComponent(r.slug) + '">' + esc(r.name) + '</a> ' + UI.vtag(r.vertical) +
            '<div class="chips-s">' + r.platforms.map(UI.pchip).join('') + '</div>';
        } },
      { key: 'spend', label: 'Spend', num: true, sort: function (r) { return r.cur.spend; },
        html: function (r) {
          return '<span class="v">' + esc(U.money(r.cur.spend)) + '</span> ' + (P.cmp ? UI.delta(U.pctChange(r.cur.spend, r.cmp.spend), { good: 'neutral', noBaseline: nb }) : '') +
            '<small class="share">' + esc(total > 0 ? U.pct(r.cur.spend / total * 100, 1) : U.DASH) + '</small>';
        } },
      { key: 'result', label: 'Primary result', num: true, sort: function (r) { return r.primary ? r.primary.result : null; },
        title: 'The objective with the most spend in the period. Result types are never added together.',
        html: function (r) { return common.resultCell(r.primary, { noBaseline: nb }); } },
      { key: 'cost', label: 'Cost/result', num: true, sort: function (r) { return r.primary ? r.primary.cost : null; },
        html: function (r) {
          return common.costCell(r.primary, { noBaseline: nb, bench: r.primary ? common.benchTick(r.primary.cost, benchOf(r)) : '',
            target: r.primary ? common.targetFor(r.client, r.primary.objective, r.primary.type) : null });
        } },
      { key: 'ctr', label: 'Link CTR', num: true, sort: function (r) { return r.k.link_ctr; }, html: function (r) { return common.linkCtrCell(r.k); } },
      { key: 'flags', label: 'Flags', sort: function (r) { return (r.flags || []).length; },
        title: 'Playbook checks hit (rules.json)',
        html: function (r) {
          var f = r.flags || [];
          if (!f.length) return '<span class="muted">' + U.DASH + '</span>';
          var bySrc = {};
          f.forEach(function (h) { var s = h.check.source || h.check.id; bySrc[s] = (bySrc[s] || 0) + 1; });
          return Object.keys(bySrc).map(function (s) { return UI.lchip(s, bySrc[s] + ' hit' + (bySrc[s] > 1 ? 's' : '')) + (bySrc[s] > 1 ? '<small>×' + bySrc[s] + '</small>' : ''); }).join(' ');
        } },
      { key: 'trend', label: 'Trend', sort: false, cls: 'spark-c', html: function (r) { return C.spark(r.spark, { color: 'var(--copper)' }); } }
    ];
    if (hasPacing) cols.push({ key: 'pacing', label: 'Pacing', sort: function (r) { return r.pacing ? r.pacing.ratio : null; }, html: function (r) { return common.pacingCell(r.pacing); } });
    var def = {
      id: 'clients', caption: 'Clients', csvName: 'clients', rows: rows, columns: cols, textCols: ['client'],
      children: function (r) { return r.isAccount || !r.accounts.length ? [] : r.accounts.map(function (a) { a.isAccount = true; return a; }); },
      rowKey: function (r) { return r.isAccount ? 'a:' + r.key : 'c:' + r.slug; },
      rowLabel: function (r) { return r.name; },
      rowHref: function (r) { return r.isAccount ? '#/client/' + encodeURIComponent(r.clientSlug) : '#/client/' + encodeURIComponent(r.slug); },
      rowClass: function (r) { return (r.isAccount ? 'sub' : '') + (r.cur.spend === 0 ? ' dim' : ''); },
      levelName: function (r) { return r.isAccount ? 'Account' : 'Client'; },
      sort: st.ui.sorts.clients || { key: 'decision', dir: 'desc' },
      expanded: ctx.app.expanded('clients'),
      empty: 'No client matches the current filters.',
      csvHeader: ['Name', 'Vertical / platform', 'Decision', 'Spend', 'Spend (comparison)', 'Spend Δ%', 'Share %', 'Primary result type', 'Primary result', 'Primary result (comparison)',
        'Result Δ%', 'Cost per result', 'Cost per result (comparison)', 'Cost Δ%', 'n', 'Link CTR %', 'Playbook flags'].concat(hasPacing ? ['Pacing % of budget'] : []),
      csvRow: function (r) {
        var p = r.primary;
        return [r.name, r.isAccount ? D.PLATFORM_LABEL[r.platform] + ' ' + r.id : r.vertical, r.decision || '', r.cur.spend, r.cmp.spend, U.pctChange(r.cur.spend, r.cmp.spend),
          total > 0 ? r.cur.spend / total * 100 : null, p ? (E.TYPE_LABEL[p.type] || p.type) : '', p ? p.result : null, p ? p.resultPrev : null, p ? p.dResult : null,
          p ? p.cost : null, p ? p.costPrev : null, p ? p.dCost : null, p ? p.n : null, r.k.link_ctr, (r.flags || []).map(function (h) { return h.check.source; }).join(' ')]
          .concat(hasPacing ? [r.pacing ? r.pacing.ratio * 100 : null] : []);
      }
    };
    var hidden = snap.clients.length - rows.length;
    return '<section class="panel"><div class="panel-h"><h2>Clients</h2><p>' + rows.length + ' shown' + (hidden ? ' · ' + hidden + ' hidden by row filters' : '') +
      ' · click a row to open the client · ▸ shows its accounts</p><div class="tools"><button type="button" class="btn ghost sm" data-act="tbl-csv" data-tbl="clients">Export CSV</button></div></div>' +
      UI.table(def) + '</section>';
  }

  function movers(ctx) {
    var snap = ctx.snap;
    if (!snap.B) return '<section class="panel"><div class="panel-h"><h2>Top movers</h2></div><p class="muted">Needs a comparison period with a baseline.</p></section>';
    var floor = Math.max(snap.F.minSpend || 0, 300);
    var el = snap.clients.filter(function (c) { return c.cur.spend >= floor && c.cmp.spend >= floor; });
    var item = function (c, main, sub) {
      return '<li><a href="#/client/' + encodeURIComponent(c.slug) + '">' + esc(c.name) + '</a><span class="mv">' + main + '</span><small>' + sub + '</small></li>';
    };
    var bySpend = el.slice().sort(function (a, b) { return (b.cur.spend - b.cmp.spend) - (a.cur.spend - a.cmp.spend); });
    var up = bySpend.filter(function (c) { return c.cur.spend > c.cmp.spend; }).slice(0, 5);
    var down = bySpend.filter(function (c) { return c.cur.spend < c.cmp.spend; }).reverse().slice(0, 5);
    var withCost = el.filter(function (c) { return c.primary && U.isNum(c.primary.dCost); });
    var improve = function (c) { return c.primary.lowerBetter ? -c.primary.dCost : c.primary.dCost; };
    var better = withCost.filter(function (c) { return improve(c) > 0; }).sort(function (a, b) { return improve(b) - improve(a); }).slice(0, 5);
    var worse = withCost.filter(function (c) { return improve(c) < 0; }).sort(function (a, b) { return improve(a) - improve(b); }).slice(0, 5);
    var spendLine = function (c) {
      return item(c, esc(U.money(c.cur.spend - c.cmp.spend, { signed: true })) + ' ' + UI.delta(U.pctChange(c.cur.spend, c.cmp.spend), { good: 'neutral' }),
        esc(U.money(c.cmp.spend) + ' → ' + U.money(c.cur.spend)));
    };
    var costLine = function (c) {
      var p = c.primary;
      return item(c, esc(p.costLabel) + ' ' + UI.delta(p.dCost, { good: p.lowerBetter ? 'down' : 'up', lowN: p.lowN }),
        esc(UI.costText(p, p.costPrev) + ' → ' + UI.costText(p, p.cost)) + (U.isNum(p.n) ? ' · n=' + esc(U.count(p.n)) : ''));
    };
    var col = function (title, list, fn) {
      return '<div class="mcol"><h3 class="sub-h">' + esc(title) + '</h3>' + (list.length ? '<ol class="movers">' + list.map(fn).join('') + '</ol>' : '<p class="muted small">None.</p>') + '</div>';
    };
    return '<section class="panel"><div class="panel-h"><h2>Top movers</h2><p>Clients with at least ' + esc(U.money(floor)) + ' spend in both periods</p></div><div class="grid4">' +
      col('Spend up', up, spendLine) + col('Spend down', down, spendLine) + col('Cost per result improved', better, costLine) + col('Cost per result worsened', worse, costLine) + '</div></section>';
  }
})(typeof window !== 'undefined' ? window : this);
