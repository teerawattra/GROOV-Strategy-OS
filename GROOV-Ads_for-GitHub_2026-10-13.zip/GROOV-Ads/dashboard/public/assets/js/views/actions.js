/* GROOV Ads Command Center · views/actions.js
 * ------------------------------------------------------------------------------------------
 * Role: Action queue (SPEC §4.2): every item that needs a human, ranked
 *   1 Immediate Action · 2 Playbook Watch Out · 3 Watch Out · 4 Delivery issue · 5 Opportunity
 * then by spend. Sources: campaign decisions, rules.json checks, delivery-integrity checks.
 * Each item: severity, title, path, Evidence (current vs comparison), Why, Action, source chip,
 * Open client, Mark reviewed (per item and period end) and Snooze 7 days (per browser).
 * Public: GROOV.views.actions.render(ctx). Handlers: aq-review, aq-unreview, aq-snooze,
 * aq-unsnooze, aq-csv, aq-clear-check.
 */
(function (root) {
  'use strict';
  var G = root.GROOV = root.GROOV || {};
  var U = G.util, D = G.data, E = G.engine, M = G.model, UI = G.ui;
  var V = G.views = G.views || {};
  var A = G.actions = G.actions || {};
  var esc = U.esc;

  var TABS = [
    { id: 'all', label: 'All', test: function () { return true; } },
    { id: 'fix', label: 'Fix now', test: function (it) { return it.level === 1 || it.level === 4; } },
    { id: 'watch', label: 'Watch', test: function (it) { return it.level === 2 || it.level === 3; } },
    { id: 'opp', label: 'Opportunities', test: function (it) { return it.level === 5; } },
    { id: 'playbook', label: 'Playbook', test: function (it) { return it.source === 'playbook'; } }
  ];
  var LEVEL_CLS = { 1: 'imm', 2: 'watch', 3: 'watch', 4: 'del', 5: 'scale' };

  /** Row filters for action items: decisions (delivery items have none), active only, min spend. */
  function rowOK(F) {
    return function (it) {
      if (F.decisions.length && (!it.decision || F.decisions.indexOf(E.SHORT[it.decision]) < 0)) return false;
      if (F.activeOnly && it.status !== 'ACTIVE') return false;
      if (F.minSpend > 0 && !(it.spend >= F.minSpend)) return false;
      return true;
    };
  }
  function visibleItems(ctx) {
    var snap = ctx.snap, st = ctx.state, b = ctx.buckets;
    var tab = TABS.filter(function (t) { return t.id === st.ui.actionsTab; })[0] || TABS[0];
    var check = st.route.params && st.route.params.check;
    var ok = rowOK(snap.F);
    var sel = function (it) { return ok(it) && tab.test(it) && (!check || it.checkId === check); };
    return { tab: tab, check: check, open: b.open.filter(sel), reviewed: b.reviewed.filter(sel), snoozed: b.snoozed.filter(sel), ok: ok };
  }

  V.actions = {
    render: function (ctx) {
      var snap = ctx.snap, st = ctx.state, P = snap.P;
      var vis = visibleItems(ctx);
      var ok = vis.ok, check = vis.check;
      var counts = TABS.map(function (t) {
        return { id: t.id, label: t.label, count: ctx.buckets.open.filter(function (it) { return ok(it) && t.test(it) && (!check || it.checkId === check); }).length };
      });
      var out = ['<div class="page">'];
      out.push('<header class="page-h"><div><div class="eyebrow">Everything that needs a human, ranked</div><h1>Action queue</h1></div>' +
        '<div class="scope"><b>' + esc(P.label) + '</b>' + (P.cmp ? ' vs ' + esc(P.cmpLabel) : '') + '<span>' + ctx.buckets.open.length + ' open · ' +
        ctx.buckets.reviewed.length + ' reviewed · ' + ctx.buckets.snoozed.length + ' snoozed</span></div></header>');
      out.push('<div class="bar-tools">' + UI.tabs('actions', counts, vis.tab.id) +
        '<button type="button" class="btn ghost sm" data-act="aq-csv">Export CSV</button></div>');
      if (check) {
        var chk = (ctx.learn.rules && ctx.learn.rules.checks || []).filter(function (c) { return c.id === check; })[0];
        out.push('<p class="filter-note">Showing playbook check <b>' + esc(chk ? (chk.source + ' · ' + (chk.title || chk.id)) : check) + '</b> ' +
          '<button type="button" class="fchip" data-act="aq-clear-check">Show all items <span aria-hidden="true">×</span></button></p>');
      }
      if (!P.cur) {
        out.push('<section class="panel"><p class="empty">No data in this period.</p></section></div>');
        return out.join('');
      }
      if (!vis.open.length) {
        out.push('<section class="panel"><p class="empty">' + (ctx.buckets.open.length ? 'Nothing open in this tab with the current filters.' : 'Nothing needs action for this period and these filters.') + '</p></section>');
      }
      var level = null;
      vis.open.forEach(function (it) {
        if (it.level !== level) {
          if (level !== null) out.push('</div>');
          level = it.level;
          var n = vis.open.filter(function (x) { return x.level === level; }).length;
          out.push('<h2 class="lvl-h ' + LEVEL_CLS[level] + '">' + esc(M.LEVEL_LABEL[level]) + ' <span>' + n + '</span></h2><div class="aq-list">');
        }
        out.push(item(it, ctx, P));
      });
      if (level !== null) out.push('</div>');
      if (vis.reviewed.length) {
        out.push('<details class="aq-done"><summary>Reviewed (' + vis.reviewed.length + ')</summary><ul class="aq-mini">' + vis.reviewed.map(function (it) {
          return mini(it, '<button type="button" class="btn ghost xs" data-act="aq-unreview" data-v="' + esc(it.key) + '">Undo</button>');
        }).join('') + '</ul></details>');
      }
      if (vis.snoozed.length) {
        out.push('<details class="aq-done"><summary>Snoozed (' + vis.snoozed.length + ')</summary><ul class="aq-mini">' + vis.snoozed.map(function (it) {
          return mini(it, '<small>until ' + esc(U.fmtDate(st.snoozed[it.key])) + '</small> <button type="button" class="btn ghost xs" data-act="aq-unsnooze" data-v="' + esc(it.key) + '">Unsnooze</button>');
        }).join('') + '</ul></details>');
      }
      out.push(G.views.common.notes([
        'Review marks are remembered per item and period end in this browser; a new period brings an item back if it still applies. Snooze hides an item for 7 days.',
        G.views.common.HONEST.results, 'Delivery checks compare the last 3 days of the period with the 7 days before, so one odd day never alerts.',
        'Opportunities (Ready to Scale) are suggestions to test, not instructions: every live change is confirmed in Claude Code first.'
      ]));
      out.push('</div>');
      return out.join('');
    }
  };

  function sourceChip(it) {
    if (it.source === 'playbook') return UI.lchip(it.sourceLabel, 'Playbook check ' + (it.checkId || ''));
    return '<span class="src">' + esc(it.sourceLabel) + '</span>';
  }
  function item(it, ctx, P) {
    var cls = LEVEL_CLS[it.level];
    return '<article class="aq ' + cls + '"><div class="aq-h"><span class="sev ' + cls + '">' + esc(it.levelLabel) + '</span><h3>' + esc(it.title) + '</h3>' + sourceChip(it) + '</div>' +
      '<p class="path">' + it.path.map(esc).join(' <span aria-hidden="true">›</span> ') + (it.row && it.row.status ? ' ' + UI.statusBadge(it.status, it.row.rawStatus) : '') +
      (it.row && it.row.isNew ? ' ' + UI.newBadge() : '') + '</p>' +
      UI.evidence(it.evidence, P.noBaseline) +
      (it.why ? '<p class="why"><em>Why</em> ' + esc(it.why) + '</p>' : '') +
      (it.action ? '<p class="act"><em>Action</em> ' + esc(it.action) + '</p>' : '') +
      '<div class="aq-f"><a class="btn sm" href="#/client/' + encodeURIComponent(it.clientSlug) + '">Open client</a>' +
      '<button type="button" class="btn ghost sm" data-act="aq-review" data-v="' + esc(it.key) + '">✓ Mark reviewed</button>' +
      '<button type="button" class="btn ghost sm" data-act="aq-snooze" data-v="' + esc(it.key) + '">Snooze 7 days</button></div></article>';
  }
  function mini(it, tools) {
    return '<li><span class="sev ' + LEVEL_CLS[it.level] + '">' + esc(it.levelLabel) + '</span> <b>' + esc(it.title) + '</b> <span class="muted">' +
      it.path.map(esc).join(' › ') + '</span> ' + tools + '</li>';
  }

  /* ---------- handlers ---------- */
  function end() { var c = G.app.ctx(); return c.snap ? c.snap.periodEnd : ''; }
  A['aq-review'] = function (el) {
    var k = el.getAttribute('data-v') + '@' + end();
    G.app.update(function (st) { st.reviewed = Object.assign({}, st.reviewed); st.reviewed[k] = 1; });
  };
  A['aq-unreview'] = function (el) {
    var k = el.getAttribute('data-v') + '@' + end();
    G.app.update(function (st) { st.reviewed = Object.assign({}, st.reviewed); delete st.reviewed[k]; });
  };
  A['aq-snooze'] = function (el) {
    var k = el.getAttribute('data-v'), until = U.addDays(U.bangkokToday(), 7);
    G.app.update(function (st) { st.snoozed = Object.assign({}, st.snoozed); st.snoozed[k] = until; });
  };
  A['aq-unsnooze'] = function (el) {
    var k = el.getAttribute('data-v');
    G.app.update(function (st) { st.snoozed = Object.assign({}, st.snoozed); delete st.snoozed[k]; });
  };
  A['aq-clear-check'] = function () {
    G.app.update(function (st) { st.route.params = Object.assign({}, st.route.params); delete st.route.params.check; });
  };
  A['aq-csv'] = function () {
    var ctx = G.app.ctx();
    if (!ctx.snap) return;
    var vis = visibleItems(ctx);
    var rows = [['Level', 'Severity', 'Title', 'Client', 'Platform', 'Path', 'Status', 'Spend', 'Why', 'Action', 'Source', 'Evidence']];
    vis.open.forEach(function (it) {
      rows.push([it.level, it.levelLabel, it.title, it.clientName, it.platform ? D.PLATFORM_LABEL[it.platform] : '', it.path.join(' › '), it.status || '', it.spend,
        it.why, it.action, it.sourceLabel, (it.evidence || []).map(function (e) { return e.label + ' ' + e.cur + (e.prev ? ' (prev ' + e.prev + ')' : ''); }).join('; ')]);
    });
    UI.download(UI.csvName('action-queue', ctx.snap.P), U.csv(rows));
  };
})(typeof window !== 'undefined' ? window : this);
