/* GROOV Ads Command Center · ui.js
 * ------------------------------------------------------------------------------------------
 * Role: shared HTML building blocks used by the sidebar and every view, plus the one tooltip /
 * popover layer. Builders return HTML strings; EVERY data value goes through util.esc().
 *
 * Public API (window.GROOV.ui):
 *   ddot(label) / dbadge(label, {why, action, evidence, short})   decision dot / badge (+ popover)
 *   statusBadge(status, raw)   ACTIVE green, anything else red (raw status in the tooltip)
 *   pchip(platform), vtag(vertical), lchip(source, title), confBadge(confidence), newBadge()
 *   delta(p, {good:'up'|'down'|'neutral', lowN, noBaseline})   signed % change with direction colour
 *   kpi({label, value, delta, sub, spark, note, foot, trend})   stat tile; `trend` = the tile's trend
 *                              chart button (views/trends.js): it covers the whole tile, so a click
 *                              anywhere on the tile opens the expanded chart
 *   pts(d)                     "+6 pts" share change in percentage points (neutral, muted)
 *   evidence(list, P)          "Spend ฿1,205 (+3%) · Messages 1 (−75%, low n) …"
 *   tabs(id, items, active)    tab bar (data-act="tab")
 *   table(def) / tableCsv(id)  sortable, expandable, sticky-header table + "exactly what's shown" CSV
 *   download(name, text)       client-side file download
 *   initTips()                 install the tooltip / popover listeners (once)
 *   moneyOr(v), resultText(prim, v), costText(prim, v)   honest formatting for primary results
 */
(function (root) {
  'use strict';
  var G = root.GROOV = root.GROOV || {};
  var U = G.util, E = G.engine, D = G.data;
  var UI = G.ui = {};
  var esc = U.esc;

  /* ---------- badges and chips ---------- */
  UI.ddot = function (label) {
    if (!label) return '<i class="ddot none" title="No delivery in this period" aria-label="No delivery in this period"></i>';
    return '<i class="ddot ' + E.CLS[label] + '" title="' + esc(label) + '" aria-label="' + esc(label) + '"></i>';
  };
  /** Decision badge; when why/action are given it opens a popover on hover, focus or tap. */
  UI.dbadge = function (label, o) {
    if (!label) return '<span class="dbadge none">No delivery</span>';
    o = o || {};
    var txt = o.short ? E.SHORT[label] : label;
    if (!o.why && !o.action) return '<span class="dbadge ' + E.CLS[label] + '">' + esc(txt) + '</span>';
    var body = '<b class="pop-h ' + E.CLS[label] + '">' + esc(label) + '</b>' +
      (o.why ? '<p><em>Why</em> ' + esc(o.why) + '</p>' : '') + (o.action ? '<p><em>Action</em> ' + esc(o.action) + '</p>' : '') +
      (o.evidence ? '<div class="pop-ev">' + UI.evidence(o.evidence) + '</div>' : '');
    return '<span class="dpop"><button type="button" class="dbadge ' + E.CLS[label] + '" data-pop aria-label="' + esc(label) +
      ': show why and action">' + esc(txt) + '</button><span class="pop-body" hidden>' + body + '</span></span>';
  };
  UI.statusBadge = function (status, raw) {
    var s = status || 'UNKNOWN';
    var ok = s === 'ACTIVE';
    var t = raw && raw !== s ? 'Raw status: ' + raw : (ok ? 'Status ACTIVE' : 'Status ' + s + (s === 'UNKNOWN' ? ' (no status in the export)' : ''));
    return '<span class="status ' + (ok ? 'ok' : 'bad') + '" data-tip="' + esc(t) + '">' + esc(s) + '</span>';
  };
  UI.pchip = function (p) {
    return '<span class="pchip ' + esc(p) + '"><i aria-hidden="true"></i>' + esc(D.PLATFORM_LABEL[p] || p) + '</span>';
  };
  UI.vtag = function (v) { return '<span class="vtag' + (v === 'Unmapped' ? ' unm' : '') + '">' + esc(v || 'Unmapped') + '</span>'; };
  UI.lchip = function (source, title) {
    var m = /^L-\d+/.exec(String(source || ''));
    var href = m ? '#/playbook?l=' + encodeURIComponent(m[0]) : '#/playbook';
    return '<a class="lchip" href="' + href + '"' + (title ? ' data-tip="' + esc(title) + '"' : '') + '>' + esc(m ? m[0] : source) + '</a>';
  };
  UI.confBadge = function (c) {
    var cls = c === 'Proven' ? 'proven' : c === 'Tested' ? 'tested' : 'obs';
    return '<span class="conf ' + cls + '">' + esc(c || 'Observation') + '</span>';
  };
  UI.newBadge = function () { return '<span class="newb" data-tip="Launched less than 7 days before the period end: fatigue and loser flags are suppressed while it learns.">New</span>'; };

  /* ---------- numbers ---------- */
  /**
   * o.good: 'up' (higher is better), 'down' (lower is better), 'neutral' (spend: no judgement)
   */
  UI.delta = function (p, o) {
    o = o || {};
    if (!U.isNum(p)) {
      if (o.noBaseline) return '<span class="delta nb" data-tip="The comparison period is outside the loaded history.">no baseline</span>';
      return '<span class="delta na">' + U.DASH + '</span>';
    }
    var t = U.deltaText(p);
    if (o.lowN) return '<span class="delta lown" data-tip="Fewer than 10 results in at least one period: treat this change as noise.">' + esc(t) + ' · low n</span>';
    var cls = 'neutral';
    if (Math.abs(p) >= 0.5 && o.good !== 'neutral') {
      var better = o.good === 'down' ? p < 0 : p > 0;
      cls = better ? 'good' : 'bad';
    }
    return '<span class="delta ' + cls + '">' + esc(t) + '</span>';
  };
  /** Primary result value, honest for its type. */
  UI.resultText = function (prim, v) {
    if (!prim) return U.DASH;
    if (prim.type === 'Conversions·value') return U.money(v);
    return U.count(v);
  };
  UI.costText = function (prim, v) {
    if (!prim) return U.DASH;
    if (prim.costFmt === 'ratio') return U.isNum(v) ? U.ratioX(v) : 'Not tracked';
    return U.money(v);
  };
  UI.nText = function (n) { return U.isNum(n) ? 'n=' + U.count(n) : ''; };
  /** Escape, then allow `code` and **bold** from the learning log (nothing else). */
  UI.mdInline = function (s) {
    return esc(s).replace(/`([^`]+)`/g, '<code>$1</code>').replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>');
  };

  /* ---------- KPI tile ---------- */
  UI.kpi = function (o) {
    var tr = o.trend || null;
    return '<div class="kpi' + (o.cls ? ' ' + o.cls : '') + (tr ? ' tr' + (tr.open ? ' open' : '') : '') + '">' +
      '<div class="kpi-l">' + o.label + '</div>' +
      '<div class="kpi-v">' + o.value + '</div>' +
      (o.delta !== undefined ? '<div class="kpi-d">' + o.delta + (o.vs ? ' <span class="vs">' + o.vs + '</span>' : '') + '</div>' : '') +
      (o.sub ? '<div class="kpi-sub">' + o.sub + '</div>' : '') +
      (o.spark ? '<div class="kpi-s">' + o.spark + '</div>' : '') +
      (tr ? tr.html : '') +
      (o.foot ? '<div class="kpi-f">' + o.foot + '</div>' : '') +
      '</div>';
  };
  /** Change in a share, in percentage points (a share moving is not good or bad by itself). */
  UI.pts = function (d) {
    if (!U.isNum(d)) return '';
    var a = Math.abs(d), t = a < 0.05 ? '±0 pts' : (d > 0 ? '+' : '−') + (a < 10 ? a.toFixed(1).replace(/\.0$/, '') : Math.round(a)) + ' pts';
    return '<small class="dpts" data-tip="Change in share vs the comparison period, in percentage points">' + esc(t) + '</small>';
  };

  /** Evidence chips: each {label, cur, prev, delta, up:'good'|'bad'|'neutral', lowN, n, note}. */
  UI.evidence = function (list, noBaseline) {
    return '<div class="ev">' + (list || []).map(function (e) {
      var good = e.up === 'bad' ? 'down' : e.up === 'neutral' ? 'neutral' : 'up';
      var d = e.prev === null || e.prev === undefined ? '' : ' ' + UI.delta(e.delta, { good: good, lowN: e.lowN, noBaseline: noBaseline });
      var prev = e.prev === null || e.prev === undefined ? '' : '<small>prev ' + esc(e.prev) + '</small>';
      var n = U.isNum(e.n) ? '<small>n=' + esc(U.count(e.n)) + '</small>' : '';
      var note = e.note ? '<small>' + esc(e.note) + '</small>' : '';
      return '<span class="evi"><span class="evl">' + esc(e.label) + '</span><b>' + esc(e.cur) + '</b>' + d + n + prev + note + '</span>';
    }).join('') + '</div>';
  };

  /* ---------- tabs ---------- */
  UI.tabs = function (group, items, active) {
    return '<div class="tabs" role="tablist" aria-label="' + esc(group) + '">' + items.map(function (t) {
      var on = t.id === active;
      return '<button type="button" role="tab" aria-selected="' + on + '" class="tab' + (on ? ' on' : '') + '" data-act="tab" data-group="' +
        esc(group) + '" data-tab="' + esc(t.id) + '">' + esc(t.label) + (t.count !== undefined ? ' <b>' + esc(t.count) + '</b>' : '') + '</button>';
    }).join('') + '</div>';
  };

  /* =========================================================================================
   * Table: sortable, expandable, sticky header, numeric columns right-aligned, CSV of what's shown
   * def = {
   *   id, columns: [{ key, label, num, sort (fn row -> value | false), html (fn row, depth), csv (fn row), title, cls }],
   *   rows (top level, already filtered), children (fn row -> rows), rowKey (fn row), rowClass (fn row),
   *   rowHref (fn row), rowAct (fn row -> {act, v} | null: a click on the row runs that action),
   *   sort: {key, dir}, expanded: Set, empty, csvName, csvExtra (fn row -> leading cells), caption, maxHeight
   * }
   * ======================================================================================= */
  var tables = new Map();
  UI.tableDef = function (id) { return tables.get(id); };
  UI.resetTables = function () { tables.clear(); };

  function sortRows(rows, def) {
    var s = def.sort;
    if (!s || !s.key) return rows;
    var col = null;
    def.columns.forEach(function (c) { if (c.key === s.key) col = c; });
    if (!col || !col.sort) return rows;
    var dir = s.dir === 'asc' ? 1 : -1;
    return rows.slice().sort(function (a, b) {
      var va = col.sort(a), vb = col.sort(b);
      var na = va === null || va === undefined || (typeof va === 'number' && !isFinite(va));
      var nb = vb === null || vb === undefined || (typeof vb === 'number' && !isFinite(vb));
      if (na && nb) return 0;
      if (na) return 1; // missing values always last
      if (nb) return -1;
      if (typeof va === 'string' || typeof vb === 'string') return dir * U.cmpText(va, vb);
      return dir * (va - vb);
    });
  }
  /** Visible rows in display order with their depth (respecting expansion and sort). */
  function visibleRows(def) {
    var out = [];
    var walk = function (rows, depth) {
      sortRows(rows, def).forEach(function (r) {
        out.push({ row: r, depth: depth });
        var key = def.rowKey(r);
        if (def.children && def.expanded && def.expanded.has(key)) {
          var kids = def.children(r) || [];
          if (kids.length) walk(kids, depth + 1);
        }
      });
    };
    walk(def.rows, 0);
    return out;
  }

  UI.table = function (def) {
    tables.set(def.id, def);
    var vis = visibleRows(def);
    var head = def.columns.map(function (c) {
      var sorted = def.sort && def.sort.key === c.key;
      var aria = sorted ? (def.sort.dir === 'asc' ? 'ascending' : 'descending') : 'none';
      var cls = (c.num ? 'num ' : '') + (c.cls || '');
      if (c.sort === false || !c.sort) return '<th scope="col" class="' + cls + '"' + (c.title ? ' data-tip="' + esc(c.title) + '"' : '') + '>' + c.label + '</th>';
      return '<th scope="col" class="' + cls + '" aria-sort="' + aria + '"><button type="button" class="sortb" data-act="tbl-sort" data-tbl="' + esc(def.id) +
        '" data-col="' + esc(c.key) + '"' + (c.title ? ' data-tip="' + esc(c.title) + '"' : '') + '>' + c.label +
        '<span class="si" aria-hidden="true">' + (sorted ? (def.sort.dir === 'asc' ? '▲' : '▼') : '↕') + '</span></button></th>';
    }).join('');
    var body = vis.length ? vis.map(function (v) {
      var r = v.row, key = def.rowKey(r);
      var kids = def.children ? (def.children(r) || []) : [];
      var open = def.expanded && def.expanded.has(key);
      var href = def.rowHref ? def.rowHref(r) : null;
      var ract = !href && def.rowAct ? def.rowAct(r) : null;
      var cls = (def.rowClass ? def.rowClass(r) : '') + ' d' + v.depth + (href || ract ? ' link' : '');
      var cells = def.columns.map(function (c, ci) {
        var inner = c.html(r, v.depth);
        if (ci === 0 && def.children) {
          var tw = kids.length ? '<button type="button" class="tw" data-act="tbl-toggle" data-tbl="' + esc(def.id) + '" data-key="' + esc(key) +
            '" aria-expanded="' + !!open + '" aria-label="' + (open ? 'Collapse' : 'Expand') + ' ' + esc(def.rowLabel ? def.rowLabel(r) : '') + '">' +
            (open ? '▾' : '▸') + '</button>' : '<span class="tw sp" aria-hidden="true"></span>';
          inner = '<div class="cell0" style="--depth:' + v.depth + '">' + tw + '<div class="cell0-in">' + inner + '</div></div>';
        }
        return '<td class="' + (c.num ? 'num ' : '') + (c.cls || '') + '">' + inner + '</td>';
      }).join('');
      return '<tr class="' + cls.trim() + '"' + (href ? ' data-href="' + esc(href) + '"' : '') +
        (ract ? ' data-row-act="' + esc(ract.act) + '" data-v="' + esc(ract.v) + '"' : '') + '>' + cells + '</tr>';
    }).join('') : '<tr><td colspan="' + def.columns.length + '" class="empty-cell">' + esc(def.empty || 'Nothing to show for this selection.') + '</td></tr>';
    return '<div class="tbl-wrap"' + (def.maxHeight ? ' style="max-height:' + def.maxHeight + '"' : '') + ' tabindex="0" role="region" aria-label="' +
      esc(def.caption || 'Table') + '"><table class="tbl" id="tbl-' + esc(def.id) + '"><thead><tr>' + head + '</tr></thead><tbody>' + body + '</tbody></table></div>';
  };

  /** CSV rows of exactly what's shown (visible rows, current sort, expanded children). */
  UI.tableCsv = function (id) {
    var def = tables.get(id);
    if (!def) return null;
    var hasKids = !!def.children;
    var header = (hasKids ? ['Level'] : []).concat(def.csvHeader || []);
    var rows = [header];
    visibleRows(def).forEach(function (v) {
      var cells = def.csvRow(v.row, v.depth);
      rows.push((hasKids ? [def.levelName ? def.levelName(v.row, v.depth) : String(v.depth)] : []).concat(cells));
    });
    return rows;
  };

  UI.download = function (name, textContent, mime) {
    if (typeof document === 'undefined') return;
    var blob = new Blob([textContent], { type: mime || 'text/csv;charset=utf-8' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url; a.download = name; a.rel = 'noopener';
    document.body.appendChild(a);
    a.click();
    setTimeout(function () { URL.revokeObjectURL(url); a.remove(); }, 1000);
  };
  UI.csvName = function (base, P) {
    var range = P && P.cur ? P.cur.from + '_to_' + P.cur.to : 'no-period';
    return 'groov-' + base + '_' + range + '.csv';
  };

  /* =========================================================================================
   * Tooltip / popover layer
   *   [data-tip]   plain text, or JSON rows [["title"], [color, value, label], …] from charts
   *   [data-pop]   rich popover: content is the next sibling .pop-body (already-escaped HTML)
   * Hover and keyboard focus show the same content; tap toggles; Esc / scroll closes.
   * ======================================================================================= */
  var tipEl = null, pinned = null, current = null, lastPointer = 'mouse';
  function ensureTip() {
    if (tipEl || typeof document === 'undefined') return tipEl;
    tipEl = document.getElementById('tip');
    if (!tipEl) {
      tipEl = document.createElement('div');
      tipEl.id = 'tip'; tipEl.className = 'tip'; tipEl.setAttribute('role', 'tooltip');
      document.body.appendChild(tipEl);
    }
    tipEl.hidden = true;
    return tipEl;
  }
  function fillTip(target) {
    var el = ensureTip();
    el.textContent = '';
    el.classList.remove('rich');
    if (target.hasAttribute('data-pop')) {
      var body = target.parentNode && target.parentNode.querySelector('.pop-body');
      if (!body) return false;
      el.innerHTML = body.innerHTML; // our own pre-escaped markup
      el.classList.add('rich');
      return true;
    }
    var raw = target.getAttribute('data-tip');
    if (!raw) return false;
    if (raw.charAt(0) === '[') {
      var rows;
      try { rows = JSON.parse(raw); } catch (e) { rows = null; }
      if (rows) {
        rows.forEach(function (r, i) {
          var line = document.createElement('div');
          if (i === 0 && r.length === 1) { line.className = 'tt-h'; line.textContent = r[0]; el.appendChild(line); return; }
          line.className = 'tt-r';
          var key = document.createElement('i');
          key.className = 'tt-k' + (r[0] === 'cmp' ? ' cmp' : r[0] ? '' : ' none');
          if (r[0] && r[0] !== 'cmp') key.style.background = r[0];
          var val = document.createElement('b'); val.textContent = r[1];
          var lab = document.createElement('span'); lab.textContent = r[2] || '';
          line.appendChild(key); line.appendChild(val); line.appendChild(lab);
          el.appendChild(line);
        });
        return true;
      }
    }
    el.textContent = raw;
    return true;
  }
  function place(target, x, y) {
    var el = tipEl;
    el.hidden = false;
    el.style.left = '0px'; el.style.top = '0px';
    var tw = el.offsetWidth, th = el.offsetHeight, vw = window.innerWidth, vh = window.innerHeight;
    var left, top;
    if (x === undefined) {
      var r = target.getBoundingClientRect();
      left = r.left; top = r.bottom + 8;
      if (top + th > vh - 8) top = r.top - th - 8;
    } else {
      left = x + 14; top = y + 14;
      if (left + tw > vw - 8) left = x - tw - 14;
      if (top + th > vh - 8) top = y - th - 14;
    }
    el.style.left = Math.max(8, Math.min(left, vw - tw - 8)) + 'px';
    el.style.top = Math.max(8, top) + 'px';
  }
  function show(target, ev) {
    if (!fillTip(target)) return;
    current = target;
    var isChart = target.closest && target.closest('svg');
    place(target, isChart && ev && ev.clientX !== undefined ? ev.clientX : undefined, isChart && ev ? ev.clientY : undefined);
  }
  function hide() { if (tipEl) tipEl.hidden = true; current = null; pinned = null; }
  UI.hideTip = hide;

  UI.initTips = function () {
    if (typeof document === 'undefined' || UI._tipsOn) return;
    UI._tipsOn = true;
    ensureTip();
    var sel = '[data-tip],[data-pop]';
    document.addEventListener('pointerdown', function (ev) { lastPointer = ev.pointerType || 'mouse'; }, true);
    document.addEventListener('pointermove', function (ev) {
      if (pinned || ev.pointerType === 'touch') return;
      var t = ev.target.closest ? ev.target.closest(sel) : null;
      if (!t) { if (current) hide(); return; }
      if (t !== current) show(t, ev);
      else if (t.closest('svg')) place(t, ev.clientX, ev.clientY);
    });
    document.addEventListener('focusin', function (ev) {
      var t = ev.target.closest ? ev.target.closest(sel) : null;
      if (t && t.matches('button,a,[tabindex]')) show(t);
    });
    document.addEventListener('focusout', function () { if (!pinned) hide(); });
    document.addEventListener('click', function (ev) {
      var t = ev.target.closest ? ev.target.closest('[data-pop]') : null;
      if (t) {
        ev.preventDefault();
        if (pinned === t) { hide(); return; }
        show(t); pinned = t;
        return;
      }
      var tt = ev.target.closest ? ev.target.closest('[data-tip]') : null;
      if (tt && lastPointer !== 'mouse' && !tt.closest('a,button,input,select,label')) {
        if (pinned === tt) { hide(); return; }
        show(tt, ev); pinned = tt;
        return;
      }
      if (pinned && !(tipEl && tipEl.contains(ev.target))) hide();
    });
    document.addEventListener('keydown', function (ev) { if (ev.key === 'Escape') hide(); });
    window.addEventListener('scroll', function () { if (current) hide(); }, true);
  };
})(typeof window !== 'undefined' ? window : this);
