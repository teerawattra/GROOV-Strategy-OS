/* GROOV Ads Command Center · data.js
 * ------------------------------------------------------------------------------------------
 * Role: where the numbers come from and how they are indexed. No DOM, no rendering.
 *
 *  1. Source     createSource(mode)       sample (window.GROOV_SAMPLE) or live JSON API; live fetches
 *                                         only missing date windows (≤ 400-day chunks) and merges them
 *                normRanges / subtractRanges / splitRange / mergePayloads   helpers for that
 *                detectMode(win)          sample only when GROOV_SAMPLE exists AND page is file:/localhost
 *                api(path, opts)          same-origin fetch; any 401 -> /login.html
 *  2. Registry   indexRegistry(reg)       clients, slugs, account -> client map (acctKey)
 *  3. Dataset    indexRows(payload, reg)  entity dictionaries + columnar typed arrays, built ONCE per load
 *  4. Periods    periods(meta, period, compare)   presets counted back from data_through (SPEC §3.3/§3.4)
 *                neededRange(meta, P, opts)       earliest date the current view needs (one span)
 *                neededRanges(meta, P, opts)      the separate windows it needs (what live mode fetches)
 *  5. Aggregates agg(ds, from, to)        one pass over rows -> campaign / ad set / ad totals and
 *                                         campaign × day cube; memoized per range on the dataset
 *                obj / zero / addInto / series / seriesObj   helpers over those arrays
 *                adsetDays(ds, from, to, idx)  daily metric objects per ad set (memoized)
 *  5b. Trends    trendGran / buckets / bucketSums   daily ≤ 45 days, else Mon–Sun weeks (SPEC §4.7)
 *  6. Monthly    indexMonthly(payload, reg)   campaign × month rows mapped to client slugs
 *  7. Breakdowns indexBreakdowns / mergeBreakdowns / bdAgg / bdSum / bdRanges   optional Meta
 *                placement + audience Sheets (DATA_CONTRACT §2.5); source.ensureBreakdowns(ranges)
 *
 * Data contract: DATA_CONTRACT.md §2. IDs are strings (18-digit Meta ids exceed 2^53): never coerce.
 * Blank metrics arrive as 0 (null only for Google reach); a 0 denominator is shown as "—" upstream.
 */
(function (root) {
  'use strict';
  var G = root.GROOV = root.GROOV || {};
  var U = G.util;
  var D = G.data = {};

  D.PLATFORMS = ['meta', 'tiktok', 'google'];
  D.PLATFORM_LABEL = { meta: 'Meta', tiktok: 'TikTok', google: 'Google' };
  /** Metric order inside every aggregate vector. */
  D.METRICS = ['spend', 'impressions', 'reach', 'clicks', 'link_clicks', 'video_views', 'messages', 'leads', 'conversions', 'conv_value', 'roas_value'];
  var NM = D.NM = D.METRICS.length;
  var MI = D.MI = {};
  D.METRICS.forEach(function (k, i) { MI[k] = i; });

  /* =========================================================================================
   * 1. Source
   * ======================================================================================= */
  D.isLocal = function (loc) {
    if (!loc) return false;
    var h = String(loc.hostname || '').toLowerCase();
    return loc.protocol === 'file:' || h === 'localhost' || h === '127.0.0.1' || h === '[::1]' || h === '::1';
  };
  D.detectMode = function (win) {
    return win && win.GROOV_SAMPLE && D.isLocal(win.location) ? 'sample' : 'live';
  };

  function apiError(status, message) {
    var e = new Error(message || ('Request failed (' + status + ')'));
    e.status = status;
    return e;
  }
  /** Called on any 401 in live mode. Separate so tests / the app can override it. */
  D.onUnauthorized = function () {
    try { root.location.href = '/login.html'; } catch (e) { /* not in a browser */ }
  };
  D.api = function (path, opts) {
    opts = opts || {};
    return root.fetch(path, {
      method: opts.method || 'GET',
      credentials: 'same-origin',
      headers: { Accept: 'application/json' },
      cache: 'no-store'
    }).then(function (res) {
      if (res.status === 401) { D.onUnauthorized(); throw apiError(401, 'Your session has ended. Redirecting to sign-in…'); }
      return res.text().then(function (t) {
        var body = null;
        if (t) { try { body = JSON.parse(t); } catch (e) { body = null; } }
        if (!res.ok) {
          var msg = body && (body.error || body.message) ? (body.error || body.message) : t;
          throw apiError(res.status, String(msg || '').slice(0, 300) || ('Request failed (' + res.status + ')'));
        }
        return body; // 202 / 204 with no body -> null
      });
    });
  };

  /* ---------- date-range sets (live fetching) ---------- */
  /** /api/rows caps one request's span; 400 days stays under both the old (400) and new (800) cap. */
  D.FETCH_CHUNK_DAYS = 400;
  /** Sort and merge overlapping or adjacent ranges. */
  D.normRanges = function (list) {
    var r = (list || []).filter(function (x) { return x && U.isIso(x.from) && U.isIso(x.to) && x.from <= x.to; })
      .map(function (x) { return { from: x.from, to: x.to }; }).sort(function (a, b) { return a.from < b.from ? -1 : a.from > b.from ? 1 : 0; });
    var out = [];
    r.forEach(function (x) {
      var last = out[out.length - 1];
      if (last && x.from <= U.addDays(last.to, 1)) { if (x.to > last.to) last.to = x.to; }
      else out.push(x);
    });
    return out;
  };
  /** Parts of `need` not inside `have` (both normalised). */
  D.subtractRanges = function (need, have) {
    var out = [];
    D.normRanges(need).forEach(function (n) {
      var cur = n.from;
      D.normRanges(have).forEach(function (h) {
        if (h.to < cur || h.from > n.to) return;
        if (h.from > cur) out.push({ from: cur, to: U.addDays(h.from, -1) });
        if (h.to >= cur) cur = U.addDays(h.to, 1);
      });
      if (cur <= n.to) out.push({ from: cur, to: n.to });
    });
    return out;
  };
  D.splitRange = function (r, maxDays) {
    var out = [], f = r.from;
    while (f <= r.to) {
      var t = U.addDays(f, maxDays - 1);
      if (t > r.to) t = r.to;
      out.push({ from: f, to: t });
      f = U.addDays(t, 1);
    }
    return out;
  };

  /**
   * Merge several /api/rows payloads (each with its own entity lists and indexes) into one payload.
   * Entities merge by `key` (a later payload's metadata wins); rows are re-indexed and de-duplicated on
   * date + entity, so overlapping fetches can never double count.
   */
  D.mergePayloads = function (payloads) {
    var outCols = ['date', 'campaign', 'adset', 'ad'].concat(D.METRICS);
    var out = { schema: 1, mode: null, generated_at: null, range: null, cols: outCols, accounts: [], campaigns: [], adsets: [], ads: [], rows: [] };
    var idx = { accounts: new Map(), campaigns: new Map(), adsets: new Map(), ads: new Map() };
    var upsert = function (kind, ent) {
      var k = ent.key, i = idx[kind].get(k);
      if (i === undefined) { i = out[kind].length; out[kind].push(ent); idx[kind].set(k, i); }
      else out[kind][i] = ent;
      return i;
    };
    var seen = new Set();
    payloads.forEach(function (p) {
      if (!p) return;
      out.mode = p.mode || out.mode;
      if (!out.generated_at || (p.generated_at && p.generated_at > out.generated_at)) out.generated_at = p.generated_at || out.generated_at;
      if (p.range) out.range = out.range ? { from: U.minIso(out.range.from, p.range.from), to: U.maxIso(out.range.to, p.range.to) } : { from: p.range.from, to: p.range.to };
      var ci = {};
      (p.cols || []).forEach(function (c, i) { ci[c] = i; });
      var aMap = (p.accounts || []).map(function (a) { return upsert('accounts', Object.assign({}, a)); });
      var cMap = (p.campaigns || []).map(function (c) { return upsert('campaigns', Object.assign({}, c, { account: aMap[c.account] })); });
      var sMap = (p.adsets || []).map(function (x) { return upsert('adsets', Object.assign({}, x, { campaign: cMap[x.campaign] })); });
      var dMap = (p.ads || []).map(function (x) {
        return upsert('ads', Object.assign({}, x, { campaign: cMap[x.campaign], adset: x.adset >= 0 && sMap[x.adset] !== undefined ? sMap[x.adset] : -1 }));
      });
      var iD = ci.date === undefined ? 0 : ci.date, iC = ci.campaign === undefined ? 1 : ci.campaign;
      var iS = ci.adset === undefined ? 2 : ci.adset, iA = ci.ad === undefined ? 3 : ci.ad;
      (p.rows || []).forEach(function (r) {
        var c = cMap[r[iC]];
        if (c === undefined) return;
        var sv = r[iS] >= 0 && sMap[r[iS]] !== undefined ? sMap[r[iS]] : -1;
        var av = r[iA] >= 0 && dMap[r[iA]] !== undefined ? dMap[r[iA]] : -1;
        var key = r[iD] + '|' + c + '|' + sv + '|' + av;
        if (seen.has(key)) return;
        seen.add(key);
        var row = [r[iD], c, sv, av];
        D.METRICS.forEach(function (m) { row.push(ci[m] === undefined ? 0 : r[ci[m]]); });
        out.rows.push(row);
      });
    });
    return out;
  };

  /**
   * A data source with one interface for both modes:
   *   loadMeta()              -> meta payload (sheets health, data_through, history_from, creatives)
   *   covers(ranges)          -> true when every range is already loaded
   *   ensureRanges(ranges)    -> Promise<boolean changed>; fetches only the missing parts (live)
   *   ensureRows(from, to)    -> ensureRanges([{from, to}])
   *   refresh(needFor)        -> live: refetch meta + rows, swap in only when both arrived
   *   loadMonthly()           -> monthly payload (lazy)
   *   ensureBreakdowns(ranges) -> Promise<boolean changed>; /api/breakdowns for the missing windows
   *                              (lazy, queued, merged like rows; a 404 means "not deployed" = unavailable)
   *   coversBreakdowns(ranges) -> true when those windows' breakdowns are loaded
   *   loadSession() / signOut() / startRefresh()   live only (/api/session, /api/refresh)
   *   reset()                 forget everything
   * State: src.meta, src.ds (indexed dataset), src.monthly (indexed), src.covered [{from,to}],
   *        src.bd (indexed breakdowns, see indexBreakdowns), src.bdCovered [{from,to}]
   */
  D.createSource = function (mode, win, regIdx) {
    var src = { mode: mode, meta: null, ds: null, monthly: null, covered: [], session: null, bd: null, bdCovered: [] };
    var payloads = [], bdPayloads = [];
    src.reset = function () { src.meta = null; src.ds = null; src.monthly = null; src.covered = []; payloads = []; src.bd = null; src.bdCovered = []; bdPayloads = []; };
    src.covers = function (ranges) {
      if (!src.ds) return false;
      if (mode === 'sample') return true; // the sample is one fixed payload; needed ranges are clamped to its history
      return D.subtractRanges(ranges, src.covered).length === 0;
    };
    src.coversBreakdowns = function (ranges) {
      if (!src.bd) return false;
      if (mode === 'sample') return true;
      return D.subtractRanges(ranges, src.bdCovered).length === 0;
    };
    src.ensureRows = function (from, to) { return src.ensureRanges([{ from: from, to: to }]); };
    if (mode === 'sample') {
      src.loadMeta = function () {
        src.meta = win.GROOV_SAMPLE.meta;
        return Promise.resolve(src.meta);
      };
      src.ensureRanges = function () {
        if (src.ds) return Promise.resolve(false);
        var p = win.GROOV_SAMPLE.rows;
        src.ds = D.indexRows(p, regIdx);
        src.covered = p.range ? [{ from: p.range.from, to: p.range.to }] : [];
        return Promise.resolve(true);
      };
      src.loadMonthly = function () {
        if (!src.monthly) src.monthly = D.indexMonthly(win.GROOV_SAMPLE.monthly, regIdx);
        return Promise.resolve(src.monthly);
      };
      // Sample breakdowns: window.GROOV_SAMPLE.breakdowns (one fixed payload). Missing = not available.
      src.ensureBreakdowns = function () {
        if (src.bd) return Promise.resolve(false);
        src.bd = D.indexBreakdowns(win.GROOV_SAMPLE.breakdowns || null);
        return Promise.resolve(true);
      };
      src.loadSession = function () { return Promise.resolve(null); };
      src.signOut = function () { return Promise.resolve(); };
      src.startRefresh = function () { return Promise.reject(new Error('Not available in sample mode.')); };
      return src;
    }
    src.loadMeta = function () {
      return D.api('/api/meta').then(function (m) { src.meta = m; return m; });
    };
    function fetchChunks(ranges) {
      var chunks = [];
      ranges.forEach(function (r) { chunks = chunks.concat(D.splitRange(r, D.FETCH_CHUNK_DAYS)); });
      return Promise.all(chunks.map(function (c) {
        return D.api('/api/rows?from=' + encodeURIComponent(c.from) + '&to=' + encodeURIComponent(c.to));
      })).then(function (list) { return { chunks: chunks, list: list }; });
    }
    function rebuild() {
      src.ds = D.indexRows(payloads.length === 1 ? payloads[0] : D.mergePayloads(payloads), regIdx);
    }
    // Row fetches are serialized: a request queued behind another sees what that one loaded, so two
    // quick period changes can never leave an older, narrower dataset in place.
    var queue = Promise.resolve();
    src.ensureRanges = function (ranges) {
      var run = function () {
        var gaps = D.subtractRanges(ranges, src.covered);
        if (src.ds && !gaps.length) return false;
        if (!gaps.length) gaps = D.normRanges(ranges);
        return fetchChunks(gaps).then(function (res) {
          payloads = payloads.concat(res.list.filter(Boolean));
          src.covered = D.normRanges(src.covered.concat(res.chunks));
          rebuild();
          return true;
        });
      };
      var p = queue.then(run, run);
      queue = p.catch(function () { /* keep the queue alive after an error */ });
      return p;
    };
    /**
     * Refresh (live): fetch meta, then the ranges `needFor(meta)` asks for, and only then swap them in,
     * so the previous numbers stay on screen (dimmed) until the new ones arrive.
     */
    src.refresh = function (needFor) {
      return D.api('/api/meta').then(function (m) {
        var ranges = D.normRanges(needFor(m));
        return fetchChunks(ranges).then(function (res) {
          src.meta = m;
          payloads = res.list.filter(Boolean);
          src.covered = D.normRanges(res.chunks);
          rebuild();
          src.monthly = null;
          // breakdowns reload lazily for the new data (the next panel or section that needs them)
          src.bd = null; src.bdCovered = []; bdPayloads = [];
          return true;
        });
      });
    };
    src.loadMonthly = function () {
      if (src.monthly) return Promise.resolve(src.monthly);
      return D.api('/api/monthly').then(function (p) { src.monthly = D.indexMonthly(p, regIdx); return src.monthly; });
    };
    /**
     * Breakdowns (live): only the windows not loaded yet, ≤ 400-day requests, serialized like rows.
     * A 404 means the endpoint is not deployed: treated as "not available" (the panels show the
     * empty state). Any other error rejects (section-level error + Retry); loaded data stays.
     */
    var bdQueue = Promise.resolve();
    src.ensureBreakdowns = function (ranges) {
      var run = function () {
        var gaps = D.subtractRanges(ranges, src.bdCovered);
        if (src.bd && !gaps.length) return false;
        if (!gaps.length) gaps = D.normRanges(ranges);
        var chunks = [];
        gaps.forEach(function (r) { chunks = chunks.concat(D.splitRange(r, D.FETCH_CHUNK_DAYS)); });
        return Promise.all(chunks.map(function (c) {
          return D.api('/api/breakdowns?from=' + encodeURIComponent(c.from) + '&to=' + encodeURIComponent(c.to)).catch(function (e) {
            if (e && e.status === 404) return { schema: 1, range: { from: c.from, to: c.to }, available: { placement: false, audience: false }, not_deployed: true };
            throw e;
          });
        })).then(function (list) {
          bdPayloads = bdPayloads.concat(list.filter(Boolean));
          src.bdCovered = D.normRanges(src.bdCovered.concat(chunks));
          src.bd = D.indexBreakdowns(bdPayloads.length === 1 ? bdPayloads[0] : D.mergeBreakdowns(bdPayloads));
          return true;
        });
      };
      var p = bdQueue.then(run, run);
      bdQueue = p.catch(function () { /* keep the queue alive after an error */ });
      return p;
    };
    src.loadSession = function () {
      return D.api('/api/session').then(function (s) { src.session = s; return s; });
    };
    src.signOut = function () {
      return D.api('/api/session', { method: 'DELETE' }).catch(function () { /* sign out anyway */ });
    };
    /** Owner only: ask the backend to re-pull the Sheets now (202 Accepted). */
    src.startRefresh = function () { return D.api('/api/refresh', { method: 'POST' }); };
    return src;
  };

  /* =========================================================================================
   * 2. Registry
   * ======================================================================================= */
  /** Normalised account key for matching registry ids to data ids ("act_" prefix and Google dashes ignored). */
  D.acctKey = function (platform, id) {
    var s = String(id === null || id === undefined ? '' : id).trim().replace(/^act_/i, '');
    if (platform === 'google') s = s.replace(/-/g, '');
    return platform + ':' + s;
  };
  D.unmappedSlug = function (platform, id) { return 'unmapped-' + platform + '-' + U.slugify(String(id)); };

  D.indexRegistry = function (reg) {
    reg = reg || {};
    var list = Array.isArray(reg.clients) ? reg.clients : [];
    var used = Object.create(null);
    var out = { clients: [], byAccountKey: new Map(), bySlug: new Map(), verticals: [], owners: [], hasBudget: false, hasTargets: false, hasOwner: false, updated: reg.updated || null };
    list.forEach(function (c) {
      var name = String(c.client || c.name || 'Unnamed client');
      var slug = U.slugify(name), base = slug, k = 2;
      while (used[slug]) slug = base + '-' + (k++);
      used[slug] = 1;
      var accounts = [];
      D.PLATFORMS.forEach(function (p) {
        (Array.isArray(c[p]) ? c[p] : []).forEach(function (a) {
          if (!a || a.id === undefined || a.id === null) return;
          accounts.push({ platform: p, id: String(a.id), name: a.name || String(a.id), status: a.status || null, key: D.acctKey(p, a.id) });
        });
      });
      var budget = c.budget && typeof c.budget === 'object' ? c.budget : null;
      var targets = c.targets && typeof c.targets === 'object' ? c.targets : null;
      var client = {
        name: name, slug: slug, vertical: c.vertical ? String(c.vertical) : 'Unmapped', folder: c.client_folder || null,
        owner: c.owner ? String(c.owner) : null, budget: budget, targets: targets, accounts: accounts, unmapped: false
      };
      if (budget && D.PLATFORMS.some(function (p) { return U.isNum(+budget[p]) && +budget[p] > 0; })) out.hasBudget = true;
      if (targets && Object.keys(targets).length) out.hasTargets = true;
      if (client.owner) out.hasOwner = true;
      var idx = out.clients.length;
      out.clients.push(client);
      out.bySlug.set(slug, idx);
      accounts.forEach(function (a) { if (!out.byAccountKey.has(a.key)) out.byAccountKey.set(a.key, idx); });
    });
    out.verticals = U.uniq(out.clients.map(function (c) { return c.vertical; })).sort(U.cmpText);
    out.owners = U.uniq(out.clients.map(function (c) { return c.owner; }).filter(Boolean)).sort(U.cmpText);
    return out;
  };

  /* =========================================================================================
   * 3. Dataset index (built once per rows payload)
   * ======================================================================================= */
  var dsVersion = 0;
  var RANGE_MEMO_MAX = 16;

  D.indexRows = function (payload, regIdx) {
    payload = payload || {};
    regIdx = regIdx || D.indexRegistry(null);
    var cols = Array.isArray(payload.cols) ? payload.cols : [];
    var ci = {};
    cols.forEach(function (c, i) { ci[c] = i; });
    var srcIdx = D.METRICS.map(function (k) { return ci[k] === undefined ? -1 : ci[k]; });

    // Clients: every registry client (so registry-only clients can still be opened) + one per unmapped account.
    var clients = regIdx.clients.map(function (c, i) {
      return { i: i, name: c.name, slug: c.slug, vertical: c.vertical, owner: c.owner, budget: c.budget, targets: c.targets,
        folder: c.folder, registryAccounts: c.accounts, unmapped: false, accounts: [], campaigns: [] };
    });
    var bySlug = new Map();
    clients.forEach(function (c) { bySlug.set(c.slug, c.i); });

    var accounts = (payload.accounts || []).map(function (a, i) {
      var platform = a.platform || String(a.key || '').split(':')[0];
      var id = String(a.id === undefined || a.id === null ? String(a.key || '').split(':').slice(1).join(':') : a.id);
      var acc = { i: i, key: a.key || (platform + ':' + id), platform: platform, id: id, name: a.name || id, client: -1, campaigns: [] };
      var cIdx = regIdx.byAccountKey.get(D.acctKey(platform, id));
      if (cIdx === undefined) {
        var slug = D.unmappedSlug(platform, id);
        if (!bySlug.has(slug)) {
          cIdx = clients.length;
          clients.push({ i: cIdx, name: acc.name, slug: slug, vertical: 'Unmapped', owner: null, budget: null, targets: null,
            folder: null, registryAccounts: [], unmapped: true, accounts: [], campaigns: [] });
          bySlug.set(slug, cIdx);
        } else cIdx = bySlug.get(slug);
      }
      acc.client = cIdx;
      clients[cIdx].accounts.push(i);
      return acc;
    });

    var campaigns = (payload.campaigns || []).map(function (c, i) {
      var acc = accounts[c.account] || null;
      var camp = {
        i: i, key: c.key, id: String(c.id), name: c.name || '(unnamed campaign)', rawObjective: c.objective || null,
        channel: c.channel || null, status: c.status || 'UNKNOWN', account: acc ? acc.i : -1,
        platform: acc ? acc.platform : String(c.key || '').split(':')[0], client: acc ? acc.client : -1,
        first_date: c.first_date || null, last_date: c.last_date || null, adsets: [], ads: []
      };
      if (acc) acc.campaigns.push(i);
      if (camp.client >= 0) clients[camp.client].campaigns.push(i);
      return camp;
    });
    var adsets = (payload.adsets || []).map(function (s, i) {
      var as = { i: i, key: s.key, id: String(s.id), name: s.name || '(unnamed ad set)', status: s.status || 'UNKNOWN',
        campaign: s.campaign, first_date: s.first_date || null, last_date: s.last_date || null, ads: [] };
      if (campaigns[s.campaign]) campaigns[s.campaign].adsets.push(i);
      return as;
    });
    var ads = (payload.ads || []).map(function (a, i) {
      var ad = { i: i, key: a.key, id: String(a.id), name: a.name || '(unnamed ad)', status: a.status || 'UNKNOWN',
        raw_status: a.raw_status || null, preview: a.preview || null, image: a.image === true,
        image_reason: a.image_reason || null, campaign: a.campaign, adset: a.adset === undefined ? -1 : a.adset,
        first_date: a.first_date || null, last_date: a.last_date || null };
      if (campaigns[a.campaign]) campaigns[a.campaign].ads.push(i);
      if (adsets[ad.adset]) adsets[ad.adset].ads.push(i);
      return ad;
    });

    // Columnar fact rows.
    var raw = Array.isArray(payload.rows) ? payload.rows : [];
    var n = raw.length;
    var day = new Int32Array(n), camp = new Int32Array(n), adset = new Int32Array(n), ad = new Int32Array(n), m = new Float64Array(n * NM);
    var iDate = ci.date === undefined ? 0 : ci.date, iC = ci.campaign === undefined ? 1 : ci.campaign;
    var iS = ci.adset === undefined ? 2 : ci.adset, iA = ci.ad === undefined ? 3 : ci.ad;
    var k = 0, minDay = Infinity, maxDay = -Infinity, skipped = 0, dayCache = Object.create(null);
    for (var r = 0; r < n; r++) {
      var row = raw[r];
      var c = row[iC];
      var ds = row[iDate];
      if (!(c >= 0 && c < campaigns.length) || !U.isIso(ds)) { skipped++; continue; }
      var dn = dayCache[ds];
      if (dn === undefined) dn = dayCache[ds] = U.dayNum(ds);
      day[k] = dn; camp[k] = c;
      var s = row[iS], a = row[iA];
      adset[k] = s >= 0 && s < adsets.length ? s : -1;
      ad[k] = a >= 0 && a < ads.length ? a : -1;
      var base = k * NM;
      for (var j = 0; j < NM; j++) {
        var si = srcIdx[j];
        var v = si < 0 ? 0 : +row[si];
        m[base + j] = U.isNum(v) ? v : 0;
      }
      if (dn < minDay) minDay = dn;
      if (dn > maxDay) maxDay = dn;
      k++;
    }
    var adsetByKey = new Map();
    adsets.forEach(function (s) { if (s.key && !adsetByKey.has(s.key)) adsetByKey.set(s.key, s.i); });
    return {
      version: ++dsVersion,
      range: payload.range || null, mode: payload.mode || null, generated_at: payload.generated_at || null,
      clients: clients, bySlug: bySlug, accounts: accounts, campaigns: campaigns, adsets: adsets, ads: ads, adsetByKey: adsetByKey,
      n: k, day: day, camp: camp, adset: adset, ad: ad, m: m, skipped: skipped,
      minDate: k ? U.isoDay(minDay) : null, maxDate: k ? U.isoDay(maxDay) : null,
      memo: new Map()
    };
  };

  /* =========================================================================================
   * 4. Periods
   * ======================================================================================= */
  D.PRESETS = [
    { id: '7d', label: '7D', days: 7 }, { id: '14d', label: '14D', days: 14 }, { id: '30d', label: '30D', days: 30 },
    { id: '60d', label: '60D', days: 60 }, { id: '90d', label: '90D', days: 90 }, { id: 'mtd', label: 'MTD' },
    { id: 'lastmonth', label: 'Last month' }, { id: 'qtd', label: 'QTD' }, { id: 'lastquarter', label: 'Last quarter' },
    { id: 'custom', label: 'Custom' }
  ];
  D.COMPARES = [
    { id: 'prev', label: 'Previous period' }, { id: 'month', label: 'Same period last month' },
    { id: 'year', label: 'Same period last year' }, { id: 'off', label: 'Off' }
  ];
  D.PRESET_IDS = D.PRESETS.map(function (p) { return p.id; });
  D.COMPARE_IDS = D.COMPARES.map(function (c) { return c.id; });
  D.PROVISIONAL_DAYS = 3;

  /** First `len` days starting at `start`, never running past `capEnd`. */
  function firstDays(start, len, capEnd) {
    var end = U.addDays(start, len - 1);
    return { from: start, to: end > capEnd ? capEnd : end };
  }

  /**
   * Resolve the current and comparison windows.
   *   meta: { data_through, history_from }       period: { preset, from, to }      compare: prev|month|year|off
   * Returns {
   *   preset, compare, T (data_through), H (history_from),
   *   nominal {from,to}  the preset's calendar window,
   *   cur {from,to}|null  nominal clipped to [history_from, data_through]; null when nothing overlaps,
   *   clipped, len, curLen,
   *   cmp {from,to}|null, cmpLen, noBaseline, reason, unequal, overlap,
   *   provisional {from,to}|null  (last 3 days up to data_through, inside cur),
   *   label, cmpLabel, key
   * }
   * Presets count back from data_through (the latest complete day in every Sheet), never from today.
   */
  D.periods = function (meta, period, compare) {
    var T = meta && meta.data_through, H = meta && meta.history_from;
    if (!U.isIso(T)) T = U.bangkokToday();
    if (!U.isIso(H)) H = T;
    period = period || {};
    var preset = D.PRESET_IDS.indexOf(period.preset) >= 0 ? period.preset : '7d';
    compare = D.COMPARE_IDS.indexOf(compare) >= 0 ? compare : 'prev';
    var from, to, prevRule = 'shift';
    var def = null;
    D.PRESETS.forEach(function (p) { if (p.id === preset) def = p; });
    if (def && def.days) { to = T; from = U.addDays(T, -(def.days - 1)); }
    else if (preset === 'mtd') { from = U.monthStart(T); to = T; prevRule = 'month'; }
    else if (preset === 'lastmonth') { to = U.addDays(U.monthStart(T), -1); from = U.monthStart(to); prevRule = 'month'; }
    else if (preset === 'qtd') { from = U.quarterStart(T); to = T; prevRule = 'quarter'; }
    else if (preset === 'lastquarter') { to = U.addDays(U.quarterStart(T), -1); from = U.quarterStart(to); prevRule = 'quarter'; }
    else { // custom
      from = U.isIso(period.from) ? period.from : U.addDays(T, -6);
      to = U.isIso(period.to) ? period.to : T;
      if (from < H) from = H;
      if (to > T) to = T;
      if (from > to) { var x = from; from = to; to = x; }
      if (from < H) from = H;
    }
    var len = U.diffDays(from, to) + 1;

    var cmp = null;
    if (compare === 'prev') {
      if (prevRule === 'month') {
        var pm = U.addMonths(U.monthStart(from), -1);
        cmp = firstDays(pm, len, U.monthEnd(pm));
      } else if (prevRule === 'quarter') {
        var pq = U.addMonths(U.quarterStart(from), -3);
        cmp = firstDays(pq, len, U.quarterEnd(pq));
      } else {
        cmp = { from: U.addDays(from, -len), to: U.addDays(from, -1) };
      }
    } else if (compare === 'month') {
      cmp = { from: U.addMonths(from, -1), to: U.addMonths(to, -1) };
    } else if (compare === 'year') {
      cmp = { from: U.addMonths(from, -12), to: U.addMonths(to, -12) };
    }

    var cur = { from: from < H ? H : from, to: to > T ? T : to };
    if (cur.from > cur.to) cur = null;
    var P = {
      preset: preset, compare: compare, T: T, H: H,
      nominal: { from: from, to: to }, cur: cur, clipped: !!cur && (cur.from !== from || cur.to !== to),
      len: len, curLen: cur ? U.diffDays(cur.from, cur.to) + 1 : 0,
      cmp: cmp, cmpLen: cmp ? U.diffDays(cmp.from, cmp.to) + 1 : 0,
      noBaseline: false, reason: null, unequal: false, overlap: false, provisional: null
    };
    if (cmp) {
      P.unequal = P.cmpLen !== len;
      P.overlap = !!cur && cmp.to >= cur.from;
      if (cmp.from < H) {
        P.noBaseline = true;
        P.reason = 'Comparison ' + U.rangeLabel(cmp.from, cmp.to) + ' starts before the history start (' + U.fmtDate(H) + '), so changes show "no baseline".';
      }
    }
    if (cur) {
      var pf = U.addDays(T, -(D.PROVISIONAL_DAYS - 1));
      var pa = pf > cur.from ? pf : cur.from;
      if (pa <= cur.to && cur.to >= pf) P.provisional = { from: pa, to: cur.to };
    }
    P.label = cur ? U.rangeLabel(cur.from, cur.to) : U.rangeLabel(from, to);
    P.cmpLabel = cmp ? U.rangeLabel(cmp.from, cmp.to) : null;
    P.key = [cur ? cur.from + '~' + cur.to : 'none', cmp && !P.noBaseline ? cmp.from + '~' + cmp.to : 'nocmp'].join('|');
    return P;
  };

  /**
   * Earliest date the dashboard needs for this state (live mode fetches [from, data_through] once).
   * Includes the comparison (when it has a baseline), 10 days before the period end for delivery
   * checks, and month-to-date + trailing 7 days for pacing when any client has a budget.
   */
  D.neededRange = function (meta, P, opts) {
    var T = P.T, H = P.H;
    var f = P.cur ? P.cur.from : T;
    if (P.cmp && !P.noBaseline) f = U.minIso(f, P.cmp.from);
    if (P.cur) f = U.minIso(f, U.addDays(P.cur.to, -9));
    if (opts && opts.pacing) f = U.minIso(f, U.minIso(U.monthStart(T), U.addDays(T, -6)));
    if (opts && opts.days) f = U.minIso(f, U.addDays(T, -(opts.days - 1)));
    if (f < H) f = H;
    return { from: f, to: T };
  };

  /**
   * The separate windows the current view needs (live mode fetches only the parts not loaded yet):
   * the current period, the comparison (when it has a baseline), the 10 days before the period end
   * (delivery checks) and, with budgets, month-to-date + the trailing 7 days (pacing). Clamped to the
   * history, merged when they touch.
   */
  D.neededRanges = function (meta, P, opts) {
    var T = P.T, H = P.H, out = [];
    var add = function (f, t) {
      if (!U.isIso(f) || !U.isIso(t)) return;
      if (f < H) f = H;
      if (t > T) t = T;
      if (f <= t) out.push({ from: f, to: t });
    };
    if (P.cur) { add(P.cur.from, P.cur.to); add(U.addDays(P.cur.to, -9), P.cur.to); }
    else add(T, T);
    if (P.cmp && !P.noBaseline) add(P.cmp.from, P.cmp.to);
    if (opts && opts.pacing) { add(U.monthStart(T), T); add(U.addDays(T, -6), T); }
    if (opts && opts.days) add(U.addDays(T, -(opts.days - 1)), T);
    return D.normRanges(out);
  };

  /* =========================================================================================
   * 5. Aggregates
   * ======================================================================================= */
  /**
   * One pass over the fact rows inside [from, to]. Returns typed arrays (NM metrics per entity):
   *   camp, adset, ad          totals per entity
   *   campDay                  campaign × day cube, offset ((c * nDays) + dayIndex) * NM
   * Memoized on the dataset by range, so switching views never re-scans rows.
   */
  D.agg = function (ds, from, to) {
    var key = from + '|' + to;
    var hit = ds.memo.get(key);
    if (hit) return hit;
    var d0 = U.dayNum(from), d1 = U.dayNum(to), nDays = Math.max(0, d1 - d0 + 1);
    var nC = ds.campaigns.length, nS = ds.adsets.length, nA = ds.ads.length;
    var camp = new Float64Array(nC * NM), adset = new Float64Array(nS * NM), ad = new Float64Array(nA * NM);
    var campDay = new Float64Array(Math.max(1, nC * nDays * NM));
    var rowsIn = 0, dayArr = ds.day, cArr = ds.camp, sArr = ds.adset, aArr = ds.ad, m = ds.m;
    for (var r = 0; r < ds.n; r++) {
      var d = dayArr[r];
      if (d < d0 || d > d1) continue;
      rowsIn++;
      var c = cArr[r], s = sArr[r], a = aArr[r], mo = r * NM;
      var co = c * NM, cdo = (c * nDays + (d - d0)) * NM, so = s * NM, ao = a * NM;
      for (var j = 0; j < NM; j++) {
        var v = m[mo + j];
        if (v === 0) continue;
        camp[co + j] += v;
        campDay[cdo + j] += v;
        if (s >= 0) adset[so + j] += v;
        if (a >= 0) ad[ao + j] += v;
      }
    }
    var res = { from: from, to: to, d0: d0, nDays: nDays, days: nDays ? U.dateRange(from, to) : [],
      camp: camp, adset: adset, ad: ad, campDay: campDay, rows: rowsIn };
    if (ds.memo.size >= RANGE_MEMO_MAX) ds.memo.delete(ds.memo.keys().next().value);
    ds.memo.set(key, res);
    return res;
  };

  /** Metric object for entity `idx` of a typed array (or zeros when arr is null). */
  D.obj = function (arr, idx) {
    var o = {}, b = idx * NM;
    for (var j = 0; j < NM; j++) o[D.METRICS[j]] = arr ? arr[b + j] : 0;
    return o;
  };
  D.zero = function () { return D.obj(null, 0); };
  D.addInto = function (t, o) {
    if (!o) return t;
    for (var j = 0; j < NM; j++) { var k = D.METRICS[j]; t[k] += o[k] || 0; }
    return t;
  };
  D.sumObjs = function (list) {
    var t = D.zero();
    for (var i = 0; i < list.length; i++) D.addInto(t, list[i]);
    return t;
  };
  /** Daily values of one metric summed over campaign indexes: array of length agg.nDays. */
  D.series = function (agg, campIdx, metric) {
    var j = MI[metric], out = new Array(agg.nDays);
    for (var d = 0; d < agg.nDays; d++) out[d] = 0;
    for (var i = 0; i < campIdx.length; i++) {
      var base = campIdx[i] * agg.nDays;
      for (var d2 = 0; d2 < agg.nDays; d2++) out[d2] += agg.campDay[(base + d2) * NM + j];
    }
    return out;
  };
  /** Daily metric objects summed over campaign indexes. */
  D.seriesObj = function (agg, campIdx) {
    var out = [];
    for (var d = 0; d < agg.nDays; d++) out.push(D.zero());
    for (var i = 0; i < campIdx.length; i++) {
      var base = campIdx[i] * agg.nDays;
      for (var d2 = 0; d2 < agg.nDays; d2++) {
        var o = out[d2], off = (base + d2) * NM;
        for (var j = 0; j < NM; j++) { var v = agg.campDay[off + j]; if (v) o[D.METRICS[j]] += v; }
      }
    }
    return out;
  };

  /**
   * Daily metric objects for each ad set in `adsetIdx` over [from, to]: one pass over the fact rows.
   * Returns an array parallel to adsetIdx, each an array of nDays metric objects (zeros on days
   * without rows). Memoized on the dataset per range + ad set list (the dataset is rebuilt when new
   * rows load, so the memo never goes stale).
   */
  D.adsetDays = function (ds, from, to, adsetIdx) {
    var key = from + '|' + to + '|' + adsetIdx.join(',');
    var memo = ds.memoAS || (ds.memoAS = new Map());
    var hit = memo.get(key);
    if (hit) return hit;
    var d0 = U.dayNum(from), d1 = U.dayNum(to), nDays = Math.max(0, d1 - d0 + 1);
    var slot = new Int32Array(ds.adsets.length);
    for (var z = 0; z < slot.length; z++) slot[z] = -1;
    adsetIdx.forEach(function (s, k) { if (s >= 0 && s < slot.length && slot[s] < 0) slot[s] = k; });
    var cube = new Float64Array(Math.max(1, adsetIdx.length * nDays * NM));
    var dayArr = ds.day, sArr = ds.adset, m = ds.m;
    for (var r = 0; r < ds.n; r++) {
      var s = sArr[r];
      if (s < 0) continue;
      var k = slot[s];
      if (k < 0) continue;
      var d = dayArr[r];
      if (d < d0 || d > d1) continue;
      var off = (k * nDays + (d - d0)) * NM, mo = r * NM;
      for (var j = 0; j < NM; j++) cube[off + j] += m[mo + j];
    }
    var out = adsetIdx.map(function (s, k2) {
      var list = [];
      for (var d2 = 0; d2 < nDays; d2++) list.push(D.obj(cube, k2 * nDays + d2));
      return list;
    });
    if (memo.size >= 32) memo.delete(memo.keys().next().value);
    memo.set(key, out);
    return out;
  };

  /* =========================================================================================
   * 5b. Trend buckets (SPEC §4.7): daily up to 45 days, weekly (Mon–Sun) beyond
   * ======================================================================================= */
  D.TREND_DAILY_MAX = 45;
  /** 0 = Monday … 6 = Sunday (day numbers count UTC days from 1970-01-01, a Thursday). */
  D.weekdayMon = function (iso) { var n = U.dayNum(iso); return ((n + 3) % 7 + 7) % 7; };
  /** 'daily' | 'weekly': an explicit Daily / Weekly choice wins; otherwise daily up to 45 days. */
  D.trendGran = function (nDays, override) {
    if (override === 'daily' || override === 'weekly') return override;
    return nDays > D.TREND_DAILY_MAX ? 'weekly' : 'daily';
  };
  /**
   * Buckets over a period's consecutive day list. Daily: one bucket per day. Weekly: Mon–Sun
   * calendar weeks; the first and last are clipped to the period and flagged `partial` when they
   * hold fewer than 7 days.
   * Each bucket: { i0, i1 (inclusive indexes into days), from, to, days, partial, weekFrom, weekTo }
   */
  D.buckets = function (days, gran) {
    var out = [];
    if (!days || !days.length) return out;
    if (gran !== 'weekly') {
      days.forEach(function (d, i) { out.push({ i0: i, i1: i, from: d, to: d, days: 1, partial: false, weekFrom: null, weekTo: null }); });
      return out;
    }
    var i = 0;
    while (i < days.length) {
      var weekFrom = U.addDays(days[i], -D.weekdayMon(days[i])), weekTo = U.addDays(weekFrom, 6);
      var j = i;
      while (j + 1 < days.length && days[j + 1] <= weekTo) j++;
      var n = j - i + 1;
      out.push({ i0: i, i1: j, from: days[i], to: days[j], days: n, partial: n < 7, weekFrom: weekFrom, weekTo: weekTo });
      i = j + 1;
    }
    return out;
  };
  /**
   * Sum day metric objects over each bucket's index range (numerators and denominators summed, so
   * a ratio is computed once per bucket from the sums). Indexes past the end of `dayObjs` are
   * skipped (a shorter comparison period); a bucket with no day inside is null.
   * Returns [{ o (summed metrics), days (days summed) } | null]
   */
  D.bucketSums = function (dayObjs, buckets) {
    return buckets.map(function (b) {
      var o = null, n = 0;
      for (var i = b.i0; i <= b.i1 && i < dayObjs.length; i++) {
        if (!o) o = D.zero();
        D.addInto(o, dayObjs[i]);
        n++;
      }
      return o ? { o: o, days: n } : null;
    });
  };

  /* =========================================================================================
   * 6. Monthly (campaign × month, /api/monthly)
   * ======================================================================================= */
  /**
   * Returns { months: ['2026-04', …], rows: [{ month, camp: {key,name,rawObjective,channel,platform,
   *   accountName, clientSlug}, m: {spend…roas_value, days} }] }. Reach is absent by contract.
   */
  D.indexMonthly = function (payload, regIdx) {
    payload = payload || {};
    regIdx = regIdx || D.indexRegistry(null);
    var cols = Array.isArray(payload.cols) ? payload.cols : [];
    var ci = {};
    cols.forEach(function (c, i) { ci[c] = i; });
    var accounts = (payload.accounts || []).map(function (a) {
      var platform = a.platform || String(a.key || '').split(':')[0];
      var id = String(a.id === undefined || a.id === null ? '' : a.id);
      var cIdx = regIdx.byAccountKey.get(D.acctKey(platform, id));
      return { platform: platform, id: id, name: a.name || id,
        clientSlug: cIdx === undefined ? D.unmappedSlug(platform, id) : regIdx.clients[cIdx].slug };
    });
    var camps = (payload.campaigns || []).map(function (c) {
      var acc = accounts[c.account] || { platform: String(c.key || '').split(':')[0], name: '', clientSlug: null };
      return { key: c.key, name: c.name || '(unnamed campaign)', rawObjective: c.objective || null, channel: c.channel || null,
        platform: acc.platform, accountName: acc.name, clientSlug: acc.clientSlug };
    });
    var keys = D.METRICS.concat(['days']);
    var rows = [];
    (payload.rows || []).forEach(function (r) {
      var month = r[ci.month === undefined ? 0 : ci.month];
      var camp = camps[r[ci.campaign === undefined ? 1 : ci.campaign]];
      if (!camp || typeof month !== 'string') return;
      var m = {};
      keys.forEach(function (k) { var i = ci[k]; var v = i === undefined ? 0 : +r[i]; m[k] = U.isNum(v) ? v : 0; });
      rows.push({ month: month, camp: camp, m: m });
    });
    var months = Array.isArray(payload.months) && payload.months.length ? payload.months.slice() :
      U.uniq(rows.map(function (r) { return r.month; })).sort();
    return { months: months, rows: rows };
  };

  /* =========================================================================================
   * 7. Breakdowns: optional Meta placement (Sheet 4) and audience (Sheet 5) splits, ad set × day ×
   *    segment (DATA_CONTRACT §2.5). The frontend joins `adsets[].key` to the rows payload's ad set
   *    keys; results are never summed across objectives (the views pick one result type).
   * ======================================================================================= */
  D.BD_METRICS = ['spend', 'impressions', 'clicks', 'link_clicks', 'video_views', 'messages', 'leads'];
  var NB = D.NB = D.BD_METRICS.length;
  D.BD_KINDS = ['placement', 'audience'];
  /** Fixed age order (DATA_CONTRACT §2.5) and gender columns. */
  D.AGE_ORDER = ['13-17', '18-24', '25-34', '35-44', '45-54', '55-64', '65+', 'Unknown'];
  D.GENDER_ORDER = ['female', 'male', 'unknown'];
  D.GENDER_LABEL = { female: 'Female', male: 'Male', unknown: 'Unknown' };
  var BD_COLS = ['date', 'adset', 'segment'].concat(D.BD_METRICS);
  var PLAT_LABEL = { facebook: 'Facebook', instagram: 'Instagram', messenger: 'Messenger', audience_network: 'Audience Network', threads: 'Threads' };
  function titleCase(s) {
    return String(s || '').replace(/[_\s]+/g, ' ').trim().replace(/(^|\s)(\S)/g, function (m, a, c) { return a + c.toUpperCase(); });
  }
  /** Readable placement name when the payload has no label (the contract's fallback: title case). */
  D.placementLabel = function (platform, position) {
    var p = String(platform || '').toLowerCase(), pos = String(position || '').toLowerCase();
    if (p === 'audience_network') return 'Audience Network';
    var pl = PLAT_LABEL[p] || titleCase(p);
    if (!pos) return pl || 'Unknown placement';
    var rest = pos.indexOf(p + '_') === 0 ? pos.slice(p.length + 1) : pos;
    return ((pl ? pl + ' ' : '') + titleCase(rest)).trim();
  };
  D.normAge = function (a) {
    var s = String(a === null || a === undefined ? '' : a).trim();
    return !s || /^unknown$/i.test(s) ? 'Unknown' : s;
  };
  D.normGender = function (g) {
    var s = String(g === null || g === undefined ? '' : g).trim().toLowerCase();
    return s === 'female' || s === 'male' ? s : 'unknown';
  };
  /** The windows a breakdown block needs: the current period and the comparison (with a baseline). */
  D.bdRanges = function (P) {
    var out = [];
    if (P && P.cur) out.push({ from: P.cur.from, to: P.cur.to });
    if (P && P.cur && P.cmp && !P.noBaseline) out.push({ from: P.cmp.from, to: P.cmp.to });
    return D.normRanges(out);
  };

  /**
   * Merge several /api/breakdowns payloads into one: ad sets, placements and audiences merge by
   * key; rows are re-indexed and de-duplicated on date + ad set + segment (a later payload wins);
   * availability is true when any payload says so.
   */
  D.mergeBreakdowns = function (payloads) {
    var out = { schema: 1, mode: null, range: null, available: { placement: false, audience: false }, adsets: [], placements: [], audiences: [],
      cols: BD_COLS.slice(), placement_rows: [], audience_rows: [], coverage: {}, not_deployed: true };
    var idx = { adsets: new Map(), placements: new Map(), audiences: new Map() };
    var upsert = function (kind, ent) {
      var k = ent.key, i = idx[kind].get(k);
      if (i === undefined) { i = out[kind].length; out[kind].push(ent); idx[kind].set(k, i); }
      else out[kind][i] = ent;
      return i;
    };
    var rowMaps = { placement: new Map(), audience: new Map() };
    (payloads || []).forEach(function (p) {
      if (!p) return;
      out.mode = p.mode || out.mode;
      if (!p.not_deployed) out.not_deployed = false;
      if (p.range && U.isIso(p.range.from) && U.isIso(p.range.to)) {
        out.range = out.range ? { from: U.minIso(out.range.from, p.range.from), to: U.maxIso(out.range.to, p.range.to) } : { from: p.range.from, to: p.range.to };
      }
      var av = p.available || {};
      var ci = {};
      (Array.isArray(p.cols) ? p.cols : BD_COLS).forEach(function (c, i) { ci[c] = i; });
      var iD = ci.date === undefined ? 0 : ci.date, iA = ci.adset === undefined ? 1 : ci.adset, iS = ci.segment === undefined ? 2 : ci.segment;
      var aMap = (p.adsets || []).map(function (a) { return upsert('adsets', normBdAdset(a)); });
      var segMaps = {
        placement: (p.placements || []).map(function (x) { return upsert('placements', normPlacement(x)); }),
        audience: (p.audiences || []).map(function (x) { return upsert('audiences', normAudience(x)); })
      };
      D.BD_KINDS.forEach(function (kind) {
        var rows = p[kind + '_rows'];
        if (av[kind] === true || (av[kind] === undefined && Array.isArray(rows) && rows.length)) out.available[kind] = true;
        var segMap = segMaps[kind];
        (Array.isArray(rows) ? rows : []).forEach(function (r) {
          if (!r) return;
          var a = aMap[r[iA]], s = segMap[r[iS]], d = r[iD];
          if (a === undefined || s === undefined || !U.isIso(d)) return;
          var row = [d, a, s];
          D.BD_METRICS.forEach(function (m) { row.push(ci[m] === undefined ? 0 : r[ci[m]]); });
          rowMaps[kind].set(d + '|' + a + '|' + s, row);
        });
        var cv = p.coverage && p.coverage[kind];
        if (cv) {
          var o = out.coverage[kind] || (out.coverage[kind] = { first_date: null, last_date: null });
          if (U.isIso(cv.first_date)) o.first_date = U.minIso(o.first_date, cv.first_date);
          if (U.isIso(cv.last_date)) o.last_date = U.maxIso(o.last_date, cv.last_date);
        }
      });
    });
    out.placement_rows = Array.from(rowMaps.placement.values());
    out.audience_rows = Array.from(rowMaps.audience.values());
    return out;
  };
  function normBdAdset(a) {
    a = a || {};
    var id = a.id === undefined || a.id === null ? String(a.key || '').split(':').slice(1).join(':') : String(a.id);
    var acc = a.account_id === undefined || a.account_id === null || a.account_id === '' ? null : String(a.account_id).replace(/^act_/i, '');
    return { key: a.key ? String(a.key) : 'meta:' + id, id: id, account_id: acc };
  }
  function normPlacement(x) {
    x = x || {};
    var platform = x.platform ? String(x.platform) : null, position = x.position ? String(x.position) : null;
    return { key: x.key ? String(x.key) : (platform || '') + '|' + (position || ''), platform: platform, position: position,
      label: x.label ? String(x.label) : D.placementLabel(platform, position) };
  }
  function normAudience(x) {
    x = x || {};
    var age = D.normAge(x.age), gender = D.normGender(x.gender);
    return { key: x.key ? String(x.key) : age + '|' + gender, age: age, gender: gender };
  }

  var bdVersion = 0;
  /**
   * Index one breakdown payload (or merged payloads). Never throws: a missing payload (no Sheets,
   * sample without breakdowns) indexes as "not available".
   * Returns { version, present, available {placement, audience}, notDeployed, range, coverage,
   *   adsets [{i, key, id, account_id}], byKey Map(key -> i), placements [{i, key, platform, position,
   *   label}], audiences [{i, key, age, gender}], placement / audience: columnar rows
   *   { n, day, as, seg, m (n × NB), minDate, maxDate }, memo }
   * Blank / null metrics count as 0 (DATA_CONTRACT §1: "not reported" sums as 0).
   */
  D.indexBreakdowns = function (payload) {
    var p = payload && typeof payload === 'object' ? payload : {};
    var ci = {};
    (Array.isArray(p.cols) ? p.cols : BD_COLS).forEach(function (c, i) { ci[c] = i; });
    var srcIdx = D.BD_METRICS.map(function (k) { return ci[k] === undefined ? -1 : ci[k]; });
    var iD = ci.date === undefined ? 0 : ci.date, iA = ci.adset === undefined ? 1 : ci.adset, iS = ci.segment === undefined ? 2 : ci.segment;
    var adsets = (p.adsets || []).map(function (a, i) { var x = normBdAdset(a); x.i = i; return x; });
    var byKey = new Map();
    adsets.forEach(function (a) { if (!byKey.has(a.key)) byKey.set(a.key, a.i); });
    var placements = (p.placements || []).map(function (x, i) { var o = normPlacement(x); o.i = i; return o; });
    var audiences = (p.audiences || []).map(function (x, i) { var o = normAudience(x); o.i = i; return o; });
    function columns(rows, nSeg) {
      rows = Array.isArray(rows) ? rows : [];
      var n = rows.length, day = new Int32Array(n), as = new Int32Array(n), seg = new Int32Array(n), m = new Float64Array(Math.max(1, n * NB));
      var k = 0, minD = Infinity, maxD = -Infinity, cache = Object.create(null);
      for (var r = 0; r < n; r++) {
        var row = rows[r];
        if (!row) continue;
        var a = row[iA], s = row[iS], d = row[iD];
        if (!(a >= 0 && a < adsets.length) || !(s >= 0 && s < nSeg) || !U.isIso(d)) continue;
        var dn = cache[d];
        if (dn === undefined) dn = cache[d] = U.dayNum(d);
        day[k] = dn; as[k] = a; seg[k] = s;
        for (var j = 0; j < NB; j++) {
          var si = srcIdx[j], raw = si < 0 ? null : row[si];
          var v = raw === null || raw === undefined || raw === '' ? 0 : +raw;
          m[k * NB + j] = U.isNum(v) ? v : 0;
        }
        if (dn < minD) minD = dn;
        if (dn > maxD) maxD = dn;
        k++;
      }
      return { n: k, day: day, as: as, seg: seg, m: m, minDate: k ? U.isoDay(minD) : null, maxDate: k ? U.isoDay(maxD) : null };
    }
    var pl = columns(p.placement_rows, placements.length), au = columns(p.audience_rows, audiences.length);
    var av = p.available || {};
    return {
      version: ++bdVersion, present: !!payload, mode: p.mode || null, range: p.range || null, notDeployed: !!p.not_deployed,
      available: { placement: av.placement === undefined ? pl.n > 0 : !!av.placement, audience: av.audience === undefined ? au.n > 0 : !!av.audience },
      coverage: p.coverage || null, adsets: adsets, byKey: byKey, placements: placements, audiences: audiences,
      placement: pl, audience: au, memo: new Map()
    };
  };

  /**
   * Per ad set totals of one kind over [from, to]: { kind, from, to, nSeg, byAdset: Map(bd ad set
   * index -> Float64Array(nSeg × NB)) }. One pass over that kind's rows, memoized per range.
   */
  D.bdAgg = function (bd, kind, from, to) {
    var key = kind + '|' + from + '|' + to, hit = bd.memo.get(key);
    if (hit) return hit;
    var t = bd[kind], nSeg = kind === 'placement' ? bd.placements.length : bd.audiences.length;
    var d0 = U.dayNum(from), d1 = U.dayNum(to), by = new Map();
    for (var r = 0; r < t.n; r++) {
      var d = t.day[r];
      if (d < d0 || d > d1) continue;
      var a = t.as[r], arr = by.get(a);
      if (!arr) { arr = new Float64Array(Math.max(1, nSeg) * NB); by.set(a, arr); }
      var off = t.seg[r] * NB, mo = r * NB;
      for (var j = 0; j < NB; j++) arr[off + j] += t.m[mo + j];
    }
    var res = { kind: kind, from: from, to: to, nSeg: nSeg, byAdset: by };
    if (bd.memo.size >= 24) bd.memo.delete(bd.memo.keys().next().value);
    bd.memo.set(key, res);
    return res;
  };
  /**
   * Segment totals summed over the ad sets with these keys (rows-payload ad set keys).
   * Returns { seg: Float64Array(nSeg × NB), nSeg, withRows (ad sets that had rows) }.
   */
  D.bdSum = function (bd, kind, from, to, keys) {
    var agg = D.bdAgg(bd, kind, from, to), out = new Float64Array(Math.max(1, agg.nSeg) * NB), withRows = 0;
    (keys || []).forEach(function (k) {
      var i = bd.byKey.get(k);
      if (i === undefined) return;
      var arr = agg.byAdset.get(i);
      if (!arr) return;
      withRows++;
      for (var j = 0; j < arr.length; j++) out[j] += arr[j];
    });
    return { seg: out, nSeg: agg.nSeg, withRows: withRows };
  };
  /** Metric object for segment `s` of a bdSum / bdAgg array. */
  D.bdObj = function (arr, s) {
    var o = {};
    for (var j = 0; j < NB; j++) o[D.BD_METRICS[j]] = arr ? arr[s * NB + j] : 0;
    return o;
  };
  /**
   * Accounts with any breakdown row of this kind in [from, to], as normalised account keys
   * ('meta:<id>', see acctKey). Used to tell "this account is not reachable" apart from "this ad
   * set had no rows". Memoized per range.
   */
  D.bdAccounts = function (bd, kind, from, to) {
    var key = 'acc|' + kind + '|' + from + '|' + to, hit = bd.memo.get(key);
    if (hit) return hit;
    var set = new Set();
    D.bdAgg(bd, kind, from, to).byAdset.forEach(function (arr, i) {
      var a = bd.adsets[i];
      if (a && a.account_id) set.add(D.acctKey('meta', a.account_id));
    });
    bd.memo.set(key, set);
    return set;
  };
})(typeof window !== 'undefined' ? window : this);
