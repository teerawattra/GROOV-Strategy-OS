/* GROOV Ads Command Center · engine.js
 * ------------------------------------------------------------------------------------------
 * Role: the pure decision engine (SPEC §5, §5b). Plain objects in, plain objects out. No DOM, no
 * dataset access, no state: every function can be unit-tested on hand-made numbers.
 *
 * Inputs are "aggregates": { spend, impressions, reach, clicks, link_clicks, video_views, messages,
 * leads, conversions, conv_value, roas_value } summed over any set of fact rows (see data.js).
 *
 * Public API (window.GROOV.engine):
 *   classify(platform, rawObjective, campaignName, agg)   the ONE objective classifier (SPEC §5)
 *   kpis(agg)                       display KPIs; ratios are null when the denominator is missing
 *   primary(objective, platform, k) primary result + cost for an objective (SPEC §5 table)
 *   resultType(objective, platform) key that says which results may be added together
 *   decisionMetrics(platform, agg, objective) campaign decision inputs: the KPIs shown on screen
 *   decideCampaign(cur, prev, rules)         campaign decision from equal-period aggregates
 *   decideEntity(objective, platform, cur, prev, status, rules, rawStatus)
 *                                   ad set / ad decision: Hermes single-account, status-aware variant
 *   mostSevere(labels), SEV, DECISIONS, SHORT, CLS, DEFAULT_RULES, RULE_DEFS, rulesFrom(obj)
 *   checkPredicates(when, ctx)      playbook `when` evaluator (every predicate must hold)
 *   matchBenchmarks(list, q), benchPosition(value, b), BENCH_METRICS
 *   fatigue(curK, prevK, objective, platform)   2-of-3 rule (SPEC §4.4)
 *   cprBridge(objective, cur, prev)  log-share decomposition of a cost-per-result change (§5b.2)
 *   deliverySignals(o)              stopped / dropped / spike (§5b.3)
 *   pacing(o)                       month-end projection and traffic light (§5b.5)
 *   creativePipeline(list, periodEnd, historyFrom)   (§5b.7)
 *   lowN(nCur, nPrev), confidence(n), isNew(firstDate, periodEnd, historyFrom), liveDays(...)
 *   bdResult(objective)             the result metric by placement / audience for an objective (§4.8.5)
 *   bdTag(spendShare, resShare, results, total)   Works / Weak / Spending, no results / Directional (§4.8)
 *
 * Two decision variants exist on purpose (both are Hermes's own logic):
 *   - decideCampaign = build_command_center.py `decide` (campaign level, rolls up to clients/accounts).
 *     Its inputs (decisionMetrics) are the KPIs on screen (SPEC §5 "Decisions judge exactly the KPIs on
 *     screen"): Engagement on cost per 3-second view (response = views ÷ impressions), Traffic on link
 *     CPC (response = link CTR). Hermes judged Engagement on CPC and Traffic on all-click CTR; on the
 *     Sep sample this deliberate change moves 3 accounts (listed in the parity test).
 *   - decideEntity  = single-client build_meta.py `decisionFor` (ad sets and ads), status-aware.
 * A Meta campaign classified "Conversions" has no conversion COUNT in the Sheet, so both variants judge
 * it on platform-reported purchase ROAS, as Hermes's single-account view does ("metaConv"). It is never
 * reported as "zero conversions". Unreported Meta link clicks are never judged as "zero link clicks".
 */
(function (root) {
  'use strict';
  var G = root.GROOV = root.GROOV || {};
  var U = G.util;
  var E = G.engine = {};

  /* ---------- constants ---------- */
  E.DECISIONS = ['Immediate Action', 'Watch Out', 'Ready to Scale', 'No Touching'];
  E.SHORT = { 'Immediate Action': 'Immediate', 'Watch Out': 'Watch', 'Ready to Scale': 'Scale', 'No Touching': 'Hold' };
  E.CLS = { 'Immediate Action': 'imm', 'Watch Out': 'watch', 'Ready to Scale': 'scale', 'No Touching': 'hold' };
  E.SEV = { 'Immediate Action': 4, 'Watch Out': 3, 'Ready to Scale': 2, 'No Touching': 1 };
  E.OBJECTIVES = ['Messages', 'Lead generation', 'Awareness', 'Traffic', 'Engagement', 'Conversions'];
  E.DEFAULT_RULES = { zeroSpend: 100, scaleMin: 3, scaleCost: 10, scaleDrop: 10, watchCost: 30, watchRes: 30, watchRate: 25, freqCap: 3.5 };
  E.RULE_DEFS = [
    { key: 'zeroSpend', label: 'Immediate Action: spend with zero results ≥', unit: '฿', min: 0, step: 10 },
    { key: 'scaleMin', label: 'Ready to Scale: results ≥', unit: '', min: 0, step: 1 },
    { key: 'scaleCost', label: 'Ready to Scale: cost per result improves ≥', unit: '%', min: 0, step: 1 },
    { key: 'scaleDrop', label: 'Ready to Scale: results drop at most', unit: '%', min: 0, step: 1 },
    { key: 'watchCost', label: 'Watch Out: cost per result worsens ≥', unit: '%', min: 0, step: 1 },
    { key: 'watchRes', label: 'Watch Out: results fall ≥, on spend ≥ 80% of prior', unit: '%', min: 0, step: 1 },
    { key: 'watchRate', label: 'Watch Out: response rate falls ≥', unit: '%', min: 0, step: 1 },
    { key: 'freqCap', label: 'Awareness frequency cap', unit: '×', min: 0, step: 0.1 }
  ];
  /** Sanitised copy of a rules object (missing / bad values fall back to the Hermes defaults). */
  E.rulesFrom = function (o) {
    var r = {};
    Object.keys(E.DEFAULT_RULES).forEach(function (k) {
      var v = o && o[k] !== undefined && o[k] !== null && o[k] !== '' ? +o[k] : NaN;
      r[k] = U.isNum(v) && v >= 0 ? v : E.DEFAULT_RULES[k];
    });
    return r;
  };
  E.rulesModified = function (r) {
    return Object.keys(E.DEFAULT_RULES).some(function (k) { return r && +r[k] !== E.DEFAULT_RULES[k]; });
  };
  E.mostSevere = function (labels) {
    var best = null;
    for (var i = 0; i < labels.length; i++) {
      var l = labels[i];
      if (l && (!best || E.SEV[l] > E.SEV[best])) best = l;
    }
    return best;
  };

  function n(v) { return U.isNum(v) ? v : 0; }
  /** Hermes change(): null when the prior value is 0 (no baseline). */
  function chg(c, p) { return p ? (c / p - 1) * 100 : null; }
  E.change = chg;
  var EPS = 1e-9;

  /* =========================================================================================
   * Objective classifier (SPEC §5): one classifier, used everywhere
   * ======================================================================================= */
  E.leadName = function (name) {
    var t = String(name || '').toUpperCase().replace(/[^A-Z0-9]+/g, '_');
    return t.indexOf('LEADGEN') >= 0 || t.indexOf('LEAD_GEN') >= 0 || t.indexOf('LEAD_GENERATION') >= 0;
  };
  E.msgName = function (name) {
    return /(^|[^A-Z])(MSG|MESSAGE|MESSAGES|INBOX|MESSENGER)([^A-Z]|$)/.test(String(name || '').toUpperCase());
  };
  /**
   * agg: the campaign's aggregate in the window being judged (messages > 0 / ROAS present are data
   * signals, as in Hermes). Meta order (SPEC §5): leads → sales objectives → awareness → messages →
   * traffic → purchase ROAS present → engagement. Message campaigns that pick up an attributed
   * purchase stay Messages.
   */
  var META_SALES = ['OUTCOME_SALES', 'CONVERSIONS', 'PRODUCT_CATALOG_SALES'];
  var META_AWARENESS = ['OUTCOME_AWARENESS', 'REACH', 'BRAND_AWARENESS'];
  E.classify = function (platform, rawObjective, name, agg) {
    var raw = String(rawObjective || '').toUpperCase();
    var messages = agg ? n(agg.messages) : 0, roas = agg ? n(agg.roas_value) : 0;
    if (platform === 'meta') {
      if (raw === 'OUTCOME_LEADS' || E.leadName(name)) return 'Lead generation';
      if (META_SALES.indexOf(raw) >= 0) return 'Conversions';
      if (META_AWARENESS.indexOf(raw) >= 0) return 'Awareness';
      if (messages > 0 || E.msgName(name)) return 'Messages';
      if (raw === 'LINK_CLICKS' || raw.indexOf('TRAFFIC') >= 0) return 'Traffic';
      if (roas > 0) return 'Conversions';
      return 'Engagement';
    }
    if (platform === 'tiktok') {
      if (raw === 'REACH') return 'Awareness';
      if (raw === 'VIDEO_VIEWS' || raw === 'ENGAGEMENT') return 'Engagement';
      if (raw === 'TRAFFIC') return 'Traffic';
      if (raw === 'LEAD_GENERATION') return 'Lead generation';
      if (messages > 0 || E.msgName(name)) return 'Messages';
      return 'Conversions';
    }
    return 'Conversions';
  };

  /* =========================================================================================
   * Display KPIs (null = missing denominator → "—")
   * ======================================================================================= */
  E.kpis = function (a) {
    a = a || {};
    var spend = n(a.spend), imp = n(a.impressions), reach = n(a.reach), clicks = n(a.clicks), lc = n(a.link_clicks);
    var vv = n(a.video_views), msg = n(a.messages), leads = n(a.leads), conv = n(a.conversions);
    var value = n(a.conv_value) + n(a.roas_value);
    // Meta leaves link_clicks blank on some rows (stored as 0). Clicks without any link clicks means
    // "not reported", not 0%: link-based ratios become null instead of a misleading 0.
    var linkKnown = !(clicks > 0 && lc === 0);
    var pctOf = function (x, y) { var r = U.ratio(x, y); return r === null ? null : r * 100; };
    return {
      spend: spend, impressions: imp, reach: reach, clicks: clicks, link_clicks: lc, linkKnown: linkKnown,
      ctr: pctOf(clicks, imp),
      link_ctr: linkKnown ? pctOf(lc, imp) : null,
      cpc: U.ratio(spend, clicks),
      cpc_link: linkKnown ? U.ratio(spend, lc) : null,
      cpm: imp ? spend / imp * 1000 : null,
      freq: U.ratio(imp, reach),               // impressions ÷ Σ daily reach = average DAILY frequency
      video_views: vv, cpv: U.ratio(spend, vv), view_rate: pctOf(vv, imp),
      messages: msg, cpmsg: U.ratio(spend, msg), chat_rate: linkKnown ? pctOf(msg, lc) : null, msg_rate: pctOf(msg, imp),
      leads: leads, cpl: U.ratio(spend, leads), lead_rate: linkKnown ? pctOf(leads, lc) : null,
      conversions: conv, cpa: U.ratio(spend, conv), conv_rate: pctOf(conv, clicks),
      value: value, roas: value > 0 ? U.ratio(value, spend) : null
    };
  };

  /** Results of different types are never added together. Meta "Conversions" is value-based (ROAS). */
  E.resultType = function (objective, platform) {
    return objective === 'Conversions' && platform === 'meta' ? 'Conversions·value' : objective;
  };
  E.RESULT_TYPES = ['Messages', 'Lead generation', 'Awareness', 'Traffic', 'Engagement', 'Conversions', 'Conversions·value'];
  E.TYPE_LABEL = { 'Conversions·value': 'Conversions (Meta ROAS)' };

  /**
   * Primary result and cost (SPEC §5 table). k = kpis(agg).
   * { type, result, resultLabel, n (count for sample-size honesty, null when not a count),
   *   cost, costLabel, costFmt ('money'|'ratio'), lowerBetter, rate, rateLabel }
   */
  E.primary = function (objective, platform, k) {
    var o = { type: E.resultType(objective, platform), lowerBetter: true, costFmt: 'money' };
    switch (objective) {
      case 'Messages':
        o.result = k.messages; o.resultLabel = 'Messages'; o.n = k.messages;
        o.cost = k.cpmsg; o.costLabel = 'Cost per message'; o.rate = k.msg_rate; o.rateLabel = 'Message rate';
        break;
      case 'Lead generation':
        o.result = k.leads; o.resultLabel = 'Leads'; o.n = k.leads;
        o.cost = k.cpl; o.costLabel = 'CPL'; o.rate = U.ratio(k.leads, k.impressions) === null ? null : k.leads / k.impressions * 100; o.rateLabel = 'Lead rate';
        break;
      case 'Awareness':
        o.result = k.impressions; o.resultLabel = 'Impressions'; o.n = null;
        o.cost = k.cpm; o.costLabel = 'CPM'; o.rate = null; o.rateLabel = null;
        break;
      case 'Traffic':
        o.result = k.linkKnown ? k.link_clicks : null; o.resultLabel = platform === 'meta' ? 'Link clicks' : 'Clicks'; o.n = o.result;
        o.cost = k.cpc_link; o.costLabel = 'CPC'; o.rate = k.link_ctr; o.rateLabel = 'Link CTR';
        break;
      case 'Engagement':
        o.result = k.video_views; o.resultLabel = 'Video views'; o.n = k.video_views;
        o.cost = k.cpv; o.costLabel = 'Cost per view'; o.rate = k.view_rate; o.rateLabel = 'View rate';
        break;
      default: // Conversions
        if (platform === 'meta') {
          o.result = k.value; o.resultLabel = 'Purchase value'; o.n = null;
          o.cost = k.roas; o.costLabel = 'ROAS'; o.costFmt = 'ratio'; o.lowerBetter = false; o.rate = k.ctr; o.rateLabel = 'CTR';
        } else {
          o.result = k.conversions; o.resultLabel = 'Conversions'; o.n = k.conversions;
          o.cost = k.cpa; o.costLabel = 'CPA'; o.rate = k.conv_rate; o.rateLabel = 'Conversion rate';
        }
    }
    return o;
  };

  /** Low sample: either period under 10 results (only for count-based results). */
  E.lowN = function (nCur, nPrev) {
    if (nCur === null || nCur === undefined) return false;
    return n(nCur) < 10 || n(nPrev) < 10;
  };
  E.confidence = function (count) {
    if (!U.isNum(count) || count < 5) return null;
    return count >= 25 ? 'confident' : 'directional';
  };

  /* =========================================================================================
   * Campaign decisions (Hermes command center, build_command_center.py) — parity variant
   * ======================================================================================= */
  /**
   * Campaign decision inputs: Hermes's metrics() structure (missing denominators are 0 here, Hermes
   * semantics, so a change from 0 reads as "no baseline"), with the KPIs the tables show:
   * Traffic = link clicks / link CPC / link CTR, Engagement = 3-second views / cost per view / view rate.
   */
  E.decisionMetrics = function (platform, a, objective) {
    a = a || {};
    var rt = function (x, y) { return y ? x / y : 0; };
    var spend = n(a.spend), imp = n(a.impressions), clicks = n(a.clicks);
    var ctr = rt(clicks, imp), cpc = rt(spend, clicks), cpm = rt(spend * 1000, imp);
    var lc = platform === 'meta' ? n(a.link_clicks) : clicks;
    var vv = n(a.video_views), msg = n(a.messages), leads = n(a.leads), conv = n(a.conversions);
    var value = n(a.conv_value) + n(a.roas_value), roas = rt(value, spend);
    var metaConv = objective === 'Conversions' && platform === 'meta';
    // Meta leaves link_clicks blank on some rows: clicks without link clicks = "not reported", not zero.
    var unreported = objective === 'Traffic' && clicks > 0 && lc === 0;
    var r;
    if (objective === 'Awareness') r = [imp, 'Impressions', cpm, 'CPM', rt(imp, spend), 'Impressions per ฿', 'count'];
    else if (objective === 'Traffic') r = [lc, platform === 'meta' ? 'Link clicks' : 'Clicks', rt(spend, lc), 'CPC', rt(lc, imp), platform === 'meta' ? 'Link CTR' : 'CTR', 'count'];
    else if (objective === 'Engagement') r = [vv, 'Video views', rt(spend, vv), 'Cost per view', rt(vv, imp), 'View rate', 'count'];
    else if (objective === 'Messages') r = [msg, 'Messages', rt(spend, msg), 'Cost per message', rt(msg, imp), 'Message rate', 'count'];
    else if (objective === 'Lead generation') r = [leads, 'Leads', rt(spend, leads), 'CPL', rt(leads, imp), 'Lead rate', 'count'];
    else if (metaConv) r = [roas, 'ROAS', roas, 'ROAS', ctr, 'CTR', 'ratio'];
    else r = [conv, 'Conversions', rt(spend, conv), 'CPA', rt(conv, clicks), 'Conversion rate', 'count'];
    return {
      spend: spend, impressions: imp, clicks: clicks, ctr: ctr, cpc: cpc, cpm: cpm,
      results: r[0], result_label: r[1], cost_per_result: r[2], cost_label: r[3],
      response_rate: r[4], response_label: r[5], resultKind: r[6], lowerBetter: !metaConv, metaConv: metaConv,
      value: value, roas: roas, unreported: unreported
    };
  };

  function deltasOf(cur, prev) {
    return { spend: chg(cur.spend, prev.spend), results: chg(cur.results, prev.results),
      cost: chg(cur.cost_per_result, prev.cost_per_result), rate: chg(cur.response_rate, prev.response_rate) };
  }
  function absPct(v) { return U.deltaText(v).replace(/^[+−]/, ''); }
  function res(label, why, action, d) { return { label: label, why: why, action: action, deltas: d }; }
  var ACT = {
    immediate: 'Check tracking and delivery setup; replace or stop the weak setup after confirming data quality.',
    scale: 'Test a controlled +10% budget increase while protecting result quality.',
    watch: 'Hold budget; inspect creative, audience, placement and tracking before scaling.',
    hold: 'Keep stable and continue collecting comparable data.',
    roasTracking: 'Validate purchase-value tracking before judging or changing performance.',
    roasScale: 'Consider a controlled +10% budget test after confirming downstream quality.'
  };

  /** Meta "Conversions": judged on platform-reported purchase ROAS (Hermes single-account `metaConv`). */
  function decideRoas(cur, prev, d, T) {
    if (cur.spend >= T.zeroSpend - EPS && cur.results === 0) {
      return res('Immediate Action', 'No tracked purchase value (ROAS) after ' + U.money(cur.spend) + ' spend.', ACT.roasTracking, d);
    }
    if (cur.results > 0 && d.results !== null && d.results >= T.scaleCost) {
      return res('Ready to Scale', 'Purchase ROAS rose ' + absPct(d.results) + ' (threshold ' + T.scaleCost + '%).', ACT.roasScale, d);
    }
    var why = [];
    if (d.results !== null && d.results <= -T.watchCost) why.push('Purchase ROAS fell ' + absPct(d.results) + ' (threshold ' + T.watchCost + '%)');
    else if (d.results !== null && d.results <= -T.watchRes && cur.spend >= prev.spend * 0.8) why.push('Purchase ROAS fell ' + absPct(d.results) + ' on roughly stable spend');
    if (d.rate !== null && d.rate <= -T.watchRate) why.push('CTR fell ' + absPct(d.rate) + ' (threshold ' + T.watchRate + '%)');
    if (why.length) return res('Watch Out', why.join('; ') + '.', ACT.watch, d);
    return res('No Touching', 'No intervention threshold was crossed.', ACT.hold, d);
  }

  /**
   * Campaign decision from equal-period aggregates. cur/prev = decisionMetrics(...).
   * Returns { label, why, action, deltas: {spend, results, cost, rate} }.
   */
  E.decideCampaign = function (cur, prev, rules) {
    var T = rules || E.DEFAULT_RULES;
    var d = deltasOf(cur, prev);
    if (cur.metaConv) return decideRoas(cur, prev, d, T);
    if (cur.unreported) {
      return res('No Touching', 'Meta reported clicks but no link clicks for this campaign, so link CPC and link CTR cannot be judged.',
        'Check the link-click column in the Meta export before judging this traffic campaign.', d);
    }
    var word = cur.result_label.toLowerCase();
    if (cur.spend >= T.zeroSpend - EPS && cur.results === 0) {
      return res('Immediate Action', U.money(cur.spend) + ' spent with zero ' + word + ' in the current period.', ACT.immediate, d);
    }
    if (cur.results >= T.scaleMin && d.cost !== null && d.cost <= -T.scaleCost && (d.results === null || d.results >= -T.scaleDrop)) {
      return res('Ready to Scale', cur.cost_label + ' improved ' + absPct(d.cost) + ' (threshold ' + T.scaleCost + '%) while ' + word +
        ' did not fall more than ' + T.scaleDrop + '%.', ACT.scale, d);
    }
    var stable = prev.spend > 0 && cur.spend >= prev.spend * 0.8, why = [];
    if (d.cost !== null && d.cost >= T.watchCost) why.push(cur.cost_label + ' worsened ' + absPct(d.cost) + ' (threshold ' + T.watchCost + '%)');
    if (d.results !== null && d.results <= -T.watchRes && stable) why.push(cur.result_label + ' fell ' + absPct(d.results) + ' on roughly stable spend');
    if (d.rate !== null && d.rate <= -T.watchRate) why.push(cur.response_label + ' fell ' + absPct(d.rate) + ' (threshold ' + T.watchRate + '%)');
    if (why.length) return res('Watch Out', why.join('; ') + '.', ACT.watch, d);
    return res('No Touching', 'No campaign-level intervention threshold was crossed.', ACT.hold, d);
  };

  /* =========================================================================================
   * Ad set / ad decisions (Hermes single-account `decisionFor`), status-aware
   * ======================================================================================= */
  function entityVals(a) {
    var spend = n(a.spend), imp = n(a.impressions), clicks = n(a.clicks), lc = n(a.link_clicks), reach = n(a.reach);
    var value = n(a.conv_value) + n(a.roas_value);
    return {
      spend: spend, impressions: imp, clicks: clicks, link_clicks: lc, video_views: n(a.video_views), messages: n(a.messages),
      leads: n(a.leads), conversions: n(a.conversions), reach: reach,
      ctr: imp ? clicks / imp * 100 : 0, cpc_link: lc ? spend / lc : 0, cpm: imp ? spend / imp * 1000 : 0,
      frequency: reach ? imp / reach : 0, cpv: n(a.video_views) ? spend / n(a.video_views) : 0,
      cpr: n(a.messages) ? spend / n(a.messages) : 0, cpl: n(a.leads) ? spend / n(a.leads) : 0,
      cpa: n(a.conversions) ? spend / n(a.conversions) : 0, roas: spend ? value / spend : 0
    };
  }
  function entityResult(objective, v, platform) {
    if (objective === 'Awareness') return [v.impressions, v.cpm, 'Impressions', 'CPM', true];
    if (objective === 'Engagement') return [v.video_views, v.cpv, 'Video views', 'Cost per view', true];
    if (objective === 'Traffic') return [v.link_clicks, v.cpc_link, platform === 'meta' ? 'Link clicks' : 'Clicks', 'CPC', true];
    if (objective === 'Messages') return [v.messages, v.cpr, 'Messages', 'Cost per message', true];
    if (objective === 'Lead generation') return [v.leads, v.cpl, 'Leads', 'CPL', true];
    if (platform === 'meta') return [v.roas, v.roas, 'ROAS', 'ROAS', false];
    return [v.conversions, v.cpa, 'Conversions', 'CPA', true];
  }
  /**
   * Status-aware decision for an ad set or ad.
   * Adaptation (documented): status UNKNOWN (no status in the export) counts as active when the
   * entity delivered in the current period, so it is judged on performance instead of silently held.
   */
  E.decideEntity = function (objective, platform, curAgg, prevAgg, status, rules, rawStatus) {
    var T = rules || E.DEFAULT_RULES;
    var cur = entityVals(curAgg || {}), prev = entityVals(prevAgg || {});
    var metaConv = objective === 'Conversions' && platform === 'meta';
    var rc = entityResult(objective, cur, platform), rp = entityResult(objective, prev, platform);
    // Response rate on screen: link CTR for Traffic, view rate for Engagement, all-click CTR otherwise.
    var rateOf = function (v) {
      if (objective === 'Traffic') return v.impressions ? v.link_clicks / v.impressions * 100 : 0;
      if (objective === 'Engagement') return v.impressions ? v.video_views / v.impressions * 100 : 0;
      return v.ctr;
    };
    var rateLabel = objective === 'Traffic' ? (platform === 'meta' ? 'Link CTR' : 'CTR') : objective === 'Engagement' ? 'View rate' : 'CTR';
    var rd = chg(rc[0], rp[0]), cd = chg(rc[1], rp[1]), ctrd = chg(rateOf(cur), rateOf(prev));
    var d = { spend: chg(cur.spend, prev.spend), results: rd, cost: cd, rate: ctrd };
    var delivering = cur.spend > 0 || cur.impressions > 0;
    var st = status || 'UNKNOWN';
    var stText = rawStatus && rawStatus !== st ? st + ' (' + rawStatus + ')' : st;
    var active = st === 'ACTIVE' || (st === 'UNKNOWN' && delivering);
    var inherit = platform === 'tiktok' ? ' TikTok ads inherit the campaign status here, so the ad itself may be paused.' : '';
    if (!active && prev.spend >= T.zeroSpend - EPS && cur.spend === 0) {
      return res('Immediate Action', 'Delivery stopped after ' + U.money(prev.spend) + ' prior spend; status ' + stText + '.',
        'Confirm that the pause or parent-level stop was intended before making any change.', d);
    }
    if (!active) return res('No Touching', stText + (delivering ? '' : '; no delivery in the current period') + '.',
      'Leave unchanged; reactivate only if the plan requires it.', d);
    if (cur.spend === 0 && cur.impressions === 0) {
      return res('Immediate Action', 'Status ' + stText + ' but no delivery in the current period.' + inherit,
        'Check schedule, budget, approval, audience and parent delivery status.', d);
    }
    if (objective === 'Traffic' && platform === 'meta' && cur.clicks > 0 && cur.link_clicks === 0) {
      return res('No Touching', 'Meta reported clicks but no link clicks, so link CPC and link CTR cannot be judged.',
        'Check the link-click column in the Meta export before judging this traffic item.', d);
    }
    var word = rc[2].toLowerCase();
    if (objective !== 'Awareness' && !metaConv && rc[0] === 0 && cur.spend >= T.zeroSpend - EPS) {
      return res('Immediate Action', U.money(cur.spend) + ' spent with zero ' + word + '.',
        'Validate tracking, then inspect the setup and weakest creative before changing delivery.', d);
    }
    if (metaConv && cur.spend >= T.zeroSpend - EPS && rc[0] === 0) {
      return res('Immediate Action', 'No tracked purchase value (ROAS) after ' + U.money(cur.spend) + ' spend.', ACT.roasTracking, d);
    }
    var scale;
    if (metaConv) scale = rc[0] > 0 && rd !== null && rd >= T.scaleCost;
    else if (objective === 'Awareness') scale = cd !== null && cd <= -T.scaleCost && (rd === null || rd >= -T.scaleDrop) && cur.frequency <= T.freqCap;
    else scale = rc[0] >= T.scaleMin && cd !== null && cd <= -T.scaleCost && (rd === null || rd >= -T.scaleDrop);
    if (scale) {
      return res('Ready to Scale', metaConv ? 'Purchase ROAS rose ' + absPct(rd) + '.' :
        rc[3] + ' improved ' + absPct(cd) + ' while ' + word + ' did not fall more than ' + T.scaleDrop + '%.' +
        (objective === 'Awareness' ? ' Frequency ' + U.ratioX(cur.frequency) + ' is within the ' + T.freqCap + '× cap.' : ''),
        'Consider a controlled +10% budget test after confirming downstream quality.', d);
    }
    var why = [];
    var lower = rc[4];
    if (cd !== null && (lower ? cd >= T.watchCost : cd <= -T.watchCost)) why.push(rc[3] + (lower ? ' worsened ' : ' fell ') + absPct(cd));
    if (rd !== null && rd <= -T.watchRes && cur.spend >= prev.spend * 0.8 && !(metaConv && why.length)) why.push(rc[2] + ' fell ' + absPct(rd) + ' on roughly stable spend');
    if (ctrd !== null && ctrd <= -T.watchRate) why.push(rateLabel + ' fell ' + absPct(ctrd));
    if (objective === 'Awareness' && cur.frequency > T.freqCap) why.push('average daily frequency ' + U.ratioX(cur.frequency) + ' is above the ' + T.freqCap + '× cap');
    if (why.length) return res('Watch Out', why.join('; ') + '.', ACT.watch, d);
    return res('No Touching', 'No intervention threshold was crossed.', 'Keep stable and continue collecting comparable data.', d);
  };

  /* =========================================================================================
   * Playbook checks (rules.json `when` predicates, defined in rules.json → "predicates").
   * Every predicate must hold.
   * ctx: { spend, ctrAll (clicks ÷ impressions × 100 | null), linkCtr (link clicks ÷ impressions × 100,
   *        null when link clicks are not reported), cpr, freq, names: [campaign names in scope], scopeSpend }
   * ======================================================================================= */
  E.PREDICATES = {
    spend_gte: function (x, c) { return n(c.spend) >= +x; },
    ctr_all_lt: function (x, c) { return U.isNum(c.ctrAll) && c.ctrAll < +x; },
    ctr_all_gt: function (x, c) { return U.isNum(c.ctrAll) && c.ctrAll > +x; },
    link_ctr_lt: function (x, c) { return U.isNum(c.linkCtr) && c.linkCtr < +x; },
    link_ctr_gt: function (x, c) { return U.isNum(c.linkCtr) && c.linkCtr > +x; },
    cpr_gt: function (x, c) { return U.isNum(c.cpr) && c.cpr > +x; },
    frequency_gt: function (x, c) { return U.isNum(c.freq) && c.freq > +x; },
    name_not_contains_any: function (list, c) {
      var needles = (Array.isArray(list) ? list : [list]).map(function (s) { return String(s).toLowerCase(); }).filter(Boolean);
      return !(c.names || []).some(function (nm) {
        var t = String(nm || '').toLowerCase();
        return needles.some(function (s) { return t.indexOf(s) >= 0; });
      });
    },
    min_spend: function (x, c) { return n(c.scopeSpend) >= +x; }
  };
  /** Legacy names from the first rules.json draft: they meant link CTR. Accepted with a warning. */
  E.LEGACY_PREDICATES = { ctr_lt: 'link_ctr_lt', ctr_gt: 'link_ctr_gt' };
  var warned = {};
  /** { ok, unsupported: [keys], legacy: [keys] } — an unknown predicate never fires (reported on Data health). */
  E.checkPredicates = function (when, ctx) {
    var keys = Object.keys(when || {}), unsupported = [], legacy = [], ok = keys.length > 0;
    for (var i = 0; i < keys.length; i++) {
      var key = keys[i], f = E.PREDICATES[key];
      if (!f && E.LEGACY_PREDICATES[key]) {
        f = E.PREDICATES[E.LEGACY_PREDICATES[key]];
        legacy.push(key);
        if (!warned[key] && root.console && console.warn) {
          warned[key] = true;
          console.warn('GROOV playbook: predicate "' + key + '" is a legacy alias of "' + E.LEGACY_PREDICATES[key] + '" (link CTR). Use ctr_all_* or link_ctr_* in rules.json.');
        }
      }
      if (!f) { unsupported.push(key); ok = false; continue; }
      if (!f(when[key], ctx)) ok = false;
    }
    return { ok: ok && !unsupported.length, unsupported: unsupported, legacy: legacy };
  };

  /* =========================================================================================
   * Benchmarks (rules.benchmarks): matched on metric + vertical, or objective + platform
   * ======================================================================================= */
  E.BENCH_METRICS = {
    cost_per_message: { label: 'Cost per message', objective: 'Messages', get: function (k) { return k.cpmsg; }, fmt: 'money' },
    cpl: { label: 'CPL', objective: 'Lead generation', get: function (k) { return k.cpl; }, fmt: 'money' },
    cost_per_lead: { label: 'CPL', objective: 'Lead generation', get: function (k) { return k.cpl; }, fmt: 'money' },
    cpm: { label: 'CPM', objective: null, get: function (k) { return k.cpm; }, fmt: 'money' },
    cpc: { label: 'CPC', objective: 'Traffic', get: function (k) { return k.cpc_link; }, fmt: 'money' },
    ctr: { label: 'Link CTR', objective: null, get: function (k) { return k.link_ctr; }, fmt: 'pct' },
    cost_per_view: { label: 'Cost per view', objective: 'Engagement', get: function (k) { return k.cpv; }, fmt: 'money' },
    cpa: { label: 'CPA', objective: 'Conversions', get: function (k) { return k.cpa; }, fmt: 'money' },
    roas: { label: 'ROAS', objective: 'Conversions', get: function (k) { return k.roas; }, fmt: 'ratio' },
    frequency: { label: 'Avg daily frequency', objective: null, get: function (k) { return k.freq; }, fmt: 'ratio' }
  };
  E.matchBenchmarks = function (list, q) {
    return (list || []).filter(function (b) {
      if (!b || b.metric !== q.metric) return false;
      if (b.vertical) return !!q.vertical && U.eqi(b.vertical, q.vertical) && (!b.platform || U.eqi(b.platform, q.platform));
      if (b.objective && b.platform) return q.objective === b.objective && U.eqi(b.platform, q.platform);
      if (b.objective) return q.objective === b.objective;
      return false;
    });
  };
  E.benchPosition = function (value, b) {
    if (!U.isNum(value) || !b || !U.isNum(+b.low) || !U.isNum(+b.high)) return null;
    return value < +b.low ? 'below' : value > +b.high ? 'above' : 'inside';
  };
  /** Benchmarks are observed ranges; only Tested / Proven ones may be called targets. */
  E.benchIsTarget = function (b) { return !!b && (b.confidence === 'Tested' || b.confidence === 'Proven'); };

  /* =========================================================================================
   * Creative fatigue (SPEC §4.4): ≥ 2,000 impressions in both periods and 2 of 3 worsened
   * ======================================================================================= */
  E.fatigue = function (ck, pk, objective, platform) {
    var eligible = n(ck.impressions) >= 2000 && n(pk.impressions) >= 2000;
    var signals = [];
    var dc = U.pctChange(ck.link_ctr, pk.link_ctr);
    signals.push({ key: 'ctr', label: 'Link CTR', change: dc, hit: dc !== null && dc <= -20, rule: 'down ≥ 20%' });
    var dm = U.pctChange(ck.cpm, pk.cpm);
    signals.push({ key: 'cpm', label: 'CPM', change: dm, hit: dm !== null && dm >= 18, rule: 'up ≥ 18%' });
    if (objective !== 'Awareness') { // for Awareness the cost per result IS the CPM: never count it twice
      var pc = E.primary(objective, platform, ck), pp = E.primary(objective, platform, pk);
      var dr = U.pctChange(pc.cost, pp.cost);
      var hit = dr !== null && (pc.lowerBetter ? dr >= 30 : dr <= -30);
      signals.push({ key: 'cpr', label: pc.costLabel, change: dr, hit: hit, rule: pc.lowerBetter ? 'up ≥ 30%' : 'down ≥ 30%' });
    }
    var hits = signals.filter(function (s) { return s.hit; }).length;
    return {
      eligible: eligible, signals: signals, hits: hits, flag: eligible && hits >= 2,
      freqSupport: platform === 'meta' && U.isNum(ck.freq) && ck.freq >= 2.5, freq: ck.freq
    };
  };

  /* =========================================================================================
   * Cost-per-result bridge (§5b.2): cost per result = CPM/1000 × 1/link CTR × 1/(results ÷ link clicks)
   * Contributions are log shares of the total change, so they add up to it exactly.
   * ======================================================================================= */
  E.cprBridge = function (objective, cur, prev) {
    var field = objective === 'Messages' ? 'messages' : objective === 'Lead generation' ? 'leads' : null;
    if (!field) return { ok: false, reason: 'Only for Messages and Lead generation.' };
    var rateLabel = field === 'messages' ? 'Chat-start rate' : 'Lead rate';
    var resLabel = field === 'messages' ? 'Cost per message' : 'CPL';
    function parts(a) {
      var imp = n(a.impressions), lc = n(a.link_clicks), r = n(a[field]), sp = n(a.spend), cl = n(a.clicks);
      if (!(imp > 0 && lc > 0 && r > 0 && sp > 0)) return null;
      if (cl > 0 && lc === 0) return null;
      return { cpm: sp / imp * 1000, ctr: lc / imp, rate: r / lc, cpr: sp / r };
    }
    var a = parts(cur || {}), b = parts(prev || {});
    if (!a || !b) {
      return { ok: false, label: resLabel, reason: 'Needs impressions, reported link clicks and ' + (field === 'messages' ? 'conversations' : 'leads') + ' in both periods.' };
    }
    var total = (a.cpr / b.cpr - 1) * 100;
    var lt = Math.log(a.cpr / b.cpr);
    var logs = [Math.log(a.cpm / b.cpm), -Math.log(a.ctr / b.ctr), -Math.log(a.rate / b.rate)];
    var own = [(a.cpm / b.cpm - 1) * 100, (a.ctr / b.ctr - 1) * 100, (a.rate / b.rate - 1) * 100];
    var labels = ['CPM', 'Link CTR', rateLabel];
    var flat = Math.abs(lt) < 1e-9;
    var drivers = labels.map(function (l, i) {
      return { label: l, change: own[i], contribution: flat ? 0 : total * logs[i] / lt, log: logs[i] };
    });
    return { ok: true, label: resLabel, total: total, drivers: drivers, offset: flat, cur: a, prev: b };
  };

  /* =========================================================================================
   * Delivery integrity (§5b.3): two windows, so one odd day never alerts
   * o: { status, last3 (spend in last 3 days of the period), prior7 (spend in the 7 days before),
   *      priorDays (days of the prior window inside history), lastDate, periodEnd, spentBefore }
   * ======================================================================================= */
  E.deliverySignals = function (o) {
    var out = [];
    var active = o.status === 'ACTIVE';
    var avg3 = n(o.last3) / 3;
    var avg7 = o.priorDays > 0 ? n(o.prior7) / o.priorDays : 0;
    var full = o.priorDays >= 7;
    if (active && n(o.last3) === 0 && o.spentBefore && o.lastDate && o.lastDate < U.addDays(o.periodEnd, -2)) {
      out.push({ type: 'stopped', title: 'Delivery stopped', avg3: avg3, avg7: avg7,
        why: 'Status ACTIVE, but no spend in the last 3 days of the period (last delivery ' + U.fmtDate(o.lastDate) + ').',
        action: 'Check budget, schedule, billing, approvals and audience size; confirm whether it was meant to stop.' });
    } else if (active && full && avg7 >= 100 && n(o.last3) > 0 && avg3 < 0.4 * avg7) {
      out.push({ type: 'dropped', title: 'Spend dropped sharply', avg3: avg3, avg7: avg7,
        why: 'Last-3-day average ' + U.money(avg3) + '/day is under 40% of the prior 7-day average ' + U.money(avg7) + '/day.',
        action: 'Look for a budget cut, a paused ad set, rejected ads or a bid limit before it costs the month.' });
    }
    if (full && avg7 > 0 && avg3 > 1.75 * avg7 && avg3 >= 500) {
      out.push({ type: 'spike', title: 'Spend spike', avg3: avg3, avg7: avg7,
        why: 'Last-3-day average ' + U.money(avg3) + '/day is over 175% of the prior 7-day average ' + U.money(avg7) + '/day.',
        action: 'Confirm the budget change was intended and results kept pace with the extra spend.' });
    }
    return out;
  };

  /* =========================================================================================
   * Pacing (§5b.5): projected month-end = MTD + trailing 7-day average × days left
   * o: { budget, mtd, avg7, elapsed (days of the month up to data_through), dim (days in month) }
   * ======================================================================================= */
  E.pacing = function (o) {
    var budget = n(o.budget);
    if (!(budget > 0)) return null;
    var daysLeft = Math.max(0, n(o.dim) - n(o.elapsed));
    var projected = n(o.mtd) + n(o.avg7) * daysLeft;
    var ratio = projected / budget;
    var dev = Math.abs(ratio - 1);
    var early = n(o.elapsed) <= 3;
    var status = early ? null : dev <= 0.10 ? 'green' : dev <= 0.20 ? 'amber' : 'red';
    return { budget: budget, mtd: n(o.mtd), avg7: n(o.avg7), projected: projected, ratio: ratio, daysLeft: daysLeft, status: status, early: early,
      label: early ? 'Too early (first 3 days of the month)' : status === 'green' ? 'On track (within ±10%)' : status === 'amber' ? 'Off by 10–20%' : 'Off by more than 20%' };
  };

  /* =========================================================================================
   * Creative pipeline (§5b.7). list: [{ first_date, spend, delivering }]
   * ======================================================================================= */
  E.creativePipeline = function (list, periodEnd, historyFrom) {
    var newCut = U.addDays(periodEnd, -13);            // launched in the last 14 days
    var oldCut = U.addDays(periodEnd, -29);            // launched more than 28 days before the period end
    var knowable = !!historyFrom && historyFrom <= oldCut;
    var active = 0, new14 = 0, spend = 0, oldSpend = 0;
    list.forEach(function (a) {
      if (a.delivering) active++;
      if (a.first_date && a.first_date >= newCut && a.first_date <= periodEnd && (!historyFrom || a.first_date > historyFrom)) new14++;
      spend += n(a.spend);
      if (a.first_date && a.first_date <= oldCut) oldSpend += n(a.spend);
    });
    var share = spend > 0 ? oldSpend / spend : null;
    return { active: active, new14: new14, oldShare: knowable ? share : null, knowable: knowable,
      refreshDue: knowable && share !== null && share >= 0.7 && new14 === 0 };
  };

  /** "New" = launched less than 7 days before the period end (and after the history start, so it is not older). */
  E.isNew = function (firstDate, periodEnd, historyFrom) {
    if (!U.isIso(firstDate) || !U.isIso(periodEnd)) return false;
    var age = U.diffDays(firstDate, periodEnd);
    return age >= 0 && age < 7 && (!historyFrom || firstDate > historyFrom);
  };
  /** Days live up to the period end; `atLeast` when the first date is the history start (it may be older). */
  E.liveDays = function (firstDate, periodEnd, historyFrom) {
    if (!U.isIso(firstDate) || !U.isIso(periodEnd)) return null;
    var d = U.diffDays(firstDate, periodEnd) + 1;
    if (d < 1) return null;
    return { days: d, atLeast: !!historyFrom && firstDate <= historyFrom };
  };

  /* =========================================================================================
   * Where results happen (SPEC §4.8): result metric by objective and share tags
   * ======================================================================================= */
  /**
   * The result metric used by placement and audience splits (Meta). `key` is the breakdown metric;
   * `per` turns spend ÷ key into the cost (1000 for CPM). Conversions (Meta ROAS) has no counts in
   * the breakdown Sheets (purchase value isn't there): sharesOnly, spend and impression shares only.
   */
  E.bdResult = function (objective) {
    switch (objective) {
      case 'Messages': return { key: 'messages', label: 'Conversations', word: 'conversations', costLabel: 'Cost per conversation', per: 1, sharesOnly: false };
      case 'Lead generation': return { key: 'leads', label: 'Leads', word: 'leads', costLabel: 'CPL', per: 1, sharesOnly: false };
      case 'Engagement': return { key: 'video_views', label: '3-second views', word: '3-second video views', costLabel: 'Cost per view', per: 1, sharesOnly: false };
      case 'Traffic': return { key: 'link_clicks', label: 'Link clicks', word: 'link clicks', costLabel: 'CPC', per: 1, sharesOnly: false };
      case 'Awareness': return { key: 'impressions', label: 'Impressions', word: 'impressions', costLabel: 'CPM', per: 1000, sharesOnly: false };
      default: return { key: null, label: 'Impressions', word: 'impressions', costLabel: 'CPM', per: 1000, sharesOnly: true };
    }
  };
  E.BD_TAG_LABEL = { works: 'Works', weak: 'Weak', nores: 'Spending, no results', directional: 'Directional' };
  /** Below this many results in the block, no tag is stronger than "directional". */
  E.BD_MIN_RESULTS = 10;
  /**
   * Share tag for one placement / audience row (SPEC §4.8). Shares are fractions (0–1) of the block
   * (the ad set, or the client's ad sets of one objective); results is the row's count, total the
   * block's. Checked in this order:
   *   Spending, no results  ≥ 10% of the spend and 0 results
   *   Works                 share of results ≥ 1.2 × share of spend, with ≥ 3 results
   *   Weak                  share of results ≤ 0.8 × share of spend
   * When the block has fewer than 10 results in total every tag becomes "directional" (lean keeps
   * the direction). Returns null (no tag) or { tag, lean, label }.
   */
  E.bdTag = function (spendShare, resShare, results, total) {
    var eps = 1e-9, lean = null;
    if (!U.isNum(spendShare) || !U.isNum(results)) return null;
    var rs = U.isNum(resShare) ? resShare : (results === 0 ? 0 : null);
    if (rs === null) return null;
    if (results === 0 && spendShare >= 0.10 - eps) lean = 'nores';
    else if (results >= 3 && rs >= 1.2 * spendShare - eps) lean = 'works';
    else if (rs <= 0.8 * spendShare + eps) lean = 'weak';
    if (!lean) return null;
    var tag = n(total) < E.BD_MIN_RESULTS ? 'directional' : lean;
    return { tag: tag, lean: lean, label: E.BD_TAG_LABEL[tag] };
  };
})(typeof window !== 'undefined' ? window : this);
