/* GROOV Ads Command Center · charts.js
 * ------------------------------------------------------------------------------------------
 * Role: inline-SVG charts. No libraries. Builders are pure string functions (testable in Node);
 * the DOM part only measures container widths so SVG text renders at its real size (≥ 11px)
 * instead of being scaled down by a viewBox.
 *
 * Public API (window.GROOV.charts):
 *   slot(spec, cls)        placeholder HTML for a chart; the spec is kept until drawAll() renders it
 *   drawAll(root)          render every placeholder inside root at its measured width (call after render)
 *   redraw()               re-render mounted charts (window resize)
 *   render(spec, width)    -> SVG string (pure). spec.type:
 *       'stacked'  daily stacked bars by series + dashed comparison line + provisional shading
 *       'lines'    daily lines with gaps (null = no value that day) + provisional shading
 *       'combo'    small multiples sharing the x axis: stacked spend bars above, result lines below
 *                  (never two y-scales on one plot)
 *       'monthly'  monthly columns with the current month marked MTD
 *       'dots'     dot plot of values over an observed range band
 *       'trend'    KPI tile trend (SPEC §4.7): current line (gaps = no denominator), dashed
 *                  comparison aligned by day number, provisional shading, end marker coloured by
 *                  direction (good / bad / neutral / muted); no text, one hover target per bucket
 *       'trendx'   the expanded KPI chart: axes, gridlines, one line per series (or current +
 *                  dashed comparison), provisional band, benchmark band, target line, "partial"
 *                  labels under partial weeks, crosshair hover
 *   spec.tag = 'span' renders the slot as a <span> (charts inside buttons)
 *   spark(values, opts)    sparkline SVG (no text, scales freely)
 *   rangeBar(o)            small HTML range bar with the value's position (benchmarks)
 *   niceTicks(max, n)      clean axis ticks from 0
 * Tooltips: hit areas carry data-tip='[["title"],[color,value,label],…]' (JSON) and ui.js renders
 * them with textContent. Every chart also gets a table view from the views (tooltips never gate).
 */
(function (root) {
  'use strict';
  var G = root.GROOV = root.GROOV || {};
  var U = G.util;
  var C = G.charts = {};

  var FONT = 11;
  var specs = new Map();
  var seq = 0;

  /* ---------- registry (DOM side) ---------- */
  C.slot = function (spec, cls) {
    var id = 'c' + (++seq);
    specs.set(id, spec);
    var h = spec.height || 220, tag = spec.tag === 'span' ? 'span' : 'div';
    return '<' + tag + ' class="chart ' + (cls || '') + '" data-chart="' + id + '" style="min-height:' + h + 'px" role="img" aria-label="' +
      U.esc(spec.title || 'Chart') + '"></' + tag + '>';
  };
  C.reset = function () { specs.clear(); };
  C.drawAll = function (rootEl) {
    if (!rootEl || !rootEl.querySelectorAll) return;
    var els = rootEl.querySelectorAll('[data-chart]');
    for (var i = 0; i < els.length; i++) {
      var el = els[i], spec = specs.get(el.getAttribute('data-chart'));
      if (!spec) continue;
      var w = Math.floor(el.clientWidth);
      if (w < 40) continue;
      if (el._w === w && el._spec === spec) continue;
      el._w = w; el._spec = spec;
      el.innerHTML = C.render(spec, w);
    }
  };
  C.redraw = function () {
    if (typeof document === 'undefined') return;
    var els = document.querySelectorAll('[data-chart]');
    for (var i = 0; i < els.length; i++) els[i]._w = null;
    C.drawAll(document);
  };

  /* ---------- helpers ---------- */
  C.niceTicks = function (max, count) {
    count = count || 4;
    if (!(max > 0) || !isFinite(max)) return [0, 1];
    var raw = max / count, mag = Math.pow(10, Math.floor(Math.log(raw) / Math.LN10)), norm = raw / mag;
    var step = (norm <= 1 ? 1 : norm <= 2 ? 2 : norm <= 2.5 ? 2.5 : norm <= 5 ? 5 : 10) * mag;
    var top = Math.ceil(max / step - 1e-9) * step, out = [];
    for (var v = 0; v <= top + step / 2; v += step) out.push(Math.round(v * 1e6) / 1e6);
    return out;
  };
  function fmtVal(v, fmt) {
    if (!U.isNum(v)) return U.DASH;
    if (fmt === 'money') return U.money(v);
    if (fmt === 'money-exact') return U.money(v, { exact: true });
    if (fmt === 'pct') return U.pct(v);
    if (fmt === 'ratio') return U.ratioX(v);
    if (fmt === 'int') return U.int(v);
    return U.count(v);
  }
  C.fmtVal = fmtVal;
  function fmtTick(v, fmt) {
    if (fmt === 'money') return '฿' + U.compact(v);
    if (fmt === 'pct') return U.compact(v) + '%';
    if (fmt === 'ratio') return U.compact(v) + '×';
    return U.compact(v);
  }
  function f1(v) { return (Math.round(v * 10) / 10).toString(); }
  function tip(rows) { return U.esc(JSON.stringify(rows)); }
  function text(x, y, s, anchor, cls) {
    return '<text x="' + f1(x) + '" y="' + f1(y) + '" text-anchor="' + (anchor || 'start') + '" class="' + (cls || 'ax') + '">' + U.esc(s) + '</text>';
  }
  /** Rect with rounded top corners only (data end), square at the baseline. */
  function colPath(x, y, w, h, r) {
    if (h <= 0 || w <= 0) return '';
    r = Math.min(r, w / 2, h);
    return '<path d="M' + f1(x) + ',' + f1(y + h) + 'V' + f1(y + r) + 'Q' + f1(x) + ',' + f1(y) + ' ' + f1(x + r) + ',' + f1(y) +
      'H' + f1(x + w - r) + 'Q' + f1(x + w) + ',' + f1(y) + ' ' + f1(x + w) + ',' + f1(y + r) + 'V' + f1(y + h) + 'Z"';
  }
  function dayLabel(iso, i, days) {
    var d = +iso.slice(8, 10);
    if (i === 0 || d === 1) return U.fmtDay(iso);
    return String(d);
  }
  /** x-axis labels that never collide: keep every k-th label so each gets ≥ 34px. */
  function xLabels(days, x0, band, y) {
    var out = [], every = Math.max(1, Math.ceil(40 / Math.max(band, 1)));
    for (var i = 0; i < days.length; i++) {
      if (i % every !== 0 && i !== days.length - 1) continue;
      if (i === days.length - 1 && i % every !== 0 && (i % every) < every / 2) continue;
      out.push(text(x0 + band * i + band / 2, y, dayLabel(days[i], i, days), 'middle'));
    }
    return out.join('');
  }
  function yAxis(ticks, x0, x1, yOf, fmt) {
    var out = [];
    ticks.forEach(function (t) {
      var y = yOf(t);
      out.push('<line x1="' + x0 + '" x2="' + x1 + '" y1="' + f1(y) + '" y2="' + f1(y) + '" class="grid"/>');
      out.push(text(x0 - 6, y + 4, fmtTick(t, fmt), 'end'));
    });
    return out.join('');
  }
  function provisionalBand(spec, days, x0, band, top, h) {
    if (!spec.provisional) return '';
    var i0 = days.indexOf(spec.provisional.from);
    if (i0 < 0) return '';
    var x = x0 + band * i0, w = band * (days.length - i0);
    return '<rect x="' + f1(x) + '" y="' + top + '" width="' + f1(w) + '" height="' + h + '" class="prov"/>' +
      text(x + w - 4, top + 12, 'provisional', 'end', 'ax prov-t');
  }

  /* =========================================================================================
   * Builders
   * ======================================================================================= */
  C.render = function (spec, width) {
    try {
      if (spec.type === 'stacked') return stacked(spec, width);
      if (spec.type === 'lines') return lines(spec, width);
      if (spec.type === 'combo') return combo(spec, width);
      if (spec.type === 'monthly') return monthly(spec, width);
      if (spec.type === 'dots') return dots(spec, width);
      if (spec.type === 'trend') return trend(spec, width);
      if (spec.type === 'trendx') return trendx(spec, width);
    } catch (e) {
      return '<p class="empty">Chart could not be drawn.</p>';
    }
    return '';
  };

  function svgOpen(w, h, title) {
    return '<svg class="viz" width="' + w + '" height="' + h + '" viewBox="0 0 ' + w + ' ' + h + '" role="img" aria-label="' + U.esc(title || '') + '">';
  }

  /** Stacked daily bars (series) with an optional dashed comparison line aligned by day number. */
  function stacked(spec, W) {
    var days = spec.days || [], n = days.length;
    var H = spec.height || 240, L = 54, R = 10, T = 14, B = 26;
    var pw = Math.max(10, W - L - R), ph = H - T - B, band = pw / Math.max(n, 1);
    var totals = days.map(function (_, i) { return spec.series.reduce(function (s, se) { return s + (U.isNum(se.values[i]) ? se.values[i] : 0); }, 0); });
    var cmp = spec.compare && spec.compare.values ? spec.compare.values : null;
    var max = Math.max.apply(null, totals.concat(cmp ? cmp.filter(U.isNum) : []).concat([0]));
    var ticks = C.niceTicks(max, 4), top = ticks[ticks.length - 1] || 1;
    var yOf = function (v) { return T + ph - (v / top) * ph; };
    var bw = Math.max(2, Math.min(24, band * 0.68));
    var out = [svgOpen(W, H, spec.title)];
    out.push(provisionalBand(spec, days, L, band, T, ph));
    out.push(yAxis(ticks, L, W - R, yOf, spec.fmt || 'money'));
    for (var i = 0; i < n; i++) {
      var x = L + band * i + (band - bw) / 2, base = T + ph, acc = 0;
      var visible = spec.series.filter(function (se) { return U.isNum(se.values[i]) && se.values[i] > 0; });
      visible.forEach(function (se, k) {
        var v = se.values[i], y0 = yOf(acc), y1 = yOf(acc + v), h = y0 - y1;
        acc += v;
        var isTop = k === visible.length - 1;
        var gap = k > 0 ? 2 : 0; // 2px surface gap between stacked segments
        var hh = h - gap;
        if (hh <= 0.4) return;
        if (isTop) out.push(colPath(x, y1, bw, hh, 4) + ' style="fill:' + se.color + '"/>');
        else out.push('<rect x="' + f1(x) + '" y="' + f1(y1) + '" width="' + f1(bw) + '" height="' + f1(hh) + '" style="fill:' + se.color + '"/>');
        base = y1;
      });
    }
    if (cmp) {
      var pts = [];
      for (var j = 0; j < Math.min(n, cmp.length); j++) if (U.isNum(cmp[j])) pts.push(f1(L + band * j + band / 2) + ',' + f1(yOf(cmp[j])));
      if (pts.length > 1) out.push('<polyline points="' + pts.join(' ') + '" class="cmp-line"/>');
    }
    out.push('<line x1="' + L + '" x2="' + (W - R) + '" y1="' + (T + ph) + '" y2="' + (T + ph) + '" class="base"/>');
    out.push(xLabels(days, L, band, H - 8));
    // hit areas: one per day, the whole column, listing every series (+ comparison)
    for (var d = 0; d < n; d++) {
      var rows = [[U.weekday(days[d]) + ' ' + U.fmtDate(days[d])]];
      var tf = (spec.fmt || 'money') === 'money' ? 'money-exact' : spec.fmt; // hover shows exact values
      spec.series.forEach(function (se) { rows.push([se.color, fmtVal(se.values[d], tf), se.label]); });
      rows.push(['', fmtVal(totals[d], tf), 'Total']);
      if (cmp && spec.compare.days && spec.compare.days[d]) rows.push(['cmp', fmtVal(cmp[d], tf), 'Comparison · ' + U.fmtDay(spec.compare.days[d])]);
      out.push('<rect x="' + f1(L + band * d) + '" y="' + T + '" width="' + f1(band) + '" height="' + ph + '" class="hit" data-tip="' + tip(rows) + '"/>');
    }
    out.push('</svg>');
    return out.join('');
  }

  /** Daily lines with gaps. series: [{label, color, values (null = gap)}]. */
  function lines(spec, W) {
    var days = spec.days || [], n = days.length;
    var H = spec.height || 200, L = 54, R = 12, T = 14, B = 26;
    var pw = Math.max(10, W - L - R), ph = H - T - B, band = pw / Math.max(n, 1);
    var all = [];
    spec.series.forEach(function (se) { se.values.forEach(function (v) { if (U.isNum(v)) all.push(v); }); });
    if (!all.length) return '<p class="empty small">' + U.esc(spec.emptyText || 'No values in this period.') + '</p>';
    var ticks = C.niceTicks(Math.max.apply(null, all), 4), top = ticks[ticks.length - 1] || 1;
    var yOf = function (v) { return T + ph - (v / top) * ph; };
    var out = [svgOpen(W, H, spec.title)];
    out.push(provisionalBand(spec, days, L, band, T, ph));
    out.push(yAxis(ticks, L, W - R, yOf, spec.fmt));
    out.push('<line x1="' + L + '" x2="' + (W - R) + '" y1="' + (T + ph) + '" y2="' + (T + ph) + '" class="base"/>');
    spec.series.forEach(function (se) {
      var seg = [], segs = [];
      se.values.forEach(function (v, i) {
        if (!U.isNum(v)) { if (seg.length) segs.push(seg); seg = []; return; }
        seg.push([L + band * i + band / 2, yOf(v)]);
      });
      if (seg.length) segs.push(seg);
      segs.forEach(function (s) {
        if (s.length > 1) out.push('<polyline points="' + s.map(function (p) { return f1(p[0]) + ',' + f1(p[1]); }).join(' ') + '" class="ln" style="stroke:' + se.color + '"/>');
      });
      // markers: isolated points always (otherwise a one-day value would be invisible); all points when sparse
      segs.forEach(function (s) {
        if (s.length === 1 || n <= 31) s.forEach(function (p) { out.push('<circle cx="' + f1(p[0]) + '" cy="' + f1(p[1]) + '" r="4" class="mk" style="fill:' + se.color + '"/>'); });
      });
    });
    out.push(xLabels(days, L, band, H - 8));
    for (var d = 0; d < n; d++) {
      var rows = [[U.weekday(days[d]) + ' ' + U.fmtDate(days[d])]];
      spec.series.forEach(function (se) { rows.push([se.color, fmtVal(se.values[d], spec.fmt === 'money' ? 'money-exact' : spec.fmt), se.label]); });
      out.push('<g class="hitg"><line x1="' + f1(L + band * d + band / 2) + '" x2="' + f1(L + band * d + band / 2) + '" y1="' + T + '" y2="' + (T + ph) + '" class="xhair"/>' +
        '<rect x="' + f1(L + band * d) + '" y="' + T + '" width="' + f1(band) + '" height="' + ph + '" class="hit" data-tip="' + tip(rows) + '"/></g>');
    }
    out.push('</svg>');
    return out.join('');
  }

  /** Small multiples: spend (stacked bars) above, primary results (lines) below, one shared x axis. */
  function combo(spec, W) {
    var days = spec.days || [], n = days.length;
    var H1 = spec.barHeight || 150, H2 = spec.lineHeight || 120, gap = 22;
    var L = 54, R = 12, T = 18, B = 26;
    var H = T + H1 + gap + H2 + B;
    var pw = Math.max(10, W - L - R), band = pw / Math.max(n, 1);
    var bw = Math.max(2, Math.min(24, band * 0.68));
    var out = [svgOpen(W, H, spec.title)];
    // panel 1: spend
    var totals = days.map(function (_, i) { return spec.bars.reduce(function (s, se) { return s + (U.isNum(se.values[i]) ? se.values[i] : 0); }, 0); });
    var t1 = C.niceTicks(Math.max.apply(null, totals.concat([0])), 3), top1 = t1[t1.length - 1] || 1;
    var y1 = function (v) { return T + H1 - (v / top1) * H1; };
    out.push(provisionalBand(spec, days, L, band, T, H1 + gap + H2));
    out.push(text(L, T - 6, spec.barLabel || 'Spend', 'start', 'ax ttl'));
    out.push(yAxis(t1, L, W - R, y1, 'money'));
    for (var i = 0; i < n; i++) {
      var x = L + band * i + (band - bw) / 2, acc = 0;
      var visible = spec.bars.filter(function (se) { return U.isNum(se.values[i]) && se.values[i] > 0; });
      visible.forEach(function (se, k) {
        var v = se.values[i], ya = y1(acc), yb = y1(acc + v), h = ya - yb - (k > 0 ? 2 : 0);
        acc += v;
        if (h <= 0.4) return;
        if (k === visible.length - 1) out.push(colPath(x, yb, bw, h, 4) + ' style="fill:' + se.color + '"/>');
        else out.push('<rect x="' + f1(x) + '" y="' + f1(yb) + '" width="' + f1(bw) + '" height="' + f1(h) + '" style="fill:' + se.color + '"/>');
      });
    }
    out.push('<line x1="' + L + '" x2="' + (W - R) + '" y1="' + (T + H1) + '" y2="' + (T + H1) + '" class="base"/>');
    // panel 2: results
    var T2 = T + H1 + gap, all = [];
    spec.lines.forEach(function (se) { se.values.forEach(function (v) { if (U.isNum(v)) all.push(v); }); });
    out.push(text(L, T2 - 6, spec.lineLabel || 'Results', 'start', 'ax ttl'));
    if (all.length) {
      var t2 = C.niceTicks(Math.max.apply(null, all.concat([0])), 3), top2 = t2[t2.length - 1] || 1;
      var y2 = function (v) { return T2 + H2 - (v / top2) * H2; };
      out.push(yAxis(t2, L, W - R, y2, spec.lineFmt || 'count'));
      spec.lines.forEach(function (se) {
        var seg = [], segs = [];
        se.values.forEach(function (v, j) { if (!U.isNum(v)) { if (seg.length) segs.push(seg); seg = []; return; } seg.push([L + band * j + band / 2, y2(v)]); });
        if (seg.length) segs.push(seg);
        segs.forEach(function (s) {
          if (s.length > 1) out.push('<polyline points="' + s.map(function (p) { return f1(p[0]) + ',' + f1(p[1]); }).join(' ') + '" class="ln" style="stroke:' + se.color + '"/>');
          if (s.length === 1 || n <= 31) s.forEach(function (p) { out.push('<circle cx="' + f1(p[0]) + '" cy="' + f1(p[1]) + '" r="4" class="mk" style="fill:' + se.color + '"/>'); });
        });
      });
    } else {
      out.push(text(L + pw / 2, T2 + H2 / 2, spec.noLinesText || 'No primary results in this period', 'middle', 'ax'));
    }
    out.push('<line x1="' + L + '" x2="' + (W - R) + '" y1="' + (T2 + H2) + '" y2="' + (T2 + H2) + '" class="base"/>');
    out.push(xLabels(days, L, band, H - 8));
    for (var d = 0; d < n; d++) {
      var rows = [[U.weekday(days[d]) + ' ' + U.fmtDate(days[d])]];
      spec.bars.forEach(function (se) { rows.push([se.color, fmtVal(se.values[d], 'money-exact'), se.label + ' · spend']); });
      spec.lines.forEach(function (se) { rows.push([se.color, fmtVal(se.values[d], spec.lineFmt || 'count'), se.label + ' · ' + (spec.lineLabel || 'results')]); });
      out.push('<g class="hitg"><line x1="' + f1(L + band * d + band / 2) + '" x2="' + f1(L + band * d + band / 2) + '" y1="' + T + '" y2="' + (T2 + H2) + '" class="xhair"/>' +
        '<rect x="' + f1(L + band * d) + '" y="' + T + '" width="' + f1(band) + '" height="' + (T2 + H2 - T) + '" class="hit" data-tip="' + tip(rows) + '"/></g>');
    }
    out.push('</svg>');
    return out.join('');
  }

  /** Monthly columns; the MTD month is lighter and labelled. */
  function monthly(spec, W) {
    var labels = spec.labels || [], n = labels.length;
    var H = spec.height || 200, L = 54, R = 10, T = 22, B = 26;
    var pw = Math.max(10, W - L - R), ph = H - T - B, band = pw / Math.max(n, 1);
    var vals = spec.values.map(function (v) { return U.isNum(v) ? v : 0; });
    var ticks = C.niceTicks(Math.max.apply(null, vals.concat([0])), 3), top = ticks[ticks.length - 1] || 1;
    var yOf = function (v) { return T + ph - (v / top) * ph; };
    var bw = Math.max(4, Math.min(24, band * 0.5));
    var out = [svgOpen(W, H, spec.title), yAxis(ticks, L, W - R, yOf, 'money')];
    for (var i = 0; i < n; i++) {
      var v = vals[i], x = L + band * i + (band - bw) / 2, y = yOf(v), h = T + ph - y;
      var mtd = spec.mtdIndex === i;
      if (h > 0.4) out.push(colPath(x, y, bw, h, 4) + ' class="' + (mtd ? 'mbar mtd' : 'mbar') + '"/>');
      if (band >= 44) out.push(text(x + bw / 2, y - 5, U.money(v), 'middle', 'ax val'));
      out.push(text(L + band * i + band / 2, H - 8, labels[i] + (mtd ? ' MTD' : ''), 'middle'));
      out.push('<rect x="' + f1(L + band * i) + '" y="' + T + '" width="' + f1(band) + '" height="' + ph + '" class="hit" data-tip="' +
        tip([[labels[i] + (mtd ? ' (month to date)' : '')], ['var(--copper)', U.money(v, { exact: true }), 'Spend']]) + '"/>');
    }
    out.push('<line x1="' + L + '" x2="' + (W - R) + '" y1="' + (T + ph) + '" y2="' + (T + ph) + '" class="base"/>');
    out.push('</svg>');
    return out.join('');
  }

  /** Dot plot over an observed range band. points: [{label, value, highlight}] */
  function dots(spec, W) {
    var pts = (spec.points || []).filter(function (p) { return U.isNum(p.value); });
    var lo = Math.min.apply(null, [spec.low].concat(pts.map(function (p) { return p.value; })));
    var hi = Math.max.apply(null, [spec.high].concat(pts.map(function (p) { return p.value; })));
    if (!(hi > lo)) { hi = lo + 1; }
    var pad = (hi - lo) * 0.08;
    lo = Math.max(0, lo - pad); hi = hi + pad;
    var rowH = 26, H = 44 + Math.max(1, pts.length) * rowH, L = 12, R = 12, T = 12;
    var pw = Math.max(10, W - L - R);
    var xOf = function (v) { return L + (v - lo) / (hi - lo) * pw; };
    var out = [svgOpen(W, H, spec.title)];
    var bx = xOf(spec.low), bx2 = xOf(spec.high);
    out.push('<rect x="' + f1(bx) + '" y="' + T + '" width="' + f1(Math.max(2, bx2 - bx)) + '" height="' + (H - T - 28) + '" class="band"/>');
    var bound = function (v) { return spec.fmt === 'money' ? U.moneyRound(v) : fmtVal(v, spec.fmt); };
    out.push(text(bx, H - 10, bound(spec.low), 'middle'));
    if (spec.high !== spec.low) out.push(text(bx2, H - 10, bound(spec.high), 'middle'));
    if (U.isNum(spec.median)) {
      var mx = xOf(spec.median);
      out.push('<line x1="' + f1(mx) + '" x2="' + f1(mx) + '" y1="' + T + '" y2="' + (H - 28) + '" class="med"/>');
    }
    pts.forEach(function (p, i) {
      var y = T + 14 + i * rowH, x = xOf(p.value);
      var anchor = x > W * 0.62 ? 'end' : 'start', tx = anchor === 'end' ? x - 9 : x + 9;
      out.push('<circle cx="' + f1(x) + '" cy="' + f1(y) + '" r="5" class="dot' + (p.highlight ? ' hl' : '') + '"/>');
      out.push(text(tx, y + 4, p.label + ' · ' + fmtVal(p.value, spec.fmt), anchor, 'ax dl'));
      out.push('<rect x="' + f1(Math.max(0, x - 12)) + '" y="' + f1(y - 12) + '" width="24" height="24" class="hit" data-tip="' +
        tip([[p.label], ['var(--soft)', fmtVal(p.value, spec.fmt), p.sub || '']]) + '"/>');
    });
    out.push('</svg>');
    return out.join('');
  }

  /**
   * Runs of numbers as polylines (null = gap, so a missing denominator is never drawn as 0). A run
   * of one point becomes a dot, otherwise it would be invisible. style: optional stroke / fill colour.
   */
  function runs(values, x, y, cls, r, color, allDots) {
    var out = [], seg = [];
    var st = color ? ' style="stroke:' + color + '"' : '', fill = color ? ' style="fill:' + color + '"' : '';
    var flush = function () {
      if (seg.length > 1) {
        out.push('<polyline points="' + seg.map(function (p) { return f1(p[0]) + ',' + f1(p[1]); }).join(' ') + '" class="' + cls + '"' + st + '/>');
        if (allDots) seg.forEach(function (p) { out.push('<circle cx="' + f1(p[0]) + '" cy="' + f1(p[1]) + '" r="' + r + '" class="' + cls + '-dot"' + fill + '/>'); });
      } else if (seg.length === 1) {
        out.push('<circle cx="' + f1(seg[0][0]) + '" cy="' + f1(seg[0][1]) + '" r="' + r + '" class="' + cls + '-dot"' + fill + '/>');
      }
      seg = [];
    };
    values.forEach(function (v, i) { if (U.isNum(v)) seg.push([x(i), y(v)]); else flush(); });
    flush();
    return out.join('');
  }
  function lastNum(values) {
    for (var i = values.length - 1; i >= 0; i--) if (U.isNum(values[i])) return i;
    return -1;
  }

  /**
   * KPI tile trend: spec { cur: [v|null], cmp: [v|null] | null, dir, provIdx, tips: [rows per bucket],
   * height }. The y range is the padded min–max of both lines (a trend shape, not a magnitude: the
   * tile's number carries the magnitude, the expanded chart has the 0-based axis).
   */
  function trend(spec, W) {
    var cur = spec.cur || [], cmp = spec.cmp || null, n = cur.length;
    var H = spec.height || 40, L = 2, R = 7, T = 6, B = 6;
    var pw = Math.max(10, W - L - R), ph = Math.max(4, H - T - B), band = pw / Math.max(n, 1);
    var vals = cur.filter(U.isNum).concat(cmp ? cmp.filter(U.isNum) : []);
    var x = function (i) { return L + band * i + band / 2; };
    var out = [svgOpen(W, H, spec.title)];
    if (spec.provIdx >= 0 && spec.provIdx < n) {
      out.push('<rect x="' + f1(L + band * spec.provIdx) + '" y="0" width="' + f1(band * (n - spec.provIdx)) + '" height="' + H + '" class="prov"/>');
    }
    if (!vals.length) {
      out.push('<line x1="' + L + '" x2="' + f1(W - R) + '" y1="' + f1(H / 2) + '" y2="' + f1(H / 2) + '" class="tr-none"/>');
    } else {
      var lo = Math.min.apply(null, vals), hi = Math.max.apply(null, vals);
      if (hi - lo < 1e-12) { var c = Math.abs(hi) || 1; lo -= c * 0.5; hi += c * 0.5; }
      else { var pad = (hi - lo) * 0.1; lo -= pad; hi += pad; }
      var y = function (v) { return T + ph - (v - lo) / (hi - lo) * ph; };
      if (cmp) out.push(runs(cmp, x, y, 'tr-cmp', 1.75));
      out.push(runs(cur, x, y, 'tr-cur', 2.25));
      var li = lastNum(cur);
      if (li >= 0) out.push('<circle cx="' + f1(x(li)) + '" cy="' + f1(y(cur[li])) + '" r="4" class="tr-end ' + U.esc(spec.dir || 'neutral') + '"/>');
    }
    for (var d = 0; d < n; d++) {
      out.push('<rect x="' + f1(L + band * d) + '" y="0" width="' + f1(band) + '" height="' + H + '" class="hit" data-tip="' + tip(spec.tips && spec.tips[d] ? spec.tips[d] : [[String(d + 1)]]) + '"/>');
    }
    out.push('</svg>');
    return out.join('');
  }

  /**
   * Expanded KPI chart. spec: { labels: [x label per bucket], partial: [bool], series: [{label, color,
   * values}], cmp: [v|null] | null (Total view), fmt, dir (end marker, single series), provIdx,
   * band: {low, high, label} | null (observed benchmark range), target: {value, label} | null,
   * tips: [rows per bucket], height, emptyText }. One 0-based y axis for every line.
   */
  function trendx(spec, W) {
    var labels = spec.labels || [], n = labels.length, partial = spec.partial || [];
    var anyPartial = partial.some(Boolean);
    var H = spec.height || 270, L = 58, R = 16, T = 18, B = anyPartial ? 40 : 28;
    var pw = Math.max(10, W - L - R), ph = Math.max(20, H - T - B), band = pw / Math.max(n, 1);
    var all = [];
    (spec.series || []).forEach(function (se) { se.values.forEach(function (v) { if (U.isNum(v)) all.push(v); }); });
    (spec.cmp || []).forEach(function (v) { if (U.isNum(v)) all.push(v); });
    if (!all.length) return '<p class="empty small">' + U.esc(spec.emptyText || 'No values in this period.') + '</p>';
    var dataMax = Math.max.apply(null, all.concat([0]));
    var max = dataMax;
    // The y-axis follows the data. A benchmark band only widens it when the band sits close to the data
    // (high <= 1.5 x data max); a wide observed range (e.g. clinic ฿87–1,205) is clipped at the top edge
    // instead of flattening the line it is meant to give context to.
    var bLow = spec.band && U.isNum(+spec.band.low) ? +spec.band.low : null;
    var bHigh = spec.band && U.isNum(+spec.band.high) ? +spec.band.high : null;
    if (bHigh != null && bHigh <= dataMax * 1.5) max = Math.max(max, bHigh);
    else if (bLow != null && bLow > max && bLow <= dataMax * 1.5) max = bLow * 1.1;
    if (spec.target && U.isNum(+spec.target.value) && +spec.target.value <= dataMax * 2) max = Math.max(max, +spec.target.value);
    var ticks = C.niceTicks(max, 4), top = ticks[ticks.length - 1] || 1;
    var y = function (v) { return T + ph - (v / top) * ph; }, x = function (i) { return L + band * i + band / 2; };
    var out = [svgOpen(W, H, spec.title)];
    if (spec.provIdx >= 0 && spec.provIdx < n) {
      var px = L + band * spec.provIdx, pwid = band * (n - spec.provIdx);
      out.push('<rect x="' + f1(px) + '" y="' + T + '" width="' + f1(pwid) + '" height="' + ph + '" class="prov"/>' + text(px + pwid - 4, T + 12, 'provisional', 'end', 'ax prov-t'));
    }
    if (bLow != null && bHigh != null) {
      var clipped = bHigh > top, above = bLow >= top;
      var yb1 = y(Math.min(bHigh, top)), yb0 = y(Math.min(bLow, top)), bh = Math.max(2, yb0 - yb1);
      if (!above) out.push('<rect x="' + L + '" y="' + f1(yb0 - bh) + '" width="' + f1(pw) + '" height="' + f1(bh) + '" class="bband"/>');
      var bl = spec.band.label ? spec.band.label + (above ? ' (above this chart)' : clipped ? ' (continues above)' : '') : '';
      if (bl) out.push(text(L + 6, above ? T + 12 : (bh >= 16 ? yb0 - bh + 12 : yb0 - bh - 4), bl, 'start', 'ax bandl'));
    }
    out.push(yAxis(ticks, L, W - R, y, spec.fmt));
    out.push('<line x1="' + L + '" x2="' + (W - R) + '" y1="' + (T + ph) + '" y2="' + (T + ph) + '" class="base"/>');
    if (spec.target && U.isNum(+spec.target.value) && +spec.target.value <= top) {
      var yt = y(+spec.target.value);
      out.push('<line x1="' + L + '" x2="' + (W - R) + '" y1="' + f1(yt) + '" y2="' + f1(yt) + '" class="tgt-line"/>');
      if (spec.target.label) out.push(text(W - R - 4, yt - 5, spec.target.label, 'end', 'ax tgtl'));
    }
    if (spec.cmp) out.push(runs(spec.cmp, x, y, 'trx-cmp', 3, null, false));
    var dots = n <= 31;
    (spec.series || []).forEach(function (se) { out.push(runs(se.values, x, y, 'ln', 3.5, se.color, dots)); });
    if (spec.dir && spec.series && spec.series.length === 1) {
      var vs = spec.series[0].values, li = lastNum(vs);
      if (li >= 0) out.push('<circle cx="' + f1(x(li)) + '" cy="' + f1(y(vs[li])) + '" r="5.5" class="tr-end ' + U.esc(spec.dir) + '"/>');
    }
    // x labels: keep every k-th so each gets ≥ 44px; "partial" under partial weeks
    var every = Math.max(1, Math.ceil(44 / Math.max(band, 1)));
    for (var i = 0; i < n; i++) {
      if (i % every !== 0 && i !== n - 1) continue;
      if (i === n - 1 && i % every !== 0 && (i % every) < every / 2) continue;
      out.push(text(x(i), T + ph + 16, labels[i], 'middle'));
      if (partial[i]) out.push(text(x(i), T + ph + 29, 'partial', 'middle', 'ax prov-t'));
    }
    for (var d = 0; d < n; d++) {
      out.push('<g class="hitg"><line x1="' + f1(x(d)) + '" x2="' + f1(x(d)) + '" y1="' + T + '" y2="' + (T + ph) + '" class="xhair"/>' +
        '<rect x="' + f1(L + band * d) + '" y="' + T + '" width="' + f1(band) + '" height="' + ph + '" class="hit" data-tip="' + tip(spec.tips && spec.tips[d] ? spec.tips[d] : [[labels[d]]]) + '"/></g>');
    }
    out.push('</svg>');
    return out.join('');
  }

  /* =========================================================================================
   * Small inline pieces (no measurement needed)
   * ======================================================================================= */
  /** Sparkline: polyline + 10% area wash; stretches to its box (no text inside, so scaling is safe). */
  C.spark = function (values, opts) {
    opts = opts || {};
    var v = (values || []).map(function (x) { return U.isNum(x) ? x : 0; });
    if (v.length < 2 || !v.some(function (x) { return x > 0; })) return '<span class="spark-empty" aria-hidden="true"></span>';
    var max = Math.max.apply(null, v), w = 100, h = 28, n = v.length;
    var pts = v.map(function (x, i) { return f1(i / (n - 1) * w) + ',' + f1(h - 2 - (x / max) * (h - 4)); });
    var color = opts.color || 'var(--soft)';
    return '<svg class="spark" viewBox="0 0 ' + w + ' ' + h + '" preserveAspectRatio="none" aria-hidden="true">' +
      '<polygon points="0,' + h + ' ' + pts.join(' ') + ' ' + w + ',' + h + '" style="fill:' + color + ';opacity:.12"/>' +
      '<polyline points="' + pts.join(' ') + '" style="stroke:' + color + '" vector-effect="non-scaling-stroke"/></svg>';
  };

  /**
   * Range bar (HTML): observed low–high band with the value's marker.
   * o: { low, high, value, median, fmt, label }
   */
  C.rangeBar = function (o) {
    var lo = Math.min(o.low, U.isNum(o.value) ? o.value : o.low), hi = Math.max(o.high, U.isNum(o.value) ? o.value : o.high);
    if (U.isNum(o.median)) { lo = Math.min(lo, o.median); hi = Math.max(hi, o.median); }
    var pad = (hi - lo) * 0.1 || Math.max(1, Math.abs(hi) * 0.1);
    lo = Math.max(0, lo - pad); hi = hi + pad;
    var pos = function (v) { return U.clamp((v - lo) / (hi - lo) * 100, 0, 100).toFixed(1) + '%'; };
    var left = pos(o.low), width = Math.max(1.5, (o.high - o.low) / (hi - lo) * 100).toFixed(1) + '%';
    var html = '<span class="rbar" aria-hidden="true"><span class="rband" style="left:' + left + ';width:' + width + '"></span>';
    if (U.isNum(o.median)) html += '<span class="rmed" style="left:' + pos(o.median) + '"></span>';
    if (U.isNum(o.value)) html += '<span class="rval" style="left:' + pos(o.value) + '"></span>';
    return html + '</span>';
  };
})(typeof window !== 'undefined' ? window : this);
