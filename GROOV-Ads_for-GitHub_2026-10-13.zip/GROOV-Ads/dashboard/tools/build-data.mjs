#!/usr/bin/env node
// Build the local preview bundle: public/data/sample.js  (sets window.GROOV_SAMPLE).
//
//   node tools/build-data.mjs                      (or: npm run build:sample)
//   node tools/build-data.mjs --now 2026-10-12T07:05:00+07:00     reproducible generated_at
//   options: --sheets <dir>  --creatives <dir>  --out <file>  --now <iso>
//   (the sheets folder may also hold meta_placements.csv and meta_audience.csv, the optional breakdown Sheets)
//
// Reads the three sample Sheets (sample/sheets/*.csv), lists the saved creatives library, runs the same
// normaliser the live API will use (mode "sample") and writes
//     window.GROOV_SAMPLE = {"meta": ..., "rows": ..., "monthly": ..., "breakdowns": ...};
// as compact JSON. `breakdowns` is the full-range /api/breakdowns payload (DATA_CONTRACT.md §2.5) built from the two
// OPTIONAL Sheets sample/sheets/meta_placements.csv and meta_audience.csv; when they are absent it is the same payload
// with available false / false and empty arrays. `meta.breakdowns` carries their health block (§2.4).
// The file is git-ignored and never deployed. It stays UTF-8 (Thai / emoji are written
// as-is), so the page that loads it must declare <meta charset="utf-8">.

import { existsSync, mkdirSync, readFileSync, readdirSync, realpathSync, statSync, writeFileSync } from 'node:fs';
import { dirname, join, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { parseCsv } from '../lib/csv.mjs';
import { PLATFORMS, meta, monthly, normalize, sliceRows } from '../lib/normalize.mjs';
import { BREAKDOWN_KINDS, breakdownFullRange, breakdownsHealth, normaliseBreakdowns, sliceBreakdowns } from '../lib/breakdowns.mjs';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
export const DEFAULTS = {
  sheetsDir: join(ROOT, 'sample', 'sheets'),
  creativesDir: resolve(ROOT, '..', 'command-center', 'creatives'),
  out: join(ROOT, 'public', 'data', 'sample.js'),
};

/** Read and parse sample/sheets/{meta,tiktok,google}.csv. */
export function readSheets(dir) {
  const sheets = {};
  for (const platform of PLATFORMS) {
    const file = join(dir, `${platform}.csv`);
    if (!existsSync(file)) throw new Error(`Missing sample sheet: ${file}`);
    sheets[platform] = parseCsv(readFileSync(file, 'utf8'));
  }
  return sheets;
}

/** The optional breakdown Sheets of the sample, keyed like lib/breakdowns.mjs input. */
export const BREAKDOWN_FILES = Object.freeze({ placements: 'meta_placements.csv', audience: 'meta_audience.csv' });

/** Read sample/sheets/meta_placements.csv and meta_audience.csv; a file that does not exist is simply absent from the result. */
export function readBreakdownSheets(dir) {
  const sheets = {};
  for (const [key, name] of Object.entries(BREAKDOWN_FILES)) {
    const file = join(dir, name);
    if (existsSync(file)) sheets[key] = parseCsv(readFileSync(file, 'utf8'));
  }
  return sheets;
}

/**
 * List <creativesDir>/<platform>/<ad_id>.jpg as keys like "meta:<ad_id>". Same validity rule as the
 * library's own loader (creatives.py): a real file bigger than 100 bytes; a stub does not count as saved.
 */
export function listSavedCreatives(dir) {
  const saved = new Set();
  const files = { meta: 0, tiktok: 0 };
  for (const platform of ['meta', 'tiktok']) {
    const folder = join(dir, platform);
    if (!existsSync(folder)) continue;
    for (const name of readdirSync(folder)) {
      const m = /^(\d+)\.jpg$/.exec(name);
      if (m && statSync(join(folder, name)).size > 100) {
        saved.add(`${platform}:${m[1]}`);
        files[platform]++;
      }
    }
  }
  return { saved, files, found: existsSync(dir) };
}

// U+2028 / U+2029 are legal inside JSON strings but older JS engines rejected them in string literals,
// so they are written as escapes. Built from char codes to keep this source free of those characters.
const LINE_SEPARATORS = new RegExp('[' + String.fromCharCode(0x2028, 0x2029) + ']', 'g');

/** Serialise exactly as the contract asks: one compact line, safe to load as a classic <script>. */
export function toSampleJs({ meta: metaPayload, rows, monthly: monthlyPayload, breakdowns }) {
  const json = JSON.stringify({ meta: metaPayload, rows, monthly: monthlyPayload, breakdowns }) // undefined breakdowns are left out
    .replace(LINE_SEPARATORS, (c) => '\\u' + c.charCodeAt(0).toString(16));
  return `window.GROOV_SAMPLE = ${json};\n`;
}

/** Everything except the file write, so tests can call it directly. */
export function buildSample({ sheetsDir = DEFAULTS.sheetsDir, creativesDir = DEFAULTS.creativesDir, now = new Date() } = {}) {
  const sheets = readSheets(sheetsDir);
  const breakdownSheets = readBreakdownSheets(sheetsDir);
  const creatives = listSavedCreatives(creativesDir);
  const dataset = normalize(sheets, { savedCreatives: creatives.saved, mode: 'sample', now });
  const breakdownDataset = normaliseBreakdowns(breakdownSheets, { mode: 'sample', now, main: dataset });
  const configured = Object.fromEntries(Object.keys(BREAKDOWN_FILES).map((k) => [k, k in breakdownSheets]));
  const metaPayload = { ...meta(dataset), breakdowns: breakdownsHealth(breakdownDataset, dataset, { configured }) };
  // Full available range: from the earliest date in any sheet to the latest date in any sheet.
  const last = dataset.rows.length ? dataset.rows[dataset.rows.length - 1][0] : null;
  const rows = sliceRows(dataset, metaPayload.history_from, last);
  // The breakdown Sheets may reach past the main ones (or start earlier), so their payload covers all of it.
  const span = breakdownFullRange(breakdownDataset, metaPayload.history_from, last);
  const payload = { meta: metaPayload, rows, monthly: monthly(dataset), breakdowns: sliceBreakdowns(breakdownDataset, span.from, span.to) };
  return { text: toSampleJs(payload), payload, dataset, creatives, breakdownDataset };
}

// ---------------------------------------------------------------------------------------------
// Console summary
// ---------------------------------------------------------------------------------------------

const fmt = (n) => n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const int = (n) => n.toLocaleString('en-US');

const pct = (share) => (share === null ? 'n/a' : `${(share * 100).toFixed(2)}%`); // 2 decimals: the ratio is reported as it is, e.g. 100.05%

/**
 * Summary of the optional breakdown Sheets: row counts, date span and spend share per Sheet. With the /api/meta health
 * block it also says how much of ALL Meta spend the Sheet covers (lower when the export misses ad accounts).
 */
export function describeBreakdowns(breakdowns, health = null) {
  const parts = BREAKDOWN_KINDS.map((kind) => {
    const file = BREAKDOWN_FILES[kind === 'placement' ? 'placements' : 'audience'];
    if (!breakdowns.available[kind]) return `${kind}: none (no usable ${file})`;
    const c = breakdowns.coverage[kind];
    const all = health?.[kind]?.all_meta_spend_share_last_28d ?? null;
    return `${kind}: ${int(breakdowns[`${kind}_rows`].length)} rows, ${c.first_date} to ${c.last_date}, spend share ${pct(c.spend_share)}${all === null ? '' : ` (${pct(all)} of all Meta spend)`}`;
  });
  return parts.join(' · ');
}

/** Human-readable list of non-zero diagnostics per breakdown Sheet. */
export function describeBreakdownQuirks(bds) {
  const out = [];
  for (const kind of BREAKDOWN_KINDS) {
    const d = bds.diagnostics[kind];
    const h = bds.health[kind];
    const add = (n, message) => { if (n) out.push(`${kind}: ${message}`); };
    add(h.columns_missing.length, `columns missing: ${h.columns_missing.join(', ')}${h.ignored ? ' (the Sheet was ignored)' : ''}`);
    add(d.extra_columns.length, `unrecognised columns ignored: ${d.extra_columns.join(', ')}`);
    add(d.skipped.bad_date + d.skipped.no_adset, `rows skipped (bad date ${d.skipped.bad_date}, no adset_id ${d.skipped.no_adset})`);
    add(d.empty_rows, `${d.empty_rows} rows with every metric 0 dropped`);
    add(d.no_account_rows, `${d.no_account_rows} rows without account_id`);
    add(d.blank_segment_rows, `${d.blank_segment_rows} rows with a blank segment kept as unknown`);
    add(Object.keys(d.unrecognised_ages).length, `unrecognised age values: ${JSON.stringify(d.unrecognised_ages)}`);
    add(Object.keys(d.unrecognised_genders).length, `unrecognised gender values: ${JSON.stringify(d.unrecognised_genders)}`);
    add(Object.keys(d.negative_values).length, `negative values: ${JSON.stringify(d.negative_values)}`);
    add(Object.keys(d.unparseable_values).length, `non-numeric cells counted as 0: ${JSON.stringify(d.unparseable_values)}`);
    add(h.duplicates, `${h.duplicates} duplicate rows (${d.duplicates_identical} identical, ${d.duplicates_conflicting} conflicting)`);
  }
  return out;
}

export function summarize({ payload, dataset, creatives, text, breakdownDataset }, outFile) {
  const { rows } = payload;
  const perRows = {};
  const perSpend = {};
  for (const r of rows.rows) {
    const platform = rows.campaigns[r[1]].key.split(':')[0];
    perRows[platform] = (perRows[platform] || 0) + 1;
    perSpend[platform] = (perSpend[platform] || 0) + r[4];
  }
  const cov = payload.meta.creatives;
  const line = (label, value) => `  ${label.padEnd(13)}${value}`;
  const out = [
    `Wrote ${outFile} (${(Buffer.byteLength(text) / 1024).toFixed(0)} KB)`,
    line('range', `${rows.range.from} to ${rows.range.to}  (data_through ${payload.meta.data_through}, history_from ${payload.meta.history_from})`),
    line('rows', `${PLATFORMS.map((p) => `${p} ${int(perRows[p] || 0)}`).join(' · ')} · total ${int(rows.rows.length)}`),
    line('spend (THB)', PLATFORMS.map((p) => `${p} ${fmt(perSpend[p] || 0)}`).join(' · ')),
    line('entities', `${rows.accounts.length} accounts · ${rows.campaigns.length} campaigns · ${rows.adsets.length} ad sets/groups · ${rows.ads.length} ads`),
    line('monthly', `${payload.monthly.months.join(', ')} · ${payload.monthly.rows.length} campaign-months`),
    line('creatives', ['meta', 'tiktok'].map((p) => `${p} ${cov[p].saved}/${cov[p].ads} saved (no_url ${cov[p].no_url}, not_saved ${cov[p].not_saved})`).join(' · ')),
    line('breakdowns', describeBreakdowns(payload.breakdowns, payload.meta.breakdowns)),
  ];
  if (!creatives.found) out.push('  WARNING       creatives folder not found: every ad is reported as not_saved / no_url');
  const quirks = [...describeQuirks(dataset), ...(breakdownDataset ? describeBreakdownQuirks(breakdownDataset) : [])];
  if (quirks.length) out.push('  data quirks   (reported as found, values untouched)', ...quirks.map((q) => `    - ${q}`));
  return out.join('\n');
}

/** Human-readable list of non-zero diagnostics per sheet. */
export function describeQuirks(dataset) {
  const out = [];
  for (const p of PLATFORMS) {
    const d = dataset.diagnostics[p];
    const h = dataset.health.sheets[p];
    const add = (n, text) => { if (n) out.push(`${p}: ${text}`); };
    add(h.columns_missing.length, `columns missing: ${h.columns_missing.join(', ')}`);
    add(d.extra_columns.length, `unrecognised columns ignored: ${d.extra_columns.join(', ')}`);
    add(d.skipped.bad_date + d.skipped.no_account + d.skipped.no_campaign, `rows skipped (bad date ${d.skipped.bad_date}, no account ${d.skipped.no_account}, no campaign ${d.skipped.no_campaign})`);
    add(d.no_ad_id_rows, `${d.no_ad_id_rows} rows without ad_id kept at ad set level (THB ${fmt(d.no_ad_id_spend)} spend)`);
    add(d.no_adset_id_rows, `${d.no_adset_id_rows} rows without an ad set / ad group id`);
    add(d.blank_status_rows, `${d.blank_status_rows} rows with blank status; entities left UNKNOWN: ${d.unknown_status.ads} ads, ${d.unknown_status.adsets} ad sets, ${d.unknown_status.campaigns} campaigns`);
    add(Object.keys(d.unrecognised_status).length, `unmapped status values: ${JSON.stringify(d.unrecognised_status)}`);
    add(Object.keys(d.negative_values).length, `negative values: ${JSON.stringify(d.negative_values)}`);
    add(Object.keys(d.unparseable_values).length, `non-numeric cells counted as 0: ${JSON.stringify(d.unparseable_values)}`);
    add(d.odd.link_clicks_gt_clicks, `${d.odd.link_clicks_gt_clicks} rows with link_clicks > clicks`);
    add(d.odd.impressions_without_spend, `${d.odd.impressions_without_spend} rows with impressions but zero spend`);
    add(d.odd.spend_without_impressions, `${d.odd.spend_without_impressions} rows with spend but zero impressions`);
    add(d.odd.zero_delivery, `${d.odd.zero_delivery} rows with zero spend and zero impressions`);
    add(h.duplicates, `${h.duplicates} duplicate rows (${d.duplicates_identical} identical, ${d.duplicates_conflicting} conflicting)`);
    add(h.missing_dates.length, `missing dates: ${h.missing_dates.join(', ')}`);
  }
  return out;
}

// ---------------------------------------------------------------------------------------------
// CLI
// ---------------------------------------------------------------------------------------------

function parseArgs(argv) {
  const opts = { ...DEFAULTS, now: new Date() };
  for (let i = 0; i < argv.length; i++) {
    const flag = argv[i];
    const value = () => {
      if (i + 1 >= argv.length) throw new Error(`${flag} needs a value`);
      return argv[++i];
    };
    if (flag === '--sheets') opts.sheetsDir = resolve(value());
    else if (flag === '--creatives') opts.creativesDir = resolve(value());
    else if (flag === '--out') opts.out = resolve(value());
    else if (flag === '--now') {
      opts.now = new Date(value());
      if (Number.isNaN(opts.now.getTime())) throw new Error('--now must be an ISO date-time, e.g. 2026-10-12T07:05:00+07:00');
    } else if (flag === '--help' || flag === '-h') opts.help = true;
    else throw new Error(`Unknown option ${flag}`);
  }
  return opts;
}

function main(argv) {
  const opts = parseArgs(argv);
  if (opts.help) {
    console.log('Usage: node tools/build-data.mjs [--sheets <dir>] [--creatives <dir>] [--out <file>] [--now <iso>]');
    console.log(`The sheets folder needs meta.csv, tiktok.csv and google.csv; ${Object.values(BREAKDOWN_FILES).join(' and ')} are optional (placement and audience breakdowns).`);
    return;
  }
  const result = buildSample(opts);
  mkdirSync(dirname(opts.out), { recursive: true });
  writeFileSync(opts.out, result.text);
  const rel = relative(process.cwd(), opts.out);
  console.log(summarize(result, rel && !rel.startsWith('..') ? rel : opts.out));
}

// Run only when executed directly, not when imported by the tests.
if (process.argv[1] && realpathSync(resolve(process.argv[1])) === realpathSync(fileURLToPath(import.meta.url))) {
  try {
    main(process.argv.slice(2));
  } catch (err) {
    console.error(`build-data failed: ${err.message}`);
    process.exitCode = 1;
  }
}
