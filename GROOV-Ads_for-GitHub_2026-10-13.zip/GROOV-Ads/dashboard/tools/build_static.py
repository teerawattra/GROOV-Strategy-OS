#!/usr/bin/env python3
"""Build the generated data files the GROOV Ads dashboard loads with plain <script> tags.

Inputs are read only. Ads/ is the parent folder of dashboard/:
    accounts/registry.json                      -> public/data/registry.js   (window.GROOV_REGISTRY)
    learnings/LOG.md, PLAYBOOK.md, rules.json   -> public/data/learnings.js  (window.GROOV_LEARNINGS)

Run from any directory:
    python3 "<Ads>/dashboard/tools/build_static.py"

Optional arguments (the VPS server uses them; the defaults are the paths above):
    --registry PATH        registry.json to read
    --learnings-dir DIR    folder holding LOG.md, PLAYBOOK.md and rules.json
    --out-dir DIR          where registry.js and learnings.js are written

Standard library only, Python 3.9+. The output shape follows DATA_CONTRACT.md section 4.
"""
import argparse
import json
import re
import sys
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent  # Ads/dashboard/tools
DASH = HERE.parent  # Ads/dashboard
ADS = DASH.parent  # Ads
REGISTRY_SRC = ADS / "accounts" / "registry.json"
LOG_SRC = ADS / "learnings" / "LOG.md"
PLAYBOOK_SRC = ADS / "learnings" / "PLAYBOOK.md"
RULES_SRC = ADS / "learnings" / "rules.json"
OUT_DIR = DASH / "public" / "data"

# Name as written in the notes -> registry client name. None = not a registry client, ignored.
CLIENT_ALIASES = {
    "The Peak": "The Peak Clinic",
    "AT EASE": "AT EASE Clinic",
    "Rena": "Rena Yakiniku",
    "Tharaville": "Tharasiri (via Bake Bread Digital)",
    "Tharasiri": "Tharasiri (via Bake Bread Digital)",
    "Birdie Pool Villa": "Birdie Pool Villa",
    "GROOV in-house": "GROOV Strategy (in-house)",
    "Anchor Buffet": "Anchor Buffet",
    "5 YEN": "5 YEN IZAKAYA",
    "SOWELL": "SOWELL",
    "Niku Machi": None,
}

# applies_to tags (exact match) and scope text (whole words) -> vertical.
VERTICAL_KEYWORDS = {
    "clinic": "Clinic",
    "f&b": "F&B",
    "buffet": "F&B",
    "real-estate": "Real Estate",
    "real estate": "Real Estate",
    "hotel": "Hotel",
}

LOG_HEADING = re.compile(r"^## (L-\d+) \u00b7 (\d{4}-\d{2}-\d{2}) \u00b7 (.+)$")
LOG_FIELD = re.compile(r"^- \*\*([^*]+?):\*\*\s*(.*)$")
LOG_REQUIRED = ("scope", "evidence", "sample", "confidence", "status", "applies_to", "next")
RULE_HEADER = ("rule", "confidence", "evidence")
OPEN_QUESTIONS = "open questions to test"


def fail(message):
    sys.exit("build_static: " + message)


def read_text(path):
    if not path.is_file():
        fail(f"missing source file {path}")
    return path.read_text(encoding="utf-8-sig")


def load_json(path):
    return json.loads(read_text(path))


def unbold(text):
    """Drop markdown bold markers. Backticks and everything else stay."""
    return text.replace("**", "")


def one_line(text):
    return unbold(text).strip()


def name_pattern(name):
    """Case-insensitive whole-phrase match: no letter or digit may touch either end."""
    return re.compile(r"(?<!\w)" + re.escape(name) + r"(?!\w)", re.IGNORECASE)


class ClientMatcher:
    """Finds registry clients by full name or alias. Results come back in registry order."""

    def __init__(self, client_names):
        self.rank = {name: i for i, name in enumerate(client_names)}
        self.patterns = [(name_pattern(name), name) for name in client_names]
        for alias, target in CLIENT_ALIASES.items():
            if target is None:
                continue
            if target not in self.rank:
                fail(f"alias {alias!r} points at {target!r}, which is not in registry.json")
            self.patterns.append((name_pattern(alias), target))

    def find(self, text):
        hits = {client for pattern, client in self.patterns if pattern.search(text)}
        return sorted(hits, key=self.rank.get)


def verticals_for(tags, scope, clients, vertical_of):
    """Verticals from applies_to tags, then scope text, then each matched client's registry vertical."""
    found = []

    def add(vertical):
        if vertical and vertical not in found:
            found.append(vertical)

    for tag in tags:
        add(VERTICAL_KEYWORDS.get(tag.lower()))
    for keyword, vertical in VERTICAL_KEYWORDS.items():
        if name_pattern(keyword).search(scope):
            add(vertical)
    for client in clients:
        add(vertical_of.get(client))
    return found


# ---------------------------------------------------------------- LOG.md

def field_key(label):
    low = label.lower()
    if low.startswith("evidence"):  # label carries the period, e.g. "Evidence (14–20 Sep 2026)"
        return "evidence"
    return "applies_to" if low == "applies to" else low


def is_footnote(line):
    """A top-level italic line such as *Source for L-001 to L-005: ...*, not a bold label."""
    text = line.strip()
    return (line[:1] not in (" ", "\t") and len(text) > 2 and text.startswith("*")
            and text.endswith("*") and not text.startswith("**"))


def parse_log(text):
    """Raw entries in file order (newest first), and the trailing *Source...* footnote if present."""
    entries, source_note = [], None
    entry, key = None, None
    for line in text.splitlines():
        line = line.rstrip()
        stripped = line.strip()
        heading = LOG_HEADING.match(line)
        if heading:
            entry = {"id": heading.group(1), "date": heading.group(2),
                     "title": one_line(heading.group(3)), "fields": {}}
            entries.append(entry)
            key = None
        elif line.startswith("## "):  # any other ## section ends the current entry
            entry, key = None, None
        elif is_footnote(line):
            if stripped[1:].startswith("Source"):
                source_note = stripped.strip("*").strip()
            entry, key = None, None
        elif entry is None or not stripped or stripped == "---":
            continue  # preamble, blank lines and separators
        else:
            field = LOG_FIELD.match(line)
            if field:
                label = field.group(1).strip()
                key = field_key(label)
                entry["fields"][key] = {"label": label, "inline": field.group(2), "more": []}
            elif key is not None:
                entry["fields"][key]["more"].append(line)  # indented sub-bullets, wrapped text
    return entries, source_note


def field_value(key, field):
    if key != "evidence":
        parts = [field["inline"].strip()] + [line.strip() for line in field["more"]]
        return one_line(" ".join(part for part in parts if part))
    # Evidence keeps its markdown: inline text first, then the sub-bullets moved to the top level.
    subs = [line.rstrip() for line in field["more"] if line.strip()]
    if subs:
        cut = min(len(line) - len(line.lstrip(" ")) for line in subs)
        subs = [line[cut:] for line in subs]
    head = [field["inline"].strip()] if field["inline"].strip() else []
    return "\n".join(unbold(line).rstrip() for line in head + subs)


def build_log(entries, matcher, vertical_of):
    log = []
    for entry in entries:
        fields = entry["fields"]
        missing = [name for name in LOG_REQUIRED if name not in fields]
        if missing:
            print(f"WARNING {entry['id']}: missing {', '.join(missing)}", file=sys.stderr)
        value = {key: field_value(key, field) for key, field in fields.items()}
        scope = value.get("scope", "")
        evidence = value.get("evidence", "")
        tags = [tag.strip() for tag in value.get("applies_to", "").split(",") if tag.strip()]
        clients = matcher.find("\n".join([entry["title"], scope, evidence]))
        log.append({
            "id": entry["id"],
            "date": entry["date"],
            "title": entry["title"],
            "scope": scope,
            "evidence_label": fields["evidence"]["label"] if "evidence" in fields else "",
            "evidence": evidence,
            "sample": value.get("sample", ""),
            "confidence": value.get("confidence", ""),
            "status": value.get("status", ""),
            "applies_to": tags,
            "next": value.get("next", ""),
            "clients": clients,
            "verticals": verticals_for(tags, scope, clients, vertical_of),
        })
    return log


# ---------------------------------------------------------------- PLAYBOOK.md

def normalise_vertical(name, registry_verticals):
    for vertical in registry_verticals:
        if vertical.lower() == name.lower():
            return vertical
    return VERTICAL_KEYWORDS.get(name.lower(), name)  # "Cross-vertical" stays as written


def split_row(line):
    cells = line.strip()
    if cells.startswith("|"):
        cells = cells[1:]
    if cells.endswith("|"):
        cells = cells[:-1]
    return [cell.strip() for cell in cells.split("|")]


def is_separator(cells):
    return all(re.fullmatch(r":?-+:?", cell) for cell in cells)


def parse_rules(lines):
    """Rules from the '| Rule | Confidence | Evidence |' table, or None when the section has no table."""
    start = None
    for i, line in enumerate(lines):
        if line.strip().startswith("|") and tuple(c.lower() for c in split_row(line)) == RULE_HEADER:
            start = i + 1
            break
    if start is None:
        return None
    rules = []
    for line in lines[start:]:
        if not line.strip().startswith("|"):
            if rules:
                break  # table has ended
            continue
        cells = split_row(line)
        if is_separator(cells) or len(cells) < 3:
            continue
        rules.append({
            "rule": one_line(cells[0]),
            "confidence": one_line(cells[1]),
            "evidence": re.findall(r"L-\d+", cells[2]),
        })
    return rules


def italic_note(lines):
    for line in lines:
        text = line.strip()
        if len(text) > 2 and text.startswith("*") and text.endswith("*") and not text.startswith("**"):
            return text.strip("*").strip()
    return None


def parse_playbook(text, registry_verticals):
    blocks = []  # (heading, body lines) for each "## " section; the preamble is dropped
    for line in text.splitlines():
        if line.startswith("## "):
            blocks.append((line[3:].strip(), []))
        elif blocks:
            blocks[-1][1].append(line)

    sections, open_questions = [], []
    for heading, lines in blocks:
        if heading.lower() == OPEN_QUESTIONS:
            open_questions += [one_line(line.strip()[2:]) for line in lines if line.strip().startswith("- ")]
            continue
        rules = parse_rules(lines)
        sections.append({
            "vertical": normalise_vertical(heading, registry_verticals),
            "rules": rules or [],
            "note": None if rules is not None else italic_note(lines),
        })
    return {"sections": sections, "open_questions": open_questions}


# ---------------------------------------------------------------- output

def to_js(data):
    text = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    # U+2028 and U+2029 are legal inside JSON strings but were syntax errors in JS literals before ES2019.
    return text.replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")


def shown(path):
    """Path relative to the dashboard folder when it is inside it, else as given."""
    try:
        return path.resolve().relative_to(DASH)
    except ValueError:
        return path


def summarise(registry, log, playbook, rules, written, out_dir=OUT_DIR):
    sections = playbook["sections"]
    total = sum(len(section["rules"]) for section in sections)
    per_section = ", ".join(f"{section['vertical']} {len(section['rules'])}" for section in sections)
    print(f"registry: {len(registry['clients'])} clients")
    print(f"log: {len(log)} entries, newest first")
    for entry in log:
        clients = ", ".join(entry["clients"]) or "none"
        verticals = ", ".join(entry["verticals"]) or "none"
        print(f"  {entry['id']}  clients: {clients}  |  verticals: {verticals}")
    print(f"playbook: {len(sections)} sections, {total} rules ({per_section}); "
          f"{len(playbook['open_questions'])} open questions")
    print(f"rules.json: {len(rules.get('checks', []))} checks, {len(rules.get('benchmarks', []))} benchmarks")
    for name, text in written:
        print(f"wrote {shown(out_dir / name)} ({len(text.encode('utf-8'))} bytes)")


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description="Build registry.js and learnings.js for the GROOV Ads dashboard.")
    parser.add_argument("--registry", type=Path, default=REGISTRY_SRC,
                        help="registry.json to read (default: Ads/accounts/registry.json)")
    parser.add_argument("--learnings-dir", type=Path, default=None,
                        help="folder with LOG.md, PLAYBOOK.md and rules.json (default: Ads/learnings)")
    parser.add_argument("--out-dir", type=Path, default=OUT_DIR,
                        help="where registry.js and learnings.js are written (default: dashboard/public/data)")
    return parser.parse_args(argv)


def main(argv=None):
    args = parse_args(argv)
    registry_src = args.registry
    if args.learnings_dir is None:
        log_src, playbook_src, rules_src = LOG_SRC, PLAYBOOK_SRC, RULES_SRC
    else:
        log_src = args.learnings_dir / "LOG.md"
        playbook_src = args.learnings_dir / "PLAYBOOK.md"
        rules_src = args.learnings_dir / "rules.json"
    out_dir = args.out_dir

    registry = load_json(registry_src)
    clients = registry["clients"]
    client_names = [client["client"] for client in clients]
    if len(set(client_names)) != len(client_names):
        fail("duplicate client names in registry.json")
    vertical_of = {client["client"]: client.get("vertical") for client in clients}
    registry_verticals = sorted({vertical for vertical in vertical_of.values() if vertical})

    entries, source_note = parse_log(read_text(log_src))
    if not entries:
        fail("no '## L-nnn' entries found in LOG.md")
    log = build_log(entries, ClientMatcher(client_names), vertical_of)
    playbook = parse_playbook(read_text(playbook_src), registry_verticals)
    rules = load_json(rules_src)

    learnings = {
        "generated_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "log": log,
        "playbook": playbook,
        "rules": rules,
    }
    if source_note:
        learnings["source_note"] = source_note

    registry_js = "window.GROOV_REGISTRY = " + to_js(registry) + ";\n"
    learnings_js = "window.GROOV_LEARNINGS = " + to_js(learnings) + ";\n"
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "registry.js").write_text(registry_js, encoding="utf-8")
    (out_dir / "learnings.js").write_text(learnings_js, encoding="utf-8")

    summarise(registry, log, playbook, rules,
              [("registry.js", registry_js), ("learnings.js", learnings_js)], out_dir)


if __name__ == "__main__":
    main()
