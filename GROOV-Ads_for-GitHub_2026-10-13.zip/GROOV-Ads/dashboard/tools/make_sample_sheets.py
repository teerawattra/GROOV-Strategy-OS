#!/usr/bin/env python3
"""Turn Hermes's frozen Windsor snapshot (command-center/source/*.json, 7–20 Sep 2026) into the
three Google Sheets exactly as DATA_CONTRACT.md §1 defines them, written as CSV:

    sample/sheets/meta.csv · sample/sheets/tiktok.csv · sample/sheets/google.csv

Real values only: fields the snapshot never had stay blank (e.g. Meta effective_status for ads
missing from the status export). Google rows are summed from ad level to ad-group level, which is
the Sheet's grain.
"""
import csv
import json
from collections import OrderedDict
from pathlib import Path

HERE = Path(__file__).resolve().parent
DASH = HERE.parent
SRC = DASH.parent / "command-center" / "source"
OUT = DASH / "sample" / "sheets"

META = ["date", "account_id", "account_name", "campaign_id", "campaign", "campaign_objective", "adset_id", "adset_name",
        "ad_id", "ad_name", "effective_status", "spend", "impressions", "reach", "clicks", "link_clicks", "actions_video_view",
        "actions_onsite_conversion_messaging_conversation_started_7d", "actions_lead", "purchase_roas_omni_purchase",
        "image_url", "ad_preview_shareable_link"]
TIKTOK = ["date", "account_id", "account_name", "campaign_id", "campaign", "objective_type", "campaign_status", "adgroup_id",
          "adgroup_name", "ad_id", "ad_name", "spend", "impressions", "reach", "clicks", "total_play",
          "messaging_total_conversation_tiktok_direct_message", "messaging_total_conversation_instant_messaging_app",
          "onsite_form", "conversions", "complete_payment_roas", "video_thumbnail_url"]
GOOGLE = ["date", "account_id", "account_name", "campaign_id", "campaign", "advertising_channel_type", "campaign_status",
          "ad_group_id", "ad_group_name", "ad_group_status", "spend", "impressions", "clicks", "conversions", "conversion_value"]


def load(name):
    return json.loads((SRC / name).read_text(encoding="utf-8"))


def clean(v):
    if v is None or v == "None":
        return ""
    if isinstance(v, float):
        return f"{v:.6f}".rstrip("0").rstrip(".") if v != int(v) else str(int(v))
    return str(v)


def write(name, header, rows):
    OUT.mkdir(parents=True, exist_ok=True)
    with open(OUT / name, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(header)
        for r in rows:
            w.writerow([clean(r.get(h)) for h in header])
    print(f"{name}: {len(rows)} rows")


def main():
    status = {str(s.get("ad_id")): s.get("effective_status") for s in load("meta-status.json") if s.get("ad_id")}
    meta = []
    for r in load("meta-ad-daily.json"):
        row = dict(r)
        row["campaign_objective"] = r.get("objective") or r.get("campaign_objective")
        row["effective_status"] = status.get(str(r.get("ad_id")))
        meta.append(row)
    meta.sort(key=lambda r: (r["date"], str(r["account_id"]), str(r["ad_id"])))
    write("meta.csv", META, meta)

    tiktok = sorted(load("tiktok-ad-daily.json"), key=lambda r: (r["date"], str(r["account_id"]), str(r["ad_id"])))
    write("tiktok.csv", TIKTOK, tiktok)

    groups = OrderedDict()
    for r in sorted(load("google-ad-daily.json"), key=lambda r: (r["date"], str(r["campaign_id"]), str(r.get("ad_group_id")))):
        key = (r["date"], str(r["campaign_id"]), str(r.get("ad_group_id") or ""))
        g = groups.get(key)
        if g is None:
            g = {k: r.get(k) for k in GOOGLE if k not in ("spend", "impressions", "clicks", "conversions", "conversion_value")}
            g.update(spend=0.0, impressions=0.0, clicks=0.0, conversions=0.0, conversion_value=0.0)
            groups[key] = g
        for k in ("spend", "impressions", "clicks", "conversions", "conversion_value"):
            g[k] += float(r.get(k) or 0)
    google = []
    for g in groups.values():
        for k in ("spend", "conversions", "conversion_value"):
            g[k] = round(g[k], 4)
        for k in ("impressions", "clicks"):
            g[k] = int(round(g[k]))
        google.append(g)
    write("google.csv", GOOGLE, google)


if __name__ == "__main__":
    main()
