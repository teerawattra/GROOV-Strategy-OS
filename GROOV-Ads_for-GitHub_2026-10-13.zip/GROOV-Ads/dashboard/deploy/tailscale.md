# Publishing the dashboard on the tailnet (Tailscale Serve)

The server listens on `127.0.0.1:8787` only. `tailscale serve` gives it an HTTPS address that **only devices in Finn's
tailnet** can reach, and tells the server who is asking. There is no password and no login page to fill in.

```
Finn's Mac / phone (Tailscale on) ──HTTPS──► https://<vps>.<tailnet>.ts.net ──tailscale serve──► http://127.0.0.1:8787
                                               adds Tailscale-User-Login / -Name          server checks ALLOWED_USERS
```

## 1. Before you start
- Tailscale is installed on the VPS and logged into Finn's tailnet: `tailscale status` lists this machine.
- HTTPS certificates are enabled for the tailnet: admin console (login.tailscale.com) → **DNS** → MagicDNS on, and
  **HTTPS Certificates** → Enable. Without this, `tailscale serve` cannot give out an `https://…ts.net` address.
- The server runs: `systemctl status groov-cc` is active, and on the VPS
  `curl -s -o /dev/null -w "%{http_code}\n" http://127.0.0.1:8787/` prints `401` (no Tailscale identity on a direct
  request, so it is refused: that is correct).

## 2. Publish (once; it survives reboots)
```bash
sudo tailscale serve --bg --https=443 http://127.0.0.1:8787
tailscale serve status
```
`tailscale serve status` shows something like:
```
https://groov-vps.tail1234.ts.net (tailnet only)
|-- / proxy http://127.0.0.1:8787
```
That address is the dashboard. Send it to Finn.

**Never run `tailscale funnel`.** Funnel puts a service on the public internet. The server also refuses requests that
arrive through Funnel (they carry `Tailscale-Funnel-Request`), but do not rely on that. Never open port 8787 in a
firewall and never set `HOST` to anything but `127.0.0.1` (the server refuses to start if you do).

To stop publishing: `sudo tailscale serve --https=443 off` (or `sudo tailscale serve reset` to remove every serve rule).

## 3. Who can open it
- `tailscale serve` adds `Tailscale-User-Login` (for example `finn@groovstrategy.co`, or `name@github` for a GitHub
  login) and `Tailscale-User-Name` to each request from a **person's** device. The server trusts these headers only
  because it listens on 127.0.0.1, where nothing but this machine can reach it.
- Devices logged in with a **tag** (servers, shared devices) carry no user, so they get the "Open this dashboard
  through your Tailscale address" page (401). Use a personal login on the device.
- `ALLOWED_USERS` in `groov.env`: comma-separated Tailscale logins. Empty means anyone in the tailnet. Others get
  "Your Tailscale account (…) is not on this dashboard's allow-list" (403).
- `OWNER_USERS`: who sees **Refresh data now** (owners are always allowed in).
- The exact login names: admin console → **Users**, or `tailscale status` on a device.
- After changing either list: `sudo systemctl restart groov-cc` (settings are read at start).
- Optional extra fence: Tailscale access controls (admin console → **Access controls**) can limit which users may reach
  this machine at all.

## 4. Finn (and the team) on a Mac or phone
1. Install Tailscale: tailscale.com/download (Mac: App Store or the standalone app; iPhone / Android: the app store).
2. Log in with the same account (identity provider) the tailnet uses, and switch Tailscale **on**.
3. Open the `https://<vps>.<tailnet>.ts.net` address in any browser. The sidebar footer says
   "Signed in via Tailscale as <login>".
4. Bookmark it (or "Add to Home Screen" on the phone).

To add someone: admin console → **Users** → **Invite users**; once they have joined, add their login to `ALLOWED_USERS`
(if the list is not empty) and restart `groov-cc`.

## 5. Check it end to end
| Check | Expected |
|---|---|
| On the VPS: `curl -s -o /dev/null -w "%{http_code}\n" http://127.0.0.1:8787/` | `401` |
| On the VPS: `curl -s http://127.0.0.1:8787/healthz` | `{"ok":true,"snapshot":"<version>"}` |
| `tailscale serve status` | `https://…ts.net (tailnet only)` proxying to `http://127.0.0.1:8787` |
| Finn's browser on the tailnet | the dashboard, footer "Signed in via Tailscale as …" |
| A phone **not** on Tailscale | the address does not resolve or connect at all |

## 6. Troubleshooting
| What you see | Why | Fix |
|---|---|---|
| "Open this dashboard through your Tailscale address" | the request has no Tailscale identity: opened by IP / `http://127.0.0.1`, from a tagged device, or `serve` is off | use the `https://…ts.net` address from a personal login; `tailscale serve status` |
| "…is not on this dashboard's allow-list" | the login is not in `ALLOWED_USERS` | add it (Finn approves), restart `groov-cc` |
| Browser certificate warning | HTTPS certificates not enabled for the tailnet | admin console → DNS → HTTPS Certificates → Enable, then run the serve command again |
| `tailscale serve` says the port is taken | another serve rule on 443 | `tailscale serve status`; remove the old rule or use `--https=8443` and that address |
| 502 Bad Gateway | the server is not running | `systemctl status groov-cc`, `journalctl -u groov-cc -n 50` |
