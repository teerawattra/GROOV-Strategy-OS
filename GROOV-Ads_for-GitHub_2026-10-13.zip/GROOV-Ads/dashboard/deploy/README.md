# deploy/: running the GROOV Command Center on the VPS

Reference for the files in this folder. The step-by-step install is `HERMES.md` (Part B); publishing on the tailnet is
`tailscale.md`.

| File | What it is |
|---|---|
| `groov-cc.service` | the dashboard server (`node server/cli.mjs serve`), `Restart=always` |
| `groov-cc-refresh.service` | the daily data job (`node server/cli.mjs refresh`), one-shot |
| `groov-cc-refresh.timer` | starts the job every day at 07:00 Bangkok (`OnCalendar=*-*-* 07:00:00 Asia/Bangkok`) |
| `groov-cc-refresh.cron` | the same schedule for cron, if this systemd has no timezone support (`0 0 * * *` = 00:00 UTC = 07:00 Bangkok) |
| `groov-cc.logrotate` | log rotation, only for the cron alternative (systemd logs go to the journal) |
| `tailscale.md` | `tailscale serve`, who can open the dashboard, how Finn joins from a Mac or phone |

## Layout these files assume
```
/opt/data/.env                  MCP_WINDSOR_API_KEY (Hermes's existing key file, chmod 600; never copied elsewhere)
/opt/data/groov-cc/
  app/                          this package (replaced on upgrade); WorkingDirectory of both units
  config/                       copied from app/config on the first install, then maintained here (CONFIG_DIR)
  data/                         raw partitions, snapshots, creatives, generated /data/*.js (DATA_DIR)
  groov.env                     settings from app/config/groov.env.example (chmod 600, no secrets)
  CHANGELOG.md                  Hermes's record of changes
```
Both units read **two** environment files, `/opt/data/.env` and `/opt/data/groov-cc/groov.env`. For a command run by
hand, load them the same way from inside `app/`:
```bash
cd /opt/data/groov-cc/app
set -a; . /opt/data/.env; . ../groov.env; set +a
node server/cli.mjs status
```
Run manual commands as the **same user** as the units (`sudo -u <user> …`), so every file in `data/` stays writable by
the daily job. `GROOV_ENV_FILE=/path/to/file` is an optional extra file; it never overrides variables already set.

## Commands (run inside app/)
| Command | What it does | Exit code |
|---|---|---|
| `node server/cli.mjs serve` | the dashboard on 127.0.0.1:8787 (the service runs this) | runs until stopped |
| `node server/cli.mjs refresh [--days N] [--force]` | pull the last N complete days, new snapshot, new creatives | 0 ok · 1 failed · 75 skipped (another job running) |
| `node server/cli.mjs backfill --from YYYY-MM-DD [--to …] [--datasets a,b] [--force]` | history; resumable (stored days are skipped unless `--force`) | same |
| `node server/cli.mjs snapshot` | rebuild the snapshot from stored data (no Windsor calls) | 0 · 1 · 75 |
| `node server/cli.mjs images` | save creatives of ads that ran in the last 7 days | 0 · 1 · 75 |
| `node server/cli.mjs status [--json]` | stored days, rows, gaps in the last 60 days, snapshot versions, creatives, last run, lock | 0 |
| `node server/cli.mjs rollback [--to VERSION]` | serve the previous snapshot (or VERSION) | 0 · 1 · 75 |
| `node server/cli.mjs seed-creatives seed/creatives` | copy the saved creative library into `data/creatives` (once) | 0 · 1 |
| `node server/cli.mjs build-static` | rebuild `/data/registry.js`, `learnings.js`, `modules.js` after editing `config/` | 0 · 1 |

After an edit in `config/`, the server also rebuilds the `/data/*.js` files by itself the next time the dashboard
loads; `build-static` does it at once and shows the result.

## Rolling back a bad snapshot
Every refresh writes a new version under `data/snapshots/<version>/` and then switches `data/current.json` to it; the
last 3 versions are kept. To serve the previous one:
```bash
node server/cli.mjs status                # "current" and "previous" versions, and every version kept
node server/cli.mjs rollback              # serve the previous version
node server/cli.mjs rollback --to <ver>   # or a specific one from the status list (also to go forward again)
```
The server notices the switch within about two seconds; no restart. The next daily refresh builds a new version from
the raw data again, so fix whatever made the bad snapshot first (status shows the last run's error and warnings).
If a version is missing or damaged, the server keeps serving the one it has and logs why.

Only if the CLI cannot run at all: write the JSON below to a temp file in `data/` and `mv` it over `data/current.json`
(the move is atomic; `version` must be a folder name from `data/snapshots/`):
```json
{"schema":1,"version":"<version>","previous":null,"updated_at":"<now, ISO 8601>","reason":"rollback"}
```

## Logs
- `journalctl -u groov-cc -n 100` (server) and `journalctl -u groov-cc-refresh -n 100` (daily job).
- Lines carry counts, dates and plain-language errors only: never the Windsor key, never a URL (image links carry
  signed tokens and are not logged either).
- Cron alternative: `/opt/data/groov-cc/logs/refresh.log`, rotated weekly by `groov-cc.logrotate`.

## Timer check
```bash
systemd-analyze calendar '*-*-* 07:00:00 Asia/Bangkok'   # must print the next run, 00:00:00 UTC
systemctl list-timers groov-cc-refresh.timer
```
If the first command reports an error, this systemd is too old for timezone names: set
`OnCalendar=*-*-* 00:00:00 UTC` in the timer (same moment; Thailand has no daylight saving time) or use the cron file.
