import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { parseCsv } from '../lib/csv.mjs';
import { MONTHLY_COLS, ROW_COLS, SHEET_COLUMNS, meta, monthly, normalize, sliceRows } from '../lib/normalize.mjs';

// ---------------------------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------------------------

const NOW = new Date('2026-10-12T00:05:00Z'); // 07:05 in Bangkok
const sheetText = (name) => readFileSync(fileURLToPath(new URL(`../sample/sheets/${name}.csv`, import.meta.url)), 'utf8');
const loadSample = () => ({ meta: parseCsv(sheetText('meta')), tiktok: parseCsv(sheetText('tiktok')), google: parseCsv(sheetText('google')) });
const run = (sheets, options = {}) => normalize(sheets, { mode: 'sample', now: NOW, ...options });

const near = (actual, expected, tolerance, label) =>
  assert.ok(Math.abs(actual - expected) <= tolerance, `${label}: ${actual} differs from ${expected} by more than ${tolerance}`);
const sumOf = (list, pick) => list.reduce((total, item) => total + pick(item), 0);
const num = (cell) => (cell === '' || cell === undefined ? 0 : Number(cell));
const col = (name) => ROW_COLS.indexOf(name);

/** One full Windsor row (every header present, blank by default) with sensible defaults, plus overrides. */
const blank = (platform) => Object.fromEntries(SHEET_COLUMNS[platform].map((c) => [c, '']));
const metaRow = (o = {}) => ({
  ...blank('meta'), date: '2026-09-14', account_id: '1001', account_name: 'Acme Co', campaign_id: '9001', campaign: 'Campaign One',
  campaign_objective: 'OUTCOME_LEADS', adset_id: '8001', adset_name: 'Ad Set One', ad_id: '7001', ad_name: 'Ad One',
  effective_status: 'ACTIVE', spend: '100', impressions: '1000', reach: '800', clicks: '50', link_clicks: '40', ...o,
});
const tiktokRow = (o = {}) => ({
  ...blank('tiktok'), date: '2026-09-14', account_id: '2001', account_name: 'Tok Co', campaign_id: '9101', campaign: 'TikTok Campaign',
  objective_type: 'REACH', campaign_status: 'CAMPAIGN_STATUS_ENABLE', adgroup_id: '8101', adgroup_name: 'Group One', ad_id: '7101',
  ad_name: 'Video One', spend: '50', impressions: '2000', reach: '1900', clicks: '30', total_play: '1500', ...o,
});
const googleRow = (o = {}) => ({
  ...blank('google'), date: '2026-09-14', account_id: '206-171-2197', account_name: 'Goo Co', campaign_id: '9201', campaign: 'Search Campaign',
  advertising_channel_type: 'SEARCH', campaign_status: 'ENABLED', ad_group_id: '8201', ad_group_name: 'Package1', ad_group_status: 'ENABLED',
  spend: '75.5', impressions: '300', clicks: '12', conversions: '1.5', conversion_value: '900', ...o,
});

const find = (list, key) => {
  const hit = list.find((e) => e.key === key);
  assert.ok(hit, `entity ${key} exists`);
  return hit;
};
const platformOf = (entity) => entity.key.split(':')[0];
/** The contract row for the first fact row of an ad (or campaign, for Google) in a payload. */
const rowOfAd = (payload, adKey) => payload.rows.find((r) => r[3] >= 0 && payload.ads[r[3]].key === adKey);

/** Small deterministic PRNG so the "shuffled input" tests are reproducible. */
function shuffled(list, seed = 7) {
  const out = list.slice();
  let s = seed;
  for (let i = out.length - 1; i > 0; i--) {
    s = (s * 1664525 + 1013904223) % 4294967296;
    const j = s % (i + 1);
    [out[i], out[j]] = [out[j], out[i]];
  }
  return out;
}

// ---------------------------------------------------------------------------------------------
// Real data: reconciliation against the CSV (7-20 Sep 2026)
// ---------------------------------------------------------------------------------------------

describe('sample data reconciles with the CSV column sums', () => {
  const sheets = loadSample();
  const payload = sliceRows(run(sheets));
  const rowsOf = (platform) => payload.rows.filter((r) => platformOf(payload.campaigns[r[1]]) === platform);

  it('keeps every CSV row as exactly one fact row', () => {
    assert.equal(rowsOf('meta').length, 2564);
    assert.equal(rowsOf('tiktok').length, 253);
    assert.equal(rowsOf('google').length, 113);
    assert.equal(payload.rows.length, 2930);
  });

  for (const platform of ['meta', 'tiktok', 'google']) {
    it(`${platform}: total spend over the full range equals the CSV spend column to 0.01`, () => {
      near(sumOf(rowsOf(platform), (r) => r[col('spend')]), sumOf(sheets[platform], (r) => num(r.spend)), 0.01, `${platform} spend`);
    });
  }

  it('matches totals derived independently of this code base (Python, same CSVs)', () => {
    near(sumOf(rowsOf('meta'), (r) => r[col('spend')]), 155403.02, 0.01, 'meta');
    near(sumOf(rowsOf('tiktok'), (r) => r[col('spend')]), 7402.27, 0.01, 'tiktok');
    near(sumOf(rowsOf('google'), (r) => r[col('spend')]), 16617.7495, 0.01, 'google');
  });

  // contract column -> source column(s) that are added together, per sheet (§2.2 mapping table)
  const mapping = {
    meta: {
      impressions: ['impressions'], reach: ['reach'], clicks: ['clicks'], link_clicks: ['link_clicks'], video_views: ['actions_video_view'],
      messages: ['actions_onsite_conversion_messaging_conversation_started_7d'], leads: ['actions_lead'],
    },
    tiktok: {
      impressions: ['impressions'], reach: ['reach'], clicks: ['clicks'], link_clicks: ['clicks'], video_views: ['total_play'],
      messages: ['messaging_total_conversation_tiktok_direct_message', 'messaging_total_conversation_instant_messaging_app'],
      leads: ['onsite_form'], conversions: ['conversions'],
    },
    google: { impressions: ['impressions'], clicks: ['clicks'], link_clicks: ['clicks'], conversions: ['conversions'], conv_value: ['conversion_value'] },
  };
  for (const [platform, columns] of Object.entries(mapping)) {
    it(`${platform}: every mapped metric sums to its source column(s)`, () => {
      for (const [contractCol, sourceCols] of Object.entries(columns)) {
        const expected = sumOf(sheets[platform], (r) => sumOf(sourceCols, (c) => num(r[c])));
        near(sumOf(rowsOf(platform), (r) => r[col(contractCol)]), expected, 0.01, `${platform}.${contractCol}`);
      }
    });
  }

  it('metrics the platform does not supply are 0, and Google reach is null', () => {
    assert.ok(rowsOf('google').every((r) => r[col('reach')] === null && r[col('video_views')] === 0 && r[col('messages')] === 0 && r[col('leads')] === 0 && r[col('roas_value')] === 0));
    assert.ok(rowsOf('meta').every((r) => r[col('conversions')] === 0 && r[col('conv_value')] === 0 && Number.isFinite(r[col('reach')])));
    assert.ok(rowsOf('tiktok').every((r) => r[col('conv_value')] === 0 && Number.isFinite(r[col('reach')])));
  });

  it('roas_value is ROAS x spend, so it can be summed', () => {
    const expected = sumOf(sheets.meta, (r) => num(r.purchase_roas_omni_purchase) * num(r.spend));
    const nonBlank = sheets.meta.filter((r) => r.purchase_roas_omni_purchase !== '').length;
    assert.ok(nonBlank > 0 && expected > 0, 'sample has tracked ROAS');
    near(sumOf(rowsOf('meta'), (r) => r[col('roas_value')]), expected, 0.005 * nonBlank + 0.01, 'meta roas_value');
  });

  it('every number is finite and there is no NaN, undefined or -0 anywhere in the payload', () => {
    for (const r of payload.rows) {
      for (let i = 4; i < r.length; i++) {
        assert.ok(r[i] === null ? i === col('reach') : Number.isFinite(r[i]) && !Object.is(r[i], -0), `row ${r.slice(0, 4)} col ${ROW_COLS[i]}`);
      }
    }
    assert.deepEqual(JSON.parse(JSON.stringify(payload)), payload, 'lossless through JSON');
  });

  it('keeps 18-digit Meta ids exactly (they exceed 2^53, so they must stay strings)', () => {
    const ids = new Set(sheets.meta.map((r) => r.ad_id));
    const got = new Set(payload.ads.filter((a) => platformOf(a) === 'meta').map((a) => a.id));
    assert.deepEqual(got, ids);
    assert.ok([...ids].some((id) => id.length === 18));
  });
});

// ---------------------------------------------------------------------------------------------
// Real data: structural integrity
// ---------------------------------------------------------------------------------------------

describe('sample data structure', () => {
  const payload = sliceRows(run(loadSample()));
  const { accounts, campaigns, adsets, ads, rows } = payload;

  it('every row points at valid entities of its own platform and hierarchy', () => {
    for (const r of rows) {
      const campaign = campaigns[r[1]];
      assert.ok(campaign, `campaign index ${r[1]}`);
      const platform = platformOf(campaign);
      assert.equal(platformOf(accounts[campaign.account]), platform);
      if (r[2] >= 0) {
        const adset = adsets[r[2]];
        assert.ok(adset, `adset index ${r[2]}`);
        assert.equal(platformOf(adset), platform);
        assert.equal(adset.campaign, r[1], 'ad set belongs to the row campaign');
      }
      if (r[3] >= 0) {
        const ad = ads[r[3]];
        assert.ok(ad, `ad index ${r[3]}`);
        assert.equal(platformOf(ad), platform);
        assert.equal(ad.campaign, r[1]);
        assert.equal(ad.adset, r[2], 'ad belongs to the row ad set');
      }
    }
  });

  it('Google rows have ad = -1; Performance Max rows also have adset = -1; Meta / TikTok rows always have both', () => {
    for (const r of rows) {
      const campaign = campaigns[r[1]];
      if (platformOf(campaign) === 'google') {
        assert.equal(r[3], -1, 'google has no ads');
        assert.equal(r[2] === -1, campaign.channel === 'PERFORMANCE_MAX', `${campaign.name}: adset -1 exactly for Performance Max`);
      } else {
        assert.ok(r[2] >= 0 && r[3] >= 0, 'ad-level platforms always carry ad set and ad');
      }
    }
    assert.ok(rows.some((r) => campaigns[r[1]].channel === 'PERFORMANCE_MAX'), 'sample has Performance Max rows');
    assert.ok(rows.some((r) => platformOf(campaigns[r[1]]) === 'google' && r[2] >= 0), 'sample has Search ad group rows');
    assert.equal(ads.filter((a) => platformOf(a) === 'google').length, 0, 'no Google ad entities');
  });

  it('entity keys are platform:id and unique; parents are valid; nothing is unreferenced', () => {
    for (const list of [accounts, campaigns, adsets, ads]) {
      assert.equal(new Set(list.map((e) => e.key)).size, list.length);
      assert.ok(list.every((e) => e.key === `${e.platform ?? platformOf(e)}:${e.id}` && typeof e.id === 'string'));
    }
    const usedCampaigns = new Set(rows.map((r) => r[1]));
    const usedAdsets = new Set(rows.map((r) => r[2]).filter((i) => i >= 0));
    const usedAds = new Set(rows.map((r) => r[3]).filter((i) => i >= 0));
    assert.equal(usedCampaigns.size, campaigns.length);
    assert.equal(usedAdsets.size, adsets.length);
    assert.equal(usedAds.size, ads.length);
    assert.equal(new Set(campaigns.map((c) => c.account)).size, accounts.length);
  });

  it('entity dictionaries have exactly the §2.1 fields in contract order (first_date / last_date on campaigns, ad sets, ads)', () => {
    assert.deepEqual(Object.keys(accounts[0]), ['key', 'platform', 'id', 'name']);
    assert.deepEqual(Object.keys(campaigns[0]), ['key', 'account', 'id', 'name', 'objective', 'channel', 'status', 'first_date', 'last_date']);
    assert.deepEqual(Object.keys(adsets[0]), ['key', 'campaign', 'id', 'name', 'status', 'first_date', 'last_date']);
    assert.deepEqual(Object.keys(ads[0]), ['key', 'campaign', 'adset', 'id', 'name', 'status', 'raw_status', 'preview', 'image', 'image_reason', 'first_date', 'last_date']);
  });

  it('objective / channel follow the platform: Meta+TikTok objective, Google channel', () => {
    for (const c of campaigns) {
      if (platformOf(c) === 'google') assert.ok(c.objective === null && typeof c.channel === 'string');
      else assert.ok(typeof c.objective === 'string' && c.channel === null, `${c.key} objective ${c.objective}`);
    }
  });

  it('statuses are drawn from the six allowed values; image_reason is set exactly when there is no image', () => {
    const allowed = new Set(['ACTIVE', 'PAUSED', 'DISAPPROVED', 'IN_REVIEW', 'REMOVED', 'UNKNOWN']);
    for (const e of [...campaigns, ...adsets, ...ads]) assert.ok(allowed.has(e.status), `${e.key} ${e.status}`);
    for (const a of ads) assert.equal(a.image_reason === null, a.image, a.key);
  });

  it('account names are trimmed (the sample has "Sunbird Juice " with a trailing space)', () => {
    assert.ok(accounts.every((a) => a.name === a.name.trim()));
    assert.ok(accounts.some((a) => a.name === 'Sunbird Juice'));
  });

  it('sorts entities by platform, account name, entity name, id', () => {
    const lower = (s) => s.toLowerCase();
    const order = (a, b) => (a < b ? -1 : a > b ? 1 : 0);
    const compare = (x, y, accountNameOf) =>
      order(platformOf(x), platformOf(y)) || order(lower(accountNameOf(x)), lower(accountNameOf(y))) || order(lower(x.name), lower(y.name)) || order(x.name, y.name);
    const accountNameOfCampaign = (c) => accounts[c.account].name;
    for (let i = 1; i < campaigns.length; i++) {
      assert.ok(compare(campaigns[i - 1], campaigns[i], accountNameOfCampaign) <= 0, `campaigns ${i - 1}/${i} out of order`);
    }
    for (let i = 1; i < accounts.length; i++) {
      assert.ok(order(platformOf(accounts[i - 1]), platformOf(accounts[i])) <= 0);
    }
    assert.deepEqual(rows.map((r) => r[0]), rows.map((r) => r[0]).slice().sort(), 'rows are in date order');
  });

  it('is independent of the order the rows arrive in', () => {
    const sheets = loadSample();
    const reordered = { meta: shuffled(sheets.meta, 1), tiktok: sheets.tiktok.slice().reverse(), google: shuffled(sheets.google, 3) };
    assert.equal(JSON.stringify(run(reordered)), JSON.stringify(run(sheets)));
  });

  it('is deterministic for identical input', () => {
    assert.equal(JSON.stringify(run(loadSample())), JSON.stringify(run(loadSample())));
  });
});

// ---------------------------------------------------------------------------------------------
// Statuses (§2.1)
// ---------------------------------------------------------------------------------------------

describe('Meta status mapping', () => {
  const ads = [
    ['a1', 'ACTIVE'], ['a2', 'CAMPAIGN_PAUSED'], ['a3', 'ADSET_PAUSED'], ['a4', 'PAUSED'], ['a5', ''], ['a6', 'DISAPPROVED'],
    ['a7', 'PENDING_REVIEW'], ['a8', 'ARCHIVED'], ['a9', 'WITH_ISSUES'], ['a10', 'None'], ['a11', ' active '],
  ].map(([ad, status]) => metaRow({ ad_id: ad, adset_id: `s-${ad}`, campaign_id: `c-${ad}`, effective_status: status }));
  const ds = run({ meta: ads });
  const adStatus = (id) => find(ds.ads, `meta:${id}`);

  it('ACTIVE -> ACTIVE', () => assert.equal(adStatus('a1').status, 'ACTIVE'));
  it('CAMPAIGN_PAUSED, ADSET_PAUSED and PAUSED all become PAUSED, raw_status keeps the original', () => {
    for (const [id, raw] of [['a2', 'CAMPAIGN_PAUSED'], ['a3', 'ADSET_PAUSED'], ['a4', 'PAUSED']]) {
      assert.equal(adStatus(id).status, 'PAUSED');
      assert.equal(adStatus(id).raw_status, raw);
    }
  });
  it('blank (and "None") -> UNKNOWN with raw_status null', () => {
    for (const id of ['a5', 'a10']) {
      assert.equal(adStatus(id).status, 'UNKNOWN');
      assert.equal(adStatus(id).raw_status, null);
    }
  });
  it('maps review / removed states and leaves unrecognised values UNKNOWN but visible in raw_status', () => {
    assert.equal(adStatus('a6').status, 'DISAPPROVED');
    assert.equal(adStatus('a7').status, 'IN_REVIEW');
    assert.equal(adStatus('a8').status, 'REMOVED');
    assert.equal(adStatus('a9').status, 'UNKNOWN');
    assert.equal(adStatus('a9').raw_status, 'WITH_ISSUES');
    assert.deepEqual(ds.diagnostics.meta.unrecognised_status, { WITH_ISSUES: 1 });
  });
  it('is tolerant of case and surrounding whitespace, while raw_status keeps the trimmed original', () => {
    assert.equal(adStatus('a11').status, 'ACTIVE');
    assert.equal(adStatus('a11').raw_status, 'active');
  });

  it('an ad set is ACTIVE if any ad is ACTIVE, otherwise PAUSED, or UNKNOWN with no status data; a campaign follows its ad sets', () => {
    const rows = [
      // cA: sA1 has only paused ads, sA2 has an active ad -> cA ACTIVE
      metaRow({ campaign_id: 'cA', adset_id: 'sA1', ad_id: 'x1', effective_status: 'PAUSED' }),
      metaRow({ campaign_id: 'cA', adset_id: 'sA1', ad_id: 'x2', effective_status: 'ADSET_PAUSED' }),
      metaRow({ campaign_id: 'cA', adset_id: 'sA2', ad_id: 'x3', effective_status: 'ACTIVE' }),
      // cB: one known (paused) ad set and one with no status data -> cB PAUSED
      metaRow({ campaign_id: 'cB', adset_id: 'sB1', ad_id: 'y1', effective_status: 'PAUSED' }),
      metaRow({ campaign_id: 'cB', adset_id: 'sB2', ad_id: 'y2', effective_status: '' }),
      // cC: nothing known -> UNKNOWN all the way up
      metaRow({ campaign_id: 'cC', adset_id: 'sC1', ad_id: 'z1', effective_status: '' }),
      // cD: a paused ad and an active ad in the SAME ad set -> ACTIVE
      metaRow({ campaign_id: 'cD', adset_id: 'sD1', ad_id: 'w1', effective_status: 'PAUSED' }),
      metaRow({ campaign_id: 'cD', adset_id: 'sD1', ad_id: 'w2', effective_status: 'ACTIVE' }),
    ];
    const d = run({ meta: rows });
    const status = (list, key) => find(list, `meta:${key}`).status;
    assert.equal(status(d.adsets, 'sA1'), 'PAUSED');
    assert.equal(status(d.adsets, 'sA2'), 'ACTIVE');
    assert.equal(status(d.campaigns, 'cA'), 'ACTIVE');
    assert.equal(status(d.adsets, 'sB1'), 'PAUSED');
    assert.equal(status(d.adsets, 'sB2'), 'UNKNOWN');
    assert.equal(status(d.campaigns, 'cB'), 'PAUSED');
    assert.equal(status(d.adsets, 'sC1'), 'UNKNOWN');
    assert.equal(status(d.campaigns, 'cC'), 'UNKNOWN');
    assert.equal(status(d.adsets, 'sD1'), 'ACTIVE');
    assert.equal(status(d.campaigns, 'cD'), 'ACTIVE');
  });

  it('a single-ad ad set whose ad is DISAPPROVED / IN_REVIEW / REMOVED rolls up to PAUSED (contract: not ACTIVE, status known)', () => {
    for (const id of ['a6', 'a7', 'a8']) {
      assert.equal(find(ds.adsets, `meta:s-${id}`).status, 'PAUSED');
      assert.equal(find(ds.campaigns, `meta:c-${id}`).status, 'PAUSED');
    }
    assert.equal(find(ds.adsets, 'meta:s-a9').status, 'UNKNOWN');
  });

  it('takes the status from the newest row of the entity, whatever order the sheet lists them in', () => {
    const rows = [
      metaRow({ ad_id: 'n1', date: '2026-09-12', effective_status: 'PAUSED' }), // newest, listed first
      metaRow({ ad_id: 'n1', date: '2026-09-10', effective_status: 'ACTIVE' }),
      metaRow({ ad_id: 'n2', date: '2026-09-10', effective_status: 'PAUSED' }),
      metaRow({ ad_id: 'n2', date: '2026-09-12', effective_status: '' }), // newest row is blank: honest UNKNOWN, no stale fallback
    ];
    const d = run({ meta: rows });
    assert.equal(find(d.ads, 'meta:n1').status, 'PAUSED');
    assert.equal(find(d.ads, 'meta:n2').status, 'UNKNOWN');
  });
});

describe('TikTok status mapping', () => {
  const rows = [
    tiktokRow({ campaign_id: 't1', adgroup_id: 'g1', ad_id: 'ta1', campaign_status: 'CAMPAIGN_STATUS_ENABLE' }),
    tiktokRow({ campaign_id: 't1', adgroup_id: 'g1', ad_id: 'ta2', campaign_status: 'CAMPAIGN_STATUS_ENABLE' }),
    tiktokRow({ campaign_id: 't2', adgroup_id: 'g2', ad_id: 'tb1', campaign_status: 'CAMPAIGN_STATUS_DISABLE' }),
    tiktokRow({ campaign_id: 't3', adgroup_id: 'g3', ad_id: 'tc1', campaign_status: 'CAMPAIGN_STATUS_DELETE' }),
    tiktokRow({ campaign_id: 't4', adgroup_id: 'g4', ad_id: 'td1', campaign_status: '' }),
    tiktokRow({ campaign_id: 't5', adgroup_id: 'g5', ad_id: 'te1', campaign_status: 'CAMPAIGN_STATUS_SOMETHING_NEW' }),
  ];
  const ds = run({ tiktok: rows });
  const get = (list, id) => find(list, `tiktok:${id}`);

  it('CAMPAIGN_STATUS_ENABLE -> ACTIVE and CAMPAIGN_STATUS_DISABLE -> PAUSED', () => {
    assert.equal(get(ds.campaigns, 't1').status, 'ACTIVE');
    assert.equal(get(ds.campaigns, 't2').status, 'PAUSED');
  });
  it('ad groups and ads inherit the campaign status; raw_status is the campaign raw value', () => {
    for (const [group, ads, status, raw] of [['g1', ['ta1', 'ta2'], 'ACTIVE', 'CAMPAIGN_STATUS_ENABLE'], ['g2', ['tb1'], 'PAUSED', 'CAMPAIGN_STATUS_DISABLE']]) {
      assert.equal(get(ds.adsets, group).status, status);
      for (const ad of ads) {
        assert.equal(get(ds.ads, ad).status, status);
        assert.equal(get(ds.ads, ad).raw_status, raw);
      }
    }
  });
  it('other values map sensibly or stay UNKNOWN with the raw value kept', () => {
    assert.equal(get(ds.campaigns, 't3').status, 'REMOVED');
    assert.equal(get(ds.campaigns, 't4').status, 'UNKNOWN');
    assert.equal(get(ds.ads, 'td1').raw_status, null);
    assert.equal(get(ds.campaigns, 't5').status, 'UNKNOWN');
    assert.equal(get(ds.ads, 'te1').raw_status, 'CAMPAIGN_STATUS_SOMETHING_NEW');
    assert.deepEqual(ds.diagnostics.tiktok.unrecognised_status, { CAMPAIGN_STATUS_SOMETHING_NEW: 1 });
  });
  it('follows the newest row when a campaign is switched off mid-range', () => {
    const d = run({
      tiktok: [
        tiktokRow({ date: '2026-09-10', campaign_status: 'CAMPAIGN_STATUS_ENABLE' }),
        tiktokRow({ date: '2026-09-12', campaign_status: 'CAMPAIGN_STATUS_DISABLE' }),
        tiktokRow({ date: '2026-09-11', campaign_status: 'CAMPAIGN_STATUS_ENABLE' }),
      ],
    });
    assert.equal(d.campaigns[0].status, 'PAUSED');
    assert.equal(d.adsets[0].status, 'PAUSED');
    assert.equal(d.ads[0].status, 'PAUSED');
  });
});

describe('Google status mapping', () => {
  const ds = run({
    google: [
      googleRow({ campaign_id: 'gc1', campaign_status: 'ENABLED', ad_group_id: 'ga1', ad_group_status: 'ENABLED' }),
      googleRow({ campaign_id: 'gc1', campaign_status: 'ENABLED', ad_group_id: 'ga2', ad_group_status: 'PAUSED' }),
      googleRow({ campaign_id: 'gc1', campaign_status: 'ENABLED', ad_group_id: 'ga3', ad_group_status: '' }),
      googleRow({ campaign_id: 'gc2', campaign_status: 'PAUSED', ad_group_id: 'ga4', ad_group_status: '' }),
      googleRow({ campaign_id: 'gc3', campaign_status: 'REMOVED', ad_group_id: 'ga5', ad_group_status: 'REMOVED' }),
      googleRow({ campaign_id: 'gc5', campaign_status: 'ENABLED', ad_group_id: 'ga6', ad_group_status: 'UNSPECIFIED' }),
      googleRow({ campaign_id: 'gc4', advertising_channel_type: 'PERFORMANCE_MAX', campaign_status: 'ENABLED', ad_group_id: '', ad_group_name: '', ad_group_status: '' }),
    ],
  });
  const get = (list, id) => find(list, `google:${id}`);

  it('campaign ENABLED / PAUSED / REMOVED -> ACTIVE / PAUSED / REMOVED', () => {
    assert.equal(get(ds.campaigns, 'gc1').status, 'ACTIVE');
    assert.equal(get(ds.campaigns, 'gc2').status, 'PAUSED');
    assert.equal(get(ds.campaigns, 'gc3').status, 'REMOVED');
  });
  it('ad groups use ad_group_status and fall back to the campaign status when it is blank / unspecified', () => {
    assert.equal(get(ds.adsets, 'ga1').status, 'ACTIVE');
    assert.equal(get(ds.adsets, 'ga2').status, 'PAUSED'); // own status wins over an ENABLED campaign
    assert.equal(get(ds.adsets, 'ga3').status, 'ACTIVE'); // blank -> campaign ENABLED
    assert.equal(get(ds.adsets, 'ga4').status, 'PAUSED'); // blank -> campaign PAUSED
    assert.equal(get(ds.adsets, 'ga5').status, 'REMOVED');
    assert.equal(get(ds.adsets, 'ga6').status, 'ACTIVE'); // UNSPECIFIED counts as not supplied
  });
  it('Performance Max has no ad group (adset = -1), no ad, channel set and objective null', () => {
    const pmax = get(ds.campaigns, 'gc4');
    assert.equal(pmax.channel, 'PERFORMANCE_MAX');
    assert.equal(pmax.objective, null);
    const payload = sliceRows(ds);
    const row = payload.rows.find((r) => payload.campaigns[r[1]].key === 'google:gc4');
    assert.deepEqual([row[2], row[3]], [-1, -1]);
    assert.equal(ds.adsets.some((s) => s.campaign === ds.campaigns.indexOf(pmax)), false);
    assert.equal(ds.ads.length, 0);
  });
});

// ---------------------------------------------------------------------------------------------
// sliceRows
// ---------------------------------------------------------------------------------------------

describe('sliceRows', () => {
  // Campaign X runs every day; Y only on 10-11 Sep; Z only on 14 Sep (other account); TikTok T only on 11 Sep.
  const sheets = {
    meta: [
      ...['10', '11', '12', '13', '14'].map((d) => metaRow({ date: `2026-09-${d}`, campaign_id: 'X', adset_id: 'xs', ad_id: 'x1', spend: `${d}` })),
      ...['10', '11'].map((d) => metaRow({ date: `2026-09-${d}`, campaign_id: 'Y', adset_id: 'ys', ad_id: 'y1', spend: '1' })),
      metaRow({ date: '2026-09-14', account_id: '1002', account_name: 'Other Co', campaign_id: 'Z', adset_id: 'zs', ad_id: 'z1', spend: '2' }),
    ],
    tiktok: [tiktokRow({ date: '2026-09-11', campaign_id: 'T', adgroup_id: 'tg', ad_id: 't1' })],
  };
  const ds = run(sheets);

  it('excludes dates outside the range and includes both endpoints', () => {
    const s = sliceRows(ds, '2026-09-12', '2026-09-13');
    assert.deepEqual(s.rows.map((r) => r[0]), ['2026-09-12', '2026-09-13']);
    assert.deepEqual(s.range, { from: '2026-09-12', to: '2026-09-13' });
    assert.deepEqual(sliceRows(ds, '2026-09-10', '2026-09-10').rows.map((r) => r[0]), ['2026-09-10', '2026-09-10']);
  });

  it('drops entities that no remaining row references, and keeps the dictionaries consistent', () => {
    const s = sliceRows(ds, '2026-09-12', '2026-09-14');
    assert.deepEqual(s.campaigns.map((c) => c.id).sort(), ['X', 'Z']);
    assert.deepEqual(s.adsets.map((c) => c.id).sort(), ['xs', 'zs']);
    assert.deepEqual(s.ads.map((c) => c.id).sort(), ['x1', 'z1']);
    assert.deepEqual(s.accounts.map((a) => a.id).sort(), ['1001', '1002']); // TikTok account is gone
    assert.equal(s.rows.length, 4);
    for (const r of s.rows) {
      assert.equal(s.ads[r[3]].campaign, r[1]);
      assert.equal(s.ads[r[3]].adset, r[2]);
      assert.equal(s.adsets[r[2]].campaign, r[1]);
      assert.ok(s.accounts[s.campaigns[r[1]].account]);
    }
    const early = sliceRows(ds, '2026-09-10', '2026-09-11');
    assert.deepEqual(early.campaigns.map((c) => c.id).sort(), ['T', 'X', 'Y']);
    assert.equal(early.accounts.length, 2);
  });

  it('re-maps indexes: the same entity gets a different index in different slices but the same identity', () => {
    const full = sliceRows(ds);
    const late = sliceRows(ds, '2026-09-14', '2026-09-14');
    const identityOf = (p, r) => [p.campaigns[r[1]].key, p.adsets[r[2]].key, p.ads[r[3]].key].join('|');
    const lateIdentities = late.rows.map((r) => identityOf(late, r)).sort();
    const sameDayInFull = full.rows.filter((r) => r[0] === '2026-09-14').map((r) => identityOf(full, r)).sort();
    assert.deepEqual(lateIdentities, sameDayInFull);
    assert.ok(Math.max(...late.rows.map((r) => r[1])) < late.campaigns.length);
    assert.ok(full.campaigns.length > late.campaigns.length);
  });

  it('entity status and image come from the full history, not from the slice', () => {
    const d = run({
      meta: [
        metaRow({ date: '2026-09-10', ad_id: 'h1', effective_status: 'ACTIVE' }),
        metaRow({ date: '2026-09-14', ad_id: 'h1', effective_status: 'PAUSED' }),
      ],
    }, { savedCreatives: new Set(['meta:h1']) });
    const s = sliceRows(d, '2026-09-10', '2026-09-10');
    assert.equal(s.ads[0].status, 'PAUSED');
    assert.equal(s.ads[0].image, true);
  });

  it('defaults to the full extent of the data and echoes it as the range', () => {
    const s = sliceRows(ds);
    assert.deepEqual(s.range, { from: '2026-09-10', to: '2026-09-14' });
    assert.equal(s.rows.length, ds.rows.length);
  });

  it('returns an empty but well-formed payload for an empty or inverted range', () => {
    for (const s of [sliceRows(ds, '2026-08-01', '2026-08-31'), sliceRows(ds, '2026-09-14', '2026-09-10'), sliceRows(ds, '2026-10-01', '2026-10-31')]) {
      assert.deepEqual([s.rows, s.accounts, s.campaigns, s.adsets, s.ads], [[], [], [], [], []]);
      assert.deepEqual(s.cols, ROW_COLS);
    }
  });

  it('rejects malformed dates', () => {
    for (const bad of ['2026-9-1', '2026-02-30', '20260914', 'yesterday', '']) assert.throws(() => sliceRows(ds, bad, '2026-09-14'), RangeError, bad);
    assert.throws(() => sliceRows(ds, '2026-09-10', 20260914), RangeError);
  });

  it('never mutates the dataset', () => {
    const before = JSON.stringify(ds);
    const s = sliceRows(ds, '2026-09-12', '2026-09-14');
    s.rows[0][4] = -1;
    s.campaigns[0].name = 'changed';
    s.ads[0].image = !s.ads[0].image;
    assert.equal(JSON.stringify(ds), before);
  });

  it('works on an empty dataset', () => {
    const empty = run({});
    const s = sliceRows(empty);
    assert.deepEqual(s.rows, []);
    assert.deepEqual(s.range, { from: null, to: null });
    assert.deepEqual(sliceRows(empty, '2026-09-01', '2026-09-30').rows, []);
  });
});

// ---------------------------------------------------------------------------------------------
// first_date / last_date (§2.1)
// ---------------------------------------------------------------------------------------------

describe('first_date and last_date on campaigns, ad sets and ads', () => {
  // Ad A delivers 11-12 Sep, ad B 13-14 Sep, ad C never. Zero-delivery rows sit around them on purpose.
  const sheets = {
    meta: [
      metaRow({ ad_id: 'A', adset_id: 'S1', campaign_id: 'C1', date: '2026-09-10', spend: '0', impressions: '0' }), // before launch
      metaRow({ ad_id: 'A', adset_id: 'S1', campaign_id: 'C1', date: '2026-09-11', spend: '5', impressions: '100' }),
      metaRow({ ad_id: 'A', adset_id: 'S1', campaign_id: 'C1', date: '2026-09-12', spend: '0', impressions: '7' }), // impressions alone count
      metaRow({ ad_id: 'A', adset_id: 'S1', campaign_id: 'C1', date: '2026-09-13', spend: '0', impressions: '0' }), // after its last delivery
      metaRow({ ad_id: 'B', adset_id: 'S2', campaign_id: 'C1', date: '2026-09-13', spend: '3', impressions: '0' }), // spend alone counts
      metaRow({ ad_id: 'B', adset_id: 'S2', campaign_id: 'C1', date: '2026-09-14', spend: '4', impressions: '50' }),
      metaRow({ ad_id: 'B', adset_id: 'S2', campaign_id: 'C1', date: '2026-09-15', spend: '0', impressions: '0' }),
      metaRow({ ad_id: 'C', adset_id: 'S3', campaign_id: 'C2', date: '2026-09-12', spend: '0', impressions: '0' }), // never delivered
    ],
  };
  const ds = run(sheets);
  const span = (list, id) => {
    const e = find(list, `meta:${id}`);
    return [e.first_date, e.last_date];
  };

  it('are the first and last day with spend > 0 or impressions > 0; zero-delivery rows do not count', () => {
    assert.deepEqual(span(ds.ads, 'A'), ['2026-09-11', '2026-09-12']);
    assert.deepEqual(span(ds.ads, 'B'), ['2026-09-13', '2026-09-14']);
    assert.deepEqual(span(ds.adsets, 'S1'), ['2026-09-11', '2026-09-12']);
    assert.deepEqual(span(ds.adsets, 'S2'), ['2026-09-13', '2026-09-14']);
  });

  it('a parent spans all of its children', () => {
    assert.deepEqual(span(ds.campaigns, 'C1'), ['2026-09-11', '2026-09-14']);
  });

  it('are null (not a made-up date) for an entity that never delivered', () => {
    assert.deepEqual(span(ds.ads, 'C'), [null, null]);
    assert.deepEqual(span(ds.adsets, 'S3'), [null, null]);
    assert.deepEqual(span(ds.campaigns, 'C2'), [null, null]);
  });

  it('describe the full history in sliceRows, whatever range was asked for', () => {
    const middle = sliceRows(ds, '2026-09-12', '2026-09-12'); // only ad A (and the never-delivered ad C) have rows that day
    assert.deepEqual(middle.ads.map((a) => [a.id, a.first_date, a.last_date]), [['A', '2026-09-11', '2026-09-12'], ['C', null, null]]);
    const late = sliceRows(ds, '2026-09-14', '2026-09-15'); // ad B only; its start and its campaign's start are before the range
    assert.deepEqual(late.ads.map((a) => [a.id, a.first_date, a.last_date]), [['B', '2026-09-13', '2026-09-14']]);
    assert.deepEqual(late.adsets.map((a) => [a.id, a.first_date, a.last_date]), [['S2', '2026-09-13', '2026-09-14']]);
    assert.deepEqual(late.campaigns.map((a) => [a.id, a.first_date, a.last_date]), [['C1', '2026-09-11', '2026-09-14']]);
  });

  it('describe the full history in monthly, including delivery in months before the one shown', () => {
    const cross = run({
      meta: [
        metaRow({ date: '2026-07-30', spend: '10' }),
        metaRow({ date: '2026-08-15', spend: '0', impressions: '0' }),
        metaRow({ date: '2026-09-02', spend: '0', impressions: '9' }),
        metaRow({ date: '2026-09-20', spend: '0', impressions: '0' }),
      ],
    });
    const m = monthly(cross);
    assert.deepEqual(m.campaigns.map((c) => [c.first_date, c.last_date]), [['2026-07-30', '2026-09-02']]);
    assert.deepEqual(Object.keys(m.campaigns[0]).slice(-2), ['first_date', 'last_date']);
  });

  it('work for TikTok and for Google ad groups and Performance Max campaigns (rows without an ad)', () => {
    const d = run({
      tiktok: [tiktokRow({ date: '2026-09-11', spend: '0', impressions: '0' }), tiktokRow({ date: '2026-09-12' }), tiktokRow({ date: '2026-09-13', spend: '1', impressions: '0' })],
      google: [
        googleRow({ date: '2026-09-10', campaign_id: 'P', advertising_channel_type: 'PERFORMANCE_MAX', ad_group_id: '', ad_group_name: '', ad_group_status: '' }),
        googleRow({ date: '2026-09-11', campaign_id: 'P', advertising_channel_type: 'PERFORMANCE_MAX', ad_group_id: '', ad_group_name: '', ad_group_status: '' }),
        googleRow({ date: '2026-09-12', campaign_id: 'S', ad_group_id: 'G1' }),
        googleRow({ date: '2026-09-14', campaign_id: 'S', ad_group_id: 'G1', spend: '0', impressions: '3' }),
        googleRow({ date: '2026-09-15', campaign_id: 'S', ad_group_id: 'G2', spend: '0', impressions: '0' }),
      ],
    });
    assert.deepEqual([d.ads[0].first_date, d.ads[0].last_date], ['2026-09-12', '2026-09-13']);
    assert.deepEqual([d.adsets.find((s) => s.id === '8101').first_date, d.adsets.find((s) => s.id === '8101').last_date], ['2026-09-12', '2026-09-13']);
    const campaign = (id) => find(d.campaigns, `google:${id}`);
    assert.deepEqual([campaign('P').first_date, campaign('P').last_date], ['2026-09-10', '2026-09-11']);
    assert.deepEqual([campaign('S').first_date, campaign('S').last_date], ['2026-09-12', '2026-09-14']);
    const adGroup = (id) => find(d.adsets, `google:${id}`);
    assert.deepEqual([adGroup('G1').first_date, adGroup('G1').last_date], ['2026-09-12', '2026-09-14']);
    assert.deepEqual([adGroup('G2').first_date, adGroup('G2').last_date], [null, null]);
  });

  it('leave accounts untouched (accounts keep the four §2.1 fields)', () => {
    assert.deepEqual(Object.keys(ds.accounts[0]), ['key', 'platform', 'id', 'name']);
  });

  describe('on the real sample', () => {
    const sample = run(loadSample());
    const full = sliceRows(sample);
    const lists = { campaigns: full.campaigns, adsets: full.adsets, ads: full.ads };

    it('match the first / last delivered day recomputed from the rows, entity by entity', () => {
      const expected = { campaigns: new Map(), adsets: new Map(), ads: new Map() };
      for (const r of full.rows) {
        if (!(r[col('spend')] > 0 || r[col('impressions')] > 0)) continue;
        const targets = [['campaigns', full.campaigns[r[1]].key], ['adsets', r[2] >= 0 ? full.adsets[r[2]].key : null], ['ads', r[3] >= 0 ? full.ads[r[3]].key : null]];
        for (const [name, key] of targets) {
          if (!key) continue;
          const seen = expected[name].get(key) ?? { first: r[0], last: r[0] };
          if (r[0] < seen.first) seen.first = r[0];
          if (r[0] > seen.last) seen.last = r[0];
          expected[name].set(key, seen);
        }
      }
      for (const [name, list] of Object.entries(lists)) {
        for (const e of list) {
          const want = expected[name].get(e.key);
          assert.deepEqual([e.first_date, e.last_date], want ? [want.first, want.last] : [null, null], `${name} ${e.key}`);
        }
      }
    });

    it('are ordered, within the data range, and null together', () => {
      for (const list of Object.values(lists)) {
        for (const e of list) {
          assert.equal(e.first_date === null, e.last_date === null, e.key);
          if (e.first_date !== null) {
            assert.ok(e.first_date <= e.last_date && e.first_date >= '2026-09-07' && e.last_date <= '2026-09-20', e.key);
          }
        }
      }
      assert.ok(full.ads.some((a) => a.first_date !== null) && full.ads.some((a) => a.first_date === null), 'the sample has both delivering and never-delivering ads');
    });

    it('stay identical in a narrower slice (full history, not the slice)', () => {
      const narrow = sliceRows(sample, '2026-09-18', '2026-09-20');
      assert.ok(narrow.ads.length < full.ads.length);
      for (const [name, list] of Object.entries({ campaigns: narrow.campaigns, adsets: narrow.adsets, ads: narrow.ads })) {
        const byKey = new Map(lists[name].map((e) => [e.key, e]));
        for (const e of list) assert.deepEqual([e.first_date, e.last_date], [byKey.get(e.key).first_date, byKey.get(e.key).last_date], e.key);
      }
      assert.ok(narrow.ads.some((a) => a.first_date !== null && a.first_date < '2026-09-18'), 'some ad started before the slice');
    });
  });
});

// ---------------------------------------------------------------------------------------------
// Duplicates and missing columns (§2.2, §2.4)
// ---------------------------------------------------------------------------------------------

describe('duplicate rows', () => {
  it('identical duplicates are counted once and reported', () => {
    const row = metaRow();
    const ds = run({ meta: [row, { ...row }, { ...row }] });
    const payload = sliceRows(ds);
    assert.equal(payload.rows.length, 1);
    assert.equal(payload.rows[0][col('spend')], 100);
    const health = meta(ds).sheets.meta;
    assert.equal(health.rows, 3, 'rows = rows read from the sheet');
    assert.equal(health.duplicates, 2);
    assert.deepEqual([ds.diagnostics.meta.duplicates_identical, ds.diagnostics.meta.duplicates_conflicting], [2, 0]);
  });

  it('differing rows for one key: the last one in sheet order wins and the duplicate is reported', () => {
    const ds = run({ meta: [metaRow({ spend: '100', effective_status: 'ACTIVE' }), metaRow({ spend: '150', effective_status: 'PAUSED' })] });
    const payload = sliceRows(ds);
    assert.equal(payload.rows.length, 1);
    assert.equal(payload.rows[0][col('spend')], 150);
    assert.equal(payload.ads[0].status, 'PAUSED');
    assert.equal(meta(ds).sheets.meta.duplicates, 1);
    assert.equal(ds.diagnostics.meta.duplicates_conflicting, 1);
  });

  it('uses the upsert key per sheet: Meta / TikTok date+ad, Google date+campaign+ad group', () => {
    const ds = run({
      meta: [metaRow(), metaRow({ date: '2026-09-15' }), metaRow({ ad_id: '7002' })], // different day / different ad: not duplicates
      tiktok: [tiktokRow(), tiktokRow(), tiktokRow({ ad_id: '7102' })],
      google: [googleRow(), googleRow({ ad_group_id: '8202' }), googleRow(), googleRow({ campaign_id: '9202', ad_group_id: '' }), googleRow({ campaign_id: '9202', ad_group_id: '' })],
    });
    const h = meta(ds).sheets;
    assert.deepEqual([h.meta.duplicates, h.tiktok.duplicates, h.google.duplicates], [0, 1, 2]);
    assert.deepEqual([h.meta.rows, h.tiktok.rows, h.google.rows], [3, 3, 5]);
    assert.equal(sliceRows(ds).rows.length, 3 + 2 + 3);
  });

  it('a duplicate that lost the dedupe still counts as "the ad once had an image link"', () => {
    const withUrl = metaRow({ image_url: 'https://example.com/a.jpg' });
    const ds = run({ meta: [withUrl, metaRow({ image_url: '' })] });
    assert.equal(ds.ads[0].image_reason, 'not_saved');
  });

  it('the real sample has none', () => {
    const h = meta(run(loadSample())).sheets;
    assert.deepEqual([h.meta.duplicates, h.tiktok.duplicates, h.google.duplicates], [0, 0, 0]);
  });
});

describe('missing columns', () => {
  it('a missing optional column does not crash: status UNKNOWN and the column is reported', () => {
    const rows = [metaRow(), metaRow({ ad_id: '7002', date: '2026-09-15' })];
    for (const r of rows) delete r.effective_status;
    const ds = run({ meta: rows });
    assert.deepEqual(meta(ds).sheets.meta.columns_missing, ['effective_status']);
    assert.deepEqual([ds.ads[0].status, ds.ads[0].raw_status, ds.adsets[0].status, ds.campaigns[0].status], ['UNKNOWN', null, 'UNKNOWN', 'UNKNOWN']);
    assert.equal(sliceRows(ds).rows.length, 2);
    assert.equal(sumOf(sliceRows(ds).rows, (r) => r[col('spend')]), 200);
  });

  it('reports every absent column in sheet order and treats its values as not reported', () => {
    const rows = [metaRow({ image_url: 'x' })];
    for (const r of rows) for (const c of ['reach', 'purchase_roas_omni_purchase', 'image_url', 'ad_preview_shareable_link']) delete r[c];
    const ds = run({ meta: rows });
    assert.deepEqual(meta(ds).sheets.meta.columns_missing, ['reach', 'purchase_roas_omni_purchase', 'image_url', 'ad_preview_shareable_link']);
    const row = sliceRows(ds).rows[0];
    assert.equal(row[col('reach')], 0);
    assert.equal(row[col('roas_value')], 0);
    assert.deepEqual([ds.ads[0].preview, ds.ads[0].image_reason], [null, 'no_url']);
  });

  it('TikTok without campaign_status and Google without status columns degrade to UNKNOWN / campaign fallback', () => {
    const t = [tiktokRow()];
    delete t[0].campaign_status;
    const g = [googleRow()];
    delete g[0].ad_group_status;
    const ds = run({ tiktok: t, google: g });
    assert.deepEqual(meta(ds).sheets.tiktok.columns_missing, ['campaign_status']);
    assert.deepEqual(meta(ds).sheets.google.columns_missing, ['ad_group_status']);
    assert.equal(find(ds.campaigns, 'tiktok:9101').status, 'UNKNOWN');
    assert.equal(find(ds.adsets, 'google:8201').status, 'ACTIVE'); // falls back to the ENABLED campaign
    const noStatus = [googleRow()];
    delete noStatus[0].ad_group_status;
    delete noStatus[0].campaign_status;
    assert.equal(run({ google: noStatus }).adsets[0].status, 'UNKNOWN');
  });

  it('a header-only sheet (parsed from CSV) still reports what its header lacks', () => {
    const rows = parseCsv('date,spend\n');
    const ds = run({ meta: rows });
    const health = meta(ds).sheets.meta;
    assert.equal(health.rows, 0);
    assert.deepEqual(health.columns_missing, SHEET_COLUMNS.meta.filter((c) => c !== 'date' && c !== 'spend'));
    assert.equal(ds.rows.length, 0);
  });

  it('a sheet with no header information at all (bare empty array, undefined) reports nothing missing', () => {
    const health = meta(run({ meta: [], tiktok: undefined })).sheets;
    assert.deepEqual([health.meta.columns_missing, health.tiktok.columns_missing, health.google.columns_missing], [[], [], []]);
  });

  it('a missing required column (date) skips the rows instead of crashing', () => {
    const rows = [metaRow(), metaRow()];
    for (const r of rows) delete r.date;
    const ds = run({ meta: rows });
    assert.deepEqual(meta(ds).sheets.meta.columns_missing, ['date']);
    assert.equal(ds.rows.length, 0);
    assert.equal(ds.diagnostics.meta.skipped.bad_date, 2);
    assert.equal(meta(ds).sheets.meta.rows, 2);
  });

  it('matches headers case-insensitively and ignores extra columns', () => {
    const upper = [Object.fromEntries(Object.entries({ ...metaRow(), surprise_column: 'x' }).map(([k, v]) => [k.toUpperCase(), v]))];
    const ds = run({ meta: upper });
    assert.deepEqual(meta(ds).sheets.meta.columns_missing, []);
    assert.equal(sliceRows(ds).rows[0][col('spend')], 100);
    assert.deepEqual(ds.diagnostics.meta.extra_columns, ['SURPRISE_COLUMN']);
  });
});

// ---------------------------------------------------------------------------------------------
// Monthly (§2.3)
// ---------------------------------------------------------------------------------------------

describe('monthly', () => {
  const ds = run({
    meta: [
      metaRow({ date: '2026-07-30', spend: '10', impressions: '100', clicks: '5', link_clicks: '4', actions_lead: '1' }),
      metaRow({ date: '2026-07-31', spend: '0', impressions: '0', reach: '0', clicks: '0', link_clicks: '0' }), // no delivery: not a delivery day
      metaRow({ date: '2026-09-01', spend: '5.55', impressions: '100', ad_id: '7001' }),
      metaRow({ date: '2026-09-01', spend: '4.45', impressions: '50', ad_id: '7002', adset_id: '8002' }), // same campaign, same day: one day
      metaRow({ date: '2026-09-02', spend: '0', impressions: '7', ad_id: '7001' }), // impressions only: still a delivery day
      metaRow({ date: '2026-09-03', spend: '0.01', impressions: '0', ad_id: '7001' }), // spend only: still a delivery day
      metaRow({ date: '2026-09-02', campaign_id: '9002', adset_id: '8003', ad_id: '7003', spend: '20', purchase_roas_omni_purchase: '3' }),
    ],
  });
  const m = monthly(ds);
  const rowFor = (month, campaignId) => m.rows.find((r) => r[0] === month && m.campaigns[r[1]].id === campaignId);

  it('has the contract shape and columns', () => {
    assert.deepEqual(Object.keys(m), ['schema', 'mode', 'months', 'accounts', 'campaigns', 'cols', 'rows']);
    assert.deepEqual(m.cols, ['month', 'campaign', 'spend', 'impressions', 'clicks', 'link_clicks', 'video_views', 'messages', 'leads', 'conversions', 'conv_value', 'roas_value', 'days']);
    assert.deepEqual(m.cols, MONTHLY_COLS);
    assert.ok(m.rows.every((r) => r.length === m.cols.length));
    assert.equal(m.mode, 'sample');
  });

  it('lists every month from first to last, including a month with no data', () => {
    assert.deepEqual(m.months, ['2026-07', '2026-08', '2026-09']);
    assert.ok(!m.rows.some((r) => r[0] === '2026-08'));
  });

  it('sums the daily rows per campaign and month with exact 2-decimal arithmetic', () => {
    const july = rowFor('2026-07', '9001');
    // after [month, campaign]: spend, impressions, clicks, link_clicks, video_views, messages, leads, conversions, conv_value, roas_value, days
    assert.deepEqual(july.slice(2), [10, 100, 5, 4, 0, 0, 1, 0, 0, 0, 1]);
    const sept = rowFor('2026-09', '9001');
    assert.equal(sept[2], 10.01); // 5.55 + 4.45 + 0 + 0.01, no floating-point drift
    assert.equal(sept[3], 157); // impressions 100 + 50 + 7 + 0
    assert.equal(rowFor('2026-09', '9002')[2], 20);
    assert.equal(rowFor('2026-09', '9002')[MONTHLY_COLS.indexOf('roas_value')], 60);
  });

  it('days = distinct dates with spend > 0 or impressions > 0', () => {
    assert.equal(rowFor('2026-07', '9001')[MONTHLY_COLS.indexOf('days')], 1); // 31 July had no delivery
    assert.equal(rowFor('2026-09', '9001')[MONTHLY_COLS.indexOf('days')], 3); // 1st (two ads, one day), 2nd (impressions), 3rd (spend)
    assert.equal(rowFor('2026-09', '9002')[MONTHLY_COLS.indexOf('days')], 1);
  });

  it('a campaign-month whose rows never delivered is still listed with days = 0', () => {
    const quiet = monthly(run({ meta: [metaRow({ spend: '0', impressions: '0' })] }));
    assert.equal(quiet.rows.length, 1);
    assert.equal(quiet.rows[0][MONTHLY_COLS.indexOf('days')], 0);
  });

  it('only references the campaigns and accounts it uses, with consistent indexes', () => {
    assert.equal(m.campaigns.length, 2);
    assert.equal(m.accounts.length, 1);
    assert.ok(m.rows.every((r) => m.campaigns[r[1]] && m.accounts[m.campaigns[r[1]].account]));
    assert.equal(m.campaigns[0].status, 'ACTIVE');
  });

  it('monthly totals equal the daily totals, per campaign, for every metric (real sample)', () => {
    const sample = run(loadSample());
    const daily = sliceRows(sample);
    const monthlyPayload = monthly(sample);
    const dailyByCampaign = new Map();
    for (const r of daily.rows) {
      const key = daily.campaigns[r[1]].key;
      const acc = dailyByCampaign.get(key) ?? { days: new Set(), sums: {} };
      for (const name of MONTHLY_COLS.slice(2, -1)) acc.sums[name] = (acc.sums[name] ?? 0) + r[col(name)];
      if (r[col('spend')] > 0 || r[col('impressions')] > 0) acc.days.add(r[0]);
      dailyByCampaign.set(key, acc);
    }
    assert.equal(monthlyPayload.rows.length, dailyByCampaign.size, 'one September row per campaign');
    for (const r of monthlyPayload.rows) {
      const expected = dailyByCampaign.get(monthlyPayload.campaigns[r[1]].key);
      MONTHLY_COLS.slice(2, -1).forEach((name, i) => near(r[2 + i], expected.sums[name], 0.0051, `${monthlyPayload.campaigns[r[1]].name} ${name}`));
      assert.equal(r[MONTHLY_COLS.indexOf('days')], expected.days.size);
    }
    for (const name of MONTHLY_COLS.slice(2, -1)) {
      near(sumOf(monthlyPayload.rows, (r) => r[MONTHLY_COLS.indexOf(name)]), sumOf(daily.rows, (r) => r[col(name)]), 0.01, `grand total ${name}`);
    }
  });

  it('has no reach column (daily reach cannot be added into unique reach)', () => {
    assert.ok(!m.cols.includes('reach'));
  });

  it('is empty but well-formed with no data', () => {
    const empty = monthly(run({}));
    assert.deepEqual([empty.months, empty.rows, empty.campaigns, empty.accounts], [[], [], [], []]);
  });
});

// ---------------------------------------------------------------------------------------------
// meta / health (§2.4)
// ---------------------------------------------------------------------------------------------

describe('meta payload', () => {
  it('on the real sample reports each sheet and the data-through / history dates', () => {
    const m = meta(run(loadSample()));
    assert.deepEqual(Object.keys(m), ['schema', 'mode', 'generated_at', 'sheets', 'data_through', 'history_from', 'creatives']);
    assert.deepEqual(m.sheets.meta, { rows: 2564, first_date: '2026-09-07', last_date: '2026-09-20', accounts: 19, missing_dates: [], duplicates: 0, columns_missing: [] });
    assert.deepEqual(m.sheets.tiktok, { rows: 253, first_date: '2026-09-07', last_date: '2026-09-20', accounts: 7, missing_dates: [], duplicates: 0, columns_missing: [] });
    assert.deepEqual(m.sheets.google, { rows: 113, first_date: '2026-09-07', last_date: '2026-09-20', accounts: 1, missing_dates: [], duplicates: 0, columns_missing: [] });
    assert.equal(m.data_through, '2026-09-20');
    assert.equal(m.history_from, '2026-09-07');
    assert.equal(m.mode, 'sample');
    assert.equal(m.schema, 1);
  });

  it('data_through is the earliest last_date among non-empty sheets; history_from the earliest first_date', () => {
    const ds = run({
      meta: [metaRow({ date: '2026-09-05' }), metaRow({ date: '2026-09-20', ad_id: '7002' })],
      tiktok: [tiktokRow({ date: '2026-09-08' }), tiktokRow({ date: '2026-09-18', ad_id: '7102' })],
      google: [googleRow({ date: '2026-09-02' }), googleRow({ date: '2026-09-19', ad_group_id: '8202' })],
    });
    const m = meta(ds);
    assert.equal(m.data_through, '2026-09-18');
    assert.equal(m.history_from, '2026-09-02');
    assert.deepEqual([m.sheets.meta.first_date, m.sheets.tiktok.first_date, m.sheets.google.first_date], ['2026-09-05', '2026-09-08', '2026-09-02']);
  });

  it('ignores empty sheets for data_through, and is null when everything is empty', () => {
    const m = meta(run({ meta: [metaRow({ date: '2026-09-20' })] }));
    assert.equal(m.data_through, '2026-09-20');
    assert.deepEqual(m.sheets.tiktok, { rows: 0, first_date: null, last_date: null, accounts: 0, missing_dates: [], duplicates: 0, columns_missing: [] });
    const none = meta(run({}));
    assert.deepEqual([none.data_through, none.history_from], [null, null]);
    assert.deepEqual(none.creatives, { meta: { ads: 0, saved: 0, no_url: 0, not_saved: 0 }, tiktok: { ads: 0, saved: 0, no_url: 0, not_saved: 0 } });
  });

  it('missing_dates lists days with no rows inside the last 60 days of the sheet, up to its last date', () => {
    const days = [];
    for (let d = Date.UTC(2026, 6, 24); d <= Date.UTC(2026, 8, 20); d += 86400000) days.push(new Date(d).toISOString().slice(0, 10));
    const present = days.filter((d) => d !== '2026-08-15' && d !== '2026-09-10');
    const rows = ['2026-06-01', ...present].map((date, i) => metaRow({ date, ad_id: String(7000 + i) }));
    const m = meta(run({ meta: rows })).sheets.meta;
    // 2026-07-23 is the first day of the 60-day window ending 2026-09-20 and has no rows; 22 July and earlier are outside it.
    assert.deepEqual(m.missing_dates, ['2026-07-23', '2026-08-15', '2026-09-10']);
    assert.equal(m.first_date, '2026-06-01');
    assert.equal(m.last_date, '2026-09-20');
  });

  it('missing_dates starts at first_date for a short history', () => {
    const rows = ['2026-09-01', '2026-09-03', '2026-09-04', '2026-09-07'].map((date, i) => metaRow({ date, ad_id: String(i) }));
    assert.deepEqual(meta(run({ meta: rows })).sheets.meta.missing_dates, ['2026-09-02', '2026-09-05', '2026-09-06']);
  });

  it('counts raw rows (including duplicates and unplaceable rows) and distinct accounts', () => {
    const ds = run({
      meta: [
        metaRow(),
        metaRow({ ad_id: '7002', account_id: '1002' }),
        metaRow(), // duplicate
        metaRow({ date: 'garbage' }), // cannot be placed
        { ...blank('meta') }, // entirely blank: not a row
      ],
    });
    const m = meta(ds).sheets.meta;
    assert.equal(m.rows, 4);
    assert.equal(m.accounts, 2);
    assert.equal(m.duplicates, 1);
  });

  it('formats generated_at as Bangkok time and echoes mode', () => {
    assert.equal(meta(run({})).generated_at, '2026-10-12T07:05:00+07:00');
    assert.equal(meta(normalize({}, { mode: 'live', now: new Date('2026-10-11T23:30:00Z') })).generated_at, '2026-10-12T06:30:00+07:00');
    assert.equal(meta(normalize({}, { now: NOW })).mode, 'live', 'mode defaults to live');
  });

  it('returns copies: editing the payload cannot corrupt the dataset', () => {
    const ds = run({ meta: [metaRow()] });
    const m = meta(ds);
    m.sheets.meta.rows = 99;
    m.sheets.meta.missing_dates.push('x');
    m.creatives.meta.ads = 99;
    const again = meta(ds);
    assert.equal(again.sheets.meta.rows, 1);
    assert.deepEqual(again.sheets.meta.missing_dates, []);
    assert.equal(again.creatives.meta.ads, 1);
  });
});

// ---------------------------------------------------------------------------------------------
// Creatives (§2.1 image rules, §2.4 coverage)
// ---------------------------------------------------------------------------------------------

describe('creative images', () => {
  const sheets = {
    meta: [
      metaRow({ ad_id: 'm1', image_url: 'https://cdn.example/m1.jpg' }), // link and saved
      metaRow({ ad_id: 'm2', image_url: 'https://cdn.example/m2.jpg' }), // link, not saved (expired)
      metaRow({ ad_id: 'm3' }), // no link, not saved
      metaRow({ ad_id: 'm4' }), // no link in the sheet, but a saved file exists
      metaRow({ ad_id: 'm5', date: '2026-09-10', image_url: 'https://cdn.example/m5.jpg' }), // link only on an older day
      metaRow({ ad_id: 'm5', date: '2026-09-14', image_url: '' }),
    ],
    tiktok: [
      tiktokRow({ ad_id: 't1', video_thumbnail_url: 'https://cdn.example/t1.image' }),
      tiktokRow({ ad_id: 't2', video_thumbnail_url: 'https://cdn.example/t2.image' }),
      tiktokRow({ ad_id: 't3' }),
    ],
    google: [googleRow()],
  };
  const saved = new Set(['meta:m1', 'meta:m4', 'tiktok:t1', 'tiktok:t3', 'meta:unrelated-ad', 'google:8201']);
  const ds = run(sheets, { savedCreatives: saved });
  const ad = (key) => find(ds.ads, key);

  it('saved -> image true, reason null (even if the sheet has no link)', () => {
    for (const key of ['meta:m1', 'meta:m4', 'tiktok:t1', 'tiktok:t3']) {
      assert.equal(ad(key).image, true, key);
      assert.equal(ad(key).image_reason, null, key);
    }
  });
  it('not saved but a link existed on some row -> not_saved', () => {
    for (const key of ['meta:m2', 'meta:m5', 'tiktok:t2']) assert.deepEqual([ad(key).image, ad(key).image_reason], [false, 'not_saved'], key);
  });
  it('not saved and no row ever had a link -> no_url', () => {
    assert.deepEqual([ad('meta:m3').image, ad('meta:m3').image_reason], [false, 'no_url']);
  });
  it('Google has no ad entities, whatever the saved set says', () => {
    assert.equal(ds.ads.filter((a) => platformOf(a) === 'google').length, 0);
  });
  it('reports coverage per platform that always adds up', () => {
    const c = meta(ds).creatives;
    assert.deepEqual(c.meta, { ads: 5, saved: 2, no_url: 1, not_saved: 2 });
    assert.deepEqual(c.tiktok, { ads: 3, saved: 2, no_url: 0, not_saved: 1 });
    assert.deepEqual(Object.keys(c), ['meta', 'tiktok']);
    for (const p of ['meta', 'tiktok']) assert.equal(c[p].saved + c[p].no_url + c[p].not_saved, c[p].ads);
  });
  it('accepts an array for savedCreatives and tolerates none at all', () => {
    assert.equal(run(sheets, { savedCreatives: ['meta:m1'] }).ads.filter((a) => a.image).length, 1);
    const none = run(sheets);
    assert.equal(none.ads.some((a) => a.image), false);
    assert.equal(find(none.ads, 'meta:m1').image_reason, 'not_saved');
  });
  it('on the real sample: Meta 349 of 350 saved (1 without a link); TikTok 15 of 41 saved (15 without a link, 11 expired)', () => {
    const library = new Set();
    const sample = loadSample();
    // Pretend the library holds every Meta ad except the one with no link, and the 15 TikTok ads that had a link and were fetched in time.
    const metaWithUrl = new Set(sample.meta.filter((r) => r.image_url).map((r) => r.ad_id));
    for (const r of sample.meta) library.add(`meta:${r.ad_id}`);
    const metaNoUrl = [...new Set(sample.meta.map((r) => r.ad_id))].filter((id) => !metaWithUrl.has(id));
    library.delete(`meta:${metaNoUrl[0]}`);
    const m = meta(run(sample, { savedCreatives: library })).creatives;
    assert.equal(m.meta.ads, 350);
    assert.equal(m.meta.saved, 349);
    assert.equal(m.meta.saved + m.meta.no_url + m.meta.not_saved, 350);
    assert.equal(m.tiktok.ads, 41);
    assert.equal(m.tiktok.saved, 0);
    assert.equal(m.tiktok.no_url, 15);
    assert.equal(m.tiktok.not_saved, 26);
  });
});

// ---------------------------------------------------------------------------------------------
// Metric mapping, number handling and rounding
// ---------------------------------------------------------------------------------------------

describe('metric mapping (§2.2)', () => {
  it('Meta', () => {
    const ds = run({
      meta: [metaRow({
        spend: '123.456', impressions: '5000', reach: '3200', clicks: '40', link_clicks: '25', actions_video_view: '300',
        actions_onsite_conversion_messaging_conversation_started_7d: '2', actions_lead: '1', purchase_roas_omni_purchase: '2.5',
      })],
    });
    assert.deepEqual(sliceRows(ds).rows[0].slice(4), [123.456, 5000, 3200, 40, 25, 300, 2, 1, 0, 0, 308.64]);
  });
  it('TikTok (clicks feed both clicks and link_clicks; messages add DMs and messaging-app conversations; leads are onsite_form)', () => {
    const ds = run({
      tiktok: [tiktokRow({
        spend: '50', impressions: '2000', reach: '1900', clicks: '30', total_play: '1500',
        messaging_total_conversation_tiktok_direct_message: '3', messaging_total_conversation_instant_messaging_app: '5',
        onsite_form: '4', conversions: '2', complete_payment_roas: '1.5',
      })],
    });
    assert.deepEqual(sliceRows(ds).rows[0].slice(4), [50, 2000, 1900, 30, 30, 1500, 8, 4, 2, 0, 75]);
  });
  it('TikTok: either messaging column may be blank (0); both blank is 0', () => {
    const messages = (o) => sliceRows(run({ tiktok: [tiktokRow(o)] })).rows[0][col('messages')];
    assert.equal(messages({ messaging_total_conversation_tiktok_direct_message: '3', messaging_total_conversation_instant_messaging_app: '' }), 3);
    assert.equal(messages({ messaging_total_conversation_tiktok_direct_message: '', messaging_total_conversation_instant_messaging_app: '5' }), 5);
    assert.equal(messages({ messaging_total_conversation_tiktok_direct_message: 'None', messaging_total_conversation_instant_messaging_app: null }), 0);
    assert.equal(messages({ messaging_total_conversation_tiktok_direct_message: '0', messaging_total_conversation_instant_messaging_app: '' }), 0);
    const leads = (o) => sliceRows(run({ tiktok: [tiktokRow(o)] })).rows[0][col('leads')];
    assert.equal(leads({ onsite_form: '' }), 0);
    assert.equal(leads({ onsite_form: '7' }), 7);
  });
  it('TikTok: the legacy total_sales_lead column (Windsor app leads) is ignored, and an old header reports the new columns missing', () => {
    const old = tiktokRow({ messaging_total_conversation_tiktok_direct_message: '2' });
    delete old.messaging_total_conversation_instant_messaging_app;
    delete old.onsite_form;
    old.total_sales_lead = '9';
    const ds = run({ tiktok: [old] });
    assert.equal(sliceRows(ds).rows[0][col('leads')], 0, 'app leads are not counted as leads');
    assert.equal(sliceRows(ds).rows[0][col('messages')], 2);
    assert.deepEqual(meta(ds).sheets.tiktok.columns_missing, ['messaging_total_conversation_instant_messaging_app', 'onsite_form']);
    assert.deepEqual(ds.diagnostics.tiktok.extra_columns, ['total_sales_lead']);
  });
  it('the TikTok sheet has the 22 columns of the contract, in order', () => {
    assert.equal(SHEET_COLUMNS.tiktok.length, 22);
    assert.deepEqual(SHEET_COLUMNS.tiktok.slice(15, 22), [
      'total_play', 'messaging_total_conversation_tiktok_direct_message', 'messaging_total_conversation_instant_messaging_app',
      'onsite_form', 'conversions', 'complete_payment_roas', 'video_thumbnail_url',
    ]);
    assert.ok(!SHEET_COLUMNS.tiktok.includes('total_sales_lead'));
  });
  it('Google (reach null, fractional conversions kept)', () => {
    const ds = run({ google: [googleRow()] });
    assert.deepEqual(sliceRows(ds).rows[0].slice(4), [75.5, 300, null, 12, 12, 0, 0, 0, 1.5, 900, 0]);
  });
  it('rows are [date, campaign, adset, ad, ...] and cols matches the contract', () => {
    assert.deepEqual(ROW_COLS, ['date', 'campaign', 'adset', 'ad', 'spend', 'impressions', 'reach', 'clicks', 'link_clicks', 'video_views', 'messages', 'leads', 'conversions', 'conv_value', 'roas_value']);
    const p = sliceRows(run({ meta: [metaRow()] }));
    assert.deepEqual(Object.keys(p), ['schema', 'mode', 'generated_at', 'range', 'accounts', 'campaigns', 'adsets', 'ads', 'cols', 'rows']);
    assert.deepEqual(p.cols, ROW_COLS);
    assert.ok(p.rows.every((r) => r.length === ROW_COLS.length));
  });
});

describe('number handling', () => {
  const spendOf = (cell) => sliceRows(run({ meta: [metaRow({ spend: cell })] })).rows[0][col('spend')];
  const row = (overrides) => sliceRows(run({ meta: [metaRow(overrides)] })).rows[0];

  it('treats blank, null, undefined and "None" as not reported (0 in the row)', () => {
    for (const cell of ['', '   ', null, undefined, 'None', 'none', 'null', 'NaN']) assert.equal(spendOf(cell), 0, String(cell));
    const r = row({ impressions: 'None', reach: null, clicks: '', link_clicks: undefined, actions_video_view: 'null' });
    assert.deepEqual(r.slice(col('impressions'), col('video_views') + 1), [0, 0, 0, 0, 0]);
  });

  it('accepts numbers, numeric strings, padded strings and thousands separators', () => {
    assert.equal(spendOf(12.5), 12.5);
    assert.equal(spendOf('12.5'), 12.5);
    assert.equal(spendOf('  12.5 '), 12.5);
    assert.equal(spendOf('1,234.50'), 1234.5);
    assert.equal(spendOf('1e2'), 100);
    assert.equal(spendOf('.5'), 0.5);
    assert.equal(spendOf(7), 7);
  });

  it('keeps counts as integers, and rounds money to 4 decimals half away from zero on the decimal digits', () => {
    assert.equal(row({ impressions: '1000.0' })[col('impressions')], 1000);
    assert.equal(Number.isInteger(row({ impressions: 1234 })[col('impressions')]), true);
    assert.equal(spendOf('1.005'), 1.005);
    assert.equal(spendOf('2.675'), 2.675);
    assert.equal(spendOf('127.8657'), 127.8657); // Google sub-satang spend survives (no drift in totals)
    assert.equal(spendOf('1.00005'), 1.0001);
    assert.equal(spendOf('2.00015'), 2.0002);
    assert.equal(spendOf('0.00004'), 0);
    assert.equal(spendOf(0.1 + 0.2), 0.3);
  });

  it('keeps negative values exactly as reported (never clamped) and flags them', () => {
    const ds = run({ meta: [metaRow({ spend: '-1.005', impressions: '-3' })] });
    const r = sliceRows(ds).rows[0];
    assert.equal(r[col('spend')], -1.005);
    assert.equal(r[col('impressions')], -3);
    assert.deepEqual(ds.diagnostics.meta.negative_values, { spend: 1, impressions: 1 });
  });

  it('counts non-numeric junk as 0 and flags the column', () => {
    const ds = run({ meta: [metaRow({ spend: 'abc', clicks: '#N/A' })] });
    const r = sliceRows(ds).rows[0];
    assert.deepEqual([r[col('spend')], r[col('clicks')]], [0, 0]);
    assert.deepEqual(ds.diagnostics.meta.unparseable_values, { spend: 1, clicks: 1 });
  });

  it('roas_value is ROAS x spend, 0 when ROAS is blank or spend is blank', () => {
    assert.equal(row({ purchase_roas_omni_purchase: '23.1662', spend: '379' })[col('roas_value')], 8779.9898); // 23.1662 x 379
    assert.equal(row({ purchase_roas_omni_purchase: '', spend: '379' })[col('roas_value')], 0);
    assert.equal(row({ purchase_roas_omni_purchase: '5', spend: '' })[col('roas_value')], 0);
  });

  it('fractional Google conversions are rounded to 2 decimals, whole ones stay integers', () => {
    const ds = run({ google: [googleRow({ conversions: '0.333333', conversion_value: '12.345' }), googleRow({ date: '2026-09-15', conversions: '3.0' })] });
    const rows = sliceRows(ds).rows;
    assert.deepEqual([rows[0][col('conversions')], rows[0][col('conv_value')]], [0.33, 12.345]);
    assert.equal(rows[1][col('conversions')], 3);
  });
});

// ---------------------------------------------------------------------------------------------
// Entity attributes and ordering
// ---------------------------------------------------------------------------------------------

describe('entity attributes', () => {
  it('account name: latest non-blank, trimmed', () => {
    const rows = [
      metaRow({ date: '2026-09-10', account_name: 'Old Name ' }),
      metaRow({ date: '2026-09-13', account_name: '' }),
      metaRow({ date: '2026-09-12', account_name: '  New Name  ' }),
    ];
    assert.equal(run({ meta: rows }).accounts[0].name, 'New Name');
    assert.equal(run({ meta: rows.slice().reverse() }).accounts[0].name, 'New Name');
  });

  it('campaign / ad set / ad names and objective follow the newest non-blank value', () => {
    const rows = [
      metaRow({ date: '2026-09-12', campaign: ' Renamed ', adset_name: 'Set v2', ad_name: 'Ad v2', campaign_objective: 'OUTCOME_SALES', ad_preview_shareable_link: 'https://fb.me/new' }),
      metaRow({ date: '2026-09-10', campaign: 'First', adset_name: 'Set v1', ad_name: 'Ad v1', campaign_objective: 'OUTCOME_LEADS', ad_preview_shareable_link: 'https://fb.me/old' }),
      metaRow({ date: '2026-09-14', campaign: '', adset_name: '', ad_name: '', campaign_objective: '', ad_preview_shareable_link: '' }),
    ];
    const ds = run({ meta: rows });
    assert.deepEqual([ds.campaigns[0].name, ds.campaigns[0].objective], ['Renamed', 'OUTCOME_SALES']);
    assert.equal(ds.adsets[0].name, 'Set v2');
    assert.deepEqual([ds.ads[0].name, ds.ads[0].preview], ['Ad v2', 'https://fb.me/new']);
  });

  it('an entity that never had a name gets "" (not the id), and no objective gets null', () => {
    const ds = run({ meta: [metaRow({ campaign: '', adset_name: '', ad_name: '', account_name: '', campaign_objective: '' })] });
    assert.deepEqual([ds.accounts[0].name, ds.campaigns[0].name, ds.adsets[0].name, ds.ads[0].name], ['', '', '', '']);
    assert.equal(ds.campaigns[0].objective, null);
    assert.equal(ds.ads[0].preview, null);
  });

  it('keeps TikTok objective, Google channel and previews per platform', () => {
    const ds = run({ meta: [metaRow()], tiktok: [tiktokRow({ objective_type: 'VIDEO_VIEWS' })], google: [googleRow()] });
    assert.equal(find(ds.campaigns, 'tiktok:9101').objective, 'VIDEO_VIEWS');
    assert.equal(find(ds.campaigns, 'google:9201').channel, 'SEARCH');
    assert.equal(find(ds.ads, 'tiktok:7101').preview, null);
  });

  it('preserves emoji, Thai text, commas and quotes in names', () => {
    const name = 'VDO "สวัสดี", Apple Pie 🍏✨ - 15 Aug 2026';
    assert.equal(run({ meta: [metaRow({ ad_name: name })] }).ads[0].name, name);
  });
});

describe('ordering', () => {
  const sheets = {
    meta: [
      metaRow({ account_id: '2', account_name: 'bravo', campaign_id: '1000', campaign: 'Same', adset_id: 's1', ad_id: 'a1' }),
      metaRow({ account_id: '2', account_name: 'bravo', campaign_id: '999', campaign: 'Same', adset_id: 's2', ad_id: 'a2' }),
      metaRow({ account_id: '3', account_name: 'Alpha', campaign_id: '5', campaign: 'Zebra', adset_id: 's3', ad_id: 'a3' }),
      metaRow({ account_id: '1', account_name: 'alpha', campaign_id: '6', campaign: 'Apple', adset_id: 's4', ad_id: 'a4' }),
    ],
    tiktok: [tiktokRow({ account_name: 'Zed' })],
    google: [googleRow({ account_name: 'Mid' })],
  };
  const ds = run(sheets);

  it('accounts: platform, then account name (case-insensitive, then exact), then id', () => {
    assert.deepEqual(ds.accounts.map((a) => a.name), ['Mid', 'Alpha', 'alpha', 'bravo', 'Zed']);
    assert.deepEqual(ds.accounts.map((a) => platformOf(a)), ['google', 'meta', 'meta', 'meta', 'tiktok']);
  });
  it('campaigns: grouped by account, then name, then numeric id (999 before 1000)', () => {
    const meta = ds.campaigns.filter((c) => platformOf(c) === 'meta');
    assert.deepEqual(meta.map((c) => c.id), ['5', '6', '999', '1000']);
    assert.deepEqual(meta.map((c) => ds.accounts[c.account].name), ['Alpha', 'alpha', 'bravo', 'bravo']);
  });
  it('is identical whatever order the input arrives in', () => {
    const reference = JSON.stringify(ds);
    for (const seed of [1, 2, 3]) {
      const mixed = { meta: shuffled(sheets.meta, seed), tiktok: sheets.tiktok, google: sheets.google };
      assert.equal(JSON.stringify(run(mixed)), reference);
    }
  });
});

// ---------------------------------------------------------------------------------------------
// Input formats and robustness
// ---------------------------------------------------------------------------------------------

describe('input formats', () => {
  it('accepts the raw Google Sheets API grid (header first, trailing empty cells dropped)', () => {
    const rows = [metaRow(), metaRow({ ad_id: '7002', date: '2026-09-15', link_clicks: '' })];
    const grid = [SHEET_COLUMNS.meta.slice(), ...rows.map((r) => SHEET_COLUMNS.meta.map((c) => r[c]))];
    for (const line of grid.slice(1)) while (line.length && line[line.length - 1] === '') line.pop(); // like the API does
    assert.equal(JSON.stringify(run({ meta: grid })), JSON.stringify(run({ meta: rows })));
    assert.deepEqual(meta(run({ meta: grid })).sheets.meta.columns_missing, []);
  });

  it('accepts typed values (numbers, not strings) and numeric ids', () => {
    const ds = run({ meta: [metaRow({ spend: 100, impressions: 1000, reach: 800, clicks: 50, ad_id: 7001, adset_id: 8001, campaign_id: 9001, account_id: 1001 })] });
    assert.deepEqual(sliceRows(ds).rows[0].slice(4, 9), [100, 1000, 800, 50, 40]);
    assert.deepEqual([ds.ads[0].id, ds.ads[0].key, ds.campaigns[0].id, ds.accounts[0].id], ['7001', 'meta:7001', '9001', '1001']);
  });

  it('turns float-typed ids ("7001.0") back into ids', () => {
    assert.equal(run({ meta: [metaRow({ ad_id: '7001.0' })] }).ads[0].id, '7001');
  });

  it('keeps long ids as given when they arrive as text', () => {
    const long = '120248983993170527';
    const ds = run({ meta: [metaRow({ ad_id: long, campaign_id: '120248983993170526' })] });
    assert.deepEqual([ds.ads[0].id, ds.ads[0].key], [long, `meta:${long}`]);
  });

  it('accepts dates with a time part, slashes, and Sheets serial numbers', () => {
    const serial = Date.UTC(2026, 8, 14) / 86400000 + 25569;
    const ds = run({ meta: [metaRow({ date: '2026-09-14T00:00:00' }), metaRow({ date: '2026/09/15', ad_id: '2' }), metaRow({ date: serial, ad_id: '3' }), metaRow({ date: '2026-09-16 00:00:00', ad_id: '4' })] });
    assert.deepEqual(sliceRows(ds).rows.map((r) => r[0]), ['2026-09-14', '2026-09-14', '2026-09-15', '2026-09-16']);
  });

  it('works end to end from CSV text with BOM, CRLF and a quoted multi-line name', () => {
    const header = SHEET_COLUMNS.meta.join(',');
    const cells = SHEET_COLUMNS.meta.map((c) => ({ ...metaRow({ ad_name: 'Line one\nLine "two", with comma' }) }[c]));
    const csv = String.fromCharCode(0xfeff) + [header, cells.map((v) => `"${String(v).replace(/"/g, '""')}"`).join(',')].join('\r\n') + '\r\n';
    const ds = run({ meta: parseCsv(csv) });
    assert.equal(ds.ads[0].name, 'Line one\nLine "two", with comma');
    assert.equal(sliceRows(ds).rows[0][col('spend')], 100);
  });
});

describe('robustness', () => {
  it('skips rows that cannot be placed (bad date, no account, no campaign) and counts them', () => {
    const ds = run({
      meta: [
        metaRow(),
        metaRow({ date: 'not a date', ad_id: '2' }),
        metaRow({ date: '2026-02-30', ad_id: '3' }),
        metaRow({ account_id: '', ad_id: '4' }),
        metaRow({ campaign_id: '', ad_id: '5' }),
      ],
    });
    assert.equal(ds.rows.length, 1);
    assert.deepEqual(ds.diagnostics.meta.skipped, { bad_date: 2, no_account: 1, no_campaign: 1 });
    assert.equal(meta(ds).sheets.meta.rows, 5);
  });

  it('keeps the spend of a row that has no ad_id (ad = -1) instead of dropping it, and reports it', () => {
    const ds = run({ meta: [metaRow({ ad_id: '', spend: '42.5' }), metaRow({ ad_id: '', spend: '7.5', date: '2026-09-15' }), metaRow({ ad_id: '7002', spend: '10' })] });
    const payload = sliceRows(ds);
    assert.equal(sumOf(payload.rows, (r) => r[col('spend')]), 60);
    assert.equal(payload.rows.filter((r) => r[3] === -1).length, 2);
    assert.equal(payload.ads.length, 1);
    assert.deepEqual([ds.diagnostics.meta.no_ad_id_rows, ds.diagnostics.meta.no_ad_id_spend], [2, 50]);
    // rows with no ad id on different days or ad sets are not duplicates of each other
    assert.equal(meta(ds).sheets.meta.duplicates, 0);
  });

  it('keeps a row with neither ad nor ad set id at the campaign level', () => {
    const ds = run({ meta: [metaRow({ ad_id: '', adset_id: '' })] });
    const r = sliceRows(ds).rows[0];
    assert.deepEqual([r[2], r[3]], [-1, -1]);
    assert.equal(ds.diagnostics.meta.no_adset_id_rows, 1);
  });

  it('feeds a campaign status from ads that have no ad set', () => {
    const ds = run({ meta: [metaRow({ adset_id: '', ad_id: 'orphan', effective_status: 'ACTIVE' })] });
    assert.equal(ds.ads[0].adset, -1);
    assert.equal(ds.campaigns[0].status, 'ACTIVE');
  });

  it('accepts missing / null sheets and rejects a non-array sheet', () => {
    for (const input of [undefined, null, {}, { meta: null }, { meta: [], tiktok: [], google: [] }]) {
      const ds = normalize(input, { now: NOW });
      assert.equal(ds.rows.length, 0);
      assert.equal(meta(ds).data_through, null);
    }
    assert.throws(() => normalize({ meta: 'nope' }, { now: NOW }), TypeError);
  });

  it('validates mode and now', () => {
    assert.throws(() => normalize({}, { mode: 'demo', now: NOW }), RangeError);
    assert.throws(() => normalize({}, { mode: 'live', now: 'today' }), TypeError);
    assert.throws(() => normalize({}, { mode: 'live', now: new Date('nope') }), TypeError);
    assert.doesNotThrow(() => normalize({}));
  });

  it('ignores rows that are not objects and entirely blank rows', () => {
    const ds = run({ meta: [metaRow(), null, { ...blank('meta') }, { ...blank('meta'), date: 'None', spend: ' ' }] });
    assert.equal(meta(ds).sheets.meta.rows, 1);
  });

  it('handles prototype-named values without surprises', () => {
    const ds = run({ meta: [metaRow({ effective_status: 'constructor', ad_name: '__proto__', campaign: 'toString' })] });
    assert.equal(ds.ads[0].status, 'UNKNOWN');
    assert.equal(ds.ads[0].name, '__proto__');
    assert.equal(ds.campaigns[0].name, 'toString');
  });

  it('does not mutate its input', () => {
    const rows = [metaRow(), metaRow({ ad_id: '2' })];
    const before = JSON.stringify(rows);
    run({ meta: rows }, { savedCreatives: new Set(['meta:7001']) });
    assert.equal(JSON.stringify(rows), before);
  });

  it('runs on a large synthetic sheet quickly (60k rows)', () => {
    const rows = [];
    for (let day = 0; day < 60; day++) {
      const date = new Date(Date.UTC(2026, 6, 1 + day)).toISOString().slice(0, 10);
      for (let ad = 0; ad < 1000; ad++) rows.push(metaRow({ date, ad_id: String(100000 + ad), adset_id: String(500 + (ad % 50)), campaign_id: String(90 + (ad % 10)), spend: String(ad % 97) }));
    }
    const started = performance.now();
    const ds = run({ meta: rows });
    assert.equal(ds.rows.length, 60000);
    assert.equal(sliceRows(ds, '2026-07-10', '2026-07-12').rows.length, 3000);
    assert.ok(performance.now() - started < 5000, 'normalising 60k rows should take well under 5 s');
  });
});
