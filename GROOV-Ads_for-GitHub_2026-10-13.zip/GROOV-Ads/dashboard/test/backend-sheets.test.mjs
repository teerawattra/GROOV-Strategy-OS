// lib/sheets.mjs: service-account auth, A1 helpers, row-object conversion, chunked reads stitched in order,
// retries and error messages, and an end-to-end read of the sample CSVs through a fake Sheets API. No network.
import { beforeEach, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { verify } from 'node:crypto';
import {
  SheetsError,
  chunkRanges,
  clearTokenCache,
  columnLetter,
  createSignedJwt,
  fetchWithRetry,
  getAccessToken,
  parseServiceAccount,
  quoteSheetTitle,
  readAllSheets,
  readOptionalSheets,
  readSheet,
  rowsToObjects,
} from '../lib/sheets.mjs';
import { normalize } from '../lib/normalize.mjs';
import {
  AUDIENCE_HEADER,
  PLACEMENT_HEADER,
  SA_PUBLIC_KEY,
  SERVICE_ACCOUNT,
  SERVICE_ACCOUNT_JSON,
  SHEET_IDS,
  TITLES,
  breakdownEnv,
  breakdownSpreadsheets,
  fakeGoogle,
  loadSampleSheets,
  sampleGrid,
  sampleSpreadsheets,
  sheetsEnv,
  syntheticBreakdownGrids,
} from './backend-fakes.mjs';

const NOW = Date.parse('2026-10-12T00:05:00Z');
const noSleep = { sleep: async () => {}, baseDelayMs: 0 };
const sa = parseServiceAccount(SERVICE_ACCOUNT_JSON);

beforeEach(() => clearTokenCache());

describe('service account', () => {
  it('parses the key as raw JSON, base64 JSON, or with escaped newlines', () => {
    assert.equal(sa.client_email, SERVICE_ACCOUNT.client_email);
    assert.equal(sa.private_key_id, 'abc123keyid');
    assert.equal(parseServiceAccount(Buffer.from(SERVICE_ACCOUNT_JSON).toString('base64')).client_email, SERVICE_ACCOUNT.client_email);
    const escaped = JSON.stringify({ ...SERVICE_ACCOUNT, private_key: SERVICE_ACCOUNT.private_key.replace(/\n/g, '\\n') });
    assert.equal(parseServiceAccount(escaped).private_key, SERVICE_ACCOUNT.private_key);
  });

  it('explains what is wrong with a bad key, without echoing it', () => {
    assert.throws(() => parseServiceAccount(''), /GOOGLE_SERVICE_ACCOUNT_JSON is not set/);
    assert.throws(() => parseServiceAccount('{"type": "service_account"'), /not valid JSON/);
    assert.throws(() => parseServiceAccount(JSON.stringify({ type: 'authorized_user' })), /service-account key/);
    assert.throws(() => parseServiceAccount(JSON.stringify({ type: 'service_account', client_email: 'a@b.c' })), /private_key/);
    // A key damaged while pasting still parses, but cannot sign; the error does not echo the key.
    const damaged = parseServiceAccount(SERVICE_ACCOUNT_JSON.replace('PRIVATE KEY-----\\n', 'PRIVATE KEY-----\\n!!'));
    assert.throws(() => createSignedJwt(damaged, { now: NOW }), (err) => err instanceof SheetsError && /cannot sign/.test(err.message) && !err.message.includes('BEGIN'));
  });

  it('signs an RS256 JWT for the read-only Sheets scope, valid for an hour', () => {
    const jwt = createSignedJwt(sa, { now: NOW });
    const [h, p, s] = jwt.split('.');
    assert.equal(verify('RSA-SHA256', Buffer.from(`${h}.${p}`), SA_PUBLIC_KEY, Buffer.from(s, 'base64url')), true);
    assert.deepEqual(JSON.parse(Buffer.from(h, 'base64url')), { alg: 'RS256', typ: 'JWT', kid: 'abc123keyid' });
    const claims = JSON.parse(Buffer.from(p, 'base64url'));
    assert.deepEqual(claims, {
      iss: SERVICE_ACCOUNT.client_email, scope: 'https://www.googleapis.com/auth/spreadsheets.readonly',
      aud: 'https://oauth2.googleapis.com/token', iat: NOW / 1000, exp: NOW / 1000 + 3600,
    });
  });

  it('exchanges the JWT for an access token and caches it', async () => {
    const google = fakeGoogle();
    const token = await getAccessToken(sa, { fetchImpl: google.fetch, now: () => NOW });
    assert.equal(token, 'ya29.fake-access-token');
    await getAccessToken(sa, { fetchImpl: google.fetch, now: () => NOW + 60_000 });
    assert.equal(google.calls.length, 1, 'second call served from cache');
    await getAccessToken(sa, { fetchImpl: google.fetch, now: () => NOW + 3600_000 });
    assert.equal(google.calls.length, 2, 'refreshed near expiry');
    assert.equal(google.calls[0].method, 'POST');
  });

  it('turns invalid_grant into a fix-it message that does not contain the assertion', async () => {
    const google = fakeGoogle({ override: () => new Response(JSON.stringify({ error: 'invalid_grant' }), { status: 400 }) });
    await assert.rejects(getAccessToken(sa, { fetchImpl: google.fetch, now: () => NOW }), (err) => {
      assert.ok(err instanceof SheetsError);
      assert.match(err.message, /invalid_grant/);
      assert.match(err.message, /new JSON key/);
      assert.ok(!err.message.includes('eyJ'));
      return true;
    });
  });
});

describe('A1 helpers and row conversion', () => {
  it('column letters', () => {
    assert.deepEqual([1, 22, 26, 27, 52, 53, 702, 703].map(columnLetter), ['A', 'V', 'Z', 'AA', 'AZ', 'BA', 'ZZ', 'AAA']);
    assert.throws(() => columnLetter(0));
  });

  it('quotes tab titles and splits a grid into row chunks', () => {
    assert.equal(quoteSheetTitle("It's · Meta"), "'It''s · Meta'");
    assert.deepEqual(chunkRanges('Meta', 45000, 22, 20000), ["'Meta'!A1:V20000", "'Meta'!A20001:V40000", "'Meta'!A40001:V45000"]);
    assert.deepEqual(chunkRanges('Meta', 1, 5, 20000), ["'Meta'!A1:E1"]);
  });

  it('builds row objects like parseCsv: trimmed headers, padded short rows, blank rows dropped', () => {
    const { rows, unsafeIdCells } = rowsToObjects([
      [' date ', 'ad_id', '', 'spend', 'spend'],
      ['2026-09-14', '120248983993170527', 'x', 1, 2],
      [],
      ['', null, '  '],
      ['2026-09-15', 7001],
      ['2026-09-16', 120248983993170530, 'y', 3.5, 4.5],
    ]);
    assert.deepEqual(rows.columns, ['date', 'ad_id', 'spend', 'spend']);
    assert.deepEqual(Object.keys(rows[0]), ['date', 'ad_id', 'spend']);
    assert.deepEqual(rows, [
      { date: '2026-09-14', ad_id: '120248983993170527', spend: 2 },
      { date: '2026-09-15', ad_id: 7001, spend: '' },
      { date: '2026-09-16', ad_id: 120248983993170530, spend: 4.5 },
    ]);
    assert.equal(JSON.stringify(rows).includes('columns'), false, 'columns is not enumerable');
    assert.equal(unsafeIdCells, 1, 'an 18-digit id stored as a number has lost precision');
  });
});

describe('readSheet: chunked reads stitched in sheet order', () => {
  const header = ['date', 'ad_id', 'spend'];
  const big = (n) => [header, ...Array.from({ length: n }, (_, i) => [`2026-09-${String((i % 28) + 1).padStart(2, '0')}`, String(1000 + i), i])];

  it('reads 3 chunks (header only in the first), keeps order, drops blank rows, max 3 in flight', async () => {
    const grid = big(44_999); // 45,000 grid rows including the header
    grid[30_000] = []; // a blank row in the middle of chunk 2
    grid.push([], [], []); // trailing blank rows in the grid
    const google = fakeGoogle({ spreadsheets: { s1: { title: 'Tab', grid, columnCount: 3 } } });
    const res = await readSheet('s1', { platform: 'meta', sa, accessToken: 'ya29.fake-access-token', fetchImpl: google.fetch, chunkRows: 20_000, concurrency: 3 });
    assert.equal(res.chunks, 3);
    assert.equal(res.rows.length, 44_998);
    assert.deepEqual(res.rows.columns, header);
    assert.deepEqual(res.rows[0], { date: '2026-09-01', ad_id: '1000', spend: 0 });
    assert.equal(res.rows[29_998].ad_id, '30998', 'row after the blank one');
    assert.equal(res.rows.at(-1).ad_id, String(1000 + 44_998));
    const ids = res.rows.map((r) => Number(r.ad_id));
    assert.ok(ids.every((v, i) => i === 0 || v > ids[i - 1]), 'sheet order preserved across chunks');
    const valueCalls = google.calls.filter((c) => c.url.includes('/values/'));
    assert.equal(valueCalls.length, 3);
    assert.ok(valueCalls.every((c) => c.url.includes('valueRenderOption=UNFORMATTED_VALUE') && c.url.includes('dateTimeRenderOption=FORMATTED_STRING')));
    assert.ok(google.maxInFlight <= 3);
  });

  it('handles a chunk with no values at all (empty tail of the grid)', async () => {
    const grid = big(10);
    const google = fakeGoogle({ spreadsheets: { s1: { title: 'Tab', grid, rowCount: 50_000, columnCount: 3 } } });
    const res = await readSheet('s1', { platform: 'meta', sa, accessToken: 'ya29.fake-access-token', fetchImpl: google.fetch, chunkRows: 20_000 });
    assert.equal(res.chunks, 3);
    assert.equal(res.rows.length, 10);
  });

  it('uses the configured tab, and lists the tabs when it does not exist', async () => {
    const google = fakeGoogle({ spreadsheets: { s1: { title: 'Old export', extraTabs: ['Data'], grid: big(3) } } });
    const res = await readSheet('s1', { platform: 'meta', tab: 'data', sa, accessToken: 'ya29.fake-access-token', fetchImpl: google.fetch });
    assert.equal(res.title, 'Data');
    await assert.rejects(readSheet('s1', { platform: 'meta', tab: 'Nope', sa, accessToken: 'ya29.fake-access-token', fetchImpl: google.fetch }), /no tab named "Nope".*"Old export", "Data"/);
  });

  it('says how to fix a missing share (403) and a wrong id (404)', async () => {
    const forbidden = fakeGoogle({ override: (url) => (url.hostname === 'sheets.googleapis.com' ? new Response('{}', { status: 403 }) : undefined) });
    await assert.rejects(readSheet('s1', { platform: 'tiktok', sa, accessToken: 'x', fetchImpl: forbidden.fetch }),
      (err) => err.status === 403 && err.message.includes(SERVICE_ACCOUNT.client_email) && err.message.includes('Share') && err.message.includes('TikTok'));
    const missing = fakeGoogle({ spreadsheets: {} });
    await assert.rejects(readSheet('nope', { platform: 'google', sa, accessToken: 'ya29.fake-access-token', fetchImpl: missing.fetch }), /SHEET_ID_GOOGLE/);
  });

  it('retries 429 / 5xx and network errors, then gives up with a clear message', async () => {
    let n = 0;
    const flaky = async () => (++n < 3 ? new Response('busy', { status: 503 }) : new Response('{"ok":true}', { status: 200 }));
    const res = await fetchWithRetry('https://sheets.googleapis.com/x', {}, { fetchImpl: flaky, ...noSleep });
    assert.equal(res.status, 200);
    assert.equal(n, 3);
    const down = async () => { throw new TypeError('ECONNRESET'); };
    await assert.rejects(fetchWithRetry('https://sheets.googleapis.com/x', {}, { fetchImpl: down, label: 'Google Sheets (Meta)', ...noSleep }), /Google Sheets \(Meta\) could not be reached after 4 attempts/);
    let waited = 0;
    const limited = async () => (waited ? new Response('{}', { status: 200 }) : new Response('slow down', { status: 429, headers: { 'retry-after': '2' } }));
    await fetchWithRetry('https://x.test', {}, { fetchImpl: limited, baseDelayMs: 0, sleep: async (ms) => { waited = ms; } });
    assert.equal(waited, 2000, 'Retry-After honoured');
  });
});

describe('readAllSheets end to end (sample CSVs through the fake API)', () => {
  it('reads all three Sheets and normalises exactly like the CSV files', async () => {
    const google = fakeGoogle({ spreadsheets: sampleSpreadsheets() });
    const { sheets, stats, serviceAccount } = await readAllSheets(sheetsEnv(), { fetchImpl: google.fetch, now: () => NOW });
    assert.equal(serviceAccount, SERVICE_ACCOUNT.client_email);
    const csv = loadSampleSheets();
    for (const p of ['meta', 'tiktok', 'google']) {
      assert.equal(sheets[p].length, csv[p].length, p);
      assert.deepEqual(sheets[p].columns, csv[p].columns, p);
      assert.equal(stats[p].rows_read, csv[p].length);
    }
    assert.equal(stats.tiktok.tab, "GROOV Ads · TikTok's", 'a tab title with an apostrophe is quoted correctly');
    const opts = { mode: 'live', now: new Date(NOW) };
    const fromApi = normalize(sheets, opts);
    const fromCsv = normalize(csv, opts);
    assert.deepEqual(fromApi.rows, fromCsv.rows);
    assert.deepEqual(fromApi.ads, fromCsv.ads);
    assert.deepEqual(fromApi.health, fromCsv.health);
  });

  it('names every missing env var before calling Google', async () => {
    const google = fakeGoogle();
    await assert.rejects(readAllSheets(sheetsEnv({ SHEET_ID_GOOGLE: '', SHEET_ID_TIKTOK: ' ' }), { fetchImpl: google.fetch }), /SHEET_ID_TIKTOK, SHEET_ID_GOOGLE are not set/);
    await assert.rejects(readAllSheets(sheetsEnv({ GOOGLE_SERVICE_ACCOUNT_JSON: '' }), { fetchImpl: google.fetch }), /GOOGLE_SERVICE_ACCOUNT_JSON is not set/);
    assert.equal(google.calls.length, 0);
  });

  it('fails as a whole when one Sheet cannot be read, naming it', async () => {
    const spreadsheets = sampleSpreadsheets();
    delete spreadsheets[SHEET_IDS.google];
    const google = fakeGoogle({ spreadsheets });
    await assert.rejects(readAllSheets(sheetsEnv(), { fetchImpl: google.fetch, now: () => NOW }), /The Google Sheet was not found/);
  });
});

describe('readOptionalSheets: the two optional Meta breakdown Sheets', () => {
  const grids = syntheticBreakdownGrids();
  const env = (extra = {}) => sheetsEnv(breakdownEnv(extra));
  const read = async (spreadsheets, e = env(), fakeOptions = {}, options = {}) => {
    const google = fakeGoogle({ spreadsheets, ...fakeOptions });
    const result = await readOptionalSheets(e, { fetchImpl: google.fetch, now: () => NOW, retry: noSleep, ...options });
    return { ...result, google };
  };

  it('asks Google for nothing when neither SHEET_ID_META_PLACEMENTS nor SHEET_ID_META_AUDIENCE is set', async () => {
    for (const e of [sheetsEnv(), sheetsEnv({ SHEET_ID_META_PLACEMENTS: '  ', SHEET_ID_META_AUDIENCE: '' }), sheetsEnv({ GOOGLE_SERVICE_ACCOUNT_JSON: '' })]) {
      const r = await read(sampleSpreadsheets(), e);
      assert.deepEqual(r.configured, { placements: false, audience: false });
      assert.deepEqual([r.sheets, r.stats, r.errors], [{}, {}, {}]);
      assert.equal(r.google.calls.length, 0, 'not even the sign-in');
    }
  });

  it('reads both Sheets from separate spreadsheets, like the main Sheets (same rows, columns, stats)', async () => {
    const r = await read({ ...sampleSpreadsheets(), ...breakdownSpreadsheets(grids) });
    assert.deepEqual(r.configured, { placements: true, audience: true });
    assert.deepEqual(r.errors, {});
    assert.equal(r.sheets.placements.length, grids.placements.length - 1);
    assert.equal(r.sheets.audience.length, grids.audience.length - 1);
    assert.deepEqual(r.sheets.placements.columns, PLACEMENT_HEADER);
    assert.deepEqual(r.sheets.audience.columns, AUDIENCE_HEADER);
    assert.deepEqual(r.sheets.placements[0], Object.fromEntries(PLACEMENT_HEADER.map((h, i) => [h, grids.placements[1][i]])));
    assert.deepEqual(r.stats.placements, { tab: TITLES.placements, grid_rows: grids.placements.length, chunks: 1, rows_read: grids.placements.length - 1, unsafe_id_cells: 0 });
    assert.equal(r.stats.audience.tab, TITLES.audience);
    // the main Sheets were not touched
    assert.ok(r.google.calls.every((c) => !c.url.includes(SHEET_IDS.meta) && !c.url.includes(SHEET_IDS.tiktok) && !c.url.includes(SHEET_IDS.google)));
  });

  it('reads only the Sheet that is configured', async () => {
    const r = await read(breakdownSpreadsheets(grids), env({ SHEET_ID_META_AUDIENCE: '' }));
    assert.deepEqual(r.configured, { placements: true, audience: false });
    assert.deepEqual(Object.keys(r.sheets), ['placements']);
    assert.ok(r.google.calls.every((c) => !c.url.includes(SHEET_IDS.audience)));
  });

  it('chunks big Sheets in order, with the same chunked reader as the main Sheets', async () => {
    const r = await read(breakdownSpreadsheets(grids), env(), {}, { chunkRows: 1000 });
    assert.equal(r.stats.placements.chunks, Math.ceil(grids.placements.length / 1000));
    assert.ok(r.stats.placements.chunks > 1);
    assert.equal(r.sheets.placements.length, grids.placements.length - 1);
    assert.deepEqual(r.sheets.placements.map((x) => x.adset_id), grids.placements.slice(1).map((row) => row[2]), 'sheet order kept across chunks');
  });

  it('reads tabs of the same spreadsheet as the Meta Sheet (tab names are case-insensitive)', async () => {
    const spreadsheets = { [SHEET_IDS.meta]: { title: TITLES.meta, grid: sampleGrid('meta'), tabs: { Placements: grids.placements, Audience: grids.audience } } };
    const e = sheetsEnv({
      SHEET_ID_META_PLACEMENTS: SHEET_IDS.meta, SHEET_TAB_META_PLACEMENTS: 'Placements',
      SHEET_ID_META_AUDIENCE: SHEET_IDS.meta, SHEET_TAB_META_AUDIENCE: 'audience',
    });
    const r = await read(spreadsheets, e);
    assert.deepEqual(r.errors, {});
    assert.equal(r.stats.placements.tab, 'Placements');
    assert.equal(r.stats.audience.tab, 'Audience');
    assert.deepEqual(r.sheets.placements.columns, PLACEMENT_HEADER, 'the right tab, not the first one');
    assert.deepEqual(r.sheets.audience.columns, AUDIENCE_HEADER);
    assert.equal(r.sheets.audience.length, grids.audience.length - 1);
  });

  it('refuses to read the first tab of a spreadsheet another Sheet uses, and two Sheets on one tab', async () => {
    const spreadsheets = { [SHEET_IDS.meta]: { title: TITLES.meta, grid: sampleGrid('meta'), tabs: { Placements: grids.placements } } };
    const noTab = await read(spreadsheets, sheetsEnv({ SHEET_ID_META_PLACEMENTS: SHEET_IDS.meta }));
    assert.match(noTab.errors.placements, /SHEET_TAB_META_PLACEMENTS is not set, but SHEET_ID_META_PLACEMENTS is the same spreadsheet as SHEET_ID_META\./);
    assert.deepEqual(noTab.sheets, {});
    assert.ok(!noTab.google.calls.some((c) => c.url.includes('/values/')), 'nothing was read');

    const sameTab = await read(spreadsheets, sheetsEnv({
      SHEET_ID_META_PLACEMENTS: SHEET_IDS.meta, SHEET_TAB_META_PLACEMENTS: 'Placements', SHEET_ID_META_AUDIENCE: SHEET_IDS.meta, SHEET_TAB_META_AUDIENCE: 'placements',
    }));
    assert.match(sameTab.errors.placements, /SHEET_TAB_META_PLACEMENTS and SHEET_TAB_META_AUDIENCE name the same tab/);
    assert.match(sameTab.errors.audience, /SHEET_TAB_META_AUDIENCE and SHEET_TAB_META_PLACEMENTS name the same tab/);

    const mainTab = await read(spreadsheets, sheetsEnv({ SHEET_ID_META_PLACEMENTS: SHEET_IDS.meta, SHEET_TAB_META_PLACEMENTS: 'Placements', SHEET_TAB_META: TITLES.meta }));
    assert.deepEqual(mainTab.errors, {}, 'a named, different tab is fine');
  });

  it('names the tab that does not exist and lists the tabs', async () => {
    const r = await read(breakdownSpreadsheets(grids), env({ SHEET_TAB_META_PLACEMENTS: 'Nope' }));
    assert.match(r.errors.placements, new RegExp(`no tab named "Nope" \\(SHEET_TAB_META_PLACEMENTS\\)\\. Tabs: "${TITLES.placements}"`));
    assert.ok(r.sheets.audience, 'the other Sheet is still read');
  });

  it('reports a Sheet that is not shared (403) or not found (404) with its own env var, and still reads the other one', async () => {
    const forbidden = await read(breakdownSpreadsheets(grids), env(), { override: (url) => (url.pathname.includes(SHEET_IDS.audience) ? new Response('{}', { status: 403 }) : undefined) });
    assert.match(forbidden.errors.audience, new RegExp(`${SERVICE_ACCOUNT.client_email.replace(/\./g, '\\.')}.*Meta audience Sheet.*Share`));
    assert.equal(forbidden.errors.placements, undefined);
    assert.equal(forbidden.sheets.placements.length, grids.placements.length - 1);
    assert.equal(forbidden.sheets.audience, undefined);

    const spreadsheets = breakdownSpreadsheets(grids);
    delete spreadsheets[SHEET_IDS.placements];
    const missing = await read(spreadsheets);
    assert.match(missing.errors.placements, /The Meta placements Sheet was not found\. Check SHEET_ID_META_PLACEMENTS/);
    assert.equal(missing.sheets.audience.length, grids.audience.length - 1);
  });

  it('reports a missing or broken service-account key for every configured Sheet instead of throwing', async () => {
    const r = await read(breakdownSpreadsheets(grids), env({ GOOGLE_SERVICE_ACCOUNT_JSON: '' }));
    assert.match(r.errors.placements, /GOOGLE_SERVICE_ACCOUNT_JSON is not set/);
    assert.match(r.errors.audience, /GOOGLE_SERVICE_ACCOUNT_JSON is not set/);
    assert.equal(r.google.calls.length, 0);
    const refused = await read(breakdownSpreadsheets(grids), env(), { override: (url) => (url.href === 'https://oauth2.googleapis.com/token' ? new Response(JSON.stringify({ error: 'invalid_grant' }), { status: 400 }) : undefined) });
    assert.match(refused.errors.placements, /invalid_grant/);
    assert.match(refused.errors.audience, /invalid_grant/);
  });

  it('turns an unexpected failure into a message too (an answer that is not JSON)', async () => {
    const r = await read(breakdownSpreadsheets(grids), env(), { override: (url) => (url.pathname.includes(SHEET_IDS.placements) && !url.pathname.includes('/values/') ? new Response('<html>oops</html>', { status: 200 }) : undefined) });
    assert.match(r.errors.placements, /^Unexpected error: /);
    assert.ok(r.sheets.audience);
  });

  it('works without any argument other than the environment, and leaves an empty tab as an empty Sheet', async () => {
    const spreadsheets = { [SHEET_IDS.placements]: { title: TITLES.placements, grid: [], rowCount: 0, columnCount: 0 }, [SHEET_IDS.audience]: { title: TITLES.audience, grid: [PLACEMENT_HEADER] } };
    const google = fakeGoogle({ spreadsheets });
    const r = await readOptionalSheets(env(), { fetchImpl: google.fetch, now: () => NOW });
    assert.deepEqual(r.errors, {});
    assert.deepEqual(r.sheets.placements, []);
    assert.equal(r.sheets.audience.length, 0);
    assert.deepEqual(r.sheets.audience.columns, PLACEMENT_HEADER, 'a header-only tab still tells which columns exist');
  });
});
