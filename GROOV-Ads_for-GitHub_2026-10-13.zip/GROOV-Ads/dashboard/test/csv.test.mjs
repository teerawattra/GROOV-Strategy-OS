import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { parseCsv, parseCsvRecords } from '../lib/csv.mjs';

const sheet = (name) => readFileSync(fileURLToPath(new URL(`../sample/sheets/${name}.csv`, import.meta.url)), 'utf8');

// Built from char codes so the source file never contains an invisible BOM or raw script ranges.
const BOM = String.fromCharCode(0xfeff);
const THAI = new RegExp('[' + String.fromCharCode(0x0e00) + '-' + String.fromCharCode(0x0e7f) + ']');

describe('parseCsvRecords: RFC 4180 mechanics', () => {
  it('splits plain records and fields', () => {
    assert.deepEqual(parseCsvRecords('a,b,c\n1,2,3\n'), [['a', 'b', 'c'], ['1', '2', '3']]);
  });

  it('keeps commas, doubled quotes and newlines inside quoted fields', () => {
    const text = 'name,note\n"Apple Pie, but make it a smoothie","He said ""hi"""\n"two\nlines","x"\n';
    assert.deepEqual(parseCsvRecords(text), [
      ['name', 'note'],
      ['Apple Pie, but make it a smoothie', 'He said "hi"'],
      ['two\nlines', 'x'],
    ]);
  });

  it('preserves CRLF that sits inside a quoted field', () => {
    assert.deepEqual(parseCsvRecords('a\r\n"x\r\ny"\r\n'), [['a'], ['x\r\ny']]);
  });

  it('accepts CRLF, LF and lone CR record separators', () => {
    const expected = [['a', 'b'], ['1', '2'], ['3', '4']];
    assert.deepEqual(parseCsvRecords('a,b\r\n1,2\r\n3,4\r\n'), expected);
    assert.deepEqual(parseCsvRecords('a,b\n1,2\n3,4'), expected);
    assert.deepEqual(parseCsvRecords('a,b\r1,2\r3,4\r'), expected);
  });

  it('strips a leading UTF-8 BOM so the first header is clean', () => {
    assert.deepEqual(parseCsvRecords(BOM + 'date,spend\n2026-09-07,1\n')[0], ['date', 'spend']);
  });

  it('handles a final record without a trailing newline and a trailing newline without an extra record', () => {
    assert.equal(parseCsvRecords('a\n1').length, 2);
    assert.equal(parseCsvRecords('a\n1\n').length, 2);
    assert.equal(parseCsvRecords('a\n1\n\n\n').length, 2);
  });

  it('skips blank lines but keeps rows made only of delimiters', () => {
    assert.deepEqual(parseCsvRecords('a,b\n\n,\n'), [['a', 'b'], ['', '']]);
  });

  it('distinguishes empty fields, a trailing delimiter and a quoted empty value', () => {
    assert.deepEqual(parseCsvRecords('a,b,c\n1,,3\n4,5,\n'), [['a', 'b', 'c'], ['1', '', '3'], ['4', '5', '']]);
    assert.deepEqual(parseCsvRecords('a,b\n"",x\n'), [['a', 'b'], ['', 'x']]);
    assert.deepEqual(parseCsvRecords('"",\n'), [['', '']]);
    assert.deepEqual(parseCsvRecords('x,'), [['x', '']]);
  });

  it('is lenient about a stray quote inside an unquoted field (like Python csv)', () => {
    assert.deepEqual(parseCsvRecords('5" nail,ok\n'), [['5" nail', 'ok']]);
  });

  it('supports another single-character delimiter', () => {
    assert.deepEqual(parseCsvRecords('a;b\n"1;2";3\n', { delimiter: ';' }), [['a', 'b'], ['1;2', '3']]);
    assert.throws(() => parseCsvRecords('a', { delimiter: ';;' }), RangeError);
  });

  it('round-trips Thai text and emoji (astral characters) untouched', () => {
    const name = 'โปรโมชั่นพิเศษ 🥣✨ - 8 Jul 2026';
    assert.deepEqual(parseCsvRecords(`n\n"${name}"\n`), [['n'], [name]]);
  });

  it('throws on an unterminated quote instead of swallowing the rest of the file', () => {
    assert.throws(() => parseCsvRecords('a,b\n1,"never closed\n2,3\n'), { name: 'SyntaxError', message: /line 2/ });
  });

  it('rejects non-string input', () => {
    assert.throws(() => parseCsvRecords(null), TypeError);
  });

  it('returns no records for empty input', () => {
    assert.deepEqual(parseCsvRecords(''), []);
    assert.deepEqual(parseCsvRecords(BOM), []);
  });
});

describe('parseCsv: header-keyed objects', () => {
  it('keys every row by the header and keeps values as strings', () => {
    assert.deepEqual(parseCsv('date,spend\n2026-09-07,12.5\n2026-09-08,\n'), [
      { date: '2026-09-07', spend: '12.5' },
      { date: '2026-09-08', spend: '' },
    ]);
  });

  it('pads short rows with "" and ignores cells beyond the header', () => {
    assert.deepEqual(parseCsv('a,b,c\n1\n1,2,3,4\n'), [{ a: '1', b: '', c: '' }, { a: '1', b: '2', c: '3' }]);
  });

  it('trims header names and drops columns with an empty header', () => {
    const rows = parseCsv(' a , ,b\n1,2,3\n');
    assert.deepEqual(rows, [{ a: '1', b: '3' }]);
    assert.deepEqual(rows.columns, ['a', 'b']);
  });

  it('exposes the header as a non-enumerable `columns` list, even with no data rows', () => {
    const rows = parseCsv('date,spend\n');
    assert.deepEqual(rows, []);
    assert.deepEqual(rows.columns, ['date', 'spend']);
    assert.equal(Object.keys(rows).length, 0);
    assert.equal(JSON.stringify(rows), '[]');
  });

  it('lets the last duplicated header win', () => {
    assert.deepEqual(parseCsv('a,a\n1,2\n'), [{ a: '2' }]);
  });

  it('parses empty input to an empty array with no columns', () => {
    const rows = parseCsv('');
    assert.deepEqual(rows, []);
    assert.deepEqual(rows.columns, []);
  });
});

describe('parseCsv on the real sample sheets', () => {
  const expected = { meta: [2564, 22], tiktok: [253, 22], google: [113, 15] };
  for (const [name, [rows, columns]] of Object.entries(expected)) {
    it(`${name}.csv has ${rows} data rows and ${columns} header columns, all complete`, () => {
      const parsed = parseCsv(sheet(name));
      assert.equal(parsed.length, rows);
      assert.equal(parsed.columns.length, columns);
      assert.ok(parsed.every((r) => Object.keys(r).length === columns), 'every row has every column');
    });
  }

  it('reads names that contain commas, quotes, emoji and Thai exactly', () => {
    const meta = parseCsv(sheet('meta'));
    const apple = meta.find((r) => r.ad_name.startsWith('VDO Apple Pie, but make it a protein-packed smoothie.'));
    assert.ok(apple, 'ad name with a comma survives as one field');
    assert.match(apple.ad_name, /🍏✨ - 15 Aug 2026$/);
    assert.ok(meta.some((r) => THAI.test(r.campaign + r.adset_name + r.ad_name)), 'Thai text present');
    assert.ok(meta.some((r) => r.ad_name.includes('"')), 'embedded quote present');
  });
});
