import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { copyFileSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync, existsSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import vm from 'node:vm';
import { parseCsv } from '../lib/csv.mjs';
import { BREAKDOWN_FILES, buildSample, describeBreakdownQuirks, describeBreakdowns, describeQuirks, listSavedCreatives, readBreakdownSheets, summarize, toSampleJs } from '../tools/build-data.mjs';
import { sliceBreakdowns } from '../lib/breakdowns.mjs';
import { syntheticBreakdownGrids } from './backend-fakes.mjs';

const ROOT = fileURLToPath(new URL('..', import.meta.url));
const CLI = join(ROOT, 'tools', 'build-data.mjs');
const NOW_ISO = '2026-10-12T07:05:00+07:00';

/** Evaluate a generated sample.js the way a browser would (classic script, `window` global) and return GROOV_SAMPLE. */
function load(text) {
  const sandbox = { window: {} };
  vm.runInNewContext(text, sandbox);
  return sandbox.window.GROOV_SAMPLE;
}

describe('tools/build-data.mjs', () => {
  let tmp;
  let creatives;
  let metaIds;
  let tiktokIds;
  let expected; // creatives coverage implied by the sheets + the 5 stand-in files saved below

  before(() => {
    tmp = mkdtempSync(join(tmpdir(), 'groov-dashboard-test-'));
    creatives = join(tmp, 'creatives');
    mkdirSync(join(creatives, 'meta'), { recursive: true });
    mkdirSync(join(creatives, 'tiktok'), { recursive: true });
    const sheet = (name) => parseCsv(readFileSync(join(ROOT, 'sample', 'sheets', `${name}.csv`), 'utf8'));
    const metaRows = sheet('meta');
    const tiktokRows = sheet('tiktok');
    metaIds = [...new Set(metaRows.map((r) => r.ad_id))].slice(0, 3);
    tiktokIds = [...new Set(tiktokRows.map((r) => r.ad_id))].slice(0, 2);
    // saved -> image; otherwise a link on some row -> not_saved; otherwise no_url
    const coverage = (rows, urlColumn, savedIds) => {
      const all = new Set(rows.map((r) => r.ad_id));
      const withLink = new Set(rows.filter((r) => r[urlColumn]).map((r) => r.ad_id));
      const saved = new Set(savedIds);
      return {
        ads: all.size,
        saved: saved.size,
        no_url: [...all].filter((id) => !saved.has(id) && !withLink.has(id)).length,
        not_saved: [...withLink].filter((id) => !saved.has(id)).length,
      };
    };
    expected = { meta: coverage(metaRows, 'image_url', metaIds), tiktok: coverage(tiktokRows, 'video_thumbnail_url', tiktokIds) };
    const image = Buffer.alloc(300, 7); // stand-in for a JPEG: only existence and a sane size matter
    for (const id of metaIds) writeFileSync(join(creatives, 'meta', `${id}.jpg`), image);
    for (const id of tiktokIds) writeFileSync(join(creatives, 'tiktok', `${id}.jpg`), image);
    writeFileSync(join(creatives, 'meta', '999999999999999999.jpg'), Buffer.alloc(10)); // stub, not a real image
    writeFileSync(join(creatives, 'meta', 'notes.txt'), image);
    writeFileSync(join(creatives, 'meta', 'not-an-id.jpg'), image);
    writeFileSync(join(creatives, 'meta', `${metaIds[0]}.png`), image); // the dashboard loads .jpg only
  });

  after(() => rmSync(tmp, { recursive: true, force: true }));

  it('listSavedCreatives keys real <ad_id>.jpg files as "platform:id" and ignores stubs and other names', () => {
    const { saved, files, found } = listSavedCreatives(creatives);
    assert.equal(found, true);
    assert.deepEqual([...saved].sort(), [...metaIds.map((id) => `meta:${id}`), ...tiktokIds.map((id) => `tiktok:${id}`)].sort());
    assert.deepEqual(files, { meta: 3, tiktok: 2 });
    assert.deepEqual(listSavedCreatives(join(tmp, 'nope')), { saved: new Set(), files: { meta: 0, tiktok: 0 }, found: false });
  });

  it('buildSample returns a one-line classic script that sets window.GROOV_SAMPLE = {meta, rows, monthly, breakdowns}', () => {
    const result = buildSample({ creativesDir: creatives, now: new Date(NOW_ISO) });
    const { text } = result;
    assert.ok(text.startsWith('window.GROOV_SAMPLE = {"meta":{'), 'starts with the assignment and compact JSON');
    assert.ok(text.endsWith('};\n'));
    assert.equal(text.split('\n').length, 2, 'a single line plus the trailing newline: no pretty-printing');
    assert.ok(Buffer.byteLength(text) < 2 * 1024 * 1024, 'under the 2 MB target');

    const sample = load(text);
    assert.deepEqual(Object.keys(sample), ['meta', 'rows', 'monthly', 'breakdowns']);
    // (objects created inside the vm context have another realm's prototypes, so compare their JSON form)
    assert.deepEqual(JSON.parse(JSON.stringify(sample)), JSON.parse(JSON.stringify(result.payload)), 'what a browser sees equals the payloads');
    assert.equal(sample.meta.mode, 'sample');
    assert.equal(sample.rows.mode, 'sample');
    assert.equal(sample.meta.generated_at, NOW_ISO);
  });

  it('covers the full available range and reflects the creatives folder', () => {
    const { payload } = buildSample({ creativesDir: creatives, now: new Date(NOW_ISO) });
    assert.deepEqual(payload.rows.range, { from: '2026-09-07', to: '2026-09-20' });
    assert.equal(payload.rows.rows.length, 2930);
    assert.deepEqual(payload.meta.creatives, expected);
    assert.deepEqual([expected.meta.ads, expected.meta.saved, expected.tiktok.ads, expected.tiktok.saved], [350, 3, 41, 2]);
    assert.equal(expected.meta.saved + expected.meta.no_url + expected.meta.not_saved, 350);
    assert.equal(payload.rows.ads.filter((a) => a.image).length, 5);
    assert.deepEqual(payload.monthly.months, ['2026-09']);
    assert.equal(payload.meta.data_through, '2026-09-20');
  });

  it('serialises line separators as escapes so older engines can load the file', () => {
    const tricky = `a${String.fromCharCode(0x2028)}b${String.fromCharCode(0x2029)}c "quoted" \\ back`;
    const text = toSampleJs({ meta: { name: tricky }, rows: {}, monthly: {} });
    assert.ok(!text.includes(String.fromCharCode(0x2028)) && !text.includes(String.fromCharCode(0x2029)));
    assert.ok(text.includes('\\u2028') && text.includes('\\u2029'));
    assert.equal(load(text).meta.name, tricky);
  });

  it('keeps Thai text and emoji as real UTF-8 (not escaped)', () => {
    const text = toSampleJs({ meta: { name: 'โปรโมชั่น 🥣' }, rows: {}, monthly: {} });
    assert.ok(text.includes('โปรโมชั่น 🥣'));
  });

  it('the CLI writes the file (creating folders), prints the summary and exits 0', () => {
    const out = join(tmp, 'deep', 'er', 'sample.js');
    const run = spawnSync(process.execPath, [CLI, '--creatives', creatives, '--out', out, '--now', NOW_ISO], { cwd: ROOT, encoding: 'utf8' });
    assert.equal(run.status, 0, run.stderr);
    assert.ok(existsSync(out));
    assert.match(run.stdout, /rows\s+meta 2,564 · tiktok 253 · google 113 · total 2,930/);
    assert.match(run.stdout, /spend \(THB\)\s+meta 155,403\.02 · tiktok 7,402\.27 · google 16,617\.75/);
    assert.match(run.stdout, /data_through 2026-09-20/);
    const c = expected;
    assert.ok(run.stdout.includes(`creatives    meta 3/350 saved (no_url ${c.meta.no_url}, not_saved ${c.meta.not_saved}) · tiktok 2/41 saved (no_url ${c.tiktok.no_url}, not_saved ${c.tiktok.not_saved})`), run.stdout);
    assert.match(run.stdout, /meta: 220 rows with blank status; entities left UNKNOWN: 73 ads, 9 ad sets, 5 campaigns/);
    assert.equal(load(readFileSync(out, 'utf8')).meta.generated_at, NOW_ISO);
  });

  it('the output is byte-for-byte reproducible for the same inputs and --now', () => {
    const [a, b] = ['one.js', 'two.js'].map((name) => {
      const out = join(tmp, name);
      const run = spawnSync(process.execPath, [CLI, '--creatives', creatives, '--out', out, '--now', NOW_ISO], { cwd: ROOT, encoding: 'utf8' });
      assert.equal(run.status, 0, run.stderr);
      return readFileSync(out);
    });
    assert.ok(a.equals(b));
  });

  it('warns (but still builds) when the creatives folder is missing', () => {
    const out = join(tmp, 'no-creatives.js');
    const run = spawnSync(process.execPath, [CLI, '--creatives', join(tmp, 'absent'), '--out', out, '--now', NOW_ISO], { cwd: ROOT, encoding: 'utf8' });
    assert.equal(run.status, 0, run.stderr);
    assert.match(run.stdout, /WARNING\s+creatives folder not found/);
    assert.equal(load(readFileSync(out, 'utf8')).meta.creatives.meta.saved, 0);
  });

  it('fails with a clear message and exit code 1 on bad input, without writing anything', () => {
    const out = join(tmp, 'never.js');
    const cases = [
      [['--sheets', join(tmp, 'no-such-dir'), '--out', out], /Missing sample sheet/],
      [['--bogus'], /Unknown option --bogus/],
      [['--now', 'not-a-date', '--out', out], /--now must be an ISO date-time/],
      [['--out'], /--out needs a value/],
    ];
    for (const [args, message] of cases) {
      const run = spawnSync(process.execPath, [CLI, ...args], { cwd: ROOT, encoding: 'utf8' });
      assert.equal(run.status, 1, args.join(' '));
      assert.match(run.stderr, message);
    }
    assert.equal(existsSync(out), false);
  });

  it('--help prints usage and exits 0', () => {
    const run = spawnSync(process.execPath, [CLI, '--help'], { cwd: ROOT, encoding: 'utf8' });
    assert.equal(run.status, 0);
    assert.match(run.stdout, /Usage: node tools\/build-data\.mjs/);
  });

  it('summarize and describeQuirks report data oddities without changing values', () => {
    const result = buildSample({ creativesDir: creatives, now: new Date(NOW_ISO) });
    const quirks = describeQuirks(result.dataset);
    assert.ok(quirks.some((q) => /^meta: 16 rows with link_clicks > clicks$/.test(q)));
    assert.ok(quirks.some((q) => /^meta: 14 rows with impressions but zero spend$/.test(q)));
    assert.ok(quirks.some((q) => /^tiktok: 35 rows with zero spend and zero impressions$/.test(q)));
    assert.ok(quirks.some((q) => /^google: 10 rows with impressions but zero spend$/.test(q)));
    assert.ok(!quirks.some((q) => /negative|duplicate|columns missing|skipped/.test(q)), 'the sample has none of those');
    assert.match(summarize(result, 'out.js'), /^Wrote out\.js \(\d+ KB\)/);
  });
});

// ---------------------------------------------------------------------------------------------
// The optional breakdown Sheets in the sample bundle
// ---------------------------------------------------------------------------------------------

describe('tools/build-data.mjs: optional breakdown Sheets (placements, audience)', () => {
  let tmp;
  let creatives;
  let grids;
  const NOW = new Date(NOW_ISO);
  const csv = (grid) => `${grid.map((row) => row.join(',')).join('\n')}\n`;
  /** A sheets folder with the three main sample Sheets and, optionally, the two breakdown Sheets (synthetic, reconciled with Sheet 1). */
  function sheetsDir(name, { placements = false, audience = false, from = grids } = {}) {
    const dir = join(tmp, name);
    mkdirSync(dir, { recursive: true });
    for (const platform of ['meta', 'tiktok', 'google']) copyFileSync(join(ROOT, 'sample', 'sheets', `${platform}.csv`), join(dir, `${platform}.csv`));
    if (placements) writeFileSync(join(dir, BREAKDOWN_FILES.placements), csv(from.placements));
    if (audience) writeFileSync(join(dir, BREAKDOWN_FILES.audience), csv(from.audience));
    return dir;
  }

  before(() => {
    tmp = mkdtempSync(join(tmpdir(), 'groov-dashboard-bd-test-'));
    creatives = join(tmp, 'creatives');
    mkdirSync(creatives, { recursive: true });
    grids = syntheticBreakdownGrids();
  });
  after(() => rmSync(tmp, { recursive: true, force: true }));

  it('names the two files the contract describes', () => {
    assert.deepEqual({ ...BREAKDOWN_FILES }, { placements: 'meta_placements.csv', audience: 'meta_audience.csv' });
  });

  it('without the files: a complete "unavailable" payload, and the existing keys exactly as before', () => {
    const dir = sheetsDir('none');
    assert.deepEqual(readBreakdownSheets(dir), {});
    const { payload, text } = buildSample({ sheetsDir: dir, creativesDir: creatives, now: NOW });
    assert.deepEqual(Object.keys(payload), ['meta', 'rows', 'monthly', 'breakdowns']);
    assert.deepEqual(payload.breakdowns, {
      schema: 1, mode: 'sample', range: { from: '2026-09-07', to: '2026-09-20' }, available: { placement: false, audience: false },
      adsets: [], placements: [], audiences: [],
      cols: ['date', 'adset', 'segment', 'spend', 'impressions', 'clicks', 'link_clicks', 'video_views', 'messages', 'leads'],
      placement_rows: [], audience_rows: [],
      coverage: {
        placement: { first_date: null, last_date: null, rows: 0, spend_share: null },
        audience: { first_date: null, last_date: null, rows: 0, spend_share: null },
      },
    });
    assert.deepEqual(payload.meta.breakdowns.placement, {
      available: false, configured: false, rows: 0, first_date: null, last_date: null, spend_share_last_28d: null, all_meta_spend_share_last_28d: null,
      duplicates: 0, columns_missing: [], error: null,
    });
    assert.equal(payload.rows.rows.length, 2930, 'rows untouched');
    assert.deepEqual(JSON.parse(JSON.stringify(load(text).breakdowns.available)), { placement: false, audience: false }); // (JSON form: the vm realm has its own prototypes)
  });

  it('with both files: the full-range /api/breakdowns payload, coverage included, and the health block in meta', () => {
    const dir = sheetsDir('both', { placements: true, audience: true });
    assert.deepEqual(Object.keys(readBreakdownSheets(dir)), ['placements', 'audience']);
    const result = buildSample({ sheetsDir: dir, creativesDir: creatives, now: NOW });
    const { breakdowns, meta: metaPayload } = result.payload;
    assert.deepEqual(breakdowns.available, { placement: true, audience: true });
    assert.deepEqual(breakdowns.range, { from: '2026-09-07', to: '2026-09-20' });
    assert.equal(breakdowns.mode, 'sample');
    assert.equal(breakdowns.placement_rows.length, grids.placements.length - 1);
    assert.equal(breakdowns.audience_rows.length, grids.audience.length - 1);
    assert.deepEqual(breakdowns.coverage.placement, { first_date: '2026-09-07', last_date: '2026-09-20', rows: grids.placements.length - 1, spend_share: 1 });
    assert.deepEqual(breakdowns.coverage.audience, { first_date: '2026-09-07', last_date: '2026-09-20', rows: grids.audience.length - 1, spend_share: 1 });
    // it is exactly what the API would serve for the same range
    assert.deepEqual(breakdowns, sliceBreakdowns(result.breakdownDataset, '2026-09-07', '2026-09-20'));
    // every ad set is one of the sample's Meta ad sets
    const known = new Set(result.payload.rows.adsets.map((a) => a.key));
    assert.ok(breakdowns.adsets.length > 50 && breakdowns.adsets.every((a) => known.has(a.key)));
    // health, as /api/meta would carry it
    assert.equal(metaPayload.breakdowns.placement.available, true);
    assert.equal(metaPayload.breakdowns.placement.configured, true);
    assert.equal(metaPayload.breakdowns.placement.rows, grids.placements.length - 1);
    assert.deepEqual([metaPayload.breakdowns.placement.spend_share_last_28d, metaPayload.breakdowns.audience.all_meta_spend_share_last_28d], [1, 1]);
    // what a browser sees
    const sample = load(result.text);
    assert.deepEqual(JSON.parse(JSON.stringify(sample.breakdowns)), JSON.parse(JSON.stringify(breakdowns)));
    assert.deepEqual(JSON.parse(JSON.stringify(sample.meta.breakdowns)), JSON.parse(JSON.stringify(metaPayload.breakdowns)));
    // the other keys do not change when breakdowns are added
    const without = buildSample({ sheetsDir: sheetsDir('none2'), creativesDir: creatives, now: NOW }).payload;
    assert.deepEqual(result.payload.rows, without.rows);
    assert.deepEqual(result.payload.monthly, without.monthly);
    const { breakdowns: _a, ...metaWith } = metaPayload;
    const { breakdowns: _b, ...metaWithout } = without.meta;
    assert.deepEqual(metaWith, metaWithout);
  });

  it('with only one of the files, only that breakdown is available', () => {
    const onlyPlacements = buildSample({ sheetsDir: sheetsDir('p-only', { placements: true }), creativesDir: creatives, now: NOW }).payload;
    assert.deepEqual(onlyPlacements.breakdowns.available, { placement: true, audience: false });
    assert.equal(onlyPlacements.breakdowns.audience_rows.length, 0);
    assert.deepEqual([onlyPlacements.meta.breakdowns.placement.configured, onlyPlacements.meta.breakdowns.audience.configured], [true, false]);
    const onlyAudience = buildSample({ sheetsDir: sheetsDir('a-only', { audience: true }), creativesDir: creatives, now: NOW }).payload;
    assert.deepEqual(onlyAudience.breakdowns.available, { placement: false, audience: true });
    assert.equal(onlyAudience.breakdowns.placement_rows.length, 0);
  });

  it('a breakdown Sheet that reaches beyond the main Sheets widens the range of its payload', () => {
    const later = {
      placements: [grids.placements[0], ['2026-10-02', '1', '555', 'facebook', 'feed', '10', '100', '5', '4', '0', '1', '0']],
      audience: [grids.audience[0], ['2026-09-01', '1', '555', '25-34', 'female', '10', '100', '5', '4', '0', '1', '0']],
    };
    const { payload } = buildSample({ sheetsDir: sheetsDir('wide', { placements: true, audience: true, from: later }), creativesDir: creatives, now: NOW });
    assert.deepEqual(payload.breakdowns.range, { from: '2026-09-01', to: '2026-10-02' });
    assert.equal(payload.breakdowns.placement_rows.length, 1);
    assert.equal(payload.breakdowns.audience_rows.length, 1);
    assert.deepEqual(payload.breakdowns.adsets.map((a) => a.key), ['meta:555'], 'an ad set that is only in the breakdown Sheets is still listed');
    assert.equal(payload.breakdowns.coverage.placement.spend_share, null, 'no Sheet 1 spend to compare with');
    assert.deepEqual(payload.rows.range, { from: '2026-09-07', to: '2026-09-20' }, 'the rows payload keeps the main range');
  });

  it('is byte-for-byte reproducible with breakdowns, and prints them in the summary', () => {
    const dir = sheetsDir('repro', { placements: true, audience: true });
    const a = buildSample({ sheetsDir: dir, creativesDir: creatives, now: NOW });
    const b = buildSample({ sheetsDir: dir, creativesDir: creatives, now: NOW });
    assert.equal(a.text, b.text);
    const summary = summarize(a, 'out.js');
    const placementRows = (grids.placements.length - 1).toLocaleString('en-US');
    const audienceRows = (grids.audience.length - 1).toLocaleString('en-US');
    assert.ok(summary.includes(`breakdowns   placement: ${placementRows} rows, 2026-09-07 to 2026-09-20, spend share 100.00% (100.00% of all Meta spend) · audience: ${audienceRows} rows, 2026-09-07 to 2026-09-20, spend share 100.00% (100.00% of all Meta spend)`), summary);
    assert.equal(describeBreakdownQuirks(a.breakdownDataset).length, 0, 'the reconciled Sheets have no quirks');
  });

  it('describes missing files and data quirks in plain words', () => {
    const none = buildSample({ sheetsDir: sheetsDir('none3'), creativesDir: creatives, now: NOW });
    assert.equal(describeBreakdowns(none.payload.breakdowns, none.payload.meta.breakdowns), 'placement: none (no usable meta_placements.csv) · audience: none (no usable meta_audience.csv)');
    assert.match(summarize(none, 'out.js'), /breakdowns\s+placement: none \(no usable meta_placements\.csv\)/);
    const messy = {
      placements: [grids.placements[0], ['bad', '1', '5', 'facebook', 'feed', '1', '1', '0', '0', '0', '0', '0'], ['2026-09-07', '1', '5', 'facebook', 'feed', '1', '1', '0', '0', '0', '0', '0'], ['2026-09-07', '1', '5', 'facebook', 'feed', '2', '1', '0', '0', '0', '0', '0']],
      audience: [['date', 'adset_id', 'spend'], ['2026-09-07', '5', '1']],
    };
    const result = buildSample({ sheetsDir: sheetsDir('messy', { placements: true, audience: true, from: messy }), creativesDir: creatives, now: NOW });
    const quirks = describeBreakdownQuirks(result.breakdownDataset);
    assert.ok(quirks.includes('placement: rows skipped (bad date 1, no adset_id 0)'), quirks.join('\n'));
    assert.ok(quirks.includes('placement: 1 duplicate rows (0 identical, 1 conflicting)'), quirks.join('\n'));
    assert.ok(quirks.some((q) => q.startsWith('audience: columns missing: ') && q.endsWith('(the Sheet was ignored)')), quirks.join('\n'));
    assert.match(summarize(result, 'out.js'), /data quirks[\s\S]*- audience: columns missing/);
  });

  it('toSampleJs leaves breakdowns out when there are none, and writes them when there are', () => {
    assert.equal(load(toSampleJs({ meta: {}, rows: {}, monthly: {} })).breakdowns, undefined);
    assert.deepEqual(Object.keys(load(toSampleJs({ meta: {}, rows: {}, monthly: {}, breakdowns: { schema: 1 } }))), ['meta', 'rows', 'monthly', 'breakdowns']);
  });

  const haveRealSheets = ['meta_placements', 'meta_audience'].every((n) => existsSync(join(ROOT, 'sample', 'sheets', `${n}.csv`)));
  it('the real sample Sheets in sample/sheets are picked up by the default build and by the CLI', { skip: haveRealSheets ? false : 'sample/sheets/meta_placements.csv or meta_audience.csv is not there' }, () => {
    const real = buildSample({ creativesDir: creatives, now: NOW });
    assert.deepEqual(real.payload.breakdowns.available, { placement: true, audience: true });
    const count = (name) => parseCsv(readFileSync(join(ROOT, 'sample', 'sheets', `${name}.csv`), 'utf8')).length;
    assert.equal(real.payload.breakdowns.placement_rows.length, count('meta_placements'));
    assert.equal(real.payload.breakdowns.audience_rows.length, count('meta_audience'));
    assert.ok(Buffer.byteLength(real.text) < 2 * 1024 * 1024, 'the bundle stays under the 2 MB target');
    const out = join(tmp, 'real.js');
    const run = spawnSync(process.execPath, [CLI, '--creatives', creatives, '--out', out, '--now', NOW_ISO], { cwd: ROOT, encoding: 'utf8' });
    assert.equal(run.status, 0, run.stderr);
    assert.match(run.stdout, /breakdowns\s+placement: [\d,]+ rows, 2026-09-07 to 2026-09-20, spend share \d+\.\d\d% \(\d+\.\d\d% of all Meta spend\)/);
    assert.match(run.stdout, /audience: [\d,]+ rows, 2026-09-07 to 2026-09-20, spend share \d+\.\d\d% \(\d+\.\d\d% of all Meta spend\)/);
    assert.deepEqual(JSON.parse(JSON.stringify(load(readFileSync(out, 'utf8')).breakdowns.available)), { placement: true, audience: true });
  });
});
