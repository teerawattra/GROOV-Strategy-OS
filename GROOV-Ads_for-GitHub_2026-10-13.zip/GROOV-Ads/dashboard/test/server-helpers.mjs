// Shared fixtures for the VPS server tests (server-*.test.mjs): temp folders, a config built through loadConfig,
// a quiet logger that keeps its lines, the sample CSVs, the "truth" (the normalisers run directly on the CSVs) and a
// small HTTP client. No network beyond 127.0.0.1.

import { mkdtemp, rm } from 'node:fs/promises';
import { readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import http from 'node:http';
import { fileURLToPath } from 'node:url';
import { gunzipSync, brotliDecompressSync } from 'node:zlib';
import { parseCsv } from '../lib/csv.mjs';
import { meta, monthly, normalize } from '../lib/normalize.mjs';
import { breakdownsHealth, normaliseBreakdowns } from '../lib/breakdowns.mjs';
import { loadConfig } from '../server/config.mjs';
import { createLogger } from '../server/util.mjs';

export const SAMPLE_DIR = fileURLToPath(new URL('../sample/sheets/', import.meta.url));
/** 07:15 Bangkok on 21 Sep 2026: "yesterday" is 20 Sep, the last day of the sample. */
export const NOW = new Date('2026-09-21T00:15:00Z');
export const noSleep = async () => {};
/** Image downloads in tests never leave the machine: every request fails like a network error. */
export const offlineFetch = async () => {
  throw new TypeError('offline test: no network');
};

export async function tempRoot(prefix = 'groov-vps-') {
  const dir = await mkdtemp(join(tmpdir(), prefix));
  return { dir, cleanup: () => rm(dir, { recursive: true, force: true }) };
}

/** A config for a temp root (data/ and config/ inside it), built through loadConfig like the CLI does. */
export function makeConfig(root, env = {}) {
  return loadConfig({
    env: { DATA_DIR: join(root, 'data'), CONFIG_DIR: join(root, 'config'), AUTH_MODE: 'none', HOST: '127.0.0.1', PORT: '0', ...env },
    cwd: root,
  });
}

/** A logger that prints nothing and keeps every line (with the secrets it was given redacted). */
export function quietLog(secrets = []) {
  return createLogger({ secrets, quiet: true });
}

export function readSample(name) {
  return parseCsv(readFileSync(join(SAMPLE_DIR, `${name}.csv`), 'utf8'));
}

/** The normalisers run straight on the sample CSVs: the payloads the API must reproduce byte for byte. */
export function expectedFromCsv({ now = NOW, savedCreatives = new Set(), breakdowns = true } = {}) {
  const dataset = normalize({ meta: readSample('meta'), tiktok: readSample('tiktok'), google: readSample('google') }, { savedCreatives, mode: 'live', now });
  const bds = normaliseBreakdowns(breakdowns ? { placements: readSample('meta_placements'), audience: readSample('meta_audience') } : {}, { mode: 'live', now, main: dataset });
  const health = breakdownsHealth(bds, dataset, { configured: { placements: breakdowns, audience: breakdowns }, errors: {} });
  return { dataset, bds, metaPayload: { ...meta(dataset), breakdowns: health }, monthlyPayload: monthly(dataset) };
}

/**
 * GET/POST with node:http (so Accept-Encoding is exactly what the test says). Returns status, headers, the raw body
 * and the decoded text.
 */
export function request(url, { method = 'GET', headers = {}, body = null } = {}) {
  return new Promise((resolve, reject) => {
    const req = http.request(url, { method, headers }, (res) => {
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => {
        const raw = Buffer.concat(chunks);
        const enc = res.headers['content-encoding'];
        const decoded = enc === 'br' ? brotliDecompressSync(raw) : enc === 'gzip' ? gunzipSync(raw) : raw;
        resolve({ status: res.statusCode, headers: res.headers, raw, body: decoded, text: decoded.toString('utf8'), json: () => JSON.parse(decoded.toString('utf8')) });
      });
      res.on('error', reject);
    });
    req.on('error', reject);
    if (body) req.write(body);
    req.end();
  });
}

/** Poll `fn` until it returns a truthy value (or time out). */
export async function waitFor(fn, { timeoutMs = 5000, intervalMs = 25 } = {}) {
  const until = Date.now() + timeoutMs;
  for (;;) {
    const v = await fn();
    if (v) return v;
    if (Date.now() > until) throw new Error('waitFor timed out');
    await new Promise((r) => setTimeout(r, intervalMs));
  }
}

/** Minimal JPEG / PNG byte strings that sniff as images (the image job and /img only check the magic bytes). */
export function jpegBytes(size = 400) {
  const b = Buffer.alloc(size, 0x11);
  b[0] = 0xff; b[1] = 0xd8; b[2] = 0xff; b[3] = 0xe0;
  return b;
}
export function pngBytes(size = 400) {
  const b = Buffer.alloc(size, 0x22);
  Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]).copy(b);
  return b;
}
