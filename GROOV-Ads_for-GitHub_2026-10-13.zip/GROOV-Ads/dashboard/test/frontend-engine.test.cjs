// Frontend engine tests: run with  node --test test/frontend-engine.test.cjs
//
// Loads the dashboard's classic browser scripts (public/assets/js/*.js) and the generated data files
// (public/data/registry.js, learnings.js, sample.js) into a Node `vm` context with a fake `window`,
// then checks the engine and the view model against the real Sep 2026 sample:
//   - Hermes parity (account-level decisions, 14–20 Sep vs 7–13 Sep 2026)
//   - totals reconcile (campaigns -> clients -> overview) under several filters
//   - period math (presets, compare windows, no-baseline rules) for data_through 2026-09-20
//   - no NaN / Infinity anywhere in computed KPIs, decisions or rendered HTML
//   - playbook predicates, formatting, cost-per-result bridge, slugs, URL state, HTML escaping
'use strict';

const { describe, test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { sampleBundleText } = require('./sample-bundle.cjs'); // public/data/sample.js, or built from sample/sheets (VPS package)

const PUB = path.join(__dirname, '..', 'public');
const SCRIPTS = ['util.js', 'data.js', 'engine.js', 'model.js', 'charts.js', 'ui.js', 'sidebar.js',
  'views/overview.js', 'views/trends.js', 'views/adset.js', 'views/actions.js', 'views/client.js', 'views/creatives.js', 'views/playbook.js', 'views/health.js', 'app.js'];

/** Fresh sandbox: data files + every script. `registryPatch` can edit the registry before indexing. */
function load(opts = {}) {
  const sandbox = { console, location: { protocol: 'file:', hostname: '', hash: '' }, __GROOV_TODAY__: '2026-09-21' };
  sandbox.window = sandbox;
  vm.createContext(sandbox);
  for (const f of ['data/registry.js', 'data/learnings.js', 'data/sample.js']) {
    vm.runInContext(f === 'data/sample.js' ? sampleBundleText() : fs.readFileSync(path.join(PUB, f), 'utf8'), sandbox, { filename: f });
  }
  if (opts.registryPatch) opts.registryPatch(sandbox.GROOV_REGISTRY);
  for (const f of SCRIPTS) vm.runInContext(fs.readFileSync(path.join(PUB, 'assets/js', f), 'utf8'), sandbox, { filename: f });
  const G = sandbox.GROOV;
  const reg = G.data.indexRegistry(sandbox.GROOV_REGISTRY);
  const ds = G.data.indexRows(sandbox.GROOV_SAMPLE.rows, reg);
  const meta = sandbox.GROOV_SAMPLE.meta;
  const learn = sandbox.GROOV_LEARNINGS;
  const state = (patch = {}) => {
    const s = G.sidebar.defaults();
    if (patch.period) Object.assign(s.period, patch.period);
    if (patch.compare) s.compare = patch.compare;
    if (patch.filters) Object.assign(s.filters, patch.filters);
    if (patch.rules) Object.assign(s.rules, patch.rules);
    if (patch.route) s.route = patch.route;
    if (patch.ui) Object.assign(s.ui, patch.ui);
    return s;
  };
  const snapshot = (patch) => { G.model.clearMemo(); return G.model.snapshot({ ds, meta, reg, learn, state: state(patch) }); };
  return { sandbox, G, reg, ds, meta, learn, state, snapshot };
}

const ENV = load();
const { G } = ENV;
const U = G.util, D = G.data, E = G.engine, M = G.model;
const near = (a, b, tol, label) => assert.ok(Math.abs(a - b) <= tol, `${label}: ${a} vs ${b} (±${tol})`);
const finiteOrNull = (v) => v === null || (typeof v === 'number' && Number.isFinite(v));
const BAD_TEXT = /\b(NaN|Infinity|undefined|null)\b/;

/** The original Hermes objective_for (build_command_center.py), kept here to document the deliberate changes. */
function hermesClassify(platform, raw, name, agg) {
  raw = String(raw || '').toUpperCase();
  if (platform === 'meta') {
    if (raw === 'OUTCOME_LEADS' || E.leadName(name)) return 'Lead generation';
    if (raw === 'OUTCOME_AWARENESS') return 'Awareness';
    if (agg.messages > 0 || E.msgName(name)) return 'Messages';
    if (raw === 'LINK_CLICKS' || raw.includes('TRAFFIC')) return 'Traffic';
    return 'Engagement';
  }
  if (platform === 'tiktok') {
    if (raw === 'REACH') return 'Awareness';
    if (raw === 'VIDEO_VIEWS' || raw === 'ENGAGEMENT') return 'Engagement';
    if (raw === 'TRAFFIC') return 'Traffic';
    if (raw === 'LEAD_GENERATION') return 'Lead generation';
    if (agg.messages > 0 || E.msgName(name)) return 'Messages';
    return 'Conversions';
  }
  return 'Conversions';
}

/** The original Hermes decision inputs: Engagement judged on CPC, Traffic's response rate = all-click CTR. */
function hermesMetrics(platform, a, objective) {
  const m = E.decisionMetrics(platform, a, objective);
  const rt = (x, y) => (y ? x / y : 0);
  if (objective === 'Engagement') { m.cost_per_result = rt(a.spend, a.clicks); m.cost_label = 'CPC'; }
  if (objective === 'Traffic') { m.response_rate = rt(a.clicks, a.impressions); m.response_label = 'CTR'; m.unreported = false; }
  return m;
}

/* =========================================================================================== */
describe('Hermes parity (7D preset: 14–20 Sep 2026 vs 7–13 Sep 2026)', () => {
  const snap = ENV.snapshot();
  const par = M.parity(snap);

  test('default periods are 14–20 Sep vs 7–13 Sep with a baseline', () => {
    assert.equal(snap.P.cur.from, '2026-09-14');
    assert.equal(snap.P.cur.to, '2026-09-20');
    assert.equal(snap.P.cmp.from, '2026-09-07');
    assert.equal(snap.P.cmp.to, '2026-09-13');
    assert.equal(snap.P.noBaseline, false);
  });

  // SPEC §5/§8: decisions judge the KPIs on screen (Engagement: cost per 3-second view + view rate;
  // Traffic: link CPC + link CTR). Hermes judged Engagement on CPC and Traffic on all-click CTR, so on
  // the Sep sample three accounts change on purpose (Hermes 3 / 10 / 2 / 6 → 3 / 9 / 4 / 5):
  //   - GAIA Krabi Ad Account (Meta)            Watch Out   → Ready to Scale
  //       Groov_TOF/ENGAGE_FB_Aug  Watch Out → No Touching · Groov_TOF/ENGAGE_IG_JULY  No Touching → Ready to Scale
  //   - Rena Yakiniku (Meta)                    Watch Out   → Ready to Scale
  //       TOF_Engagement_BA  Ready to Scale → No Touching · TOF_Engagement_CH  Watch Out → No Touching
  //   - Pakasai Resort Krabi Ad Account (Meta)  No Touching → Watch Out
  //       Groov_FB_TOF_TrafficPage_AUD_TH_8JULY26  No Touching → Watch Out (link CTR fell ≥ 25%)
  const CHANGED = {
    'GAIA Krabi Ad Account': ['Watch Out', 'Ready to Scale'],
    'Rena Yakiniku': ['Watch Out', 'Ready to Scale'],
    'Pakasai Resort Krabi Ad Account': ['No Touching', 'Watch Out']
  };

  test('21 delivering accounts: Immediate 3 / Watch 9 / Scale 4 / Hold 5', () => {
    assert.equal(par.accounts.length, 21);
    assert.deepEqual({ ...par.counts }, { 'Immediate Action': 3, 'Watch Out': 9, 'Ready to Scale': 4, 'No Touching': 5 });
    const byPlatform = {};
    par.accounts.forEach((a) => { byPlatform[a.platform] = (byPlatform[a.platform] || 0) + 1; });
    assert.deepEqual(byPlatform, { meta: 17, tiktok: 3, google: 1 });
  });

  test('total current spend ฿91,303.10 (±0.01; money kept to 4 decimals)', () => {
    near(par.total, 91303.10, 0.01, 'total spend');
    const per = {};
    par.accounts.forEach((a) => { per[a.platform] = (per[a.platform] || 0) + a.spend; });
    near(per.meta, 79855.83, 0.005, 'Meta spend');
    near(per.tiktok, 3464.85, 0.005, 'TikTok spend');
    near(per.google, 7982.4231, 0.0005, 'Google spend');
  });

  test('only the documented accounts differ from Hermes (KPI-consistency change), by name', () => {
    const acc = new Map();
    snap.camps.filter((r) => r.delivering).forEach((r) => {
      const o = hermesClassify(r.platform, r.rawObjective, r.name, r.cur);
      const d = E.decideCampaign(hermesMetrics(r.platform, r.cur, o), hermesMetrics(r.platform, r.cmp, o), E.DEFAULT_RULES).label;
      const k = r.platform + '::' + r.account.id;
      acc.set(k, E.mostSevere([acc.get(k), d].filter(Boolean)));
    });
    const hermesCounts = { 'Immediate Action': 0, 'Watch Out': 0, 'Ready to Scale': 0, 'No Touching': 0 };
    acc.forEach((d) => { hermesCounts[d]++; });
    assert.deepEqual(hermesCounts, { 'Immediate Action': 3, 'Watch Out': 10, 'Ready to Scale': 2, 'No Touching': 6 }, 'the original Hermes build');
    const changed = {};
    par.accounts.forEach((a) => { const h = acc.get(a.key); if (h !== a.decision) changed[a.name] = [h, a.decision]; });
    assert.deepEqual(changed, CHANGED);
  });

  test('SPEC §5 classifier: message campaigns with an attributed sale stay Messages', () => {
    const differ = snap.camps.filter((r) => r.delivering && hermesClassify(r.platform, r.rawObjective, r.name, r.cur) !== r.objective);
    assert.deepEqual(Array.from(differ, (r) => r.name), [], 'no campaign is classified differently from Hermes on the sample');
    const peak = snap.camps.filter((r) => r.client.name === 'The Peak Clinic' && r.delivering);
    assert.ok(peak.length >= 9);
    peak.forEach((r) => assert.equal(r.objective, 'Messages', r.name));
    assert.ok(peak.some((r) => r.cur.roas_value > 0), 'some of them carry purchase ROAS and still stay Messages');
  });

  test('evidence cites the same numbers the tables show (Engagement and Traffic)', () => {
    const eng = snap.camps.find((r) => r.delivering && r.objective === 'Engagement' && r.prim.cost !== null);
    assert.equal(eng.hm.cost_label, 'Cost per view');
    near(eng.hm.cost_per_result, eng.prim.cost, 1e-9, 'cost per view');
    assert.equal(eng.evidence[2].cur, U.money(eng.prim.cost));
    const tr = snap.camps.find((r) => r.delivering && r.objective === 'Traffic' && r.platform === 'meta');
    assert.equal(tr.hm.response_label, 'Link CTR');
    near(tr.hm.response_rate * 100, tr.k.link_ctr, 1e-9, 'link CTR');
    near(tr.hm.cost_per_result, tr.prim.cost, 1e-9, 'link CPC');
  });

  test('GROOV lead campaign stays Lead generation with CPL (Hermes regression check)', () => {
    const lead = snap.camps.find((r) => r.name === 'Groov_TOF_LeadGen_F&B_17AUG26');
    assert.ok(lead, 'lead campaign present');
    assert.equal(lead.objective, 'Lead generation');
    assert.equal(lead.prim.costLabel, 'CPL');
  });

  test('decision rules come from the sidebar thresholds', () => {
    const strict = ENV.snapshot({ rules: { zeroSpend: 100000 } });
    const p2 = M.parity(strict);
    assert.equal(p2.counts['Immediate Action'], 0, 'no account is Immediate when the zero-result spend bar is ฿100,000');
    ENV.snapshot();
  });
});

/* =========================================================================================== */
describe('totals reconcile (campaigns → clients → overview) under the same filters', () => {
  const KEYS = D.METRICS;
  const combos = [
    {}, { platforms: ['meta'] }, { platforms: ['tiktok', 'google'] }, { verticals: ['Clinic'] }, { objectives: ['Messages'] },
    { verticals: ['F&B'], objectives: ['Awareness', 'Engagement'] }, { decisions: ['Watch'], activeOnly: true, minSpend: 500 }
  ];
  for (const f of combos) {
    test('filters ' + JSON.stringify(f), () => {
      const snap = ENV.snapshot({ filters: f });
      let sumClients = D.zero();
      snap.clients.forEach((c) => {
        const s = D.sumObjs(c.camps.map((r) => r.cur));
        KEYS.forEach((k) => near(c.cur[k], s[k], 1e-6, `${c.name} ${k}`));
        D.addInto(sumClients, c.cur);
      });
      KEYS.forEach((k) => near(snap.totals.cur[k], sumClients[k], 1e-6, 'overview ' + k));
      const sumScoped = D.sumObjs(snap.scoped.map((r) => r.cur));
      KEYS.forEach((k) => near(snap.totals.cur[k], sumScoped[k], 1e-6, 'scoped ' + k));
      // every in-scope campaign respects the scope filters
      snap.scoped.forEach((r) => {
        if (f.platforms) assert.ok(f.platforms.includes(r.platform));
        if (f.verticals) assert.ok(f.verticals.includes(r.vertical));
        if (f.objectives) assert.ok(f.objectives.includes(r.objective));
      });
    });
  }
  test('row filters (decisions, active only, min spend) never change totals', () => {
    const a = ENV.snapshot();
    const b = ENV.snapshot({ filters: { decisions: ['Immediate'], activeOnly: true, minSpend: 2000 } });
    near(a.totals.cur.spend, b.totals.cur.spend, 1e-9, 'spend');
    near(a.totals.cmp.spend, b.totals.cmp.spend, 1e-9, 'comparison spend');
    assert.equal(b.rowFiltersActive, true);
    const rf = M.rowFilter(b.F);
    b.clients.filter(rf).forEach((c) => {
      assert.equal(c.decision, 'Immediate Action');
      assert.ok(c.cur.spend >= 2000);
    });
  });
  test('all-platform overview spend equals the sample rows summed over 14–20 Sep', () => {
    const snap = ENV.snapshot();
    let raw = 0;
    ENV.sandbox.GROOV_SAMPLE.rows.rows.forEach((r) => { if (r[0] >= '2026-09-14' && r[0] <= '2026-09-20') raw += r[4]; });
    near(snap.totals.cur.spend, raw, 1e-6, 'raw rows');
  });
});

/* =========================================================================================== */
describe('period math for data_through 2026-09-20 (history from 2026-09-07)', () => {
  const meta = { data_through: '2026-09-20', history_from: '2026-09-07' };
  const P = (preset, compare = 'prev', extra = {}) => D.periods(meta, Object.assign({ preset }, extra), compare);

  test('7D', () => {
    const p = P('7d');
    assert.deepEqual({ ...p.cur }, { from: '2026-09-14', to: '2026-09-20' });
    assert.deepEqual({ ...p.cmp }, { from: '2026-09-07', to: '2026-09-13' });
    assert.equal(p.noBaseline, false);
    assert.deepEqual({ ...p.provisional }, { from: '2026-09-18', to: '2026-09-20' });
    assert.equal(p.label, '14–20 Sep 2026');
    assert.equal(p.cmpLabel, '7–13 Sep 2026');
  });
  test('14D: comparison 24 Aug–6 Sep starts before history → no baseline', () => {
    const p = P('14d');
    assert.deepEqual({ ...p.cur }, { from: '2026-09-07', to: '2026-09-20' });
    assert.deepEqual({ ...p.cmp }, { from: '2026-08-24', to: '2026-09-06' });
    assert.equal(p.noBaseline, true);
    assert.match(p.reason, /before the history start/);
  });
  test('30D: clipped to the history start, comparison has no baseline', () => {
    const p = P('30d');
    assert.deepEqual({ ...p.nominal }, { from: '2026-08-22', to: '2026-09-20' });
    assert.deepEqual({ ...p.cur }, { from: '2026-09-07', to: '2026-09-20' });
    assert.equal(p.clipped, true);
    assert.deepEqual({ ...p.cmp }, { from: '2026-07-23', to: '2026-08-21' });
    assert.equal(p.len, 30); assert.equal(p.cmpLen, 30);
    assert.equal(p.noBaseline, true);
  });
  test('MTD vs the same number of days at the start of last month', () => {
    const p = P('mtd');
    assert.deepEqual({ ...p.nominal }, { from: '2026-09-01', to: '2026-09-20' });
    assert.deepEqual({ ...p.cur }, { from: '2026-09-07', to: '2026-09-20' });
    assert.deepEqual({ ...p.cmp }, { from: '2026-08-01', to: '2026-08-20' });
    assert.equal(p.noBaseline, true);
  });
  test('Last month (August) lies wholly before the history: no current data', () => {
    const p = P('lastmonth');
    assert.deepEqual({ ...p.nominal }, { from: '2026-08-01', to: '2026-08-31' });
    assert.equal(p.cur, null);
    assert.deepEqual({ ...p.cmp }, { from: '2026-07-01', to: '2026-07-31' });
    assert.equal(p.noBaseline, true);
  });
  test('QTD and last quarter', () => {
    const q = P('qtd');
    assert.deepEqual({ ...q.nominal }, { from: '2026-07-01', to: '2026-09-20' });
    assert.deepEqual({ ...q.cmp }, { from: '2026-04-01', to: '2026-06-21' });
    assert.equal(q.len, 82); assert.equal(q.cmpLen, 82);
    const lq = P('lastquarter');
    assert.deepEqual({ ...lq.nominal }, { from: '2026-04-01', to: '2026-06-30' });
    assert.deepEqual({ ...lq.cmp }, { from: '2026-01-01', to: '2026-03-31' }, 'Q1 is shorter: capped at its end');
    assert.equal(lq.unequal, true);
  });
  test('custom ranges and their equal-length comparison', () => {
    const a = P('custom', 'prev', { from: '2026-09-14', to: '2026-09-17' });
    assert.deepEqual({ ...a.cur }, { from: '2026-09-14', to: '2026-09-17' });
    assert.deepEqual({ ...a.cmp }, { from: '2026-09-10', to: '2026-09-13' });
    assert.equal(a.noBaseline, false);
    const b = P('custom', 'prev', { from: '2026-09-10', to: '2026-09-16' });
    assert.deepEqual({ ...b.cmp }, { from: '2026-09-03', to: '2026-09-09' });
    assert.equal(b.noBaseline, true);
    const c = P('custom', 'prev', { from: '2026-08-01', to: '2026-12-31' });
    assert.deepEqual({ ...c.cur }, { from: '2026-09-07', to: '2026-09-20' }, 'custom inputs are limited to history start and data-through');
    const d = P('custom', 'prev', { from: '2026-09-18', to: '2026-09-12' });
    assert.deepEqual({ ...d.cur }, { from: '2026-09-12', to: '2026-09-18' }, 'reversed inputs are swapped');
  });
  test('compare modes: same period last month / last year / off', () => {
    const m = P('7d', 'month');
    assert.deepEqual({ ...m.cmp }, { from: '2026-08-14', to: '2026-08-20' });
    assert.equal(m.noBaseline, true);
    const y = P('7d', 'year');
    assert.deepEqual({ ...y.cmp }, { from: '2025-09-14', to: '2025-09-20' });
    assert.equal(y.noBaseline, true);
    const o = P('7d', 'off');
    assert.equal(o.cmp, null);
    assert.equal(o.noBaseline, false);
  });
  test('needed fetch range (live mode) never precedes the history start', () => {
    assert.deepEqual({ ...D.neededRange(meta, P('7d')) }, { from: '2026-09-07', to: '2026-09-20' });
    assert.deepEqual({ ...D.neededRange(meta, P('7d', 'off')) }, { from: '2026-09-11', to: '2026-09-20' }, 'delivery checks need 10 days');
    assert.deepEqual({ ...D.neededRange(meta, P('90d')) }, { from: '2026-09-07', to: '2026-09-20' });
    const later = { data_through: '2026-12-20', history_from: '2026-01-01' };
    assert.deepEqual({ ...D.neededRange(later, D.periods(later, { preset: '30d' }, 'prev')) }, { from: '2026-10-22', to: '2026-12-20' });
    assert.deepEqual({ ...D.neededRange(later, D.periods(later, { preset: '7d' }, 'off'), { pacing: true }) }, { from: '2026-12-01', to: '2026-12-20' });
  });
  test('date helpers clamp month ends and label ranges', () => {
    assert.equal(U.addMonths('2026-03-31', -1), '2026-02-28');
    assert.equal(U.addMonths('2024-03-31', -1), '2024-02-29');
    assert.equal(U.addMonths('2026-01-15', -12), '2025-01-15');
    assert.equal(U.quarterStart('2026-09-20'), '2026-07-01');
    assert.equal(U.quarterEnd('2026-02-10'), '2026-03-31');
    assert.equal(U.rangeLabel('2026-08-28', '2026-09-03'), '28 Aug–3 Sep 2026');
    assert.equal(U.rangeLabel('2025-12-28', '2026-01-03'), '28 Dec 2025–3 Jan 2026');
  });
});

/* =========================================================================================== */
describe('no NaN / Infinity / undefined in computed values', () => {
  const states = [{}, { period: { preset: '14d' } }, { period: { preset: 'mtd' }, compare: 'off' }, { period: { preset: 'custom', from: '2026-09-20', to: '2026-09-20' } },
    { period: { preset: 'lastmonth' } }, { compare: 'year' }];
  for (const s of states) {
    test('state ' + JSON.stringify(s), () => {
      const snap = ENV.snapshot(s);
      const rows = snap.camps.concat(snap.adsets, snap.ads);
      rows.forEach((r) => {
        for (const k of Object.keys(r.k)) if (k !== 'linkKnown') assert.ok(finiteOrNull(r.k[k]), `${r.level} ${r.name} k.${k}=${r.k[k]}`);
        for (const k of Object.keys(r.kp)) if (k !== 'linkKnown') assert.ok(finiteOrNull(r.kp[k]), `${r.level} ${r.name} kp.${k}`);
        for (const k of ['result', 'cost', 'n', 'rate']) assert.ok(r.prim[k] === undefined || finiteOrNull(r.prim[k]), `${r.name} prim.${k}=${r.prim[k]}`);
        assert.ok(E.DECISIONS.includes(r.decision.label), r.name);
        assert.ok(!BAD_TEXT.test(r.decision.why + ' ' + r.decision.action), `${r.name}: ${r.decision.why}`);
        (r.evidence || []).forEach((e) => assert.ok(!BAD_TEXT.test(`${e.cur} ${e.prev}`), `${r.name} evidence ${e.label}: ${e.cur} / ${e.prev}`));
      });
      snap.camps.forEach((r) => {
        for (const k of ['spend', 'impressions', 'results', 'cost_per_result', 'response_rate', 'ctr', 'cpm', 'roas']) {
          assert.ok(Number.isFinite(r.hm[k]), `${r.name} hermes ${k}=${r.hm[k]}`);
        }
      });
      snap.clients.forEach((c) => {
        if (c.primary) for (const k of ['result', 'cost', 'dResult', 'dCost']) assert.ok(finiteOrNull(c.primary[k]), `${c.name} primary.${k}`);
      });
      snap.actions.forEach((a) => assert.ok(!BAD_TEXT.test(a.title + ' ' + a.why + ' ' + a.action), a.title));
    });
  }
});

/* =========================================================================================== */
describe('engine units', () => {
  test('classifier order (SPEC §5)', () => {
    assert.equal(E.classify('meta', 'OUTCOME_LEADS', 'Anything MSG', { messages: 5 }), 'Lead generation');
    assert.equal(E.classify('meta', 'OUTCOME_ENGAGEMENT', 'TOF_LEADGEN test', {}), 'Lead generation');
    assert.equal(E.classify('meta', 'OUTCOME_SALES', 'MSG sale', { messages: 3 }), 'Conversions');
    assert.equal(E.classify('meta', 'CONVERSIONS', 'x', {}), 'Conversions');
    assert.equal(E.classify('meta', 'PRODUCT_CATALOG_SALES', 'x', {}), 'Conversions');
    assert.equal(E.classify('meta', 'OUTCOME_ENGAGEMENT', 'TOF_MSG', { messages: 2, roas_value: 10 }), 'Messages', 'a message campaign with an attributed sale stays Messages');
    assert.equal(E.classify('meta', 'OUTCOME_TRAFFIC', 'Traffic', { roas_value: 10 }), 'Traffic');
    assert.equal(E.classify('meta', 'OUTCOME_ENGAGEMENT', 'Engage', { roas_value: 10 }), 'Conversions', 'ROAS present, not messages or traffic');
    assert.equal(E.classify('meta', 'REACH', 'x', {}), 'Awareness');
    assert.equal(E.classify('meta', 'BRAND_AWARENESS', 'MSG name', { messages: 4 }), 'Awareness');
    assert.equal(E.classify('meta', 'OUTCOME_ENGAGEMENT', 'Inbox push', {}), 'Messages');
    assert.equal(E.classify('meta', 'OUTCOME_TRAFFIC', 'x', {}), 'Traffic');
    assert.equal(E.classify('meta', 'OUTCOME_ENGAGEMENT', 'Engage', {}), 'Engagement');
    assert.equal(E.classify('tiktok', 'LEAD_GENERATION', 'x', {}), 'Lead generation');
    assert.equal(E.classify('tiktok', 'CONVERSIONS', 'DM campaign', { messages: 1 }), 'Messages');
    assert.equal(E.classify('tiktok', 'PRODUCT_SALES', 'x', {}), 'Conversions');
    assert.equal(E.classify('google', null, 'Search', {}), 'Conversions');
  });
  test('campaign decision thresholds', () => {
    const m = (o) => E.decisionMetrics('meta', o, 'Messages');
    const z = m({ spend: 150, impressions: 1000, clicks: 10, messages: 0 });
    assert.equal(E.decideCampaign(z, m({ spend: 100, impressions: 900, messages: 2 }), E.DEFAULT_RULES).label, 'Immediate Action');
    assert.equal(E.decideCampaign(z, m({}), E.rulesFrom({ zeroSpend: 200 })).label, 'No Touching');
    // exactly −10% is −9.999…% in floating point (as in Hermes), so test clearly past the boundary
    const better = E.decideCampaign(m({ spend: 880, impressions: 9000, messages: 10 }), m({ spend: 1000, impressions: 9000, messages: 10 }), E.DEFAULT_RULES);
    assert.equal(better.label, 'Ready to Scale');
    assert.equal(E.decideCampaign(m({ spend: 880, impressions: 9000, messages: 10 }), m({ spend: 1000, impressions: 9000, messages: 10 }), E.rulesFrom({ scaleCost: 15 })).label,
      'No Touching', 'a stricter scale threshold from the sidebar applies');
    const worse = E.decideCampaign(m({ spend: 1300, impressions: 9000, messages: 10 }), m({ spend: 1000, impressions: 9000, messages: 10 }), E.DEFAULT_RULES);
    assert.equal(worse.label, 'Watch Out');
    assert.match(worse.why, /Cost per message worsened 30%/);
    // Engagement is judged on cost per view (not CPC); Traffic on link CPC / link CTR
    const e = (o) => E.decisionMetrics('meta', o, 'Engagement');
    const eng = E.decideCampaign(e({ spend: 1000, impressions: 50000, clicks: 100, video_views: 10000 }), e({ spend: 1000, impressions: 50000, clicks: 200, video_views: 8000 }), E.DEFAULT_RULES);
    assert.equal(eng.label, 'Ready to Scale', 'cost per view improved 20% although CPC doubled');
    assert.match(eng.why, /Cost per view improved 20%/);
    const t = (o) => E.decisionMetrics('meta', o, 'Traffic');
    const tr = E.decideCampaign(t({ spend: 1000, impressions: 20000, clicks: 600, link_clicks: 100 }), t({ spend: 1000, impressions: 20000, clicks: 300, link_clicks: 150 }), E.DEFAULT_RULES);
    assert.equal(tr.label, 'Watch Out');
    assert.match(tr.why, /Link CTR fell 33%/);
    const un = E.decideCampaign(t({ spend: 900, impressions: 20000, clicks: 300, link_clicks: 0 }), t({ spend: 900, impressions: 20000, clicks: 300, link_clicks: 120 }), E.DEFAULT_RULES);
    assert.equal(un.label, 'No Touching', 'unreported link clicks are never "zero link clicks"');
    assert.match(un.why, /no link clicks/);
  });
  test('entity variant is status-aware', () => {
    const r = E.decideEntity('Messages', 'meta', { spend: 0 }, { spend: 250, messages: 2 }, 'PAUSED', E.DEFAULT_RULES, 'CAMPAIGN_PAUSED');
    assert.equal(r.label, 'Immediate Action');
    assert.match(r.why, /PAUSED \(CAMPAIGN_PAUSED\)/);
    assert.equal(E.decideEntity('Messages', 'meta', { spend: 0 }, { spend: 50 }, 'PAUSED', E.DEFAULT_RULES).label, 'No Touching');
    assert.equal(E.decideEntity('Messages', 'meta', { spend: 300, impressions: 900, messages: 0 }, {}, 'UNKNOWN', E.DEFAULT_RULES).label, 'Immediate Action',
      'UNKNOWN status but delivering is judged on performance');
    const aw = E.decideEntity('Awareness', 'meta', { spend: 100, impressions: 20000, reach: 4000 }, { spend: 100, impressions: 20000, reach: 4000 }, 'ACTIVE', E.DEFAULT_RULES);
    assert.equal(aw.label, 'Watch Out', 'frequency 5× is above the 3.5× cap');
  });
  test('playbook predicates (rules.json → predicates) and legacy aliases', () => {
    const ok = (w, c) => E.checkPredicates(w, c).ok;
    assert.equal(ok({ spend_gte: 500, ctr_all_lt: 1.5 }, { spend: 600, ctrAll: 1.2, linkCtr: 0.3 }), true);
    assert.equal(ok({ spend_gte: 500, ctr_all_lt: 1.5 }, { spend: 600, ctrAll: 2.1, linkCtr: 0.3 }), false, 'judged on all-click CTR');
    assert.equal(ok({ ctr_all_gt: 1 }, { ctrAll: 1.5 }), true);
    assert.equal(ok({ link_ctr_lt: 1.5 }, { linkCtr: 1.2 }), true);
    assert.equal(ok({ link_ctr_gt: 1 }, { linkCtr: 1.2 }), true);
    assert.equal(ok({ link_ctr_lt: 1.5 }, { linkCtr: null }), false, 'link clicks not reported never fires');
    assert.equal(ok({ cpr_gt: 100 }, { cpr: 120 }), true);
    assert.equal(ok({ frequency_gt: 3 }, { freq: 2 }), false);
    const warns = [];
    const orig = ENV.sandbox.console;
    ENV.sandbox.console = { warn: (m) => warns.push(m), log() {}, error() {} };
    const legacy = E.checkPredicates({ spend_gte: 500, ctr_lt: 1.5 }, { spend: 600, linkCtr: 1.2, ctrAll: 5 });
    ENV.sandbox.console = orig;
    assert.equal(legacy.ok, true, 'legacy ctr_lt is read as link CTR');
    assert.deepEqual([...legacy.legacy], ['ctr_lt']);
    assert.equal(warns.length, 1);
    assert.match(warns[0], /legacy alias/);
    assert.equal(ok({ spend_gte: 500, ctr_lt: 1.5 }, { spend: 600, linkCtr: null }), false, 'legacy alias never fires on unreported link clicks');
    assert.equal(ok({ name_not_contains_any: ['lookalike', 'LAL'], min_spend: 1000 }, { names: ['TOF_Message lookalike'], scopeSpend: 5000 }), false);
    assert.equal(ok({ name_not_contains_any: ['lookalike', 'LAL'], min_spend: 1000 }, { names: ['TOF_Message interest'], scopeSpend: 5000 }), true);
    assert.equal(ok({ name_not_contains_any: ['lookalike'], min_spend: 1000 }, { names: ['x'], scopeSpend: 999 }), false);
    const u = E.checkPredicates({ spend_gte: 1, made_up: 3 }, { spend: 5 });
    assert.equal(u.ok, false);
    assert.deepEqual([...u.unsupported], ['made_up']);
  });
  test('L-005 hits: clinic Meta message ads with ≥ ฿500 spend and all-click CTR < 1.5% (5 on the sample)', () => {
    const snap = ENV.snapshot();
    const c = snap.checks.find((x) => x.check.id === 'L-005-low-ctr-clinic-messages');
    assert.deepEqual({ ...c.check.when }, { spend_gte: 500, ctr_all_lt: 1.5 });
    c.hits.forEach((h) => {
      assert.equal(h.clientRow.vertical, 'Clinic');
      assert.equal(h.adRow.platform, 'meta');
      assert.equal(h.adRow.objective, 'Messages');
      assert.ok(h.spend >= 500);
      assert.ok(h.k.ctr < 1.5);
    });
    // brute force: every eligible ad is a hit
    const expected = snap.ads.filter((a) => a.inScope && a.delivering && a.client.vertical === 'Clinic' && a.platform === 'meta' && a.objective === 'Messages' &&
      a.cur.spend >= 500 && a.k.ctr !== null && a.k.ctr < 1.5).map((a) => a.key).sort();
    assert.deepEqual(c.hits.map((h) => h.adRow.key).sort(), expected);
    assert.equal(c.hits.length, 5);
    assert.ok(c.hits.every((h) => h.clientRow.name === 'AT EASE Clinic'), 'all at AT EASE Clinic');
    assert.equal(c.legacy.length, 0);
    // the action-queue evidence shows the CTR basis the check used
    const item = snap.actions.find((it) => it.checkId === 'L-005-low-ctr-clinic-messages');
    assert.ok(item.evidence.some((e) => e.label === 'CTR (all clicks)'));
  });
  test('L-002 fires exactly for F&B clients with Meta message spend ≥ ฿1,000 and no lookalike campaign', () => {
    const snap = ENV.snapshot();
    const c = snap.checks.find((x) => x.check.id === 'L-002-lookalike-price-led');
    const expected = snap.clients.filter((cl) => {
      if (cl.vertical !== 'F&B') return false;
      const sc = cl.camps.filter((r) => r.delivering && r.platform === 'meta' && r.objective === 'Messages');
      if (!sc.length) return false;
      const spend = sc.reduce((s, r) => s + r.cur.spend, 0);
      return spend >= 1000 && !sc.some((r) => /lookalike|lal|lla/i.test(r.name));
    }).map((cl) => cl.slug).sort();
    assert.deepEqual(c.hits.map((h) => h.clientRow.slug).sort(), expected);
  });
  test('cost-per-result bridge contributions add up to the total change', () => {
    const cur = { spend: 1420, impressions: 10000, clicks: 300, link_clicks: 120, messages: 10 };
    const prev = { spend: 1000, impressions: 10000, clicks: 300, link_clicks: 150, messages: 12 };
    const b = E.cprBridge('Messages', cur, prev);
    assert.equal(b.ok, true);
    near(b.drivers.reduce((s, d) => s + d.contribution, 0), b.total, 1e-9, 'sum of contributions');
    near(b.total, (142 / (1000 / 12) - 1) * 100, 1e-9, 'total change');
    assert.equal(E.cprBridge('Messages', cur, { spend: 0 }).ok, false);
    assert.equal(E.cprBridge('Awareness', cur, prev).ok, false);
  });
  test('fatigue needs 2 of 3 and never double-counts CPM for awareness', () => {
    const k = (o) => E.kpis(o);
    const prev = k({ spend: 1000, impressions: 10000, clicks: 200, link_clicks: 100, messages: 20 });
    const cur = k({ spend: 1300, impressions: 10000, clicks: 150, link_clicks: 70, messages: 18 });
    const f = E.fatigue(cur, prev, 'Messages', 'meta');
    assert.equal(f.eligible, true);
    assert.ok(f.hits >= 2);
    assert.equal(f.flag, true);
    const aw = E.fatigue(k({ spend: 1300, impressions: 10000, clicks: 100, link_clicks: 100 }), k({ spend: 1000, impressions: 10000, clicks: 100, link_clicks: 100 }), 'Awareness', 'meta');
    assert.equal(aw.signals.length, 2);
    assert.equal(aw.flag, false, 'CPM alone is one signal');
  });
  test('delivery signals use two windows', () => {
    const base = { status: 'ACTIVE', priorDays: 7, periodEnd: '2026-09-20', spentBefore: true };
    assert.equal(E.deliverySignals({ ...base, last3: 0, prior7: 700, lastDate: '2026-09-16' })[0].type, 'stopped');
    assert.equal(E.deliverySignals({ ...base, last3: 0, prior7: 0, lastDate: null, spentBefore: false }).length, 0, 'never delivered is not "stopped"');
    assert.equal(E.deliverySignals({ ...base, last3: 90, prior7: 1400, lastDate: '2026-09-20' })[0].type, 'dropped');
    assert.equal(E.deliverySignals({ ...base, last3: 3000, prior7: 2800, lastDate: '2026-09-20' })[0].type, 'spike');
    assert.equal(E.deliverySignals({ ...base, last3: 300, prior7: 700, lastDate: '2026-09-20' }).length, 0);
  });
  test('pacing traffic light and early-month silence', () => {
    const p = E.pacing({ budget: 30000, mtd: 10000, avg7: 1000, elapsed: 10, dim: 30 });
    near(p.projected, 30000, 1e-9, 'projected');
    assert.equal(p.status, 'green');
    assert.equal(E.pacing({ budget: 30000, mtd: 10000, avg7: 1300, elapsed: 10, dim: 30 }).status, 'amber');
    assert.equal(E.pacing({ budget: 30000, mtd: 1000, avg7: 300, elapsed: 2, dim: 30 }).status, null);
    assert.equal(E.pacing({ budget: 0, mtd: 1, avg7: 1, elapsed: 5, dim: 30 }), null);
  });
  test('new-ad and live-days logic respect the history start', () => {
    assert.equal(E.isNew('2026-09-15', '2026-09-20', '2026-09-07'), true);
    assert.equal(E.isNew('2026-09-13', '2026-09-20', '2026-09-07'), false);
    assert.equal(E.isNew('2026-09-15', '2026-09-20', '2026-09-15'), false, 'may be older than the history');
    assert.equal(E.isNew(null, '2026-09-20', '2026-09-07'), false);
    assert.deepEqual({ ...E.liveDays('2026-09-07', '2026-09-20', '2026-09-07') }, { days: 14, atLeast: true });
    assert.equal(E.liveDays(null, '2026-09-20', '2026-09-07'), null);
  });
  test('link CTR is "not reported" when clicks exist without link clicks', () => {
    const k = E.kpis({ spend: 100, impressions: 1000, clicks: 20, link_clicks: 0, messages: 2 });
    assert.equal(k.linkKnown, false);
    assert.equal(k.link_ctr, null);
    assert.equal(k.chat_rate, null);
    assert.equal(E.kpis({ spend: 100, impressions: 1000, clicks: 0, link_clicks: 0 }).link_ctr, 0);
  });
});

/* =========================================================================================== */
describe('formatting never prints NaN / Infinity / undefined / null', () => {
  test('money, counts, percentages, deltas', () => {
    assert.equal(U.money(87.456), '฿87.46');
    assert.equal(U.money(1205.4), '฿1,205');
    assert.equal(U.money(91303.1031, { exact: true }), '฿91,303.10');
    assert.equal(U.money(-12.5), '−฿12.50');
    assert.equal(U.money(null), '—');
    assert.equal(U.money(NaN), '—');
    assert.equal(U.money(Infinity), '—');
    assert.equal(U.int(1234567.4), '1,234,567');
    assert.equal(U.count(12.5), '12.5');
    assert.equal(U.count(12), '12');
    assert.equal(U.pct(1.523), '1.52%');
    assert.equal(U.pct(12.345), '12.3%');
    assert.equal(U.pct(undefined), '—');
    assert.equal(U.ratioX(2.314), '2.31×');
    assert.equal(U.deltaText(-8.2), '−8%');
    assert.equal(U.deltaText(7800.4), '+7,800%');
    assert.equal(U.deltaText(0.4), '+0.4%');
    assert.equal(U.deltaText(null), '—');
    assert.equal(U.pctChange(5, 0), null);
    for (const f of [U.money, U.int, U.count, U.pct, U.ratioX, U.deltaText, U.compact]) {
      for (const v of [null, undefined, NaN, Infinity, -Infinity, 'abc']) assert.ok(!BAD_TEXT.test(f(v)), `${f.name}(${v})`);
    }
  });
  test('CSV quoting, BOM and formula guard', () => {
    const t = U.csv([['a,b', 'he said "hi"', '=SUM(A1)', 12.3456789, null]]);
    assert.ok(t.startsWith('﻿'));
    assert.match(t, /"a,b","he said ""hi""",'=SUM\(A1\),12\.3457,/);
  });
  test('slugs keep Thai letters and marks; SPEC example slug', () => {
    assert.equal(U.slugify('Rena Yakiniku'), 'rena-yakiniku');
    assert.equal(U.slugify('GAIA Kitchen & Bar'), 'gaia-kitchen-and-bar');
    assert.equal(U.slugify("The Rabbit's Grove"), 'the-rabbits-grove');
    assert.equal(U.slugify('เฝอหม้อไฟ สุขสวัสดิ์'), 'เฝอหม้อไฟ-สุขสวัสดิ์');
    const slugs = ENV.reg.clients.map((c) => c.slug);
    assert.equal(new Set(slugs).size, slugs.length, 'registry slugs are unique');
  });
});

/* =========================================================================================== */
describe('URL state', () => {
  test('hash routes parse, with key state after "?"', () => {
    const r = G.app.parseHash('#/client/rena-yakiniku?p=30d&c=prev&pl=meta,tiktok');
    assert.equal(r.page, 'client');
    assert.equal(r.slug, 'rena-yakiniku');
    assert.deepEqual({ ...r.params }, { p: '30d', c: 'prev', pl: 'meta,tiktok' });
    assert.equal(G.app.parseHash('#/client/' + encodeURIComponent('เฝอหม้อไฟ-สุขสวัสดิ์')).slug, 'เฝอหม้อไฟ-สุขสวัสดิ์');
    assert.equal(G.app.parseHash('#/nonsense').page, 'overview');
    assert.equal(G.app.parseHash('').page, 'overview');
  });
  test('state -> hash', () => {
    G.app.state = G.sidebar.sanitize({ period: { preset: '30d' }, compare: 'prev', filters: { platforms: ['meta', 'tiktok'] },
      route: { page: 'client', slug: 'rena-yakiniku', params: {} } });
    assert.equal(G.app.buildHash(), '#/client/rena-yakiniku?p=30d&c=prev&pl=meta,tiktok');
  });
  test('sanitize drops malformed stored state', () => {
    const s = G.sidebar.sanitize({ period: { preset: 'bogus', from: 'x' }, compare: 7, filters: { platforms: ['meta', 'myspace'], minSpend: -5 },
      rules: { zeroSpend: 'abc', freqCap: 4 }, pinned: [1, 'rena-yakiniku'], ui: { sorts: [] } });
    assert.equal(s.period.preset, '7d');
    assert.equal(s.period.from, null);
    assert.equal(s.compare, 'prev');
    assert.deepEqual([...s.filters.platforms], ['meta']);
    assert.equal(s.filters.minSpend, 0);
    assert.equal(s.rules.zeroSpend, 100);
    assert.equal(s.rules.freqCap, 4);
    assert.deepEqual([...s.pinned], ['rena-yakiniku']);
  });
});

/* =========================================================================================== */
describe('views render to clean HTML (string level, no DOM)', () => {
  function ctxFor(env, patch) {
    const st = env.state(patch);
    env.G.model.clearMemo();
    const snap = env.G.model.snapshot({ ds: env.ds, meta: env.meta, reg: env.reg, learn: env.learn, state: st });
    const expanded = new Map();
    const app = {
      expanded: (id) => { if (!expanded.has(id)) expanded.set(id, new Set()); return expanded.get(id); },
      loadMonthly: () => {}
    };
    env.G.app.expanded = app.expanded;
    env.G.app.loadMonthly = app.loadMonthly;
    return {
      state: st, mode: 'sample', meta: env.meta, ds: env.ds, reg: env.reg, learn: env.learn, snap,
      buckets: env.G.model.actionBuckets(snap, st, '2026-09-21'), badge: 0, build: 'test', loading: false, error: null, session: null,
      monthly: env.G.data.indexMonthly(env.sandbox.GROOV_SAMPLE.monthly, env.reg), monthlyLoading: false, monthlyError: null, app, crumbs: [{ label: 'Overview' }]
    };
  }
  const textOf = (html) => html.replace(/<[^>]*>/g, ' ');
  function clean(html, label) {
    assert.equal(typeof html, 'string', label);
    const bad = textOf(html).match(BAD_TEXT);
    assert.ok(!bad, `${label}: found "${bad && bad[0]}" in text: …${bad ? textOf(html).slice(Math.max(0, textOf(html).indexOf(bad[0]) - 80), textOf(html).indexOf(bad[0]) + 40) : ''}…`);
    assert.ok(!/="(NaN|undefined|null|Infinity)"/.test(html), `${label}: bad attribute value`);
  }
  const V = ENV.G.views;

  test('overview, actions (every tab), creatives (every tab), playbook, data health, sidebar, top bar', () => {
    const base = ctxFor(ENV, { route: { page: 'overview', slug: null, params: {} } });
    clean(V.overview.render(base), 'overview');
    clean(ENV.G.sidebar.render(base), 'sidebar');
    clean(ENV.G.sidebar.topbar(base), 'topbar');
    for (const tab of ['all', 'fix', 'watch', 'opp', 'playbook']) clean(V.actions.render(ctxFor(ENV, { route: { page: 'actions', params: {} }, ui: { actionsTab: tab } })), 'actions ' + tab);
    for (const tab of ['winners', 'zero', 'fatigue', 'all']) clean(V.creatives.render(ctxFor(ENV, { route: { page: 'creatives', params: {} }, ui: { creativesTab: tab } })), 'creatives ' + tab);
    clean(V.playbook.render(ctxFor(ENV, { route: { page: 'playbook', params: {} } })), 'playbook');
    clean(V.data.render(ctxFor(ENV, { route: { page: 'data', params: {} } })), 'data health');
  });
  test('every client view renders (all platforms switch values), incl. no-baseline and empty periods', () => {
    const snap = ENV.snapshot();
    const slugs = ENV.ds.clients.map((c) => c.slug);
    assert.ok(slugs.length >= 20);
    for (const slug of slugs) {
      for (const cp of ['all', 'meta', 'tiktok', 'google']) {
        clean(V.client.render(ctxFor(ENV, { route: { page: 'client', slug, params: {} }, ui: { clientPlatform: cp } })), `client ${slug} ${cp}`);
      }
    }
    clean(V.client.render(ctxFor(ENV, { route: { page: 'client', slug: 'rena-yakiniku', params: {} }, period: { preset: '30d' } })), 'client 30d (no baseline)');
    clean(V.client.render(ctxFor(ENV, { route: { page: 'client', slug: 'rena-yakiniku', params: {} }, period: { preset: 'lastmonth' } })), 'client last month (no data)');
    clean(V.overview.render(ctxFor(ENV, { period: { preset: 'lastmonth' } })), 'overview last month');
    clean(V.client.render(ctxFor(ENV, { route: { page: 'client', slug: 'no-such-client', params: {} } })), 'unknown client');
    void snap;
  });
  test('names are escaped everywhere (hostile client name in the registry)', () => {
    const evil = 'Evil <img src=x onerror=alert(1)> & "Co" \'Thai ทดสอบ\'';
    const env = load({ registryPatch: (reg) => { reg.clients.find((c) => c.client === 'Rena Yakiniku').client = evil; } });
    const slug = env.G.util.slugify(evil);
    const pages = [
      env.G.views.overview.render(ctxFor(env, {})),
      env.G.views.client.render(ctxFor(env, { route: { page: 'client', slug, params: {} } })),
      env.G.views.actions.render(ctxFor(env, { route: { page: 'actions', params: {} } })),
      env.G.views.creatives.render(ctxFor(env, { route: { page: 'creatives', params: {} }, ui: { creativesTab: 'all' } })),
      env.G.sidebar.render(ctxFor(env, {}))
    ];
    pages.forEach((html, i) => {
      assert.ok(html.includes('Evil &lt;img'), 'hostile name present (escaped) in page ' + i);
      assert.ok(!html.includes('<img src=x'), 'raw tag leaked in page ' + i);
      assert.ok(!html.includes('"Co"'), 'double quotes unescaped in page ' + i);
      assert.ok(!html.includes("'Thai"), 'single quotes unescaped in page ' + i);
    });
    assert.ok(pages[1].includes('Evil &lt;img src=x onerror=alert(1)&gt; &amp; &quot;Co&quot;'), 'client name escaped in the client view');
  });
  test('charts render to SVG with no NaN coordinates', () => {
    const C = ENV.G.charts;
    const days = U.dateRange('2026-09-14', '2026-09-20');
    const svgs = [
      C.render({ type: 'stacked', days, series: [{ label: 'Meta', color: 'var(--meta)', values: [1, 2, 0, 4, 5, 6, 7] }], compare: { values: [1, 1, 1, 1, 1, 1, 1], days }, provisional: { from: '2026-09-18', to: '2026-09-20' } }, 640),
      C.render({ type: 'lines', days, series: [{ label: 'A', color: '#fff', values: [null, 2, null, 4, 5, null, 7] }] }, 320),
      C.render({ type: 'combo', days, bars: [{ label: 'A', color: '#fff', values: [0, 0, 0, 0, 0, 0, 0] }], lines: [] }, 390),
      C.render({ type: 'monthly', labels: ['Aug', 'Sep'], values: [0, 1200], mtdIndex: 1 }, 300),
      C.render({ type: 'dots', low: 16, high: 115, points: [{ label: 'A', value: 20 }, { label: 'B', value: 300 }], fmt: 'money' }, 360),
      C.spark([0, 0, 0]), C.spark([1, 5, 2]), C.rangeBar({ low: 9, high: 9, value: 12 })
    ];
    svgs.forEach((s, i) => assert.ok(!/NaN|Infinity|undefined/.test(s), 'chart ' + i));
  });
});

/* =========================================================================================== */
describe('live mode data path: windows, ≤ 400-day chunks, payload merge, errors', () => {
  /** Mimic /api/rows: slice the sample payload to [from, to] and re-index only referenced entities. */
  function slice(p, from, to) {
    const rows = p.rows.filter((r) => r[0] >= from && r[0] <= to);
    const cUsed = [...new Set(rows.map((r) => r[1]))].sort((a, b) => a - b);
    const sUsed = [...new Set(rows.map((r) => r[2]).filter((x) => x >= 0))].sort((a, b) => a - b);
    const aUsed = [...new Set(rows.map((r) => r[3]).filter((x) => x >= 0))].sort((a, b) => a - b);
    const accUsed = [...new Set(cUsed.map((c) => p.campaigns[c].account))].sort((a, b) => a - b);
    const m = (list) => new Map(list.map((v, i) => [v, i]));
    const cM = m(cUsed), sM = m(sUsed), aM = m(aUsed), accM = m(accUsed);
    return {
      schema: 1, mode: 'live', generated_at: '2026-10-12T07:05:00+07:00', range: { from, to }, cols: p.cols.slice(),
      accounts: accUsed.map((i) => ({ ...p.accounts[i] })),
      campaigns: cUsed.map((i) => ({ ...p.campaigns[i], account: accM.get(p.campaigns[i].account) })),
      adsets: sUsed.map((i) => ({ ...p.adsets[i], campaign: cM.get(p.adsets[i].campaign) })),
      ads: aUsed.map((i) => ({ ...p.ads[i], campaign: cM.get(p.ads[i].campaign), adset: p.ads[i].adset >= 0 ? sM.get(p.ads[i].adset) : -1 })),
      rows: rows.map((r) => [r[0], cM.get(r[1]), r[2] >= 0 ? sM.get(r[2]) : -1, r[3] >= 0 ? aM.get(r[3]) : -1].concat(r.slice(4)))
    };
  }
  const FULL = ENV.sandbox.GROOV_SAMPLE.rows;

  // results come from the vm realm: copy into this realm before deepEqual
  const plain = (list) => Array.from(list, (r) => ({ from: r.from, to: r.to }));

  test('range sets: normalise, subtract, split', () => {
    assert.deepEqual(plain(D.normRanges([{ from: '2026-09-10', to: '2026-09-12' }, { from: '2026-09-01', to: '2026-09-05' }, { from: '2026-09-06', to: '2026-09-09' }])),
      [{ from: '2026-09-01', to: '2026-09-12' }]);
    assert.deepEqual(plain(D.subtractRanges([{ from: '2026-09-01', to: '2026-09-30' }], [{ from: '2026-09-05', to: '2026-09-10' }, { from: '2026-09-20', to: '2026-10-05' }])),
      [{ from: '2026-09-01', to: '2026-09-04' }, { from: '2026-09-11', to: '2026-09-19' }]);
    assert.equal(D.subtractRanges([{ from: '2026-09-14', to: '2026-09-20' }], [{ from: '2026-09-07', to: '2026-09-20' }]).length, 0);
    const parts = plain(D.splitRange({ from: '2024-01-01', to: '2026-09-20' }, 400));
    assert.ok(parts.every((x) => U.diffDays(x.from, x.to) + 1 <= 400));
    assert.equal(parts[0].from, '2024-01-01');
    assert.equal(parts[parts.length - 1].to, '2026-09-20');
    for (let i = 1; i < parts.length; i++) assert.equal(parts[i].from, U.addDays(parts[i - 1].to, 1), 'contiguous, no overlap');
  });

  test('needed windows stay separate (current, comparison, delivery, pacing)', () => {
    const meta = { data_through: '2026-09-20', history_from: '2024-01-01' };
    // 477-day custom period vs the same period last year: overlapping windows merge into one 843-day
    // span, which the source then requests as ≤ 400-day chunks.
    const yr = D.periods(meta, { preset: 'custom', from: '2025-06-01', to: '2026-09-20' }, 'year');
    assert.equal(yr.noBaseline, false);
    assert.deepEqual(plain(D.neededRanges(meta, yr)), [{ from: '2024-06-01', to: '2026-09-20' }]);
    assert.ok(plain(D.splitRange({ from: '2024-06-01', to: '2026-09-20' }, D.FETCH_CHUNK_DAYS)).every((x) => U.diffDays(x.from, x.to) + 1 <= 400));
    assert.deepEqual(plain(D.neededRanges(meta, D.periods(meta, { preset: '7d' }, 'year'))),
      [{ from: '2025-09-14', to: '2025-09-20' }, { from: '2026-09-11', to: '2026-09-20' }], 'last-year week fetched on its own, not the year in between');
    assert.deepEqual(plain(D.neededRanges(meta, D.periods(meta, { preset: '7d' }, 'off'), { pacing: true })), [{ from: '2026-09-01', to: '2026-09-20' }]);
  });

  test('merging two API-shaped halves reproduces the full sample exactly', () => {
    const a = slice(FULL, '2026-09-07', '2026-09-13'), b = slice(FULL, '2026-09-14', '2026-09-20');
    assert.ok(a.campaigns.length !== FULL.campaigns.length || b.campaigns.length !== FULL.campaigns.length, 'halves carry different entity subsets');
    const merged = D.mergePayloads([b, a, slice(FULL, '2026-09-12', '2026-09-15')]); // overlapping third payload must not double count
    const dsM = D.indexRows(merged, ENV.reg);
    const snapM = M.snapshot({ ds: dsM, meta: ENV.meta, reg: ENV.reg, learn: ENV.learn, state: ENV.state() });
    const parM = M.parity(snapM);
    M.clearMemo();
    const par = M.parity(ENV.snapshot());
    assert.deepEqual({ ...parM.counts }, { ...par.counts });
    near(parM.total, par.total, 1e-6, 'current spend');
    near(snapM.totals.cmp.spend, ENV.snapshot().totals.cmp.spend, 1e-6, 'comparison spend');
    assert.equal(dsM.n, FULL.rows.length, 'every fact row exactly once');
    // entity metadata survives the merge (first/last dates, image flags)
    const ad = FULL.ads.find((x) => x.image === false);
    const mAd = merged.ads.find((x) => x.key === ad.key);
    assert.equal(mAd.image_reason, ad.image_reason);
  });

  test('live source fetches only missing windows in ≤ 400-day requests and surfaces a 400 as an error', async () => {
    const calls = [];
    let failNext = false;
    const fakeFetch = async (url) => {
      calls.push(url);
      const u = new URL(url, 'https://x.test');
      const json = (status, body) => ({ status, ok: status >= 200 && status < 300, text: async () => (body === null ? '' : JSON.stringify(body)) });
      if (u.pathname === '/api/meta') return json(200, ENV.meta);
      if (u.pathname === '/api/rows') {
        const from = u.searchParams.get('from'), to = u.searchParams.get('to');
        if (failNext) { failNext = false; return json(400, { error: 'range too long' }); }
        if (U.diffDays(from, to) + 1 > 400) return json(400, { error: 'span over cap' });
        return json(200, slice(FULL, from, to));
      }
      if (u.pathname === '/api/refresh') return json(202, null);
      return json(404, { error: 'nope' });
    };
    ENV.sandbox.fetch = fakeFetch;
    const src = D.createSource('live', ENV.sandbox, ENV.reg);
    await src.loadMeta();
    const P7 = D.periods(src.meta, { preset: '7d' }, 'prev');
    await src.ensureRanges(D.neededRanges(src.meta, P7));
    assert.equal(calls.filter((c) => c.startsWith('/api/rows')).length, 1);
    assert.ok(src.covers(D.neededRanges(src.meta, P7)));
    const snap = M.snapshot({ ds: src.ds, meta: src.meta, reg: ENV.reg, learn: ENV.learn, state: ENV.state() });
    assert.deepEqual({ ...M.parity(snap).counts }, { 'Immediate Action': 3, 'Watch Out': 9, 'Ready to Scale': 4, 'No Touching': 5 });
    // same windows again: no new request
    const before = calls.length;
    assert.equal(await src.ensureRanges(D.neededRanges(src.meta, P7)), false);
    assert.equal(calls.length, before);
    // a 400 from /api/rows rejects with the status (shown as a section-level error by app.js)
    failNext = true;
    await assert.rejects(src.ensureRanges([{ from: '2026-08-01', to: '2026-08-05' }]), (e) => e.status === 400 && /range too long/.test(e.message));
    assert.ok(src.ds, 'the last good dataset stays loaded');
    // owner refresh returns null on 202 with an empty body
    assert.equal(await src.startRefresh(), null);
    M.clearMemo();
  });
});

describe('link safety', () => {
  test('only http(s) URLs from data become hrefs', () => {
    assert.equal(U.safeUrl('https://fb.me/abc'), 'https://fb.me/abc');
    assert.equal(U.safeUrl('javascript:alert(1)'), null);
    assert.equal(U.safeUrl(' JAVASCRIPT:alert(1)'), null);
    assert.equal(U.safeUrl('data:text/html,x'), null);
    assert.equal(U.safeUrl(null), null);
  });
});
