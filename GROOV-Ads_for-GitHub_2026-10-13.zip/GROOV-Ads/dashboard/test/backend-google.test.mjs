// Google ID token verification (lib/google-id-token.mjs) with a locally generated RSA key pair and a mocked JWKS
// endpoint, plus the /api/session handler end to end. No network.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { generateKeyPairSync, sign } from 'node:crypto';
import {
  AuthError,
  GOOGLE_JWKS_URL,
  authorizeGoogleAccount,
  createJwksCache,
  maxAgeSeconds,
  verifyGoogleIdToken,
} from '../lib/google-id-token.mjs';
import { verifySession } from '../lib/session.mjs';
import { SESSION_COOKIE } from '../lib/session-token.mjs';
import { createSessionHandler } from '../netlify/functions/api-session.mjs';

const CLIENT_ID = '1234567890-abc.apps.googleusercontent.com';
const SECRET = 'unit-test-session-secret-0123456789abcdef';
const NOW = Date.parse('2026-10-12T00:05:00Z');
const T = Math.floor(NOW / 1000);
const LISTS = { allowedDomains: ['groovstrategy.co'], allowedEmails: ['friend.of.groov@gmail.com'] };
const ENV = {
  SESSION_SECRET: SECRET, GOOGLE_CLIENT_ID: CLIENT_ID, ALLOWED_DOMAINS: 'groovstrategy.co',
  ALLOWED_EMAILS: 'friend.of.groov@gmail.com', OWNER_EMAILS: 'finn@groovstrategy.co',
};

const KID = 'test-key-1';
const google = generateKeyPairSync('rsa', { modulusLength: 2048 });
const attacker = generateKeyPairSync('rsa', { modulusLength: 2048 });
const jwk = { ...google.publicKey.export({ format: 'jwk' }), kid: KID, alg: 'RS256', use: 'sig' };

const b64 = (obj) => Buffer.from(JSON.stringify(obj)).toString('base64url');

function idToken(claims = {}, { key = google.privateKey, kid = KID, alg = 'RS256' } = {}) {
  const header = { alg, kid, typ: 'JWT' };
  const payload = {
    iss: 'https://accounts.google.com', aud: CLIENT_ID, azp: CLIENT_ID, sub: '1100220033',
    email: 'finn@groovstrategy.co', email_verified: true, hd: 'groovstrategy.co',
    iat: T - 10, exp: T + 3590, name: 'Finn', ...claims,
  };
  for (const k of Object.keys(payload)) if (payload[k] === undefined) delete payload[k];
  const input = `${b64(header)}.${b64(payload)}`;
  return `${input}.${sign('RSA-SHA256', Buffer.from(input), key).toString('base64url')}`;
}

/** JWKS endpoint mock: counts calls; `fail` makes it error. */
function mockJwks({ keys = [jwk], cacheControl = 'public, max-age=21600, must-revalidate, no-transform', fail = false } = {}) {
  const calls = [];
  const fetchImpl = async (url) => {
    calls.push(String(url));
    if (fail) throw new TypeError('network down');
    return new Response(JSON.stringify({ keys }), { headers: { 'content-type': 'application/json', 'cache-control': cacheControl } });
  };
  return { fetchImpl, calls };
}

function setup(options) {
  let now = NOW;
  const mock = mockJwks(options);
  const jwks = createJwksCache({ fetchImpl: mock.fetchImpl, clock: () => now });
  return { mock, jwks, advance: (ms) => { now += ms; }, now: () => now };
}

async function rejects(promise, code, status) {
  await assert.rejects(promise, (err) => {
    assert.ok(err instanceof AuthError, `expected AuthError, got ${err}`);
    assert.equal(err.code, code);
    if (status) assert.equal(err.status, status);
    return true;
  });
}

describe('verifyGoogleIdToken', () => {
  it('accepts a valid Workspace token and fetches the JWKS once', async () => {
    const { mock, jwks } = setup();
    const user = await verifyGoogleIdToken(idToken({ email: 'Finn@GroovStrategy.co' }), { clientId: CLIENT_ID, jwks, now: NOW });
    assert.deepEqual(user, { email: 'finn@groovstrategy.co', hd: 'groovstrategy.co', sub: '1100220033', name: 'Finn' });
    await verifyGoogleIdToken(idToken(), { clientId: CLIENT_ID, jwks, now: NOW });
    assert.deepEqual(mock.calls, [GOOGLE_JWKS_URL]);
  });

  it('accepts both issuer spellings and the string "true" for email_verified', async () => {
    const { jwks } = setup();
    await verifyGoogleIdToken(idToken({ iss: 'accounts.google.com', email_verified: 'true' }), { clientId: CLIENT_ID, jwks, now: NOW });
  });

  it('rejects a token for another client id (wrong aud)', async () => {
    const { jwks } = setup();
    await rejects(verifyGoogleIdToken(idToken({ aud: 'someone-else.apps.googleusercontent.com' }), { clientId: CLIENT_ID, jwks, now: NOW }), 'wrong_audience', 401);
  });

  it('rejects an expired token but allows 60 s of clock skew', async () => {
    const { jwks } = setup();
    await rejects(verifyGoogleIdToken(idToken({ iat: T - 4000, exp: T - 120 }), { clientId: CLIENT_ID, jwks, now: NOW }), 'expired', 401);
    await verifyGoogleIdToken(idToken({ iat: T - 3700, exp: T - 30 }), { clientId: CLIENT_ID, jwks, now: NOW });
    await rejects(verifyGoogleIdToken(idToken({ iat: T + 600, exp: T + 4000 }), { clientId: CLIENT_ID, jwks, now: NOW }), 'not_yet_valid');
    await rejects(verifyGoogleIdToken(idToken({ nbf: T + 600 }), { clientId: CLIENT_ID, jwks, now: NOW }), 'not_yet_valid');
  });

  it('rejects an unverified email (403) and a missing email', async () => {
    const { jwks } = setup();
    await rejects(verifyGoogleIdToken(idToken({ email_verified: false }), { clientId: CLIENT_ID, jwks, now: NOW }), 'email_unverified', 403);
    await rejects(verifyGoogleIdToken(idToken({ email: undefined }), { clientId: CLIENT_ID, jwks, now: NOW }), 'no_email', 403);
  });

  it('rejects a token not issued by Google', async () => {
    const { jwks } = setup();
    await rejects(verifyGoogleIdToken(idToken({ iss: 'https://evil.example' }), { clientId: CLIENT_ID, jwks, now: NOW }), 'wrong_issuer');
  });

  it('rejects a bad signature: other key, edited payload, alg confusion', async () => {
    const { jwks } = setup();
    await rejects(verifyGoogleIdToken(idToken({}, { key: attacker.privateKey }), { clientId: CLIENT_ID, jwks, now: NOW }), 'bad_signature', 401);
    const [h, , s] = idToken().split('.');
    const edited = `${h}.${b64({ iss: 'https://accounts.google.com', aud: CLIENT_ID, email: 'boss@groovstrategy.co', email_verified: true, hd: 'groovstrategy.co', iat: T, exp: T + 3600 })}.${s}`;
    await rejects(verifyGoogleIdToken(edited, { clientId: CLIENT_ID, jwks, now: NOW }), 'bad_signature');
    const hs = `${b64({ alg: 'HS256', kid: KID })}.${b64({ email: 'x@groovstrategy.co' })}.abc`;
    await rejects(verifyGoogleIdToken(hs, { clientId: CLIENT_ID, jwks, now: NOW }), 'malformed');
    const none = `${b64({ alg: 'none', kid: KID })}.${b64({ email: 'x@groovstrategy.co' })}.`;
    await rejects(verifyGoogleIdToken(none, { clientId: CLIENT_ID, jwks, now: NOW }), 'malformed');
    for (const junk of ['', 'a.b', 'a.b.c.d', 'x'.repeat(9000), 42]) {
      await rejects(verifyGoogleIdToken(junk, { clientId: CLIENT_ID, jwks, now: NOW }), 'malformed');
    }
  });

  it('refetches the JWKS once for an unknown kid (key rotation), throttled to every 30 s', async () => {
    const { mock, jwks, advance } = setup();
    await verifyGoogleIdToken(idToken(), { clientId: CLIENT_ID, jwks, now: NOW });
    await rejects(verifyGoogleIdToken(idToken({}, { kid: 'rotated-key' }), { clientId: CLIENT_ID, jwks, now: NOW }), 'unknown_key');
    assert.equal(mock.calls.length, 1, 'no refetch within 30 s of the last fetch');
    advance(31_000);
    await rejects(verifyGoogleIdToken(idToken({}, { kid: 'rotated-key' }), { clientId: CLIENT_ID, jwks, now: NOW }), 'unknown_key');
    assert.equal(mock.calls.length, 2);
  });

  it('honours Cache-Control max-age, and keeps stale keys when Google is unreachable', async () => {
    let fail = false;
    let calls = 0;
    let now = NOW;
    const jwks = createJwksCache({
      clock: () => now,
      fetchImpl: async () => {
        calls++;
        if (fail) throw new TypeError('offline');
        return new Response(JSON.stringify({ keys: [jwk] }), { headers: { 'cache-control': 'public, max-age=600' } });
      },
    });
    await verifyGoogleIdToken(idToken(), { clientId: CLIENT_ID, jwks, now: NOW });
    now += 599_000;
    await verifyGoogleIdToken(idToken(), { clientId: CLIENT_ID, jwks, now: NOW });
    assert.equal(calls, 1);
    now += 2_000;
    fail = true;
    await verifyGoogleIdToken(idToken(), { clientId: CLIENT_ID, jwks, now: NOW });
    assert.equal(calls, 2, 'tried to refresh after max-age');
    const { jwks: empty } = setup({ fail: true });
    await rejects(verifyGoogleIdToken(idToken(), { clientId: CLIENT_ID, jwks: empty, now: NOW }), 'jwks_unavailable', 503);
  });

  it('parses max-age defensively', () => {
    assert.equal(maxAgeSeconds('public, max-age=21600, must-revalidate'), 21600);
    assert.equal(maxAgeSeconds(null), 3600);
    assert.equal(maxAgeSeconds('max-age=5'), 60);
    assert.equal(maxAgeSeconds('max-age=999999'), 86400);
  });

  it('500 when GOOGLE_CLIENT_ID is missing; error messages never contain the token', async () => {
    const { jwks } = setup();
    const token = idToken({ aud: 'other' });
    await rejects(verifyGoogleIdToken(token, { clientId: '', jwks, now: NOW }), 'config', 500);
    await assert.rejects(verifyGoogleIdToken(token, { clientId: CLIENT_ID, jwks, now: NOW }), (err) => !err.message.includes(token.slice(0, 20)));
  });
});

describe('authorizeGoogleAccount (allow-list)', () => {
  it('allows a Workspace account of an allowed domain', () => {
    assert.deepEqual(authorizeGoogleAccount({ email: 'finn@groovstrategy.co', hd: 'groovstrategy.co' }, LISTS), { email: 'finn@groovstrategy.co', via: 'domain' });
  });

  it('allows an explicitly listed email (e.g. Gmail)', () => {
    assert.deepEqual(authorizeGoogleAccount({ email: 'friend.of.groov@gmail.com', hd: null }, LISTS), { email: 'friend.of.groov@gmail.com', via: 'email' });
  });

  it('rejects a domain that is not allowed, with the exact message', () => {
    assert.throws(() => authorizeGoogleAccount({ email: 'stranger@gmail.com', hd: null }, LISTS), (err) => {
      assert.equal(err.code, 'not_allowed');
      assert.equal(err.status, 403);
      assert.equal(err.message, "This Google account isn't on the allow-list. Ask Finn to add it.");
      return true;
    });
  });

  it('rejects a personal Google account that only uses an allowed-domain address (no hd claim)', () => {
    assert.throws(() => authorizeGoogleAccount({ email: 'ex.staff@groovstrategy.co', hd: null }, LISTS), (err) => err.reason === 'domain_not_workspace');
    assert.throws(() => authorizeGoogleAccount({ email: 'x@groovstrategy.co', hd: 'other.co' }, LISTS), (err) => err.code === 'not_allowed');
  });
});

describe('/api/session handler', () => {
  const make = (overrides = {}) => {
    const { jwks } = setup();
    return createSessionHandler({ jwks, getEnv: () => ({ ...ENV, ...overrides }), clock: () => NOW });
  };
  const post = (body, headers = {}) => new Request('https://ads.example.test/api/session', {
    method: 'POST', headers: { 'content-type': 'application/json', origin: 'https://ads.example.test', ...headers }, body: typeof body === 'string' ? body : JSON.stringify(body),
  });
  const cookieOf = (res) => /groov_session=([^;]*)/.exec(res.headers.get('set-cookie') ?? '')?.[1];

  it('POST with a valid credential sets the session cookie and returns the email', async () => {
    const res = await make()(post({ credential: idToken() }));
    assert.equal(res.status, 200);
    const body = await res.json();
    assert.deepEqual(body, { email: 'finn@groovstrategy.co', expires: new Date((T + 604800) * 1000).toISOString(), owner: true });
    const setCookie = res.headers.get('set-cookie');
    for (const attr of ['HttpOnly', 'Secure', 'SameSite=Lax', 'Path=/', 'Max-Age=604800']) assert.ok(setCookie.includes(attr), attr);
    const verified = verifySession(cookieOf(res), { secret: SECRET, now: NOW });
    assert.equal(verified.ok, true);
    assert.equal(verified.session.email, 'finn@groovstrategy.co');
    assert.equal(res.headers.get('cache-control'), 'private, no-store');
  });

  it('POST for an account outside the allow-list answers 403 with the human message', async () => {
    const res = await make()(post({ credential: idToken({ email: 'stranger@gmail.com', hd: undefined }) }));
    assert.equal(res.status, 403);
    assert.deepEqual(await res.json(), { error: "This Google account isn't on the allow-list. Ask Finn to add it." });
    assert.equal(res.headers.get('set-cookie'), null);
  });

  it('POST rejects cross-site origins, non-JSON bodies, missing credentials and bad tokens', async () => {
    const handler = make();
    assert.equal((await handler(post({ credential: idToken() }, { origin: 'https://evil.example' }))).status, 403);
    assert.equal((await handler(post('credential=abc', { 'content-type': 'application/x-www-form-urlencoded' }))).status, 415);
    assert.equal((await handler(post({}))).status, 400);
    assert.equal((await handler(post('{not json'))).status, 400);
    const expired = await handler(post({ credential: idToken({ iat: T - 9000, exp: T - 5000 }) }));
    assert.equal(expired.status, 401);
    assert.match((await expired.json()).error, /expired/);
  });

  it('POST explains a missing server configuration', async () => {
    assert.match((await (await make({ GOOGLE_CLIENT_ID: '' })(post({ credential: idToken() }))).json()).error, /GOOGLE_CLIENT_ID/);
    assert.match((await (await make({ SESSION_SECRET: 'short' })(post({ credential: idToken() }))).json()).error, /SESSION_SECRET/);
    assert.equal((await make({ ALLOWED_DOMAINS: '', ALLOWED_EMAILS: '' })(post({ credential: idToken() }))).status, 500);
  });

  it('GET reports the signed-in user, 401 otherwise (clearing a stale cookie)', async () => {
    const handler = make();
    const signIn = await handler(post({ credential: idToken() }));
    const cookie = `${SESSION_COOKIE}=${cookieOf(signIn)}`;
    const me = await handler(new Request('https://ads.example.test/api/session', { headers: { cookie } }));
    assert.equal(me.status, 200);
    assert.deepEqual(await me.json(), { email: 'finn@groovstrategy.co', expires: new Date((T + 604800) * 1000).toISOString(), owner: true });
    const anon = await handler(new Request('https://ads.example.test/api/session'));
    assert.equal(anon.status, 401);
    assert.equal(anon.headers.get('set-cookie'), null);
    const stale = await handler(new Request('https://ads.example.test/api/session', { headers: { cookie: `${SESSION_COOKIE}=bogus.value` } }));
    assert.equal(stale.status, 401);
    assert.match(stale.headers.get('set-cookie'), /Max-Age=0/);
  });

  it('DELETE clears the cookie (204); other methods are 405', async () => {
    const handler = make();
    const out = await handler(new Request('https://ads.example.test/api/session', { method: 'DELETE', headers: { origin: 'https://ads.example.test' } }));
    assert.equal(out.status, 204);
    assert.match(out.headers.get('set-cookie'), /^groov_session=; .*Max-Age=0/);
    assert.equal((await handler(new Request('https://ads.example.test/api/session', { method: 'PUT' }))).status, 405);
  });
});
