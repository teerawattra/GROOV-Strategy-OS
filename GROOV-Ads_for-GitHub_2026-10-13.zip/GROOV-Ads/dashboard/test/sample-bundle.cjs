'use strict';
// The sample bundle (window.GROOV_SAMPLE) the frontend tests load: public/data/sample.js where it exists (Finn's Mac,
// built by `npm run build:sample`), otherwise the same bundle built on the fly from sample/sheets with
// tools/build-data.mjs. The VPS package never ships public/data/sample.js (real client numbers must never be served),
// so this keeps the frontend tests, Hermes parity included, running there too.

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { execFileSync } = require('node:child_process');

const ROOT = path.join(__dirname, '..');
let cached = null;

function sampleBundleText() {
  if (cached) return cached;
  const shipped = path.join(ROOT, 'public', 'data', 'sample.js');
  if (fs.existsSync(shipped)) {
    cached = fs.readFileSync(shipped, 'utf8');
    return cached;
  }
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'groov-sample-'));
  try {
    const out = path.join(dir, 'sample.js');
    // The saved-creatives library: ../command-center/creatives on the Mac, seed/creatives in the VPS package.
    const creatives = [path.join(ROOT, '..', 'command-center', 'creatives'), path.join(ROOT, 'seed', 'creatives')].find((d) => fs.existsSync(d)) || path.join(dir, 'none');
    execFileSync(process.execPath, [path.join(ROOT, 'tools', 'build-data.mjs'), '--out', out, '--creatives', creatives, '--now', '2026-10-12T07:05:00+07:00'], { cwd: ROOT, stdio: 'pipe' });
    cached = fs.readFileSync(out, 'utf8');
    return cached;
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
}

module.exports = { sampleBundleText };
