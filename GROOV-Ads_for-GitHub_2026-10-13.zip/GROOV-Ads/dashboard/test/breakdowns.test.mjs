// lib/breakdowns.mjs: the optional Meta placement and age x gender Sheets (DATA_CONTRACT.md Sheets 4-5, §2.4, §2.5).
// Pure functions only: placement labels, fixed age / gender order, number rules (the same as Sheets 1-3), de-duplication
// on the upsert keys, the /api/breakdowns slice, spend_share coverage against the main dataset, health and warnings.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { existsSync, readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { parseCsv } from '../lib/csv.mjs';
import { SHEET_COLUMNS, normalize, sheetHelpers } from '../lib/normalize.mjs';
import {
  AGE_ORDER,
  BREAKDOWN_COLS,
  BREAKDOWN_KINDS,
  BREAKDOWN_SHEET_COLUMNS,
  GENDER_ORDER,
  PLACEMENT_LABELS,
  attachMainSpend,
  breakdownCoverage,
  breakdownFullRange,
  breakdownWarnings,
  breakdownsHealth,
  emptyBreakdowns,
  mainSpendByAdsetDay,
  normaliseAge,
  normaliseBreakdowns,
  normaliseGender,
  placementLabel,
  sliceBreakdowns,
} from '../lib/breakdowns.mjs';

// ---------------------------------------------------------------------------------------------
// Fixtures
// ---------------------------------------------------------------------------------------------

const NOW = new Date('2026-10-13T00:05:00Z');
const ADSET = '120240940877700786';
const ACCOUNT = '628812601062307';

const blank = (kind) => Object.fromEntries(BREAKDOWN_SHEET_COLUMNS[kind].map((c) => [c, '']));
const placementRow = (o = {}) => ({
  ...blank('placement'), date: '2026-10-11', account_id: ACCOUNT, adset_id: ADSET, publisher_platform: 'facebook', platform_position: 'feed',
  spend: '100', impressions: '1000', clicks: '10', link_clicks: '8', ...o,
});
const audienceRow = (o = {}) => ({
  ...blank('audience'), date: '2026-10-11', account_id: ACCOUNT, adset_id: ADSET, age: '25-34', gender: 'female',
  spend: '100', impressions: '1000', clicks: '10', link_clicks: '8', ...o,
});
const run = (sheets, options = {}) => normaliseBreakdowns(sheets, { mode: 'sample', now: NOW, ...options });
const json = (x) => JSON.parse(JSON.stringify(x));

/** Small deterministic PRNG so the "shuffled input" tests are reproducible. */
function shuffled(list, seed = 7) {
  const out = list.slice();
  let s = seed;
  for (let i = out.length - 1; i > 0; i--) {
    s = (s * 1664525 + 1013904223) % 4294967296;
    const j = s % (i + 1);
    [out[i], out[j]] = [out[j], out[i]];
  }
  return out;
}

/** One full Windsor Sheet 1 row (every header present, blank by default). */
const mainRow = (o = {}) => ({
  ...Object.fromEntries(SHEET_COLUMNS.meta.map((c) => [c, ''])),
  date: '2026-10-09', account_id: ACCOUNT, account_name: 'Acme Co', campaign_id: '9001', campaign: 'Campaign One', campaign_objective: 'OUTCOME_LEADS',
  adset_id: 'A', adset_name: 'Ad Set A', ad_id: '7001', ad_name: 'Ad One', effective_status: 'ACTIVE', spend: '100', impressions: '1000', ...o,
});
const mainFrom = (rows, extra = {}) => normalize({ meta: rows, ...extra }, { mode: 'sample', now: NOW });

// ---------------------------------------------------------------------------------------------
// Placement labels
// ---------------------------------------------------------------------------------------------

describe('placement labels', () => {
  // The 17 publisher_platform x platform_position pairs observed in the real Windsor pull (Sep 2026), with the labels agreed for them.
  const OBSERVED = [
    ['facebook', 'feed', 'Facebook Feed'],
    ['facebook', 'facebook_reels', 'Facebook Reels'],
    ['instagram', 'feed', 'Instagram Feed'],
    ['instagram', 'instagram_reels', 'Instagram Reels'],
    ['facebook', 'facebook_stories', 'Facebook Stories'],
    ['instagram', 'instagram_stories', 'Instagram Stories'],
    ['facebook', 'facebook_reels_overlay', 'Facebook Reels overlay ads'],
    ['facebook', 'instream_video', 'Facebook In-stream video'],
    ['facebook', 'search', 'Facebook Search'],
    ['facebook', 'facebook_profile_feed', 'Facebook Profile feed'],
    ['facebook', 'marketplace', 'Facebook Marketplace'],
    ['instagram', 'instagram_explore_grid_home', 'Instagram Explore home'],
    ['facebook', 'facebook_notification', 'Facebook Notifications'],
    ['instagram', 'instagram_search', 'Instagram Search'],
    ['threads', 'threads_feed', 'Threads Feed'],
    ['audience_network', 'rewarded_video', 'Audience Network rewarded video'],
    ['audience_network', 'an_classic', 'Audience Network'],
  ];
  // Other pairs Meta documents, in the same style (not seen in the sample yet).
  const ALSO_KNOWN = [
    ['facebook', 'video_feeds', 'Facebook Video feeds'],
    ['facebook', 'right_hand_column', 'Facebook Right column'],
    ['facebook', 'profile_feed', 'Facebook Profile feed'],
    ['facebook', 'instant_article', 'Facebook Instant articles'],
    ['instagram', 'instagram_explore', 'Instagram Explore'],
    ['instagram', 'instagram_profile_feed', 'Instagram Profile feed'],
    ['instagram', 'profile_feed', 'Instagram Profile feed'],
    ['instagram', 'instagram_profile_reels', 'Instagram Profile reels'],
    ['instagram', 'search', 'Instagram Search'],
    ['messenger', 'messenger_inbox', 'Messenger Inbox'],
    ['messenger', 'messenger_stories', 'Messenger Stories'],
    ['audience_network', 'instream_video', 'Audience Network in-stream video'],
    ['unknown', 'unknown', 'Unknown'],
  ];
  const KNOWN = [...OBSERVED, ...ALSO_KNOWN];
  // Same label on purpose: Meta reports these positions with and without the platform prefix.
  const ALIASES = new Set(['facebook|profile_feed', 'instagram|profile_feed', 'instagram|search']);

  it('names the 17 observed pairs exactly as agreed', () => {
    assert.equal(OBSERVED.length, 17);
    for (const [platform, position, label] of OBSERVED) assert.equal(placementLabel(platform, position), label, `${platform}|${position}`);
  });

  it('names every known pair, and the map has nothing else', () => {
    for (const [platform, position, label] of KNOWN) assert.equal(placementLabel(platform, position), label, `${platform}|${position}`);
    assert.deepEqual(Object.keys(PLACEMENT_LABELS).sort(), KNOWN.map(([p, q]) => `${p}|${q}`).sort(), 'the tables above and PLACEMENT_LABELS list the same pairs');
  });

  it('covers every position the original brief listed', () => {
    const positions = new Set(KNOWN.map(([, position]) => position));
    for (const wanted of [
      'feed', 'facebook_reels', 'facebook_reels_overlay', 'facebook_stories', 'instream_video', 'facebook_notification', 'search', 'marketplace',
      'video_feeds', 'right_hand_column', 'profile_feed', 'instagram_reels', 'instagram_stories', 'instagram_explore', 'instagram_explore_grid_home',
      'instagram_profile_feed', 'instagram_search', 'messenger_inbox', 'messenger_stories', 'an_classic', 'rewarded_video', 'threads_feed',
    ]) assert.ok(positions.has(wanted), wanted);
    assert.ok(KNOWN.some(([p, q]) => p === 'audience_network' && q === 'instream_video'));
  });

  it('matches the contract examples (§2.5)', () => {
    assert.equal(placementLabel('facebook', 'facebook_reels'), 'Facebook Reels');
    assert.equal(placementLabel('instagram', 'instagram_stories'), 'Instagram Stories');
    assert.equal(placementLabel('messenger', 'messenger_inbox'), 'Messenger Inbox');
    assert.equal(placementLabel('audience_network', 'an_classic'), 'Audience Network');
  });

  it('keeps the labels distinct, so a placement table never shows two identical rows (aliases aside)', () => {
    const seen = new Map();
    for (const [platform, position, label] of KNOWN) {
      const key = `${platform}|${position}`;
      if (ALIASES.has(key)) continue;
      assert.equal(seen.get(label), undefined, `${label} is used by ${seen.get(label)} and ${key}`);
      seen.set(label, key);
    }
  });

  it('falls back to a title-cased "Platform · Position" for anything unknown', () => {
    assert.equal(placementLabel('facebook', 'some_new_position'), 'Facebook · Some New Position');
    assert.equal(placementLabel('audience_network', 'banner'), 'Audience Network · Banner');
    assert.equal(placementLabel('whatsapp', 'status_ads'), 'Whatsapp · Status Ads');
    assert.equal(placementLabel('instagram', 'facebook_reels'), 'Instagram · Facebook Reels', 'a pair Meta never reports is not guessed at');
    assert.equal(placementLabel('unknown', 'feed'), 'Unknown · Feed');
  });

  it('reaches the dictionary: normalised keys, platform and position, and the label', () => {
    const bds = run({
      placements: [
        placementRow({ publisher_platform: 'Facebook ', platform_position: 'Facebook_Reels' }),
        placementRow({ publisher_platform: 'audience-network', platform_position: 'an_classic' }),
        placementRow({ publisher_platform: 'threads', platform_position: 'brand_new_thing' }),
      ],
    });
    assert.deepEqual(bds.placements.map((p) => [p.key, p.platform, p.position, p.label]), [
      ['facebook|facebook_reels', 'facebook', 'facebook_reels', 'Facebook Reels'],
      ['audience_network|an_classic', 'audience_network', 'an_classic', 'Audience Network'],
      ['threads|brand_new_thing', 'threads', 'brand_new_thing', 'Threads · Brand New Thing'],
    ]);
  });
});

// ---------------------------------------------------------------------------------------------
// Ordering
// ---------------------------------------------------------------------------------------------

describe('fixed age, gender and platform order', () => {
  it('exports the contract orders', () => {
    assert.deepEqual([...AGE_ORDER], ['13-17', '18-24', '25-34', '35-44', '45-54', '55-64', '65+', 'Unknown']);
    assert.deepEqual([...GENDER_ORDER], ['female', 'male', 'unknown']);
  });

  it('orders the audience dictionary by age band, then female / male / unknown, whatever the input order', () => {
    const cells = [];
    for (const age of AGE_ORDER) for (const gender of GENDER_ORDER) cells.push({ age, gender });
    const expected = cells.map((c) => `${c.age}|${c.gender}`);
    for (const seed of [1, 2, 3]) {
      const rows = shuffled(cells, seed).map((c) => audienceRow({ ...c, spend: '5' }));
      assert.deepEqual(run({ audience: rows }).audiences.map((a) => a.key), expected, `seed ${seed}`);
    }
  });

  it('keeps Unknown age and unknown gender (they are real spend) and puts them last', () => {
    const bds = run({ audience: [audienceRow({ age: 'Unknown', gender: 'unknown' }), audienceRow({ age: '65+', gender: 'male' }), audienceRow({ age: '13-17', gender: 'female' })] });
    assert.deepEqual(bds.audiences.map((a) => a.key), ['13-17|female', '65+|male', 'Unknown|unknown']);
    assert.equal(bds.audience_rows.length, 3);
  });

  it('puts unrecognised bands and genders after the known ones (age: before Unknown) and reports them', () => {
    const bds = run({ audience: [
      audienceRow({ age: 'Unknown', gender: 'female' }), audienceRow({ age: '18-65+', gender: 'male' }), audienceRow({ age: '25-34', gender: 'nonbinary' }),
      audienceRow({ age: '25-34', gender: 'unknown' }), audienceRow({ age: '65+', gender: 'female' }),
    ] });
    assert.deepEqual(bds.audiences.map((a) => a.key), ['25-34|unknown', '25-34|nonbinary', '65+|female', '18-65+|male', 'Unknown|female']);
    assert.deepEqual(bds.diagnostics.audience.unrecognised_ages, { '18-65+': 1 });
    assert.deepEqual(bds.diagnostics.audience.unrecognised_genders, { nonbinary: 1 });
  });

  it('reads age and gender spellings leniently', () => {
    assert.deepEqual(['18-24', '18 - 24', '18–24', ' 18-24 '].map(normaliseAge), ['18-24', '18-24', '18-24', '18-24']);
    assert.deepEqual(['65+', '65 +', '65 plus', '65_plus', '65PLUS'].map(normaliseAge), ['65+', '65+', '65+', '65+', '65+']);
    assert.deepEqual(['Unknown', 'unknown', ' UNKNOWN ', '', null, undefined, 'None'].map(normaliseAge), Array(7).fill('Unknown'));
    assert.equal(normaliseAge('teens'), 'teens');
    assert.deepEqual(['Female', ' MALE ', 'unknown', '', null, 'None'].map(normaliseGender), ['female', 'male', 'unknown', 'unknown', 'unknown', 'unknown']);
  });

  it('orders placements by platform (facebook, instagram, messenger, audience network, threads, others), then position', () => {
    const rows = [
      ['threads', 'threads_feed'], ['zeta', 'a'], ['instagram', 'instagram_stories'], ['audience_network', 'an_classic'], ['facebook', 'search'],
      ['messenger', 'messenger_inbox'], ['instagram', 'feed'], ['facebook', 'facebook_reels'], ['alpha', 'z'], ['facebook', 'feed'],
    ].map(([publisher_platform, platform_position]) => placementRow({ publisher_platform, platform_position }));
    const expected = [
      'facebook|facebook_reels', 'facebook|feed', 'facebook|search', 'instagram|feed', 'instagram|instagram_stories', 'messenger|messenger_inbox',
      'audience_network|an_classic', 'threads|threads_feed', 'alpha|z', 'zeta|a',
    ];
    assert.deepEqual(run({ placements: rows }).placements.map((p) => p.key), expected);
    assert.deepEqual(run({ placements: shuffled(rows, 5) }).placements.map((p) => p.key), expected);
  });

  it('is identical whatever order the input rows arrive in', () => {
    const placements = [];
    const audience = [];
    for (const date of ['2026-10-09', '2026-10-10', '2026-10-11']) {
      for (const adset_id of ['120240940877700786', '9', '120240940877700790']) {
        for (const [publisher_platform, platform_position] of [['facebook', 'feed'], ['instagram', 'instagram_reels'], ['facebook', 'facebook_stories']]) {
          placements.push(placementRow({ date, adset_id, publisher_platform, platform_position, spend: String(adset_id.length + date.length) }));
        }
        for (const [age, gender] of [['18-24', 'female'], ['25-34', 'male'], ['Unknown', 'unknown']]) audience.push(audienceRow({ date, adset_id, age, gender, spend: '7' }));
      }
    }
    const a = run({ placements, audience });
    const b = run({ placements: shuffled(placements, 3), audience: shuffled(audience, 9) });
    assert.deepEqual(b, a);
    assert.deepEqual(a.placement_rows.map((r) => r[0]), a.placement_rows.map((r) => r[0]).slice().sort(), 'rows are date-sorted');
    assert.deepEqual(a.adsets.map((s) => s.id), ['9', '120240940877700786', '120240940877700790'], 'ids compare numerically by length, without losing digits');
  });
});

// ---------------------------------------------------------------------------------------------
// Numbers, ids, dates, headers: the Sheets 1-3 rules
// ---------------------------------------------------------------------------------------------

describe('cells are read by the same rules as Sheets 1-3', () => {
  const spendOf = (cell) => run({ placements: [placementRow({ spend: cell })] }).placement_rows[0]?.[3];
  const impressionsOf = (cell) => run({ placements: [placementRow({ impressions: cell, spend: '1' })] }).placement_rows[0][4];

  it('money: numbers, numeric strings, thousands separators and exponents; 4 decimals, half away from zero', () => {
    const cases = [
      ['12.5', 12.5], [12.5, 12.5], [' 1,234.50 ', 1234.5], ['+7', 7], ['1e3', 1000], ['.5', 0.5], ['5.', 5],
      ['1.00005', 1.0001], ['12.34565', 12.3457], ['0.00004', 0], ['262.23', 262.23], ['1056.03', 1056.03],
      ['-5', -5], [-0, 0],
    ];
    for (const [cell, expected] of cases) {
      const row = run({ placements: [placementRow({ spend: cell, impressions: '1' })] }).placement_rows[0];
      assert.equal(row[3], expected, `spend ${JSON.stringify(cell)}`);
      assert.ok(!Object.is(row[3], -0), 'no negative zero');
    }
  });

  it('blank, null, None and NaN mean "not reported" and count as 0 (without being flagged as bad data)', () => {
    for (const cell of ['', '   ', null, undefined, 'None', 'none', 'null', 'NaN', 'undefined']) {
      assert.equal(impressionsOf(cell), 0, JSON.stringify(cell));
    }
    const bds = run({ placements: [placementRow({ impressions: 'None', clicks: null, spend: '5' })] });
    assert.deepEqual(bds.diagnostics.placement.unparseable_values, {});
  });

  it('counts: integers stay integers, fractions keep 2 decimals, thousands separators work', () => {
    assert.equal(impressionsOf('1,000'), 1000);
    assert.equal(impressionsOf('2.0'), 2);
    assert.equal(impressionsOf('3.456'), 3.46);
    assert.equal(impressionsOf(7.5), 7.5);
    assert.equal(impressionsOf(4577), 4577);
  });

  it('counts unparseable text as 0 per header and keeps negative values as reported', () => {
    const bds = run({ placements: [placementRow({ spend: 'abc', impressions: '12k', clicks: '-3' }), placementRow({ platform_position: 'search', spend: '4', link_clicks: 'n/a' })] });
    assert.deepEqual(bds.diagnostics.placement.unparseable_values, { spend: 1, impressions: 1, link_clicks: 1 });
    assert.deepEqual(bds.diagnostics.placement.negative_values, { clicks: 1 });
    const [feed, search] = bds.placement_rows; // facebook|feed sorts before facebook|search
    assert.deepEqual(feed.slice(3), [0, 0, -3, 8, 0, 0, 0], 'bad spend and impressions are 0, the negative click count is kept');
    assert.deepEqual(search.slice(3), [4, 1000, 10, 0, 0, 0, 0], 'bad link_clicks is 0');
  });

  it('maps the Windsor metric headers onto the contract columns', () => {
    const row = placementRow({
      spend: '262.23', impressions: '1115', clicks: '9', link_clicks: '8', actions_video_view: '30',
      actions_onsite_conversion_messaging_conversation_started_7d: '1', actions_lead: '2',
    });
    const bds = run({ placements: [row] });
    assert.deepEqual([...BREAKDOWN_COLS], ['date', 'adset', 'segment', 'spend', 'impressions', 'clicks', 'link_clicks', 'video_views', 'messages', 'leads']);
    assert.deepEqual(bds.placement_rows, [['2026-10-11', 0, 0, 262.23, 1115, 9, 8, 30, 1, 2]]);
  });

  it('gives the same number as Sheet 1 for every spelling of a cell (parity with normalize)', () => {
    const cells = ['12.5', 12.5, ' 1,234.50 ', '1e3', '.5', '1.00005', '12.34565', '3.456', '-5', '', null, 'None', 'NaN', 'abc', '12k', 7.5, 4577, '0.00004', '+7', '2.0'];
    for (const cell of cells) {
      const main = normalize({ meta: [mainRow({ spend: cell, impressions: cell, clicks: cell, link_clicks: cell, actions_video_view: cell, actions_lead: cell })] }, { mode: 'sample', now: NOW });
      const sheet1 = main.rows[0]; // [date, campaign, adset, ad, spend, impressions, reach, clicks, link_clicks, video_views, messages, leads, ...]
      const bds = run({ placements: [placementRow({ spend: cell, impressions: cell, clicks: cell, link_clicks: cell, actions_video_view: cell, actions_lead: cell })] });
      const row = bds.placement_rows[0] ?? [null, null, null, 0, 0, 0, 0, 0, 0, 0];
      assert.deepEqual([row[3], row[4], row[5], row[6], row[7], row[9]], [sheet1[4], sheet1[5], sheet1[7], sheet1[8], sheet1[9], sheet1[11]], JSON.stringify(cell));
    }
  });

  it('dates: text with a time part, slashes and Sheets serial numbers; unreadable dates are skipped and counted', () => {
    const bds = run({ placements: [
      placementRow({ date: '2026-10-11' }), placementRow({ date: '2026/10/12 07:00:00', platform_position: 'search' }),
      placementRow({ date: 46308, platform_position: 'marketplace' }), // Sheets serial day number of 2026-10-13
      placementRow({ date: '14/10/2026' }), placementRow({ date: '2026-02-30' }), placementRow({ date: '' }),
    ] });
    assert.deepEqual(bds.placement_rows.map((r) => r[0]), ['2026-10-11', '2026-10-12', '2026-10-13']);
    assert.equal(bds.diagnostics.placement.skipped.bad_date, 3);
    assert.equal(bds.health.placement.rows, 6, 'every non-blank Sheet row is counted');
    assert.equal(bds.health.placement.fact_rows, 3);
  });

  it('ids stay strings: float-typed ids lose ".0", long numeric ids render without an exponent, blank adset_id is skipped', () => {
    const bds = run({ placements: [
      placementRow({ adset_id: '120240940877700786.0' }), placementRow({ adset_id: 7001, platform_position: 'search' }),
      placementRow({ adset_id: '', platform_position: 'marketplace' }), placementRow({ adset_id: 'None', platform_position: 'video_feeds' }),
    ], audience: [] });
    assert.deepEqual(bds.adsets.map((a) => a.key), ['meta:7001', `meta:${ADSET}`]);
    assert.equal(bds.diagnostics.placement.skipped.no_adset, 2);
    assert.ok(bds.adsets.every((a) => typeof a.id === 'string' && typeof a.account_id === 'string'));
  });

  it('accepts the raw Sheets API grid (header first, trailing empty cells dropped)', () => {
    const header = BREAKDOWN_SHEET_COLUMNS.placement.slice();
    const grid = [
      header,
      ['2026-10-11', ACCOUNT, ADSET, 'facebook', 'feed', 262.23, 1115, 9, 8], // shorter than the header: the tail cells are missing
      ['2026-10-11', ACCOUNT, ADSET, 'instagram', 'instagram_stories', '50', '300', '3', '2', '', '', ''],
      [],
    ];
    const bds = run({ placements: grid });
    assert.deepEqual(bds.placement_rows, [
      ['2026-10-11', 0, 0, 262.23, 1115, 9, 8, 0, 0, 0],
      ['2026-10-11', 0, 1, 50, 300, 3, 2, 0, 0, 0],
    ]);
  });

  it('matches headers with spaces and other capitalisation, and reports extra columns', () => {
    const rows = [{ ' Date ': '2026-10-11', ADSET_ID: ADSET, Publisher_Platform: 'facebook', platform_position: 'feed', Spend: '9', impressions: '10', note: 'x' }];
    const bds = run({ placements: rows });
    assert.deepEqual(bds.placement_rows, [['2026-10-11', 0, 0, 9, 10, 0, 0, 0, 0, 0]]);
    assert.deepEqual(bds.diagnostics.placement.extra_columns, ['note']);
  });

  it('ignores a Sheet that lacks a key column and says which (e.g. the main Meta tab by mistake)', () => {
    const mainTab = [mainRow(), mainRow({ date: '2026-10-10' })]; // Sheet 1 rows: no publisher_platform / platform_position
    const bds = run({ placements: mainTab });
    assert.equal(bds.available.placement, false);
    assert.deepEqual(bds.health.placement.columns_missing.slice(0, 2), ['publisher_platform', 'platform_position']);
    assert.equal(bds.health.placement.ignored, true);
    assert.equal(bds.health.placement.rows, 2);
    assert.equal(bds.placement_rows.length, 0);
    // a missing metric column is not fatal: it counts as 0 and is reported
    const noLeads = [{ date: '2026-10-11', adset_id: ADSET, age: '25-34', gender: 'male', spend: '9', impressions: '10' }];
    const ok = run({ audience: noLeads });
    assert.equal(ok.available.audience, true);
    assert.ok(ok.health.audience.columns_missing.includes('actions_lead'));
    assert.equal(ok.health.audience.ignored, false);
  });

  it('keeps blank segment values as unknown, rows without account_id, and drops rows with every metric 0', () => {
    const bds = run({ placements: [
      placementRow({ publisher_platform: '', platform_position: '' }),
      placementRow({ account_id: '', platform_position: 'search' }),
      placementRow({ platform_position: 'marketplace', spend: '0', impressions: '0', clicks: '', link_clicks: 'None' }),
      placementRow({ platform_position: 'video_feeds', spend: '0', impressions: '50' }),
    ] });
    assert.deepEqual(bds.placements.map((p) => p.key), ['facebook|search', 'facebook|video_feeds', 'unknown|unknown']);
    assert.equal(bds.placements.find((p) => p.key === 'unknown|unknown').label, 'Unknown');
    assert.equal(bds.diagnostics.placement.blank_segment_rows, 1);
    assert.equal(bds.diagnostics.placement.no_account_rows, 1);
    assert.equal(bds.diagnostics.placement.empty_rows, 1);
    assert.equal(bds.placement_rows.length, 3);
    assert.equal(bds.adsets[0].account_id, ACCOUNT, 'the account comes from a row that has one');
  });

  it('does not mutate its input, and the dataset survives JSON unchanged (it is stored as JSON)', () => {
    const input = { placements: [placementRow(), placementRow({ platform_position: 'search' })], audience: [audienceRow()] };
    const copy = json(input);
    const bds = run(input);
    assert.deepEqual(json(input), copy);
    assert.deepEqual(json(bds), bds);
  });

  it('validates mode and now, and rejects a Sheet that is not an array', () => {
    assert.throws(() => normaliseBreakdowns({}, { mode: 'nope' }), /mode must be "live" or "sample"/);
    assert.throws(() => normaliseBreakdowns({}, { now: 'yesterday' }), /now must be a valid Date/);
    assert.throws(() => normaliseBreakdowns({ placements: 'a,b,c' }), /Sheet rows must be an array/);
  });

  it('exposes the shared helpers of lib/normalize.mjs (so nothing is re-implemented)', () => {
    assert.equal(sheetHelpers.round4(1.00005), 1.0001);
    assert.equal(sheetHelpers.parseDate('2026-10-11T07:00:00'), '2026-10-11');
    assert.equal(sheetHelpers.id('123.0'), '123');
  });
});

// ---------------------------------------------------------------------------------------------
// De-duplication on the upsert keys
// ---------------------------------------------------------------------------------------------

describe('de-duplication on the upsert keys', () => {
  it('placements: identical rows collapse to one and are counted as identical', () => {
    const bds = run({ placements: [placementRow(), placementRow(), placementRow({ spend: '100.0000' })] });
    assert.equal(bds.placement_rows.length, 1);
    assert.equal(bds.health.placement.rows, 3);
    assert.equal(bds.health.placement.duplicates, 2);
    assert.equal(bds.diagnostics.placement.duplicates_identical, 2, 'same value, different spelling, is still identical');
    assert.equal(bds.diagnostics.placement.duplicates_conflicting, 0);
  });

  it('conflicting rows: the last one in sheet order wins and the conflict is counted', () => {
    const bds = run({ placements: [placementRow({ spend: '100', impressions: '1000' }), placementRow({ spend: '120', impressions: '1100' }), placementRow({ spend: '130', impressions: '1200' })] });
    assert.deepEqual(bds.placement_rows, [['2026-10-11', 0, 0, 130, 1200, 10, 8, 0, 0, 0]]);
    assert.equal(bds.health.placement.duplicates, 2);
    assert.equal(bds.diagnostics.placement.duplicates_conflicting, 2);
    // and the order matters: reversed input gives the other winner
    const reversed = run({ placements: [placementRow({ spend: '130' }), placementRow({ spend: '100' })] });
    assert.equal(reversed.placement_rows[0][3], 100);
  });

  it('the key is date + ad set + placement: other days, ad sets and placements are separate rows', () => {
    const bds = run({ placements: [
      placementRow(), placementRow({ date: '2026-10-12' }), placementRow({ adset_id: '2' }),
      placementRow({ publisher_platform: 'instagram' }), placementRow({ platform_position: 'search' }),
    ] });
    assert.equal(bds.placement_rows.length, 5);
    assert.equal(bds.health.placement.duplicates, 0);
  });

  it('spelling variants of a segment are the same key', () => {
    const bds = run({ placements: [placementRow(), placementRow({ publisher_platform: 'Facebook', platform_position: ' FEED ', spend: '101' })] });
    assert.equal(bds.placement_rows.length, 1);
    assert.equal(bds.diagnostics.placement.duplicates_conflicting, 1);
  });

  it('audience: the key is date + ad set + age + gender', () => {
    const bds = run({ audience: [
      audienceRow(), audienceRow(), audienceRow({ spend: '90' }), audienceRow({ gender: 'male' }), audienceRow({ age: '35-44' }), audienceRow({ date: '2026-10-12' }),
      audienceRow({ age: '25 - 34', spend: '55' }), // same band spelled differently: duplicates the first key, last wins
    ] });
    assert.equal(bds.audience_rows.length, 4);
    assert.equal(bds.health.audience.rows, 7);
    assert.equal(bds.health.audience.duplicates, 3);
    assert.equal(bds.diagnostics.audience.duplicates_identical, 1);
    assert.equal(bds.diagnostics.audience.duplicates_conflicting, 2);
    assert.equal(bds.audience_rows.find((r) => r[0] === '2026-10-11' && bds.audiences[r[2]].key === '25-34|female')[3], 55);
  });

  it('a different account on an otherwise identical row counts as a conflict', () => {
    const bds = run({ placements: [placementRow(), placementRow({ account_id: '999' })] });
    assert.equal(bds.diagnostics.placement.duplicates_conflicting, 1);
    assert.equal(bds.adsets[0].account_id, '999');
  });

  it('a later all-zero duplicate replaces an earlier row, and the key then disappears (last wins, empty rows are dropped)', () => {
    const bds = run({ placements: [placementRow(), placementRow({ spend: '0', impressions: '0', clicks: '0', link_clicks: '0' })] });
    assert.equal(bds.placement_rows.length, 0);
    assert.equal(bds.diagnostics.placement.empty_rows, 1);
    assert.equal(bds.available.placement, false);
  });
});

// ---------------------------------------------------------------------------------------------
// sliceBreakdowns: the /api/breakdowns payload
// ---------------------------------------------------------------------------------------------

describe('sliceBreakdowns', () => {
  // 3 ad sets x 4 days. Ad set X (id 11) runs days 1-2, Y (id 22) days 2-3, Z (id 33) day 4.
  const days = ['2026-10-08', '2026-10-09', '2026-10-10', '2026-10-11'];
  const plan = [['11', [0, 1]], ['22', [1, 2]], ['33', [3]]];
  const placements = [];
  const audience = [];
  for (const [adset_id, offsets] of plan) {
    for (const d of offsets) {
      const date = days[d];
      placements.push(placementRow({ date, adset_id, publisher_platform: 'facebook', platform_position: 'feed', spend: String(10 + d), impressions: '100' }));
      placements.push(placementRow({ date, adset_id, publisher_platform: 'instagram', platform_position: adset_id === '33' ? 'instagram_search' : 'instagram_stories', spend: String(1 + d), impressions: '10' }));
      audience.push(audienceRow({ date, adset_id, age: adset_id === '22' ? '45-54' : '18-24', gender: adset_id === '11' ? 'male' : 'female', spend: String(20 + d), impressions: '200' }));
    }
  }
  const bds = run({ placements, audience });

  it('has exactly the §2.5 keys, in order', () => {
    const payload = sliceBreakdowns(bds, '2026-10-08', '2026-10-11');
    assert.deepEqual(Object.keys(payload), ['schema', 'mode', 'range', 'available', 'adsets', 'placements', 'audiences', 'cols', 'placement_rows', 'audience_rows', 'coverage']);
    assert.equal(payload.schema, 1);
    assert.equal(payload.mode, 'sample');
    assert.deepEqual(payload.range, { from: '2026-10-08', to: '2026-10-11' });
    assert.deepEqual(payload.available, { placement: true, audience: true });
    assert.deepEqual(payload.cols, [...BREAKDOWN_COLS]);
    assert.deepEqual(Object.keys(payload.coverage), ['placement', 'audience']);
    assert.deepEqual(Object.keys(payload.coverage.placement), ['first_date', 'last_date', 'rows', 'spend_share']);
    assert.deepEqual(Object.keys(payload.adsets[0]), ['key', 'id', 'account_id']);
    assert.deepEqual(Object.keys(payload.placements[0]), ['key', 'platform', 'position', 'label']);
    assert.deepEqual(Object.keys(payload.audiences[0]), ['key', 'age', 'gender']);
    assert.deepEqual(json(payload), payload, 'plain JSON');
  });

  it('every row is [date, adset index, segment index, ...7 metrics] and points at the right entries', () => {
    const payload = sliceBreakdowns(bds, '2026-10-08', '2026-10-11');
    assert.equal(payload.placement_rows.length, 10);
    assert.equal(payload.audience_rows.length, 5);
    for (const r of payload.placement_rows) {
      assert.equal(r.length, BREAKDOWN_COLS.length);
      assert.ok(payload.adsets[r[1]] && payload.placements[r[2]]);
    }
    for (const r of payload.audience_rows) assert.ok(payload.adsets[r[1]] && payload.audiences[r[2]]);
    const first = payload.placement_rows[0];
    assert.equal(payload.adsets[first[1]].key, 'meta:11');
    assert.equal(payload.placements[first[2]].key, 'facebook|feed');
    assert.deepEqual(first, ['2026-10-08', 0, 0, 10, 100, 10, 8, 0, 0, 0]);
  });

  it('keeps only the ad sets and segments the returned rows use, re-indexed in their original relative order', () => {
    // Day 4 holds only ad set Z: one ad set, its two placements, one audience
    const day4 = sliceBreakdowns(bds, '2026-10-11', '2026-10-11');
    assert.deepEqual(day4.adsets.map((a) => a.key), ['meta:33']);
    assert.deepEqual(day4.placements.map((p) => p.key), ['facebook|feed', 'instagram|instagram_search']);
    assert.deepEqual(day4.audiences.map((a) => a.key), ['18-24|female']);
    assert.deepEqual(day4.placement_rows.map((r) => [r[1], r[2]]), [[0, 0], [0, 1]]);
    assert.deepEqual(day4.audience_rows.map((r) => [r[1], r[2]]), [[0, 0]]);

    // Days 2-3 hold Y (and X on day 2): the dictionary keeps the full dataset's relative order
    const mid = sliceBreakdowns(bds, '2026-10-09', '2026-10-10');
    assert.deepEqual(mid.adsets.map((a) => a.key), ['meta:11', 'meta:22']);
    assert.deepEqual(mid.placements.map((p) => p.key), ['facebook|feed', 'instagram|instagram_stories']);
    assert.deepEqual(mid.audiences.map((a) => a.key), ['18-24|male', '45-54|female']);
    for (const r of mid.placement_rows) assert.ok(r[0] >= '2026-10-09' && r[0] <= '2026-10-10');
    const keyOfRow = (payload, r, dict) => `${payload.adsets[r[1]].key}/${payload[dict][r[2]].key}`;
    const fromFull = sliceBreakdowns(bds, '2026-10-08', '2026-10-11');
    const wanted = fromFull.placement_rows.filter((r) => r[0] >= '2026-10-09' && r[0] <= '2026-10-10').map((r) => [r[0], keyOfRow(fromFull, r, 'placements'), ...r.slice(3)]);
    assert.deepEqual(mid.placement_rows.map((r) => [r[0], keyOfRow(mid, r, 'placements'), ...r.slice(3)]), wanted, 'the same facts, indexed against the smaller dictionaries');
  });

  it('two adjacent ranges add up to the whole range', () => {
    const sum = (payload) => payload.placement_rows.reduce((t, r) => t + r[3], 0) + payload.audience_rows.reduce((t, r) => t + r[3], 0);
    const whole = sliceBreakdowns(bds, '2026-10-08', '2026-10-11');
    const a = sliceBreakdowns(bds, '2026-10-08', '2026-10-09');
    const b = sliceBreakdowns(bds, '2026-10-10', '2026-10-11');
    assert.equal(sum(a) + sum(b), sum(whole));
    assert.equal(a.placement_rows.length + b.placement_rows.length, whole.placement_rows.length);
  });

  it('defaults to the full extent of the data, and a range outside it is empty but still "available"', () => {
    const all = sliceBreakdowns(bds);
    assert.deepEqual(all.range, { from: '2026-10-08', to: '2026-10-11' });
    assert.equal(all.placement_rows.length, 10);
    const outside = sliceBreakdowns(bds, '2020-01-01', '2020-01-31');
    assert.deepEqual([outside.adsets, outside.placements, outside.audiences, outside.placement_rows, outside.audience_rows], [[], [], [], [], []]);
    assert.deepEqual(outside.available, { placement: true, audience: true }, 'available describes the Sheets, not the range');
    assert.deepEqual(outside.coverage.placement, { first_date: null, last_date: null, rows: 0, spend_share: null });
    assert.deepEqual(outside.range, { from: '2020-01-01', to: '2020-01-31' });
  });

  it('coverage rows / first_date / last_date describe the returned rows', () => {
    const payload = sliceBreakdowns(bds, '2026-10-09', '2026-10-10');
    assert.equal(payload.coverage.placement.rows, payload.placement_rows.length);
    assert.equal(payload.coverage.audience.rows, payload.audience_rows.length);
    assert.equal(payload.coverage.placement.first_date, '2026-10-09');
    assert.equal(payload.coverage.placement.last_date, '2026-10-10');
    assert.equal(payload.coverage.placement.spend_share, null, 'no main dataset attached, so no share');
  });

  it('handles one Sheet only: the other is unavailable with empty arrays', () => {
    const only = sliceBreakdowns(run({ audience }), '2026-10-08', '2026-10-11');
    assert.deepEqual(only.available, { placement: false, audience: true });
    assert.deepEqual([only.placements, only.placement_rows], [[], []]);
    assert.ok(only.audience_rows.length > 0);
    const other = sliceBreakdowns(run({ placements }), '2026-10-08', '2026-10-11');
    assert.deepEqual(other.available, { placement: true, audience: false });
    assert.deepEqual([other.audiences, other.audience_rows], [[], []]);
  });

  it('rejects ranges that are not real YYYY-MM-DD dates', () => {
    for (const bad of ['2026-9-1', '2026-02-30', '20261001', 'x', 5]) {
      assert.throws(() => sliceBreakdowns(bds, bad, '2026-10-11'), /from must be a YYYY-MM-DD date/, String(bad));
      assert.throws(() => sliceBreakdowns(bds, '2026-10-08', bad), /to must be a YYYY-MM-DD date/, String(bad));
    }
  });

  it('keeps the §2.5 example intact: 262.23 spend, 1,115 impressions, one conversation', () => {
    const one = run({ placements: [placementRow({ publisher_platform: 'facebook', platform_position: 'feed', spend: '262.23', impressions: '1115', clicks: '9', link_clicks: '8', actions_onsite_conversion_messaging_conversation_started_7d: '1' })] });
    assert.deepEqual(sliceBreakdowns(one, '2026-10-11', '2026-10-11').placement_rows, [['2026-10-11', 0, 0, 262.23, 1115, 9, 8, 0, 1, 0]]);
  });
});

describe('unavailable Sheets', () => {
  const cases = [
    ['nothing at all', undefined],
    ['an empty object', {}],
    ['null Sheets', { placements: null, audience: null }],
    ['empty arrays', { placements: [], audience: [] }],
    ['header-only CSV files', { placements: Object.assign([], { columns: [...BREAKDOWN_SHEET_COLUMNS.placement] }), audience: Object.assign([], { columns: [...BREAKDOWN_SHEET_COLUMNS.audience] }) }],
    ['only blank rows', { placements: [blank('placement'), blank('placement')], audience: [{}] }],
    ['rows that all fail', { placements: [placementRow({ date: 'x' }), placementRow({ adset_id: '' })], audience: [audienceRow({ spend: '0', impressions: '0', clicks: '0', link_clicks: '0' })] }],
  ];
  for (const [name, input] of cases) {
    it(`${name}: available false / false, empty arrays, no error`, () => {
      const bds = normaliseBreakdowns(input, { mode: 'live', now: NOW });
      assert.deepEqual(bds.available, { placement: false, audience: false });
      const payload = sliceBreakdowns(bds, '2026-10-01', '2026-10-31');
      assert.deepEqual(payload.available, { placement: false, audience: false });
      assert.deepEqual([payload.adsets, payload.placements, payload.audiences, payload.placement_rows, payload.audience_rows], [[], [], [], [], []]);
      assert.deepEqual(payload.coverage, {
        placement: { first_date: null, last_date: null, rows: 0, spend_share: null },
        audience: { first_date: null, last_date: null, rows: 0, spend_share: null },
      });
      assert.equal(payload.mode, 'live');
      assert.equal(payload.schema, 1);
      assert.deepEqual(json(payload), payload);
    });
  }

  it('emptyBreakdowns() is the same thing, and a full-extent slice of it has a null range', () => {
    const payload = sliceBreakdowns(emptyBreakdowns({ mode: 'live', now: NOW }));
    assert.deepEqual(payload.range, { from: null, to: null });
    assert.deepEqual(payload.available, { placement: false, audience: false });
    assert.deepEqual(payload.coverage.audience, { first_date: null, last_date: null, rows: 0, spend_share: null });
  });

  it('one empty Sheet next to a good one leaves the good one alone', () => {
    const bds = run({ placements: [], audience: [audienceRow()] });
    assert.deepEqual(bds.available, { placement: false, audience: true });
    assert.deepEqual(bds.health.placement, { rows: 0, fact_rows: 0, first_date: null, last_date: null, adsets: 0, duplicates: 0, columns_missing: [], ignored: false });
  });
});

// ---------------------------------------------------------------------------------------------
// Coverage: spend_share against the main dataset
// ---------------------------------------------------------------------------------------------

describe('spend_share (coverage against Sheet 1)', () => {
  const D1 = '2026-10-09';
  const D2 = '2026-10-10';
  const D3 = '2026-10-11';
  // Sheet 1, Meta: ad set A has two ads on D1 (100 + 50), one on D2 (70) and one on D3 (30); B: 40 on D1; C: 10 on D1.
  // The TikTok ad group "A" (same id!) and a Google ad group must never be counted.
  const metaRows = [
    mainRow({ date: D1, adset_id: 'A', ad_id: '7001', spend: '100' }),
    mainRow({ date: D1, adset_id: 'A', ad_id: '7002', spend: '50' }),
    mainRow({ date: D2, adset_id: 'A', ad_id: '7001', spend: '70' }),
    mainRow({ date: D3, adset_id: 'A', ad_id: '7001', spend: '30' }),
    mainRow({ date: D1, adset_id: 'B', ad_id: '7003', campaign_id: '9002', spend: '40' }),
    mainRow({ date: D1, adset_id: 'C', ad_id: '7004', campaign_id: '9003', spend: '10' }),
  ];
  const tiktokRow = { date: D1, account_id: '2001', account_name: 'Tok', campaign_id: '9101', campaign: 'T', objective_type: 'REACH', campaign_status: 'CAMPAIGN_STATUS_ENABLE', adgroup_id: 'A', adgroup_name: 'A', ad_id: '7101', ad_name: 'V', spend: '999', impressions: '10' };
  const main = mainFrom(metaRows, { tiktok: [tiktokRow] });

  const placements = [
    placementRow({ date: D1, adset_id: 'A', platform_position: 'feed', spend: '90' }),
    placementRow({ date: D1, adset_id: 'A', platform_position: 'facebook_reels', spend: '55' }), // A on D1: 145 of 150
    placementRow({ date: D2, adset_id: 'A', platform_position: 'feed', spend: '70' }), // A on D2: 70 of 70
    placementRow({ date: D1, adset_id: 'B', platform_position: 'feed', spend: '40' }), // B on D1: 40 of 40; nothing for A on D3, nothing for C
  ];
  const audience = [
    placementRow({ date: D1, adset_id: 'A', spend: '150' }), // (audience rows built below)
  ].map(() => audienceRow({ date: D1, adset_id: 'A', spend: '150' })).concat([
    audienceRow({ date: D1, adset_id: 'B', spend: '40' }), // no audience rows for A on D2 or D3
  ]);
  const bds = run({ placements, audience }, { main });

  it('sums Sheet 1 spend over ads per ad set and day, for Meta ad sets only, joined on the "meta:<id>" key', () => {
    const idx = mainSpendByAdsetDay(bds, main);
    assert.deepEqual(idx.map(([date, adset, spend]) => [date, bds.adsets[adset].key, spend]), [
      [D1, 'meta:A', 150], [D1, 'meta:B', 40], [D2, 'meta:A', 70], [D3, 'meta:A', 30],
    ], 'ad set C is not in the Sheets, and the TikTok ad group with the same id is another entity');
    assert.deepEqual(bds.main_spend, idx);
  });

  it('is breakdown spend / Sheet 1 spend of the same ad sets over the same range', () => {
    // placements D1..D2: (145 + 70 + 40) / (150 + 70 + 40) = 255 / 260
    assert.deepEqual(breakdownCoverage(bds, main, D1, D2).placement, { first_date: D1, last_date: D2, rows: 4, spend_share: 0.9808 });
    // D1 only: (145 + 40) / (150 + 40) = 185 / 190
    assert.equal(breakdownCoverage(bds, main, D1, D1).placement.spend_share, 0.9737);
    // D2 only: 70 / 70
    assert.equal(breakdownCoverage(bds, main, D2, D2).placement.spend_share, 1);
  });

  it('a missing day lowers it (the Sheet has no rows for ad set A on D3)', () => {
    assert.deepEqual(breakdownCoverage(bds, main, D3, D3).placement, { first_date: null, last_date: null, rows: 0, spend_share: 0 });
    // D1..D3: 255 / (150 + 70 + 30 + 40) = 255 / 290
    assert.equal(breakdownCoverage(bds, main, D1, D3).placement.spend_share, 0.8793);
  });

  it('the audience Sheet is judged on its own rows and ad sets', () => {
    // audience D1..D2: (150 + 40) / (150 + 70 + 40) = 190 / 260
    assert.deepEqual(breakdownCoverage(bds, main, D1, D2).audience, { first_date: D1, last_date: D1, rows: 2, spend_share: 0.7308 });
  });

  it('an ad set that never appears in a Sheet is not part of its denominator (nothing to compare it with)', () => {
    const onlyB = run({ placements: [placementRow({ date: D1, adset_id: 'B', spend: '40' })] }, { main });
    assert.equal(breakdownCoverage(onlyB, main, D1, D3).placement.spend_share, 1, 'A and C have Sheet 1 spend but are not in this Sheet');
  });

  it('each Sheet is compared on its own ad sets: the other Sheet\'s ad sets are not in its denominator', () => {
    const b = run({
      placements: [placementRow({ date: D1, adset_id: 'B', spend: '40' })], // only ad set B
      audience: [audienceRow({ date: D1, adset_id: 'A', spend: '150' }), audienceRow({ date: D1, adset_id: 'B', spend: '40' })],
    }, { main });
    const coverage = breakdownCoverage(b, main, D1, D3);
    assert.equal(coverage.placement.spend_share, 1, 'B: 40 of 40, however much A spent');
    assert.equal(coverage.audience.spend_share, 0.6552, '(150 + 40) of (A 150 + 70 + 30, B 40) = 190 / 290');
    assert.deepEqual(b.adsets.map((a) => a.key), ['meta:A', 'meta:B'], 'one shared ad set dictionary');
  });

  it('is null without a Sheet 1 denominator: no main spend for those ad sets in the range, or no main dataset attached', () => {
    assert.equal(breakdownCoverage(bds, main, '2026-01-01', '2026-01-31').placement.spend_share, null);
    assert.equal(breakdownCoverage(run({ placements }), mainFrom([]), D1, D3).placement.spend_share, null, 'the main dataset has no Meta ad sets');
    assert.equal(sliceBreakdowns(run({ placements }), D1, D3).coverage.placement.spend_share, null, 'nothing attached');
    assert.equal(breakdownCoverage(run({ audience }), main, D1, D3).placement.spend_share, null, 'the placement Sheet is empty');
  });

  it('can exceed 1 (rounding, late attribution) and is reported as it is', () => {
    const over = run({ placements: [placementRow({ date: D2, adset_id: 'A', spend: '70.5' })] }, { main });
    assert.equal(breakdownCoverage(over, main, D2, D2).placement.spend_share, 1.0071);
  });

  it('sliceBreakdowns carries the same coverage when the main spend is attached, with no main dataset at hand', () => {
    for (const [from, to] of [[D1, D2], [D1, D1], [D2, D3], [D3, D3], ['2026-01-01', '2026-12-31']]) {
      const viaPayload = sliceBreakdowns(bds, from, to).coverage;
      assert.deepEqual(viaPayload, breakdownCoverage(bds, main, from, to), `${from}..${to}`);
    }
    const plain = run({ placements, audience });
    assert.deepEqual(sliceBreakdowns(attachMainSpend(plain, main), D1, D2).coverage, sliceBreakdowns(bds, D1, D2).coverage);
    assert.equal(plain.main_spend, null, 'attachMainSpend returns a new dataset');
    assert.deepEqual(json(bds), bds);
  });

  it('rounds the money in the denominator without drift (integer 1/10000 sums)', () => {
    const cents = Array.from({ length: 30 }, (_, i) => mainRow({ date: D1, adset_id: 'A', ad_id: String(8000 + i), spend: '0.1' }));
    const m = mainFrom(cents);
    const b = run({ placements: [placementRow({ date: D1, adset_id: 'A', spend: '3' })] }, { main: m });
    assert.equal(b.main_spend[0][2], 3, '30 x 0.1 is exactly 3');
    assert.equal(breakdownCoverage(b, m, D1, D1).placement.spend_share, 1);
  });

  it('validates the range', () => {
    assert.throws(() => breakdownCoverage(bds, main, '2026-1-1', D2), /from must be a YYYY-MM-DD date/);
    assert.throws(() => breakdownCoverage(bds, main, D1, 'x'), /to must be a YYYY-MM-DD date/);
  });
});

// ---------------------------------------------------------------------------------------------
// Health (/api/meta) and refresh warnings
// ---------------------------------------------------------------------------------------------

describe('breakdownsHealth and breakdownWarnings', () => {
  const metaRows = [
    mainRow({ date: '2026-08-01', adset_id: 'A', ad_id: '7001', spend: '500' }), // far outside the last 28 days
    mainRow({ date: '2026-10-09', adset_id: 'A', ad_id: '7001', spend: '100' }),
    mainRow({ date: '2026-10-10', adset_id: 'A', ad_id: '7001', spend: '100' }),
    mainRow({ date: '2026-10-11', adset_id: 'A', ad_id: '7001', spend: '100' }),
    mainRow({ date: '2026-10-11', adset_id: 'B', ad_id: '7003', campaign_id: '9002', spend: '100' }), // no breakdown rows at all
  ];
  const main = mainFrom(metaRows);
  const placements = [
    placementRow({ date: '2026-08-01', adset_id: 'A', spend: '500' }),
    placementRow({ date: '2026-10-09', adset_id: 'A', spend: '100' }),
    placementRow({ date: '2026-10-10', adset_id: 'A', spend: '50' }),
    // nothing on 2026-10-11
  ];
  const bds = run({ placements }, { main });

  it('reports each Sheet, with the share over the 28 days that end on the last Meta date', () => {
    const health = breakdownsHealth(bds, main, { configured: { placements: true, audience: true } });
    assert.deepEqual(Object.keys(health), ['placement', 'audience']);
    assert.deepEqual(health.placement, {
      available: true, configured: true, rows: 3, first_date: '2026-08-01', last_date: '2026-10-10',
      // same ad sets (A): the 500 on 1 Aug is outside the 28-day window, (100 + 50) / (100 + 100 + 100)
      spend_share_last_28d: 0.5,
      // all Meta spend: 150 / (100 + 100 + 100 + 100)
      all_meta_spend_share_last_28d: 0.375,
      duplicates: 0, columns_missing: [], error: null,
    });
    assert.deepEqual(health.audience, {
      available: false, configured: true, rows: 0, first_date: null, last_date: null,
      spend_share_last_28d: null, all_meta_spend_share_last_28d: null, duplicates: 0, columns_missing: [], error: null,
    });
  });

  it('the 28 days are inclusive: the last Meta date and the 27 days before it count, the 28th day before does not', () => {
    const rows = [
      mainRow({ date: '2026-09-13', adset_id: 'A', ad_id: '7001', spend: '1000' }), // 28 days before the last date: outside
      mainRow({ date: '2026-09-14', adset_id: 'A', ad_id: '7001', spend: '100' }), // 27 days before: the first day inside
      mainRow({ date: '2026-10-11', adset_id: 'A', ad_id: '7001', spend: '100' }), // the last Meta date
    ];
    const m = mainFrom(rows);
    const b = run({ placements: [
      placementRow({ date: '2026-09-13', adset_id: 'A', spend: '1000' }), placementRow({ date: '2026-09-14', adset_id: 'A', spend: '50' }), placementRow({ date: '2026-10-11', adset_id: 'A', spend: '50' }),
    ] }, { main: m });
    const h = breakdownsHealth(b, m).placement;
    assert.equal(h.spend_share_last_28d, 0.5, '(50 + 50) / (100 + 100); the outside day would give 1.0');
    assert.equal(h.all_meta_spend_share_last_28d, 0.5);
  });

  it('configured defaults to "has rows"; read errors are passed through', () => {
    const health = breakdownsHealth(bds, main, { errors: { audience: 'The Meta audience Sheet was not found.' } });
    assert.equal(health.placement.configured, true);
    assert.equal(health.audience.configured, false);
    assert.equal(health.audience.error, 'The Meta audience Sheet was not found.');
    assert.equal(health.placement.error, null);
  });

  it('has no share without the main dataset, and a stalled export shows up as a low share', () => {
    const noMain = breakdownsHealth(bds);
    assert.equal(noMain.placement.spend_share_last_28d, null);
    assert.equal(noMain.placement.all_meta_spend_share_last_28d, null);
    assert.equal(noMain.placement.rows, 3);
    const stalled = run({ placements: [placementRow({ date: '2026-08-01', adset_id: 'A', spend: '500' })] }, { main });
    assert.equal(breakdownsHealth(stalled, main).placement.spend_share_last_28d, 0, 'rows exist, but none in the window');
  });

  it('uses the window of the main Meta Sheet, not the calendar', () => {
    const withTiktokLater = mainFrom(metaRows, { tiktok: [{ date: '2026-10-20', account_id: '2001', campaign_id: '9101', campaign: 'T', adgroup_id: 'g', ad_id: '7101', spend: '5', impressions: '5' }] });
    const b = run({ placements }, { main: withTiktokLater });
    assert.equal(breakdownsHealth(b, withTiktokLater).placement.spend_share_last_28d, 0.5, 'TikTok dates do not move the Meta window');
  });

  it('warns about errors, missing columns, unreadable dates, conflicts, lost id digits and low coverage', () => {
    const mess = run({
      placements: [
        placementRow({ date: 'x' }), placementRow({ date: 'y' }), placementRow({ date: '2026-10-10', adset_id: 'A', spend: '5' }),
        placementRow({ date: '2026-10-10', adset_id: 'A', spend: '6' }), placementRow({ date: '2026-10-11', adset_id: '' }),
      ],
      audience: [{ date: '2026-10-10', spend: '3' }],
    }, { main });
    const health = breakdownsHealth(mess, main, { configured: { placements: true, audience: true }, errors: { placements: 'The Meta placements Sheet was not found. Check SHEET_ID_META_PLACEMENTS.' } });
    const warnings = breakdownWarnings(mess, health, { stats: { placements: { unsafe_id_cells: 4 } } });
    const has = (re) => assert.ok(warnings.some((w) => re.test(w)), `${re} in:\n${warnings.join('\n')}`);
    has(/^placements: The Meta placements Sheet was not found\. Check SHEET_ID_META_PLACEMENTS\. The dashboard shows no placement splits until this is fixed\./);
    has(/^placements: 2 of 5 rows have a date the dashboard can't read/);
    has(/^placements: 1 rows have no adset_id and were skipped/);
    has(/^placements: 1 conflicting duplicate rows/);
    has(/^placements: 4 ID cells are stored as numbers/);
    has(/^placements: the Sheet covers only 1\.5% of the Meta spend of the last 28 days/);
    has(/^audience: columns missing from the Sheet: .*adset_id.*age.*gender.* The Sheet was ignored\./);
  });

  it('says nothing when everything is fine, or when a Sheet is simply not configured', () => {
    const fine = run({ placements: [
      placementRow({ date: '2026-10-09', adset_id: 'A', spend: '100' }), placementRow({ date: '2026-10-10', adset_id: 'A', spend: '100' }),
      placementRow({ date: '2026-10-11', adset_id: 'A', spend: '100' }), placementRow({ date: '2026-10-11', adset_id: 'B', spend: '100' }),
    ] }, { main });
    assert.deepEqual(breakdownWarnings(fine, breakdownsHealth(fine, main, { configured: { placements: true } })), []);
    const none = run({}, { main });
    assert.deepEqual(breakdownWarnings(none, breakdownsHealth(none, main)), []);
  });

  it('breakdownFullRange spans the main range and both Sheets', () => {
    assert.deepEqual(breakdownFullRange(bds, '2026-09-01', '2026-10-20'), { from: '2026-08-01', to: '2026-10-20' });
    assert.deepEqual(breakdownFullRange(bds, '2026-09-01', '2026-10-05'), { from: '2026-08-01', to: '2026-10-10' });
    assert.deepEqual(breakdownFullRange(emptyBreakdowns({ now: NOW })), { from: null, to: null });
    assert.deepEqual(breakdownFullRange(emptyBreakdowns({ now: NOW }), '2026-09-01', '2026-09-20'), { from: '2026-09-01', to: '2026-09-20' });
  });
});

// ---------------------------------------------------------------------------------------------
// Scale
// ---------------------------------------------------------------------------------------------

describe('scale', () => {
  it('normalises and slices a large synthetic Sheet quickly (120k rows)', () => {
    const placements = [];
    for (let day = 0; day < 120; day++) {
      const date = new Date(Date.UTC(2026, 5, 1 + day)).toISOString().slice(0, 10);
      for (let a = 0; a < 100; a++) {
        for (let p = 0; p < 10; p++) {
          placements.push({ date, account_id: '1', adset_id: String(120000000000000000n + BigInt(a)), publisher_platform: p < 5 ? 'facebook' : 'instagram', platform_position: `pos_${p}`, spend: String((a + p) / 10 + 1), impressions: '100' });
        }
      }
    }
    const started = performance.now();
    const bds = run({ placements });
    const slice = sliceBreakdowns(bds, '2026-08-01', '2026-08-31');
    const ms = performance.now() - started;
    assert.equal(bds.placement_rows.length, 120_000);
    assert.equal(bds.adsets.length, 100);
    assert.equal(slice.placement_rows.length, 31 * 1000);
    assert.ok(ms < 8000, `took ${Math.round(ms)} ms`);
  });
});

// ---------------------------------------------------------------------------------------------
// The real sample Sheets (sample/sheets/meta_placements.csv and meta_audience.csv), when present
// ---------------------------------------------------------------------------------------------

const sampleDir = fileURLToPath(new URL('../sample/sheets/', import.meta.url));
const haveSample = ['meta', 'tiktok', 'google', 'meta_placements', 'meta_audience'].every((n) => existsSync(`${sampleDir}${n}.csv`));

describe('real sample Sheets', { skip: haveSample ? false : 'sample/sheets/meta_placements.csv and meta_audience.csv are not there' }, () => {
  const read = (name) => parseCsv(readFileSync(`${sampleDir}${name}.csv`, 'utf8'));
  const sheets = { placements: read('meta_placements'), audience: read('meta_audience') };
  const main = normalize({ meta: read('meta'), tiktok: read('tiktok'), google: read('google') }, { mode: 'sample', now: NOW });
  const bds = normaliseBreakdowns(sheets, { mode: 'sample', now: NOW, main });
  const payload = sliceBreakdowns(bds);
  const csvSum = (rows, col) => rows.reduce((t, r) => t + (r[col] === '' ? 0 : Number(r[col])), 0);
  const near = (a, b, tolerance, label) => assert.ok(Math.abs(a - b) <= tolerance, `${label}: ${a} differs from ${b} by more than ${tolerance}`);

  it('keeps every CSV row as exactly one fact row (the sample has no duplicates and no blanks)', () => {
    assert.equal(payload.placement_rows.length, sheets.placements.length);
    assert.equal(payload.audience_rows.length, sheets.audience.length);
    assert.deepEqual(payload.available, { placement: true, audience: true });
    assert.equal(bds.health.placement.duplicates + bds.health.audience.duplicates, 0);
  });

  it('every metric sums to its CSV column', () => {
    const columns = { spend: 3, impressions: 4, clicks: 5, link_clicks: 6, actions_video_view: 7, actions_onsite_conversion_messaging_conversation_started_7d: 8, actions_lead: 9 };
    for (const [kind, rows, source] of [['placement_rows', payload.placement_rows, sheets.placements], ['audience_rows', payload.audience_rows, sheets.audience]]) {
      for (const [header, i] of Object.entries(columns)) {
        near(rows.reduce((t, r) => t + r[i], 0), csvSum(source, header), header === 'spend' ? 0.01 : 0, `${kind}.${header}`);
      }
    }
  });

  it('every placement in the sample has an explicit label (no "Platform · Position" fallback)', () => {
    const fallbacks = payload.placements.filter((p) => p.label.includes('·')).map((p) => p.key);
    assert.deepEqual(fallbacks, [], 'add these pairs to PLACEMENT_LABELS in lib/breakdowns.mjs (and to the table in this test)');
  });

  it('joins the main dataset: every ad set key exists in Sheet 1, and the share is close to complete for those ad sets', () => {
    const mainKeys = new Set(main.adsets.map((a) => a.key));
    for (const a of payload.adsets) assert.ok(mainKeys.has(a.key), `${a.key} is in Sheet 1`);
    for (const kind of BREAKDOWN_KINDS) {
      const share = payload.coverage[kind].spend_share;
      assert.ok(share > 0.97 && share < 1.03, `${kind} spend_share ${share}`);
    }
  });

  it('is deterministic and lossless through JSON', () => {
    assert.deepEqual(json(payload), payload);
    assert.deepEqual(sliceBreakdowns(normaliseBreakdowns(sheets, { mode: 'sample', now: NOW, main })), payload);
  });
});
