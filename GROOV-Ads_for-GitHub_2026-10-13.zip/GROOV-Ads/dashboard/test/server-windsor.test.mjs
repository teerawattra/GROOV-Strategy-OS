// The Windsor REST client (server/windsor.mjs) against the mock Windsor (test/mock-windsor.mjs): field lists, answer
// shapes, chunking and row-limit splits, retries, timeouts, "pending" polling, and that neither the key nor the URL
// ever reaches an error message or a log line.

import { after, before, beforeEach, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { DATASETS, DATASET_IDS, MAIN_DATASETS, BREAKDOWN_DATASETS, enabledDatasets, keepRow, normaliserInputs } from '../lib/datasets.mjs';
import { SHEET_COLUMNS } from '../lib/normalize.mjs';
import { BREAKDOWN_SHEET_COLUMNS } from '../lib/breakdowns.mjs';
import { createWindsorClient, WindsorError } from '../server/windsor.mjs';
import { refresh } from '../server/refresh.mjs';
import { startMockWindsor } from './mock-windsor.mjs';
import { NOW, makeConfig, noSleep, offlineFetch, quietLog, readSample, tempRoot } from './server-helpers.mjs';

const countIn = (rows, from, to) => rows.filter((r) => r.date >= from && r.date <= to).length;

describe('lib/datasets.mjs: one source of truth', () => {
  it('takes every field list from the normalisers (same arrays, not copies)', () => {
    assert.equal(DATASETS.meta.fields, SHEET_COLUMNS.meta);
    assert.equal(DATASETS.tiktok.fields, SHEET_COLUMNS.tiktok);
    assert.equal(DATASETS.google.fields, SHEET_COLUMNS.google);
    assert.equal(DATASETS.meta_placements.fields, BREAKDOWN_SHEET_COLUMNS.placement);
    assert.equal(DATASETS.meta_audience.fields, BREAKDOWN_SHEET_COLUMNS.audience);
  });

  it('names the five datasets, their connectors and normaliser inputs', () => {
    assert.deepEqual(DATASET_IDS, ['meta', 'tiktok', 'google', 'meta_placements', 'meta_audience']);
    assert.deepEqual(MAIN_DATASETS, ['meta', 'tiktok', 'google']);
    assert.deepEqual(BREAKDOWN_DATASETS, ['meta_placements', 'meta_audience']);
    assert.deepEqual(DATASET_IDS.map((d) => DATASETS[d].connector), ['facebook', 'tiktok', 'google_ads', 'facebook', 'facebook']);
    assert.deepEqual(enabledDatasets({ enableBreakdowns: false }), ['meta', 'tiktok', 'google']);
    const inputs = normaliserInputs({ meta: [1], tiktok: [2], google: [3], meta_placements: [4], meta_audience: [5] });
    assert.deepEqual(inputs, { main: { meta: [1], tiktok: [2], google: [3] }, breakdowns: { placements: [4], audience: [5] } });
  });

  it('keeps breakdown rows only with spend > 0 (read like the normaliser reads numbers)', () => {
    assert.equal(keepRow('meta_placements', { spend: 1.5 }), true);
    assert.equal(keepRow('meta_placements', { spend: '0.01' }), true);
    assert.equal(keepRow('meta_placements', { spend: 0 }), false);
    assert.equal(keepRow('meta_audience', { spend: null }), false);
    assert.equal(keepRow('meta_audience', { spend: '' }), false);
    assert.equal(keepRow('meta', { spend: 0 }), true, 'main datasets keep every row');
  });
});

describe('Windsor client', () => {
  let mock;
  let sleeps;
  const client = (o = {}) => createWindsorClient({ apiKey: mock.key, baseUrl: mock.url, sleep: async (ms) => { sleeps.push(ms); }, ...o });

  before(async () => {
    mock = await startMockWindsor();
  });
  after(async () => {
    await mock.close();
  });
  beforeEach(() => {
    mock.resetRequests();
    mock.clearFaults();
    mock.setShape('data');
    sleeps = [];
  });

  it('asks for exactly the contract fields, the dates and _max_rows, and returns Windsor-typed rows', async () => {
    const pieces = [];
    await client().pullRange('meta', { from: '2026-09-14', to: '2026-09-20' }, async (p) => { pieces.push(p); });
    assert.equal(mock.requests.length, 1);
    const r = mock.requests[0];
    assert.equal(r.connector, 'facebook');
    assert.deepEqual(r.fields, SHEET_COLUMNS.meta);
    assert.equal(r.date_from, '2026-09-14');
    assert.equal(r.date_to, '2026-09-20');
    assert.equal(r.max_rows, 100_000);
    assert.equal(r.key_ok, true);
    assert.equal(pieces.length, 1);
    assert.equal(pieces[0].rows.length, countIn(readSample('meta'), '2026-09-14', '2026-09-20'));
    const row = pieces[0].rows[0];
    assert.deepEqual(Object.keys(row), SHEET_COLUMNS.meta);
    assert.equal(typeof row.account_id, 'string');
    assert.equal(typeof row.spend, 'number');
  });

  it('accepts {"data": [...]} and a bare array alike', async () => {
    const a = await client().fetchRows({ connector: 'tiktok', fields: DATASETS.tiktok.fields, from: '2026-09-07', to: '2026-09-20' });
    mock.setShape('array');
    const b = await client().fetchRows({ connector: 'tiktok', fields: DATASETS.tiktok.fields, from: '2026-09-07', to: '2026-09-20' });
    assert.equal(a.rows.length, 253);
    assert.deepEqual(b.rows, a.rows);
  });

  it('picks the placement and audience tables by their fields', async () => {
    const p = await client().fetchRows({ connector: 'facebook', fields: DATASETS.meta_placements.fields, from: '2026-09-07', to: '2026-09-07' });
    const a = await client().fetchRows({ connector: 'facebook', fields: DATASETS.meta_audience.fields, from: '2026-09-07', to: '2026-09-07' });
    assert.equal(p.rows.length, countIn(readSample('meta_placements'), '2026-09-07', '2026-09-07'));
    assert.equal(a.rows.length, countIn(readSample('meta_audience'), '2026-09-07', '2026-09-07'));
    assert.ok(p.rows.every((x) => 'publisher_platform' in x && !('age' in x)));
  });

  it('splits a range that reaches _max_rows into halves until every piece is complete', async () => {
    const pieces = [];
    const stats = { requests: 0, rows: 0, splits: 0 };
    await client({ maxRows: 300 }).pullRange('meta', { from: '2026-09-14', to: '2026-09-20' }, async (p) => { pieces.push(p); }, stats);
    const total = countIn(readSample('meta'), '2026-09-14', '2026-09-20');
    assert.equal(pieces.reduce((n, p) => n + p.rows.length, 0), total, 'nothing lost, nothing doubled');
    assert.ok(pieces.every((p) => p.rows.length < 300));
    assert.ok(stats.splits >= 2, `splits ${stats.splits}`);
    const days = pieces.flatMap((p) => { const out = []; for (let d = p.from; d <= p.to; d = new Date(Date.parse(d) + 86400000).toISOString().slice(0, 10)) out.push(d); return out; });
    assert.deepEqual(days, ['2026-09-14', '2026-09-15', '2026-09-16', '2026-09-17', '2026-09-18', '2026-09-19', '2026-09-20'], 'pieces tile the range in order');
  });

  it('refuses a single day that still reaches the row limit', async () => {
    await assert.rejects(
      client({ maxRows: 100 }).pullRange('meta_audience', { from: '2026-09-14', to: '2026-09-14' }, async () => {}),
      (err) => err instanceof WindsorError && err.code === 'max_rows' && /WINDSOR_MAX_ROWS/.test(err.message),
    );
  });

  it('retries 5xx twice with backoff, then succeeds', async () => {
    mock.addFault({ kind: 'status', status: 503, times: 2 });
    const r = await client().fetchRows({ connector: 'google_ads', fields: DATASETS.google.fields, from: '2026-09-07', to: '2026-09-20' });
    assert.equal(r.rows.length, 113);
    assert.equal(r.attempts, 3);
    assert.equal(sleeps.length, 2);
    assert.ok(sleeps[0] >= 1600 && sleeps[0] <= 2400 && sleeps[1] >= 6400 && sleeps[1] <= 9600, `backoff ${sleeps}`);
  });

  it('gives up after 3 attempts with a plain message', async () => {
    mock.addFault({ kind: 'status', status: 500, times: 5 });
    await assert.rejects(
      client().fetchRows({ connector: 'google_ads', fields: DATASETS.google.fields, from: '2026-09-07', to: '2026-09-20', label: 'Windsor google_ads (google 2026-09-07..2026-09-20)' }),
      (err) => err instanceof WindsorError && /HTTP 500/.test(err.message) && /gave up after 3 attempts/.test(err.message) && err.message.startsWith('Windsor google_ads (google 2026-09-07..2026-09-20)'),
    );
    assert.equal(mock.requests.length, 3);
  });

  it('times out a hanging request and retries it', async () => {
    mock.addFault({ kind: 'hang', times: 1 });
    const r = await client({ timeoutMs: 300 }).fetchRows({ connector: 'tiktok', fields: DATASETS.tiktok.fields, from: '2026-09-20', to: '2026-09-20' });
    assert.equal(r.attempts, 2);
    mock.addFault({ kind: 'hang', times: 3 });
    await assert.rejects(
      client({ timeoutMs: 300 }).fetchRows({ connector: 'tiktok', fields: DATASETS.tiktok.fields, from: '2026-09-20', to: '2026-09-20' }),
      /timed out after 300 ms \(gave up after 3 attempts\)/,
    );
  });

  it('polls a "pending" answer with growing waits', async () => {
    mock.addFault({ kind: 'pending', times: 3 });
    const r = await client({ pendingDelayMs: 1000 }).fetchRows({ connector: 'tiktok', fields: DATASETS.tiktok.fields, from: '2026-09-07', to: '2026-09-20' });
    assert.equal(r.rows.length, 253);
    assert.deepEqual(sleeps, [1000, 2000, 4000]);
    mock.addFault({ kind: 'pending', times: 50 });
    await assert.rejects(client({ pendingPolls: 2 }).fetchRows({ connector: 'tiktok', fields: DATASETS.tiktok.fields, from: '2026-09-07', to: '2026-09-07' }), /still answered "pending"/);
  });

  it('retries an answer that is not JSON (a proxy error page)', async () => {
    mock.addFault({ kind: 'garbage', times: 1 });
    const r = await client().fetchRows({ connector: 'google_ads', fields: DATASETS.google.fields, from: '2026-09-07', to: '2026-09-07' });
    assert.equal(r.attempts, 2);
  });

  it('never puts the key or the URL in an error, even when Windsor echoes them', async () => {
    const wrong = createWindsorClient({ apiKey: 'FAKE-TEST-ONLY-MUST-NOT-LEAK-42', baseUrl: mock.url, sleep: noSleep });
    let err;
    try {
      await wrong.fetchRows({ connector: 'facebook', fields: DATASETS.meta.fields, from: '2026-09-07', to: '2026-09-07' });
    } catch (e) {
      err = e;
    }
    assert.ok(err instanceof WindsorError);
    assert.equal(err.status, 401);
    assert.equal(err.fatal, true, 'a refused key stops the run');
    assert.match(err.message, /API key was refused/);
    assert.ok(!err.message.includes('THIS-KEY-MUST-NOT-LEAK'), err.message);
    assert.ok(!err.message.includes(mock.url) && !err.message.includes('127.0.0.1'), err.message);
    assert.ok(!/api_key=(?!\[redacted\])/.test(err.message), err.message);
    assert.ok(!(err.stack ?? '').includes('THIS-KEY-MUST-NOT-LEAK'));

    mock.addFault({ kind: 'status', status: 400, times: 1, body: JSON.stringify({ error: `bad field in https://connectors.windsor.ai/facebook?api_key=${mock.key}&fields=x` }) });
    await assert.rejects(client().fetchRows({ connector: 'facebook', fields: ['date'], from: '2026-09-07', to: '2026-09-07' }), (e) => {
      assert.ok(!e.message.includes(mock.key), e.message);
      assert.match(e.message, /HTTP 400/);
      return true;
    });

    const dead = createWindsorClient({ apiKey: mock.key, baseUrl: 'http://127.0.0.1:9', sleep: noSleep, timeoutMs: 2000 });
    await assert.rejects(dead.fetchRows({ connector: 'tiktok', fields: ['date'], from: '2026-09-07', to: '2026-09-07' }), (e) => {
      assert.match(e.message, /network error|timed out/);
      assert.ok(!e.message.includes(mock.key) && !e.message.includes('127.0.0.1:9'), e.message);
      return true;
    });
  });

  it('redacts the key in every spelling Windsor could echo (raw, URL-encoded, form-encoded)', async () => {
    const odd = 'Ab+c/d=e&f?g h~SECRET';
    const c = createWindsorClient({ apiKey: odd, baseUrl: mock.url, sleep: noSleep });
    await assert.rejects(c.fetchRows({ connector: 'tiktok', fields: ['date'], from: '2026-09-07', to: '2026-09-07' }), (e) => {
      for (const form of [odd, encodeURIComponent(odd), new URLSearchParams({ k: odd }).toString().slice(2), 'SECRET']) assert.ok(!e.message.includes(form), `${form} in: ${e.message}`);
      return true;
    });
  });

  it('refuses to start without a key', () => {
    assert.throws(() => createWindsorClient({ apiKey: '', baseUrl: mock.url }), (e) => e instanceof WindsorError && e.fatal && /WINDSOR_API_KEY or MCP_WINDSOR_API_KEY/.test(e.message));
  });
});

describe('refresh: chunking and secrets in logs', () => {
  let mock;
  let root;
  before(async () => {
    mock = await startMockWindsor();
    root = await tempRoot();
  });
  after(async () => {
    await mock.close();
    await root.cleanup();
  });

  it('pulls the last 28 complete days in four 7-day chunks per dataset, never today', async () => {
    const config = makeConfig(root.dir, { WINDSOR_BASE_URL: mock.url, WINDSOR_API_KEY: mock.key });
    const log = quietLog();
    const status = await refresh(config, { now: NOW, log, sleep: noSleep, imageFetchImpl: offlineFetch });
    assert.equal(status.state, 'ok', status.error);
    assert.deepEqual(status.range, { from: '2026-08-24', to: '2026-09-20' });
    for (const d of DATASET_IDS) {
      const ranges = mock.requests.filter((r) => r.table === d).map((r) => `${r.date_from}..${r.date_to}`).sort();
      assert.deepEqual(ranges, ['2026-08-24..2026-08-30', '2026-08-31..2026-09-06', '2026-09-07..2026-09-13', '2026-09-14..2026-09-20'], d);
    }
    assert.ok(log.lines.length > 5);
    for (const { line } of log.lines) assert.ok(!line.includes(mock.key), line);
  });

  it('a refused key stops the run after the first answers, and nothing in the logs shows the key', async () => {
    mock.resetRequests();
    const secret = 'FAKE-TEST-ONLY-REFUSED-0001';
    const config = makeConfig(root.dir, { WINDSOR_BASE_URL: mock.url, MCP_WINDSOR_API_KEY: secret });
    assert.equal(config.keySource, 'MCP_WINDSOR_API_KEY');
    const log = quietLog();
    const status = await refresh(config, { now: NOW, log, sleep: noSleep, imageFetchImpl: offlineFetch });
    assert.equal(status.state, 'error');
    assert.match(status.error, /API key was refused/);
    assert.ok(mock.requests.length <= config.windsor.concurrency, `stopped early (${mock.requests.length} requests)`);
    for (const { line } of log.lines) assert.ok(!line.includes(secret) && !line.includes('api_key='), line);
    assert.ok(!JSON.stringify(status).includes(secret));
  });
});
