// Session cookie (lib/session.mjs, node:crypto) + shared format (lib/session-token.mjs, Web Crypto) + the edge
// function that enforces it (netlify/edge-functions/auth.js). No network.
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { createHmac } from 'node:crypto';
import {
  INTERNAL_TOKEN_HEADER,
  authConfig,
  clearedSessionCookie,
  mintInternalToken,
  mintSession,
  requireSession,
  sessionCookie,
  verifyInternalToken,
  verifySession,
} from '../lib/session.mjs';
import {
  SESSION_COOKIE,
  SESSION_TTL_SECONDS,
  base64urlDecode,
  base64urlEncode,
  isDocumentRequest,
  isEmailAllowed,
  parseList,
  readCookie,
  signSessionWeb,
  verifySessionWeb,
} from '../lib/session-token.mjs';
import auth, { PUBLIC_PATHS, config as edgeConfig, isPublicPath } from '../netlify/edge-functions/auth.js';

const SECRET = 'unit-test-session-secret-0123456789abcdef';
const NOW = Date.parse('2026-10-12T00:05:00Z');
const NOW_S = Math.floor(NOW / 1000);
const ENV = {
  SESSION_SECRET: SECRET,
  GOOGLE_CLIENT_ID: 'client-123.apps.googleusercontent.com',
  ALLOWED_DOMAINS: 'groovstrategy.co',
  ALLOWED_EMAILS: 'Friend.Of.Groov@gmail.com',
  OWNER_EMAILS: 'finn@groovstrategy.co',
};

/** Fixed vector, computed independently with createHmac + Buffer base64url. */
const VECTOR = {
  secret: 'groov-test-vector-secret-0123456789abcdef',
  email: 'finn@groovstrategy.co',
  exp: 1790000000,
  token: 'eyJlbWFpbCI6ImZpbm5AZ3Jvb3ZzdHJhdGVneS5jbyIsImV4cCI6MTc5MDAwMDAwMH0.51hDu0elBvGRCS5dFAYwKjAmCCPqbY-7YlF2pjI2164',
};

const withCookie = (token, url = 'https://ads.example.test/api/rows', headers = {}) =>
  new Request(url, { headers: { cookie: `other=1; ${SESSION_COOKIE}=${token}; theme=dark`, ...headers } });

describe('cookie format: mint and verify (node:crypto)', () => {
  it('mints a 7-day cookie that verifies, with the email lower-cased', () => {
    const { token, exp, email } = mintSession('Finn@GroovStrategy.CO', { secret: SECRET, now: NOW });
    assert.equal(email, 'finn@groovstrategy.co');
    assert.equal(exp, NOW_S + SESSION_TTL_SECONDS);
    assert.equal(SESSION_TTL_SECONDS, 604800);
    const result = verifySession(token, { secret: SECRET, now: NOW + 1000 });
    assert.deepEqual(result, { ok: true, session: { email: 'finn@groovstrategy.co', exp } });
  });

  it('matches the fixed test vector exactly', () => {
    const independent = (() => {
      const payload = Buffer.from(JSON.stringify({ email: VECTOR.email, exp: VECTOR.exp })).toString('base64url');
      return `${payload}.${createHmac('sha256', VECTOR.secret).update(payload).digest('base64url')}`;
    })();
    assert.equal(independent, VECTOR.token);
    const minted = mintSession(VECTOR.email, { secret: VECTOR.secret, now: (VECTOR.exp - SESSION_TTL_SECONDS) * 1000 });
    assert.equal(minted.token, VECTOR.token);
  });

  it('rejects an expired cookie, and one whose lifetime is longer than 7 days', () => {
    const { token, exp } = mintSession('finn@groovstrategy.co', { secret: SECRET, now: NOW });
    assert.deepEqual(verifySession(token, { secret: SECRET, now: exp * 1000 }), { ok: false, reason: 'expired' });
    assert.deepEqual(verifySession(token, { secret: SECRET, now: (exp + 3600) * 1000 }), { ok: false, reason: 'expired' });
    const long = mintSession('finn@groovstrategy.co', { secret: SECRET, now: NOW, ttlSeconds: 30 * 86400 });
    assert.deepEqual(verifySession(long.token, { secret: SECRET, now: NOW }), { ok: false, reason: 'lifetime_too_long' });
  });

  it('rejects tampering: payload, signature, wrong secret', () => {
    const { token } = mintSession('someone@gmail.com', { secret: SECRET, now: NOW });
    const [payload, sig] = token.split('.');
    const forgedPayload = Buffer.from(JSON.stringify({ email: 'finn@groovstrategy.co', exp: NOW_S + 3600 })).toString('base64url');
    assert.equal(verifySession(`${forgedPayload}.${sig}`, { secret: SECRET, now: NOW }).reason, 'bad_signature');
    const flipped = sig.slice(0, -2) + (sig.at(-2) === 'A' ? 'B' : 'A') + sig.at(-1);
    assert.equal(verifySession(`${payload}.${flipped}`, { secret: SECRET, now: NOW }).reason, 'bad_signature');
    assert.equal(verifySession(token, { secret: `${SECRET}-rotated`, now: NOW }).reason, 'bad_signature');
    assert.equal(verifySession(`${payload}.${sig.slice(0, 20)}`, { secret: SECRET, now: NOW }).reason, 'bad_signature');
  });

  it('rejects malformed values', () => {
    for (const bad of ['', 'abc', 'a.b.c', 'abc.', '.abc', 'ab+c.def', 'abc.d/ef', `${'a'.repeat(2000)}.abc`, null, undefined, 42]) {
      assert.equal(verifySession(bad, { secret: SECRET, now: NOW }).ok, false, `value ${String(bad).slice(0, 20)}`);
    }
    // A correctly signed payload that is not a session object is still rejected.
    const payload = Buffer.from('["not", "an", "object"]').toString('base64url');
    const sig = createHmac('sha256', SECRET).update(payload).digest('base64url');
    assert.deepEqual(verifySession(`${payload}.${sig}`, { secret: SECRET, now: NOW }), { ok: false, reason: 'malformed' });
  });

  it('refuses to work without a long enough secret', () => {
    assert.throws(() => mintSession('a@b.co', { secret: 'short' }), /SESSION_SECRET/);
    assert.deepEqual(verifySession('a.b', { secret: '' }), { ok: false, reason: 'server_secret_missing' });
  });

  it('builds the Set-Cookie headers with the required attributes', () => {
    const header = sessionCookie('abc.def');
    assert.equal(header, 'groov_session=abc.def; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=604800');
    const cleared = clearedSessionCookie();
    assert.match(cleared, /^groov_session=; /);
    assert.match(cleared, /Max-Age=0/);
    assert.match(cleared, /HttpOnly; Secure; SameSite=Lax; Path=\//);
  });
});

describe('cookie format: Node and Web Crypto implementations agree (edge algorithm)', () => {
  it('a cookie minted by lib/session.mjs verifies with verifySessionWeb', async () => {
    const { token, exp } = mintSession('finn@groovstrategy.co', { secret: SECRET, now: NOW });
    assert.deepEqual(await verifySessionWeb(token, SECRET, NOW_S), { ok: true, session: { email: 'finn@groovstrategy.co', exp } });
  });

  it('a cookie signed with Web Crypto verifies with lib/session.mjs, byte-identical to the Node mint', async () => {
    const exp = NOW_S + SESSION_TTL_SECONDS;
    const web = await signSessionWeb({ email: 'finn@groovstrategy.co', exp }, SECRET);
    assert.equal(web, mintSession('finn@groovstrategy.co', { secret: SECRET, now: NOW }).token);
    assert.equal(verifySession(web, { secret: SECRET, now: NOW }).ok, true);
    assert.equal(await signSessionWeb({ email: VECTOR.email, exp: VECTOR.exp }, VECTOR.secret), VECTOR.token);
  });

  it('both reject the same tampered, expired and wrong-secret cookies', async () => {
    const { token, exp } = mintSession('finn@groovstrategy.co', { secret: SECRET, now: NOW });
    const [payload, sig] = token.split('.');
    const forged = `${Buffer.from(JSON.stringify({ email: 'evil@groovstrategy.co', exp })).toString('base64url')}.${sig}`;
    for (const [value, secret, now, reason] of [
      [forged, SECRET, NOW_S, 'bad_signature'],
      [token, 'another-secret-that-is-long-enough-0123', NOW_S, 'bad_signature'],
      [token, SECRET, exp + 1, 'expired'],
      [`${payload}`, SECRET, NOW_S, 'malformed'],
    ]) {
      assert.equal((await verifySessionWeb(value, secret, now)).reason, reason);
      assert.equal(verifySession(value, { secret, now: now * 1000 }).reason, reason);
    }
  });

  it('base64url helpers round-trip and reject foreign characters', () => {
    const bytes = new Uint8Array([0, 1, 2, 250, 251, 252, 253, 254, 255]);
    const text = base64urlEncode(bytes);
    assert.equal(text, Buffer.from(bytes).toString('base64url'));
    assert.deepEqual(base64urlDecode(text), bytes);
    assert.throws(() => base64urlDecode('ab/c'));
  });
});

describe('cookie header, allow-list and request helpers', () => {
  it('reads one cookie out of a Cookie header', () => {
    assert.equal(readCookie('a=1; groov_session=xyz.abc; b=2', 'groov_session'), 'xyz.abc');
    assert.equal(readCookie('groov_session="quoted.value"', 'groov_session'), 'quoted.value');
    assert.equal(readCookie('xgroov_session=1; groov_sessionx=2', 'groov_session'), null);
    assert.equal(readCookie('', 'groov_session'), null);
    assert.equal(readCookie(null, 'groov_session'), null);
  });

  it('parses allow-lists and checks emails case-insensitively', () => {
    assert.deepEqual(parseList(' GroovStrategy.co, @other.co ;; groovstrategy.co\nx@y.co '), ['groovstrategy.co', 'other.co', 'x@y.co']);
    const lists = { allowedDomains: ['groovstrategy.co'], allowedEmails: ['friend@gmail.com'] };
    assert.equal(isEmailAllowed('Finn@GroovStrategy.co', lists), true);
    assert.equal(isEmailAllowed('friend@gmail.com', lists), true);
    assert.equal(isEmailAllowed('stranger@gmail.com', lists), false);
    assert.equal(isEmailAllowed('finn@groovstrategy.co.evil.com', lists), false);
    assert.equal(isEmailAllowed('not-an-email', lists), false);
  });

  it('tells page navigations from other requests', () => {
    const req = (headers, method = 'GET') => new Request('https://x.test/', { method, headers });
    assert.equal(isDocumentRequest(req({ 'sec-fetch-dest': 'document' })), true);
    assert.equal(isDocumentRequest(req({ 'sec-fetch-dest': 'script', accept: 'text/html' })), false);
    assert.equal(isDocumentRequest(req({ 'sec-fetch-mode': 'navigate' })), true);
    assert.equal(isDocumentRequest(req({ accept: 'text/html,application/xhtml+xml' })), true);
    assert.equal(isDocumentRequest(req({ accept: 'application/json' })), false);
    assert.equal(isDocumentRequest(req({ 'sec-fetch-dest': 'document' }, 'POST')), false);
  });

  it('reports configuration problems without exposing values', () => {
    assert.deepEqual(authConfig(ENV).problems, []);
    const cfg = authConfig({});
    assert.equal(cfg.problems.length, 3);
    assert.ok(cfg.problems.every((p) => !p.includes(SECRET)));
  });
});

describe('requireSession (every protected function)', () => {
  it('401 without a cookie, ok with one, owner flag from OWNER_EMAILS', () => {
    const none = requireSession(new Request('https://x.test/api/meta'), { env: ENV, now: NOW });
    assert.equal(none.ok, false);
    assert.equal(none.status, 401);
    const owner = requireSession(withCookie(mintSession('finn@groovstrategy.co', { secret: SECRET, now: NOW }).token), { env: ENV, now: NOW });
    assert.deepEqual({ ok: owner.ok, email: owner.email, owner: owner.owner }, { ok: true, email: 'finn@groovstrategy.co', owner: true });
    const guest = requireSession(withCookie(mintSession('friend.of.groov@gmail.com', { secret: SECRET, now: NOW }).token), { env: ENV, now: NOW });
    assert.equal(guest.ok, true);
    assert.equal(guest.owner, false);
  });

  it('locks out an email removed from the allow-list, and says why an expired session failed', () => {
    const token = mintSession('ex.staff@gmail.com', { secret: SECRET, now: NOW }).token;
    const res = requireSession(withCookie(token), { env: ENV, now: NOW });
    assert.equal(res.status, 401);
    assert.equal(res.reason, 'not_allowed');
    const expired = requireSession(withCookie(mintSession('finn@groovstrategy.co', { secret: SECRET, now: NOW - 8 * 86400_000 }).token), { env: ENV, now: NOW });
    assert.equal(expired.reason, 'expired');
    assert.match(expired.error, /expired/);
  });

  it('500 when the server has no secret', () => {
    const res = requireSession(withCookie('a.b'), { env: { ...ENV, SESSION_SECRET: '' }, now: NOW });
    assert.equal(res.status, 500);
  });
});

describe('internal trigger token (scheduled function -> background function)', () => {
  it('verifies for the same trigger and force flag within 5 minutes', () => {
    const token = mintInternalToken({ secret: SECRET, trigger: 'schedule', now: NOW });
    assert.equal(verifyInternalToken(token, { secret: SECRET, trigger: 'schedule', now: NOW + 60_000 }), true);
    assert.equal(verifyInternalToken(token, { secret: SECRET, trigger: 'manual', now: NOW }), false);
    assert.equal(verifyInternalToken(token, { secret: SECRET, trigger: 'schedule', force: true, now: NOW }), false);
    assert.equal(verifyInternalToken(token, { secret: SECRET, trigger: 'schedule', now: NOW + 301_000 }), false);
    assert.equal(verifyInternalToken(token, { secret: `${SECRET}x`, trigger: 'schedule', now: NOW }), false);
    for (const bad of [null, '', 'abc', `${NOW_S}.short`, `x${token}`]) {
      assert.equal(verifyInternalToken(bad, { secret: SECRET, trigger: 'schedule', now: NOW }), false);
    }
    assert.equal(INTERNAL_TOKEN_HEADER, 'x-groov-refresh');
  });

  it('a session cookie signature is never accepted as a trigger token', () => {
    const { token } = mintSession('finn@groovstrategy.co', { secret: SECRET, now: NOW });
    const sig = token.split('.')[1];
    assert.equal(verifyInternalToken(`${NOW_S}.${sig}`, { secret: SECRET, trigger: 'schedule', now: NOW }), false);
  });
});

describe('edge function auth (netlify/edge-functions/auth.js)', () => {
  let saved;
  before(() => {
    saved = globalThis.Netlify;
    globalThis.Netlify = { env: { get: (name) => ENV[name] } };
  });
  after(() => {
    if (saved === undefined) delete globalThis.Netlify;
    else globalThis.Netlify = saved;
  });

  const nav = (url, cookie) => new Request(url, { headers: { 'sec-fetch-dest': 'document', 'sec-fetch-mode': 'navigate', accept: 'text/html', ...(cookie ? { cookie } : {}) } });
  const api = (url, cookie) => new Request(url, { headers: { 'sec-fetch-dest': 'empty', accept: 'application/json', ...(cookie ? { cookie } : {}) } });

  it('lets a request with a cookie minted by lib/session.mjs through (returns undefined)', async () => {
    const { token } = mintSession('finn@groovstrategy.co', { secret: SECRET, now: Date.now() });
    assert.equal(await auth(nav('https://ads.example.test/', `${SESSION_COOKIE}=${token}`)), undefined);
    assert.equal(await auth(api('https://ads.example.test/api/rows?from=2026-09-01&to=2026-09-20', `${SESSION_COOKIE}=${token}`)), undefined);
    assert.equal(await auth(new Request('https://ads.example.test/assets/app.css', { headers: { cookie: `a=b; ${SESSION_COOKIE}=${token}` } })), undefined);
  });

  it('redirects page loads to /login.html and answers other requests 401 JSON', async () => {
    const page = await auth(nav('https://ads.example.test/'));
    assert.equal(page.status, 302);
    assert.equal(page.headers.get('location'), '/login.html');
    assert.equal(page.headers.get('cache-control'), 'no-store');
    const head = await auth(new Request('https://ads.example.test/index.html', { method: 'HEAD', headers: { accept: 'text/html' } }));
    assert.equal(head.status, 302);
    const data = await auth(api('https://ads.example.test/api/meta'));
    assert.equal(data.status, 401);
    assert.deepEqual(await data.json(), { error: 'Not signed in.' });
    const script = await auth(new Request('https://ads.example.test/data/registry.js', { headers: { 'sec-fetch-dest': 'script' } }));
    assert.equal(script.status, 401);
  });

  it('rejects tampered, expired and no-longer-allowed cookies, and clears them', async () => {
    const { token, exp } = mintSession('finn@groovstrategy.co', { secret: SECRET, now: Date.now() });
    const sig = token.split('.')[1];
    const forged = `${Buffer.from(JSON.stringify({ email: 'boss@groovstrategy.co', exp })).toString('base64url')}.${sig}`;
    const expired = mintSession('finn@groovstrategy.co', { secret: SECRET, now: Date.now() - 8 * 86400_000 }).token;
    const removed = mintSession('ex.staff@gmail.com', { secret: SECRET, now: Date.now() }).token;
    for (const bad of [forged, expired, removed]) {
      const res = await auth(nav('https://ads.example.test/', `${SESSION_COOKIE}=${bad}`));
      assert.equal(res.status, 302);
      assert.match(res.headers.get('set-cookie'), /^groov_session=; .*Max-Age=0/);
      assert.equal((await auth(api('https://ads.example.test/api/rows', `${SESSION_COOKIE}=${bad}`))).status, 401);
    }
  });

  it('serves the public paths and Netlify internals without a session', async () => {
    for (const path of [...PUBLIC_PATHS, '/.netlify/functions/refresh-background']) {
      assert.equal(await auth(nav(`https://ads.example.test${path}`)), undefined, path);
      assert.equal(isPublicPath(path), true);
    }
    assert.equal(isPublicPath('/login.html/../index.html'), false);
    assert.equal(isPublicPath('/api/sessions'), false);
    // Same as Netlify's generated exclusion patterns: an optional trailing slash.
    assert.equal(isPublicPath('/api/session/'), true);
    assert.equal(isPublicPath('/.netlify'), true);
    assert.equal(isPublicPath('/'), false);
    assert.equal(isPublicPath('/.netlifyx/a'), false);
  });

  it('never serves the local sample bundle, even when signed in', async () => {
    const { token } = mintSession('finn@groovstrategy.co', { secret: SECRET, now: Date.now() });
    const res = await auth(new Request('https://ads.example.test/data/sample.js', { headers: { cookie: `${SESSION_COOKIE}=${token}` } }));
    assert.equal(res.status, 404);
  });

  it('fails closed with an explanation when SESSION_SECRET is not visible to edge functions', async () => {
    const before = globalThis.Netlify;
    globalThis.Netlify = { env: { get: () => undefined } };
    try {
      const page = await auth(nav('https://ads.example.test/'));
      assert.equal(page.status, 500);
      assert.match(await page.text(), /SESSION_SECRET/);
      const data = await auth(api('https://ads.example.test/api/meta'));
      assert.equal(data.status, 500);
    } finally {
      globalThis.Netlify = before;
    }
  });

  it('declares path /* and excludes exactly the public paths plus /.netlify/*', () => {
    assert.equal(edgeConfig.path, '/*');
    assert.deepEqual([...edgeConfig.excludedPath].sort(), [...PUBLIC_PATHS, '/.netlify/*'].sort());
  });
});
