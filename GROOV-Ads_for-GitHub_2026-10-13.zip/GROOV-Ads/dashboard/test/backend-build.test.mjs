// Deploy plumbing: scripts/prebuild.mjs never publishes the sample bundle, netlify.toml carries the intended
// settings and one CSP, every function declares a literal route or schedule, and scripts/seed-creatives.mjs
// uploads only missing, real images. No network.
import { after, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { existsSync, mkdirSync, mkdtempSync, readFileSync, readdirSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { buildDist, isExcluded } from '../scripts/prebuild.mjs';
import { scanLibrary, seedCreatives } from '../scripts/seed-creatives.mjs';
import { createMemoryStore, toArrayBuffer } from '../lib/blobs-store.mjs';
import { jpegBytes, pngBytes } from './backend-fakes.mjs';

const ROOT = fileURLToPath(new URL('..', import.meta.url));
const temp = mkdtempSync(join(tmpdir(), 'groov-backend-build-'));
after(() => rmSync(temp, { recursive: true, force: true }));

function makeTree(base, files) {
  for (const [rel, content] of Object.entries(files)) {
    mkdirSync(join(base, rel, '..'), { recursive: true });
    writeFileSync(join(base, rel), content);
  }
}

describe('scripts/prebuild.mjs', () => {
  it('copies public/ to dist/ without the sample bundle or dot-files', () => {
    const src = join(temp, 'public');
    const out = join(temp, 'dist');
    makeTree(src, {
      'index.html': '<!doctype html>', 'login.html': 'x', 'assets/app.css': 'x', 'assets/js/app.js': 'x', '.DS_Store': 'x',
      'assets/.DS_Store': 'x', 'data/registry.js': 'x', 'data/learnings.js': 'x', 'data/sample.js': 'window.GROOV_SAMPLE={}', 'data/sample.json': '{}',
    });
    makeTree(out, { 'stale.txt': 'from an older build' });
    const result = buildDist({ src, out });
    const listed = [];
    const walk = (dir, prefix = '') => {
      for (const name of readdirSync(dir, { withFileTypes: true })) {
        if (name.isDirectory()) walk(join(dir, name.name), `${prefix}${name.name}/`);
        else listed.push(`${prefix}${name.name}`);
      }
    };
    walk(out);
    assert.deepEqual(listed.sort(), ['assets/app.css', 'assets/js/app.js', 'data/learnings.js', 'data/registry.js', 'index.html', 'login.html']);
    assert.equal(result.files, 6);
    assert.ok(result.skipped.includes(join('data', 'sample.js')));
  });

  it('refuses to build without the dashboard or its generated data files', () => {
    const src = join(temp, 'incomplete');
    makeTree(src, { 'login.html': 'x', 'data/registry.js': 'x' });
    assert.throws(() => buildDist({ src, out: join(temp, 'dist2') }), /index\.html, data\/learnings\.js/);
  });

  it('isExcluded', () => {
    assert.equal(isExcluded(join('data', 'sample.js')), true);
    assert.equal(isExcluded(join('data', 'Sample.JS')), true);
    assert.equal(isExcluded('.DS_Store'), true);
    assert.equal(isExcluded(join('assets', '.hidden', 'x.js')), true);
    assert.equal(isExcluded(join('data', 'registry.js')), false);
    assert.equal(isExcluded(join('assets', 'sample.js')), false);
  });
});

describe('netlify.toml', () => {
  const toml = readFileSync(join(ROOT, 'netlify.toml'), 'utf8');
  const setting = (key) => new RegExp(`^\\s*${key}\\s*=\\s*"([^"]*)"`, 'm').exec(toml)?.[1];

  it('builds dist/ with the prebuild script and declares the function folders', () => {
    assert.equal(setting('command'), 'node scripts/prebuild.mjs');
    assert.equal(setting('publish'), 'dist');
    assert.equal(setting('functions'), 'netlify/functions');
    assert.equal(setting('edge_functions'), 'netlify/edge-functions');
    assert.equal(setting('node_bundler'), 'esbuild');
  });

  it('sets exactly one strict Content-Security-Policy that allows Google sign-in', () => {
    const csps = toml.match(/^\s*Content-Security-Policy\s*=\s*"([^"]*)"/gm) ?? [];
    assert.equal(csps.length, 1);
    const csp = setting('Content-Security-Policy');
    for (const part of [
      "default-src 'self'", "script-src 'self' https://accounts.google.com/gsi/client", 'frame-src https://accounts.google.com/gsi/',
      "connect-src 'self' https://accounts.google.com/gsi/", 'https://accounts.google.com/gsi/style', "frame-ancestors 'none'", "object-src 'none'",
    ]) assert.ok(csp.includes(part), part);
    assert.ok(!csp.includes('unsafe-eval'));
    assert.ok(!/script-src[^;]*unsafe-inline/.test(csp), 'no inline scripts');
    for (const header of ['X-Frame-Options', 'X-Content-Type-Options', 'Referrer-Policy', 'Permissions-Policy', 'Cross-Origin-Opener-Policy']) {
      assert.ok(setting(header), header);
    }
    assert.equal(setting('Cross-Origin-Opener-Policy'), 'same-origin-allow-popups');
    assert.equal((toml.match(/^\s*for\s*=/gm) ?? []).length, 1, 'one header rule, so nothing is merged');
  });
});

describe('function routes (static config Netlify reads at deploy time)', () => {
  const dir = join(ROOT, 'netlify', 'functions');
  const configs = Object.fromEntries(readdirSync(dir).filter((f) => f.endsWith('.mjs')).map((f) => {
    const text = readFileSync(join(dir, f), 'utf8');
    return [f, /export const config = (\{[^}]*\});/.exec(text)?.[1] ?? null];
  }));

  it('every function has a literal config with the expected route or schedule', () => {
    assert.deepEqual(configs, {
      'api-breakdowns.mjs': "{ path: '/api/breakdowns' }",
      'api-config.mjs': "{ path: '/api/config' }",
      'api-meta.mjs': "{ path: '/api/meta' }",
      'api-monthly.mjs': "{ path: '/api/monthly' }",
      'api-refresh.mjs': "{ path: '/api/refresh' }",
      'api-rows.mjs': "{ path: '/api/rows' }",
      'api-session.mjs': "{ path: '/api/session' }",
      'img.mjs': "{ path: '/img/:platform/:id' }",
      'refresh-background.mjs': '{ background: true }',
      'refresh-data.mjs': "{ schedule: '15 0 * * *' }",
    });
  });

  it('the login page loads no inline script and only same-origin assets', () => {
    const html = readFileSync(join(ROOT, 'public', 'login.html'), 'utf8');
    assert.ok(!/<script(?![^>]*\bsrc=)[^>]*>/.test(html), 'no inline <script>');
    assert.ok(!/\son[a-z]+\s*=/.test(html), 'no inline event handlers');
    for (const ref of html.matchAll(/(?:src|href)="([^"]+)"/g)) assert.ok(ref[1].startsWith('/'), ref[1]);
    assert.ok(existsSync(join(ROOT, 'public', 'assets', 'login.js')));
    assert.ok(existsSync(join(ROOT, 'public', 'assets', 'login.css')));
  });
});

describe('scripts/seed-creatives.mjs', () => {
  const lib = join(temp, 'creatives');
  makeTree(lib, {});
  mkdirSync(join(lib, 'meta'), { recursive: true });
  mkdirSync(join(lib, 'tiktok'), { recursive: true });
  writeFileSync(join(lib, 'meta', '111.jpg'), jpegBytes(400));
  writeFileSync(join(lib, 'meta', '222.jpg'), jpegBytes(400));
  writeFileSync(join(lib, 'meta', '333.jpg'), 'tiny'); // stub: not saved
  writeFileSync(join(lib, 'meta', '444.jpg'), Buffer.alloc(300, 'x')); // not an image
  writeFileSync(join(lib, 'meta', 'notes.txt'), 'ignored');
  writeFileSync(join(lib, 'tiktok', '555.jpg'), pngBytes(300)); // PNG bytes behind a .jpg name

  it('uploads only missing, real images with metadata, and counts the rest', async () => {
    const store = createMemoryStore();
    await store.set('meta/222', toArrayBuffer(jpegBytes(64)), { metadata: { contentType: 'image/jpeg' } });
    const counts = await seedCreatives({ store, dir: lib, now: () => new Date('2026-10-12T00:00:00Z') });
    assert.deepEqual(counts, { found: 5, already: 1, uploaded: 2, invalid: 2, failed: 0 });
    assert.deepEqual([...store.entries.keys()].sort(), ['meta/111', 'meta/222', 'tiktok/555']);
    const png = await store.getMetadata('tiktok/555');
    assert.deepEqual(png.metadata, { contentType: 'image/png', savedAt: '2026-10-12T00:00:00.000Z', sourceDate: null, bytes: 300, source: 'seed' });
    const again = await seedCreatives({ store, dir: lib });
    assert.equal(again.uploaded, 0);
    assert.equal(again.already, 3);
  });

  it('dry run only counts local files', async () => {
    const counts = await seedCreatives({ store: null, dir: lib, dryRun: true });
    assert.equal(counts.would_upload, 4);
    assert.equal(scanLibrary(lib).invalid, 1);
  });
});
