// Integration: the store layer, API handlers, data job and seeding script against the REAL @netlify/blobs client
// talking to its own local Blobs server (the one `netlify dev` runs) on localhost. This checks every assumption the
// in-memory test store makes: ArrayBuffer values, metadata, strong reads, ETag / 304, prefix listing, deletes.
// Skipped when @netlify/blobs is not installed (run `npm install`). No internet access.
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, mkdirSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { brotliDecompressSync } from 'node:zlib';
import { gunzipSync } from 'node:zlib';
import { meta, monthly, normalize, sliceRows } from '../lib/normalize.mjs';
import { breakdownsHealth, normaliseBreakdowns, sliceBreakdowns } from '../lib/breakdowns.mjs';
import {
  CREATIVES_STORE,
  DATASET_STORE,
  MANIFEST_KEY,
  cleanupOldVersions,
  createMemoryStore,
  listSavedCreatives,
  loadBreakdowns,
  loadDataset,
  newVersionId,
  openStore,
  readManifest,
  resetReadCaches,
  setStoreFactory,
  toArrayBuffer,
  writeDatasetVersion,
} from '../lib/blobs-store.mjs';
import { runRefresh } from '../lib/refresh.mjs';
import { mintSession } from '../lib/session.mjs';
import { clearTokenCache, rowsToObjects } from '../lib/sheets.mjs';
import { seedCreatives } from '../scripts/seed-creatives.mjs';
import { SECRET, breakdownEnv, breakdownSpreadsheets, fakeGoogle, jpegBytes, loadSampleSheets, quietLog, sampleSpreadsheets, sheetsEnv, syntheticBreakdownGrids } from './backend-fakes.mjs';

let BlobsServer = null;
try {
  ({ BlobsServer } = await import('@netlify/blobs/server'));
} catch {
  // not installed: the suite is skipped
}

const skip = BlobsServer ? false : '@netlify/blobs is not installed (run npm install)';
const NOW = new Date('2026-10-12T00:05:00Z');

describe('real @netlify/blobs client + local Blobs server', { skip }, () => {
  let server;
  let dir;
  let savedEnv;
  const cookie = () => `groov_session=${mintSession('finn@groovstrategy.co', { secret: SECRET, now: Date.now() }).token}`;

  before(async () => {
    dir = mkdtempSync(join(tmpdir(), 'groov-blobs-'));
    server = new BlobsServer({ directory: dir, token: 'local-test-token', logger: () => {} });
    const { port } = await server.start();
    savedEnv = { ...process.env };
    const context = { edgeURL: `http://localhost:${port}`, uncachedEdgeURL: `http://localhost:${port}`, siteID: 'site-local-test', token: 'local-test-token' };
    Object.assign(process.env, sheetsEnv(), { NETLIFY_BLOBS_CONTEXT: Buffer.from(JSON.stringify(context)).toString('base64') });
    setStoreFactory(null); // use the real client
    resetReadCaches();
  });

  after(async () => {
    await server?.stop();
    for (const k of Object.keys(process.env)) if (!(k in savedEnv)) delete process.env[k];
    Object.assign(process.env, savedEnv);
    rmSync(dir, { recursive: true, force: true });
    resetReadCaches();
  });

  it('writes a version, reads the manifest strongly and the dataset back, and serves /api/rows + /api/meta', async () => {
    const dataset = normalize(loadSampleSheets(), { mode: 'live', now: NOW });
    const store = await openStore(DATASET_STORE);
    const manifest = await writeDatasetVersion(store, { dataset, metaPayload: meta(dataset), monthlyPayload: monthly(dataset), now: NOW });
    assert.equal((await readManifest(store, { maxAgeMs: 0 })).version, manifest.version);
    const back = await loadDataset(store, manifest);
    assert.deepEqual(back.rows, JSON.parse(JSON.stringify(dataset.rows)));

    const { default: rows } = await import('../netlify/functions/api-rows.mjs');
    const { default: metaFn } = await import('../netlify/functions/api-meta.mjs');
    const res = await rows(new Request('https://ads.example.test/api/rows?from=2026-09-14&to=2026-09-20', { headers: { cookie: cookie(), 'accept-encoding': 'br' } }));
    assert.equal(res.status, 200);
    const payload = JSON.parse(brotliDecompressSync(Buffer.from(await res.arrayBuffer())).toString('utf8'));
    assert.deepEqual(payload, JSON.parse(JSON.stringify(sliceRows(dataset, '2026-09-14', '2026-09-20'))));
    const m = await metaFn(new Request('https://ads.example.test/api/meta', { headers: { cookie: cookie() } }));
    assert.deepEqual(await m.json(), JSON.parse(JSON.stringify(meta(dataset))));
  });

  it('stores the breakdown dataset as a gzip blob next to the dataset, reads it back, and serves /api/breakdowns + the /api/meta health block', async () => {
    const dataset = normalize(loadSampleSheets(), { mode: 'live', now: NOW });
    const grids = syntheticBreakdownGrids();
    const bds = normaliseBreakdowns({ placements: rowsToObjects(grids.placements).rows, audience: rowsToObjects(grids.audience).rows }, { mode: 'live', now: NOW, main: dataset });
    const store = await openStore(DATASET_STORE);
    const at = new Date(NOW.getTime() + 600_000);
    const health = breakdownsHealth(bds, dataset, { configured: { placements: true, audience: true } });
    const manifest = await writeDatasetVersion(store, { dataset, metaPayload: { ...meta(dataset), breakdowns: health }, monthlyPayload: monthly(dataset), breakdowns: bds, now: at });
    assert.equal(manifest.keys.breakdowns, `v/${manifest.version}/breakdowns.json.gz`);
    resetReadCaches();
    const current = await readManifest(store, { maxAgeMs: 0 });
    assert.equal(current.version, manifest.version);
    const back = await loadBreakdowns(store, current);
    assert.deepEqual(back, JSON.parse(JSON.stringify(bds)));
    const raw = await store.getWithMetadata(manifest.keys.breakdowns, { type: 'arrayBuffer' });
    assert.equal(raw.metadata.version, manifest.version);
    assert.equal(JSON.parse(gunzipSync(Buffer.from(raw.data)).toString('utf8')).placement_rows.length, bds.placement_rows.length, 'a real gzip blob');

    const { default: breakdownsFn } = await import('../netlify/functions/api-breakdowns.mjs');
    const { default: metaFn } = await import('../netlify/functions/api-meta.mjs');
    const res = await breakdownsFn(new Request('https://ads.example.test/api/breakdowns?from=2026-09-14&to=2026-09-20', { headers: { cookie: cookie(), 'accept-encoding': 'br' } }));
    assert.equal(res.status, 200);
    assert.equal(res.headers.get('x-data-version'), manifest.version);
    const payload = JSON.parse(brotliDecompressSync(Buffer.from(await res.arrayBuffer())).toString('utf8'));
    assert.deepEqual(payload, JSON.parse(JSON.stringify(sliceBreakdowns(bds, '2026-09-14', '2026-09-20'))));
    assert.equal(payload.available.placement && payload.available.audience, true);
    const m = await metaFn(new Request('https://ads.example.test/api/meta', { headers: { cookie: cookie() } }));
    assert.deepEqual((await m.json()).breakdowns, JSON.parse(JSON.stringify(health)));
  });

  it('stores an image with metadata, serves it via /img with an ETag, then 304s', async () => {
    const creatives = await openStore(CREATIVES_STORE);
    const bytes = jpegBytes(5000);
    await creatives.set('meta/120249786888520484', toArrayBuffer(bytes), { metadata: { contentType: 'image/jpeg', savedAt: NOW.toISOString(), sourceDate: '2026-09-20' } });
    assert.ok((await listSavedCreatives(creatives)).has('meta:120249786888520484'));
    const { default: img } = await import('../netlify/functions/img.mjs');
    const call = (headers = {}) => img(new Request('https://ads.example.test/img/meta/120249786888520484', { headers: { cookie: cookie(), ...headers } }), { params: { platform: 'meta', id: '120249786888520484' } });
    const res = await call();
    assert.equal(res.status, 200);
    assert.equal(res.headers.get('content-type'), 'image/jpeg');
    assert.deepEqual(new Uint8Array(await res.arrayBuffer()), bytes);
    // Production Netlify Blobs returns ETags (documented); the local emulator's GET does not send one. Either way the
    // route must behave: 304 on a matching If-None-Match when there is an ETag, a full 200 without one.
    // (The 304 path itself is covered with the in-memory store in backend-api.test.mjs.)
    const etag = res.headers.get('etag');
    if (etag) assert.equal((await call({ 'if-none-match': etag })).status, 304);
    else assert.equal((await call({ 'if-none-match': '"stale"' })).status, 200);
    const missing = await img(new Request('https://ads.example.test/img/tiktok/1', { headers: { cookie: cookie() } }), { params: { platform: 'tiktok', id: '1' } });
    assert.equal(missing.status, 404);
  });

  it('runs the whole data job against real stores', async () => {
    clearTokenCache();
    const google = fakeGoogle({ spreadsheets: sampleSpreadsheets() });
    const [datasetStore, creativesStore] = await Promise.all([openStore(DATASET_STORE), openStore(CREATIVES_STORE)]);
    const status = await runRefresh({
      datasetStore, creativesStore, env: process.env, fetchImpl: google.fetch, clock: () => Date.parse('2026-09-21T00:15:00Z'), log: quietLog,
      sheetsOptions: { retry: { sleep: async () => {}, baseDelayMs: 0 } },
    });
    assert.equal(status.state, 'ok', status.error);
    const manifest = await datasetStore.get(MANIFEST_KEY, { type: 'json', consistency: 'strong' });
    assert.equal(manifest.version, status.data.version);
    assert.equal(manifest.meta.data_through, '2026-09-20');
    assert.equal(manifest.meta.creatives.meta.saved, 1, 'the image stored in the previous test counts as saved');
  });

  it('runs the whole data job with the two breakdown Sheets against real stores', async () => {
    clearTokenCache();
    const google = fakeGoogle({ spreadsheets: { ...sampleSpreadsheets(), ...breakdownSpreadsheets() } });
    const [datasetStore, creativesStore] = await Promise.all([openStore(DATASET_STORE), openStore(CREATIVES_STORE)]);
    const status = await runRefresh({
      datasetStore, creativesStore, env: { ...process.env, ...breakdownEnv() }, fetchImpl: google.fetch, clock: () => Date.parse('2026-09-21T00:15:00Z'), log: quietLog,
      sheetsOptions: { retry: { sleep: async () => {}, baseDelayMs: 0 } },
    });
    assert.equal(status.state, 'ok', status.error);
    assert.deepEqual(status.warnings, []);
    const manifest = await datasetStore.get(MANIFEST_KEY, { type: 'json', consistency: 'strong' });
    assert.equal(manifest.keys.breakdowns, `v/${manifest.version}/breakdowns.json.gz`);
    assert.equal(manifest.meta.breakdowns.placement.available, true);
    assert.equal(manifest.meta.breakdowns.audience.available, true);
    resetReadCaches();
    const bds = await loadBreakdowns(datasetStore, manifest);
    assert.equal(bds.placement_rows.length, manifest.breakdown_rows.placement);
    assert.equal(bds.audience_rows.length, manifest.breakdown_rows.audience);
  });

  it('deletes old versions by prefix listing', async () => {
    const store = await openStore(DATASET_STORE);
    const old = newVersionId(new Date(Date.now() - 6 * 3600_000));
    await store.set(`v/${old}/dataset.json.gz`, 'x');
    await store.set(`v/${old}/monthly.json`, '{}');
    const current = (await store.get(MANIFEST_KEY, { type: 'json', consistency: 'strong' })).version;
    const deleted = await cleanupOldVersions(store, { keepVersion: current });
    assert.ok(deleted >= 2);
    assert.equal(await store.get(`v/${old}/monthly.json`), null);
    assert.ok(await store.get(`v/${current}/monthly.json`));
  });

  it('seeds creatives once and skips them on the second run', async () => {
    const lib = join(dir, 'library');
    mkdirSync(join(lib, 'meta'), { recursive: true });
    mkdirSync(join(lib, 'tiktok'), { recursive: true });
    writeFileSync(join(lib, 'meta', '777.jpg'), jpegBytes(700));
    writeFileSync(join(lib, 'tiktok', '888.jpg'), jpegBytes(700));
    const store = await openStore(CREATIVES_STORE);
    const first = await seedCreatives({ store, dir: lib });
    assert.equal(first.uploaded, 2);
    const second = await seedCreatives({ store, dir: lib });
    assert.deepEqual([second.uploaded, second.already], [0, 2]);
    const entry = await store.getWithMetadata('tiktok/888', { type: 'arrayBuffer' });
    assert.equal(entry.metadata.source, 'seed');
    assert.equal(entry.data.byteLength, 700);
  });
});

describe('blobs-store: versions with a breakdown dataset (in-memory store)', () => {
  const dataset = normalize(loadSampleSheets(), { mode: 'live', now: NOW });
  const grids = syntheticBreakdownGrids();
  const bds = normaliseBreakdowns({ placements: rowsToObjects(grids.placements).rows, audience: rowsToObjects(grids.audience).rows }, { mode: 'live', now: NOW, main: dataset });
  const write = (store, breakdowns = bds, now = NOW) => writeDatasetVersion(store, { dataset, metaPayload: meta(dataset), monthlyPayload: monthly(dataset), breakdowns, now });

  it('writes every blob of the version first and the manifest last (the manifest is the commit point)', async () => {
    const store = createMemoryStore('dataset');
    const order = [];
    const set = store.set.bind(store);
    store.set = async (key, ...rest) => { order.push(key); return set(key, ...rest); };
    const manifest = await write(store);
    assert.equal(order.at(-1), MANIFEST_KEY);
    assert.deepEqual(order.slice(0, -1).sort(), Object.values(manifest.keys).sort());
    assert.deepEqual(Object.keys(manifest.keys).sort(), ['breakdowns', 'dataset', 'monthly']);
    assert.ok(Object.values(manifest.keys).every((k) => k.startsWith(`v/${manifest.version}/`)), 'one version, one prefix');
    assert.deepEqual(manifest.breakdown_rows, { placement: bds.placement_rows.length, audience: bds.audience_rows.length });
    assert.ok(manifest.sizes.breakdowns_gz > 0 && manifest.sizes.breakdowns_json > manifest.sizes.breakdowns_gz);
    assert.deepEqual(JSON.parse(gunzipSync(Buffer.from(await store.get(manifest.keys.breakdowns, { type: 'arrayBuffer' }))).toString('utf8')), JSON.parse(JSON.stringify(bds)));
  });

  it('a version without breakdowns looks exactly like before: no key, no sizes, no row counts', async () => {
    const store = createMemoryStore('dataset');
    const manifest = await write(store, null);
    assert.deepEqual(Object.keys(manifest.keys).sort(), ['dataset', 'monthly']);
    assert.deepEqual(Object.keys(manifest.sizes).sort(), ['dataset_gz', 'dataset_json', 'monthly_json']);
    assert.equal('breakdown_rows' in manifest, false);
    assert.equal([...store.entries.keys()].some((k) => k.includes('breakdowns')), false);
    const omitted = await writeDatasetVersion(store, { dataset, metaPayload: meta(dataset), monthlyPayload: monthly(dataset), now: new Date(NOW.getTime() + 1000) }); // the argument left out entirely
    assert.equal(omitted.keys.breakdowns, undefined);
  });

  it('loadBreakdowns: null without a key (no read at all), parsed once per version, retried after a failure', async () => {
    const store = createMemoryStore('dataset');
    const plain = await write(store, null);
    resetReadCaches();
    assert.equal(await loadBreakdowns(store, plain), null);
    assert.equal(await loadBreakdowns(store, { version: 'old-manifest' }), null);
    assert.equal(await loadBreakdowns(store, null), null);
    assert.equal(store.calls.get, 0);

    const manifest = await write(store, bds, new Date(NOW.getTime() + 60_000));
    resetReadCaches();
    const first = await loadBreakdowns(store, manifest);
    const again = await loadBreakdowns(store, manifest);
    assert.equal(first, again, 'the same parsed object');
    assert.equal(store.calls.get, 1);
    assert.deepEqual(first, JSON.parse(JSON.stringify(bds)));

    const next = await write(store, bds, new Date(NOW.getTime() + 120_000));
    assert.notEqual(await loadBreakdowns(store, next), first, 'a new version is loaded again');
    assert.equal(store.calls.get, 2);

    const gone = { ...next, version: 'gone-version', keys: { ...next.keys, breakdowns: 'v/gone/breakdowns.json.gz' } };
    await assert.rejects(loadBreakdowns(store, gone), /breakdowns blob v\/gone\/breakdowns\.json\.gz is missing/);
    assert.equal(store.calls.get, 3);
    await assert.rejects(loadBreakdowns(store, gone), /is missing/);
    assert.equal(store.calls.get, 4, 'a failed load is not cached');
  });

  it('cleanup removes an old version\'s breakdown blob with the rest of it, and never the current one', async () => {
    const store = createMemoryStore('dataset');
    const old = await write(store, bds, new Date(NOW.getTime() - 5 * 3600_000));
    const current = await write(store, bds, NOW);
    assert.equal(await cleanupOldVersions(store, { keepVersion: current.version, now: NOW.getTime() }), 3);
    assert.equal(await store.get(old.keys.breakdowns), null);
    assert.ok(await store.get(current.keys.breakdowns, { type: 'arrayBuffer' }));
    assert.ok(await store.get(current.keys.dataset, { type: 'arrayBuffer' }));
  });
});
