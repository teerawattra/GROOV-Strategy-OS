// Frontend touch-ups for the VPS server: run with  node --test test/frontend-modules.test.cjs
//
//   - the module switcher at the top of the sidebar (window.GROOV_MODULES from data/modules.js): hidden while only
//     "ads" is enabled, compact chips when more modules are, never a non-hash link
//   - the sidebar footer when /api/session says mode "tailscale" ("Signed in via Tailscale as …", no Sign out) or
//     "none" (local test), and unchanged for the Netlify build (Sign out)
//   - public/data/modules.js is exactly what server/static-data.mjs makes of config/modules.json
// Needs no sample data: the sidebar renders before any data has loaded.
'use strict';

const { describe, test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { pathToFileURL } = require('node:url');

const ROOT = path.join(__dirname, '..');
const PUB = path.join(ROOT, 'public');
const SCRIPTS = ['util.js', 'data.js', 'engine.js', 'model.js', 'charts.js', 'ui.js', 'sidebar.js'];

function load(globals = {}) {
  const sandbox = { console, location: { protocol: 'https:', hostname: 'groov-vps.tailnet.ts.net', hash: '' }, __GROOV_TODAY__: '2026-09-21' };
  sandbox.window = sandbox;
  vm.createContext(sandbox);
  for (const f of ['data/registry.js', 'data/learnings.js', 'data/modules.js']) vm.runInContext(fs.readFileSync(path.join(PUB, f), 'utf8'), sandbox, { filename: f });
  Object.assign(sandbox, globals); // e.g. a different GROOV_MODULES than the shipped data/modules.js
  for (const f of SCRIPTS) vm.runInContext(fs.readFileSync(path.join(PUB, 'assets/js', f), 'utf8'), sandbox, { filename: f });
  const G = sandbox.GROOV;
  const reg = G.data.indexRegistry(sandbox.GROOV_REGISTRY);
  const ctx = (patch = {}) => Object.assign({
    state: G.sidebar.defaults(), meta: null, mode: 'live', reg, ds: null, snap: null, session: null, badge: 0, build: 'test', loading: false, error: null,
  }, patch);
  return { sandbox, G, S: G.sidebar, ctx };
}

const KOL_ON = { modules: [
  { id: 'ads', label: 'Ads', enabled: true, route: '#/overview' },
  { id: 'kol', label: 'KOL & <Creators>', enabled: true, route: '#/kol' },
  { id: 'content', label: 'Content', enabled: false, route: '#/content' },
  { id: 'crm', label: 'CRM', enabled: true, route: 'javascript:alert(1)' },
] };

describe('module switcher', () => {
  test('the shipped data/modules.js enables only Ads, so no switcher is drawn', () => {
    const { sandbox, S, ctx } = load();
    assert.deepEqual(JSON.parse(JSON.stringify(S.modules(sandbox.GROOV_MODULES))), [{ id: 'ads', label: 'Ads', route: '#/overview' }]);
    assert.equal(S.moduleSwitcher(ctx()), '');
    assert.ok(!S.render(ctx()).includes('sb-mods'));
  });

  test('two or more enabled modules: compact chips at the top of the sidebar, Ads marked current', () => {
    const { S, ctx } = load();
    const html = S.render(ctx({ modules: KOL_ON }));
    assert.ok(html.startsWith('<nav class="sb-mods chips" aria-label="Modules">'), 'first thing in the sidebar body');
    const nav = html.slice(0, html.indexOf('</nav>'));
    assert.equal((nav.match(/<a /g) || []).length, 3, 'disabled modules are left out');
    assert.match(nav, /<a class="chip on" href="#\/overview" aria-current="true">Ads<\/a>/);
    assert.match(nav, /<a class="chip" href="#\/kol">KOL &amp; &lt;Creators&gt;<\/a>/, 'labels are escaped');
    assert.match(nav, /<a class="chip" href="#\/crm">CRM<\/a>/, 'a non-hash route falls back to #/<id>');
    assert.ok(!nav.includes('javascript:'));
  });

  test('reads window.GROOV_MODULES when the context does not carry modules, and accepts a bare list', () => {
    const { S, ctx } = load({ GROOV_MODULES: KOL_ON.modules });
    assert.match(S.render(ctx()), /sb-mods/);
    assert.equal(S.modules([{ id: 'ads', enabled: true }, { id: 'ads', enabled: true }, { id: 'Bad Id', enabled: true }, { id: 'x', enabled: 'yes' }, null]).length, 1);
  });
});

describe('sidebar footer by session mode', () => {
  test('Tailscale: "Signed in via Tailscale as <login>", no Sign out; owners keep the refresh button', () => {
    const { S, ctx } = load();
    const html = S.render(ctx({ session: { email: 'finn@groovstrategy.co', name: 'Finn', expires: null, owner: true, mode: 'tailscale' } }));
    assert.match(html, /Signed in via Tailscale as finn@groovstrategy\.co/);
    assert.ok(!html.includes('data-act="signout"'), 'no Sign out button');
    assert.match(html, /data-act="data-refresh" data-tip="Ask the server to re-pull the last days from Windsor now \(owner only\)"/);
    const viewer = S.render(ctx({ session: { email: 'team@groovstrategy.co', owner: false, mode: 'tailscale' } }));
    assert.ok(!viewer.includes('data-act="data-refresh"'));
    assert.ok(!viewer.includes('data-act="signout"'));
  });

  test('AUTH_MODE=none: a local test label, no Sign out', () => {
    const { S, ctx } = load();
    const html = S.render(ctx({ session: { email: null, name: null, expires: null, owner: true, mode: 'none' } }));
    assert.match(html, /Local test mode · no sign-in/);
    assert.ok(!html.includes('data-act="signout"'));
  });

  test('the Netlify build (no session mode) is unchanged: email + Sign out', () => {
    const { S, ctx } = load();
    const html = S.render(ctx({ session: { email: 'finn@groovstrategy.co', expires: '2026-10-20T00:00:00.000Z', owner: false } }));
    assert.match(html, /<span>finn@groovstrategy\.co<\/span><button type="button" class="btn ghost sm" data-act="signout">Sign out<\/button>/);
    assert.ok(!html.includes('via Tailscale'));
    assert.match(S.render(ctx({ session: null })), /<span class="muted">Signed in<\/span>/);
  });

  test('escapes the login', () => {
    const { S, ctx } = load();
    const html = S.render(ctx({ session: { email: '<img src=x onerror=alert(1)>@x', owner: false, mode: 'tailscale' } }));
    assert.ok(!html.includes('<img src=x'));
    assert.match(html, /Signed in via Tailscale as &lt;img src=x onerror=alert\(1\)&gt;@x/);
  });
});

describe('data/modules.js', () => {
  test('public/data/modules.js is generated from config/modules.json by server/static-data.mjs', async () => {
    const { modulesJs } = await import(pathToFileURL(path.join(ROOT, 'server', 'static-data.mjs')).href);
    const config = JSON.parse(fs.readFileSync(path.join(ROOT, 'config', 'modules.json'), 'utf8'));
    assert.equal(fs.readFileSync(path.join(PUB, 'data', 'modules.js'), 'utf8'), modulesJs(config));
    assert.deepEqual(config.modules.map((m) => [m.id, m.enabled]), [['ads', true], ['kol', false], ['content', false], ['crm', false]]);
  });

  test('index.html loads data/modules.js before the dashboard scripts', () => {
    const html = fs.readFileSync(path.join(PUB, 'index.html'), 'utf8');
    const at = (s) => html.indexOf(s);
    assert.ok(at('<script src="data/modules.js"></script>') > at('<script src="data/learnings.js"></script>'));
    assert.ok(at('<script src="data/modules.js"></script>') < at('<script src="assets/js/util.js"></script>'));
  });
});
