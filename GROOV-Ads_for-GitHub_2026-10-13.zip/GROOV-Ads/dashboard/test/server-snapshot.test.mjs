// Raw partitions -> snapshot -> API, end to end against the mock Windsor:
//   - every payload (/api/meta, /api/rows, /api/monthly, /api/breakdowns) is byte-identical to lib/normalize.mjs and
//     lib/breakdowns.mjs run directly on the sample CSVs
//   - parity: 14–20 Sep 2026 has 21 delivering accounts and ฿91,303.10 (SPEC §8)
//   - snapshots flip atomically, the server hot-reloads them, the last 3 are kept, rollback works, a failed pull or a
//     broken snapshot never replaces what is served, and the lock keeps jobs from running twice

import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { existsSync, readdirSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { emptyBreakdowns, sliceBreakdowns } from '../lib/breakdowns.mjs';
import { sliceRows } from '../lib/normalize.mjs';
import { acquireLock, backfill, refresh } from '../server/refresh.mjs';
import { createDashboardServer } from '../server/server.mjs';
import { KEEP_VERSIONS, buildSnapshot, listVersions, readCurrent, rollback, setCurrent, snapshotsRoot } from '../server/snapshot.mjs';
import { startMockWindsor } from './mock-windsor.mjs';
import { NOW, expectedFromCsv, makeConfig, noSleep, offlineFetch, quietLog, request, tempRoot, waitFor } from './server-helpers.mjs';

const RANGES = [['2026-09-07', '2026-09-20'], ['2026-09-14', '2026-09-20'], ['2026-09-07', '2026-09-13'], ['2026-09-01', '2026-09-30']];

describe('refresh -> snapshot -> API', () => {
  let mock;
  let root;
  let config;
  let app;
  let base;
  let log;
  let expected;
  const get = (path, headers = {}) => request(`${base}${path}`, { headers: { 'accept-encoding': 'br, gzip', ...headers } });

  before(async () => {
    mock = await startMockWindsor();
    root = await tempRoot();
    config = makeConfig(root.dir, { WINDSOR_BASE_URL: mock.url, WINDSOR_API_KEY: mock.key });
    log = quietLog([mock.key]);
    const status = await backfill(config, { from: '2026-09-07', to: '2026-09-20', now: NOW, log, sleep: noSleep, imageFetchImpl: offlineFetch });
    assert.equal(status.state, 'ok', status.error);
    expected = expectedFromCsv();
    app = createDashboardServer(config, { log, checkEveryMs: 20, watchIntervalMs: 50, imageFetchImpl: offlineFetch, sleep: noSleep });
    const { port } = await app.listen();
    base = `http://127.0.0.1:${port}`;
  });
  after(async () => {
    await app?.close();
    await mock?.close();
    await root?.cleanup();
  });

  it('/api/meta is byte-identical to { ...meta(normalize(csv)), breakdowns: breakdownsHealth(...) }', async () => {
    const res = await get('/api/meta');
    assert.equal(res.status, 200);
    assert.equal(res.headers['content-type'], 'application/json; charset=utf-8');
    assert.equal(res.text, JSON.stringify(expected.metaPayload));
    const m = res.json();
    assert.equal(m.data_through, '2026-09-20');
    assert.equal(m.history_from, '2026-09-07');
    assert.deepEqual(m.sheets.meta.missing_dates, []);
    assert.equal(m.breakdowns.placement.available, true);
    assert.equal(m.breakdowns.placement.configured, true);
  });

  it('/api/rows and /api/breakdowns are byte-identical to sliceRows / sliceBreakdowns for any range', async () => {
    for (const [from, to] of RANGES) {
      const rows = await get(`/api/rows?from=${from}&to=${to}`);
      assert.equal(rows.status, 200);
      assert.equal(rows.text, JSON.stringify(sliceRows(expected.dataset, from, to)), `rows ${from}..${to}`);
      const bd = await get(`/api/breakdowns?from=${from}&to=${to}`);
      assert.equal(bd.status, 200);
      assert.equal(bd.text, JSON.stringify(sliceBreakdowns(expected.bds, from, to)), `breakdowns ${from}..${to}`);
    }
  });

  it('/api/monthly is byte-identical to monthly(normalize(csv))', async () => {
    const res = await get('/api/monthly');
    assert.equal(res.text, JSON.stringify(expected.monthlyPayload));
  });

  it('parity: 14–20 Sep 2026 has 21 delivering accounts and ฿91,303.10', async () => {
    const p = (await get('/api/rows?from=2026-09-14&to=2026-09-20')).json();
    const byAccount = new Map();
    for (const r of p.rows) {
      const account = p.campaigns[r[1]].account;
      byAccount.set(account, (byAccount.get(account) ?? 0) + r[4]);
    }
    const delivering = [...byAccount.values()].filter((v) => v > 0);
    const total = delivering.reduce((a, b) => a + b, 0);
    assert.equal(delivering.length, 21);
    assert.ok(Math.abs(total - 91303.10) <= 0.01, `total ${total}`);
  });

  it('one X-Data-Version across meta, rows, monthly and breakdowns; compressed as asked', async () => {
    const versions = new Set();
    for (const path of ['/api/meta', '/api/rows?from=2026-09-14&to=2026-09-20', '/api/monthly', '/api/breakdowns?from=2026-09-14&to=2026-09-20']) {
      const res = await get(path);
      versions.add(res.headers['x-data-version']);
      assert.equal(res.headers['content-encoding'], 'br');
      assert.equal(res.headers['cache-control'], 'private, no-store');
    }
    assert.equal(versions.size, 1);
    assert.equal([...versions][0], (await readCurrent(config.dataDir)).version);
    const gz = await request(`${base}/api/meta`, { headers: { 'accept-encoding': 'gzip' } });
    assert.equal(gz.headers['content-encoding'], 'gzip');
    const plain = await request(`${base}/api/meta`, { headers: { 'accept-encoding': 'identity' } });
    assert.equal(plain.headers['content-encoding'], undefined);
    assert.equal(plain.text, gz.text);
  });

  it('validates ranges like the Netlify functions (both dates, real dates, at most 800 days)', async () => {
    assert.equal((await get('/api/rows')).status, 400);
    assert.match((await get('/api/rows?from=2026-09-07')).json().error, /Both from and to are required/);
    assert.match((await get('/api/rows?from=2026-02-30&to=2026-03-01')).json().error, /from must be a real date/);
    assert.match((await get('/api/breakdowns?from=2020-01-01&to=2026-09-20')).json().error, /Date range too long/);
    assert.equal((await request(`${base}/api/meta`, { method: 'POST' })).status, 405);
  });

  it('flips to a new snapshot atomically and hot-reloads it without a restart', async () => {
    const before = (await get('/api/meta')).headers['x-data-version'];
    const manifest = await buildSnapshot(config, { now: new Date(NOW.getTime() + 60_000), log, reason: 'test' });
    assert.notEqual(manifest.version, before);
    assert.equal((await readCurrent(config.dataDir)).version, manifest.version);
    assert.equal((await readCurrent(config.dataDir)).previous, before);
    await waitFor(async () => (await get('/api/meta')).headers['x-data-version'] === manifest.version);
    const names = readdirSync(snapshotsRoot(config.dataDir));
    assert.ok(!names.some((n) => n.startsWith('.tmp-')), 'no half-written version folders');
    for (const f of ['manifest.json', 'meta.json', 'dataset.json.gz', 'monthly.json.gz', 'breakdowns.json.gz']) {
      assert.ok(existsSync(join(snapshotsRoot(config.dataDir), manifest.version, f)), f);
    }
  });

  it('keeps the last 3 versions (and never the one being served)', async () => {
    for (let i = 2; i <= 5; i++) await buildSnapshot(config, { now: new Date(NOW.getTime() + i * 60_000), log, reason: 'test' });
    const versions = await listVersions(config.dataDir);
    assert.equal(versions.length, KEEP_VERSIONS);
    const cur = await readCurrent(config.dataDir);
    assert.equal(versions[0].version, cur.version, 'newest first');
    assert.equal(versions[1].version, cur.previous);
  });

  it('rollback serves the previous version; the server follows', async () => {
    const cur = await readCurrent(config.dataDir);
    const r = await rollback(config.dataDir);
    assert.equal(r.from, cur.version);
    assert.equal(r.to, cur.previous);
    await waitFor(async () => (await get('/api/meta')).headers['x-data-version'] === cur.previous);
    await assert.rejects(rollback(config.dataDir, { to: '20200101T000000Z-abcdef' }), /not on disk/);
    await setCurrent(config.dataDir, cur.version); // forward again
    await waitFor(async () => (await get('/api/meta')).headers['x-data-version'] === cur.version);
  });

  it('a snapshot that cannot be loaded never replaces the one being served', async () => {
    const served = (await get('/api/meta')).headers['x-data-version'];
    const manifest = await buildSnapshot(config, { now: new Date(NOW.getTime() + 10 * 60_000), log, reason: 'test', flip: false });
    writeFileSync(join(snapshotsRoot(config.dataDir), manifest.version, 'dataset.json.gz'), 'damaged');
    await setCurrent(config.dataDir, manifest.version);
    await waitFor(() => log.lines.some((l) => l.level === 'error' && l.line.includes(`still serving ${served}`)));
    assert.equal((await get('/api/meta')).headers['x-data-version'], served);
    await setCurrent(config.dataDir, served);
  });

  it('a failed pull leaves the previous snapshot serving', async () => {
    const served = (await readCurrent(config.dataDir)).version;
    mock.addFault({ kind: 'status', status: 502, times: 99, match: { table: 'google' } });
    const status = await refresh(config, { now: NOW, log, days: 7, sleep: noSleep, imageFetchImpl: offlineFetch });
    mock.clearFaults();
    assert.equal(status.state, 'error');
    assert.match(status.error, /Windsor pull failed for google/);
    assert.equal((await readCurrent(config.dataDir)).version, served);
    assert.equal((await get('/api/meta')).headers['x-data-version'], served);
    const api = (await get('/api/refresh')).json();
    assert.equal(api.status.state, 'error');
    assert.equal(api.can_refresh, true, 'AUTH_MODE=none is the local operator');
  });

  it('a failed breakdown pull still builds the snapshot, with the reason in /api/meta health', async () => {
    mock.addFault({ kind: 'status', status: 500, times: 99, match: { table: 'meta_audience' } });
    const status = await refresh(config, { now: NOW, log, days: 7, sleep: noSleep, imageFetchImpl: offlineFetch });
    mock.clearFaults();
    assert.equal(status.state, 'ok', status.error);
    await waitFor(async () => (await get('/api/meta')).headers['x-data-version'] === status.snapshot.version);
    const m = (await get('/api/meta')).json();
    assert.match(m.breakdowns.audience.error, /The latest pull failed/);
    assert.equal(m.breakdowns.audience.available, true, 'the stored days still show');
    assert.equal(m.breakdowns.placement.error, null);
    assert.ok(status.warnings.some((w) => w.startsWith('meta_audience: The latest pull failed')));
  });

  it('the lock keeps a second job from running at the same time', async () => {
    const lock = await acquireLock(config.dataDir, { command: 'test' });
    assert.ok(lock);
    const skipped = await refresh(config, { now: NOW, log, days: 1, sleep: noSleep, imageFetchImpl: offlineFetch });
    assert.equal(skipped.state, 'skipped');
    const res = await request(`${base}/api/refresh`, { method: 'POST' });
    assert.equal(res.status, 409);
    await lock.release();
    const [a, b] = await Promise.all([
      refresh(config, { now: NOW, log, days: 1, sleep: noSleep, imageFetchImpl: offlineFetch }),
      refresh(config, { now: NOW, log, days: 1, sleep: noSleep, imageFetchImpl: offlineFetch }),
    ]);
    assert.deepEqual([a.state, b.state].sort(), ['ok', 'skipped']);
  });

  it('POST /api/refresh starts the job in the background (202) and GET /api/refresh follows it', async () => {
    const res = await request(`${base}/api/refresh`, { method: 'POST' });
    assert.equal(res.status, 202);
    assert.equal(res.json().started, true);
    const status = await app.lastRefresh;
    assert.equal(status.state, 'ok', status.error);
    assert.equal(status.trigger, 'manual');
    const api = (await get('/api/refresh')).json();
    assert.equal(api.status.started_at, status.started_at);
    await waitFor(async () => (await get('/api/meta')).headers['x-data-version'] === status.snapshot.version);
  });
});

describe('breakdowns switched off (ENABLE_BREAKDOWNS=0)', () => {
  it('pulls the three main datasets only; /api/breakdowns answers "not available" like Netlify without the Sheets', async () => {
    const mock = await startMockWindsor();
    const root = await tempRoot();
    const config = makeConfig(root.dir, { WINDSOR_BASE_URL: mock.url, WINDSOR_API_KEY: mock.key, ENABLE_BREAKDOWNS: '0' });
    const log = quietLog();
    const status = await backfill(config, { from: '2026-09-07', to: '2026-09-20', now: NOW, log, sleep: noSleep, imageFetchImpl: offlineFetch });
    assert.equal(status.state, 'ok', status.error);
    assert.deepEqual([...new Set(mock.requests.map((r) => r.table))].sort(), ['google', 'meta', 'tiktok']);
    const app = createDashboardServer(config, { log });
    const { port } = await app.listen();
    try {
      const m = (await request(`http://127.0.0.1:${port}/api/meta`)).json();
      assert.equal(m.breakdowns.placement.configured, false);
      assert.equal(m.breakdowns.audience.available, false);
      const expected = expectedFromCsv({ breakdowns: false });
      assert.equal(JSON.stringify(m), JSON.stringify(expected.metaPayload));
      const bd = await request(`http://127.0.0.1:${port}/api/breakdowns?from=2026-09-14&to=2026-09-20`);
      assert.equal(bd.status, 200);
      assert.equal(bd.text, JSON.stringify(sliceBreakdowns(emptyBreakdowns({ mode: 'live' }), '2026-09-14', '2026-09-20')));
    } finally {
      await app.close();
      await mock.close();
      await root.cleanup();
    }
  });
});
