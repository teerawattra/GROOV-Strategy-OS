// The image job on the VPS (server/images.mjs, reusing lib/creatives-job.mjs) against a mock image server: what is
// saved and where, the index, what is refused, that links (they carry signed tokens) are never logged, the seed
// command, and that the snapshot then says image: true.

import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { findCreative, listSavedCreatives, runImages, seedCreatives } from '../server/images.mjs';
import { buildSnapshot, loadSnapshot, readCurrent } from '../server/snapshot.mjs';
import { writePartition } from '../server/store.mjs';
import { NOW, jpegBytes, makeConfig, pngBytes, quietLog, tempRoot } from './server-helpers.mjs';

const CDN = 'https://scontent.cdn.example.test';

/** A CDN double: /ok.jpg, /pic.png, /page.html (not an image), /big.jpg (6 MB), /gone.jpg (404), /hang.jpg (never answers). */
async function startImageServer() {
  const hits = [];
  const hanging = new Set();
  const server = http.createServer((req, res) => {
    const path = req.url.split('?')[0];
    hits.push(path);
    if (path.startsWith('/ok')) return res.writeHead(200, { 'content-type': 'image/jpeg' }).end(jpegBytes(2048));
    if (path.startsWith('/pic')) return res.writeHead(200, { 'content-type': 'image/png' }).end(pngBytes(1024));
    if (path.startsWith('/page')) return res.writeHead(200, { 'content-type': 'text/html' }).end('<html>login</html>'.padEnd(500));
    if (path.startsWith('/big')) return res.writeHead(200, { 'content-type': 'image/jpeg' }).end(Buffer.concat([jpegBytes(16), Buffer.alloc(6 * 1024 * 1024)]));
    if (path.startsWith('/gone')) return res.writeHead(404).end();
    if (path.startsWith('/hang')) {
      hanging.add(res);
      return undefined;
    }
    return res.writeHead(500).end();
  });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const port = server.address().port;
  // The real image links are https on public hosts; the double is plain http on 127.0.0.1, so the fetch used by the
  // job rewrites the host (lib/creatives-job.mjs checks the original https URL first, as in production).
  const fetchImpl = (url, init) => globalThis.fetch(String(url).replace(CDN, `http://127.0.0.1:${port}`), init);
  return {
    hits, fetchImpl,
    close: () => new Promise((r) => {
      for (const res of hanging) res.destroy();
      server.closeAllConnections?.();
      server.close(() => r());
    }),
  };
}

const metaRow = (date, adId, url, extra = {}) => ({
  date, account_id: '1329660951861233', account_name: 'GROOV_Strategy_IH', campaign_id: '120248983993170527', campaign: 'Groov_TOF', campaign_objective: 'OUTCOME_LEADS',
  adset_id: '1202490000001', adset_name: 'Bangkok', ad_id: adId, ad_name: `Ad ${adId}`, effective_status: 'ACTIVE', spend: 10, impressions: 100, reach: 90, clicks: 3, link_clicks: 2,
  actions_video_view: null, actions_onsite_conversion_messaging_conversation_started_7d: null, actions_lead: 1, purchase_roas_omni_purchase: null,
  image_url: url, ad_preview_shareable_link: null, ...extra,
});
const tiktokRow = (date, adId, url) => ({
  date, account_id: '7527201634402009089', account_name: 'Sunbirdfoods', campaign_id: '1865864972638241', campaign: 'TOF_Reach', objective_type: 'REACH',
  campaign_status: 'CAMPAIGN_STATUS_ENABLE', adgroup_id: '1865864972826913', adgroup_name: 'Location', ad_id: adId, ad_name: `TT ${adId}`, spend: 5, impressions: 50, reach: 40,
  clicks: 1, total_play: 10, messaging_total_conversation_tiktok_direct_message: 0, messaging_total_conversation_instant_messaging_app: 0, onsite_form: 0, conversions: 0,
  complete_payment_roas: 0, video_thumbnail_url: url,
});

describe('image job', () => {
  let cdn;
  let root;
  let config;
  let log;
  let first;

  before(async () => {
    cdn = await startImageServer();
    root = await tempRoot();
    config = makeConfig(root.dir);
    log = quietLog();
    // Raw rows dated within the last 7 days of NOW (21 Sep 2026), plus one older ad whose link must be ignored.
    await writePartition(config.dataDir, 'meta', '2026-09-19', [
      metaRow('2026-09-19', '101', `${CDN}/ok.jpg?stp=dst-jpg&_nc_sid=SECRET_TOKEN_A&oh=00_SIG`),
      metaRow('2026-09-19', '102', `${CDN}/pic.png?oh=SECRET_TOKEN_B`),
      metaRow('2026-09-19', '103', `${CDN}/page.html?oh=SECRET_TOKEN_C`),
      metaRow('2026-09-19', '104', `${CDN}/big.jpg?oh=SECRET_TOKEN_D`),
      metaRow('2026-09-19', '105', `${CDN}/gone.jpg?oh=SECRET_TOKEN_E`),
      metaRow('2026-09-19', '106', null),
      metaRow('2026-09-19', '107', 'https://127.0.0.1/evil.jpg'),
    ]);
    await writePartition(config.dataDir, 'meta', '2026-09-20', [metaRow('2026-09-20', '101', `${CDN}/ok.jpg?oh=SECRET_TOKEN_NEWER`)]);
    await writePartition(config.dataDir, 'meta', '2026-09-01', [metaRow('2026-09-01', '199', `${CDN}/ok.jpg?oh=SECRET_TOKEN_OLD`)]);
    await writePartition(config.dataDir, 'tiktok', '2026-09-20', [tiktokRow('2026-09-20', '201', `${CDN}/ok.jpg?x-signature=SECRET_TOKEN_T`)]);
    first = await runImages(config, { now: NOW, fetchImpl: cdn.fetchImpl, log });
  });
  after(async () => {
    await cdn.close();
    await root.cleanup();
  });

  it('saves the newest link of each recent ad once, by real image type', async () => {
    assert.equal(first.since, '2026-09-14');
    assert.equal(first.counts.candidates, 7, 'Meta 101-105 and 107, TikTok 201; ad 106 has no link and 199 is older than 7 days');
    assert.deepEqual(first.savedKeys.sort(), ['meta:101', 'meta:102', 'tiktok:201']);
    assert.ok(existsSync(join(config.dataDir, 'creatives', 'meta', '101.jpg')));
    assert.ok(existsSync(join(config.dataDir, 'creatives', 'meta', '102.png')), 'a PNG keeps its type and extension');
    assert.ok(existsSync(join(config.dataDir, 'creatives', 'tiktok', '201.jpg')));
    assert.equal(cdn.hits.filter((h) => h === '/ok.jpg').length, 2, 'meta 101 (newest row only) + tiktok 201');
    assert.deepEqual(first.counts.failures, { not_image: 1, too_large: 1, expired_or_gone: 1, unsafe_url: 1 });
  });

  it('records each saved file in data/creatives/index.json', () => {
    const index = JSON.parse(readFileSync(join(config.dataDir, 'creatives', 'index.json'), 'utf8'));
    assert.deepEqual(index.files['meta/102'], {
      file: 'meta/102.png', content_type: 'image/png', bytes: 1024, saved_at: index.files['meta/102'].saved_at, source_date: '2026-09-19', source: 'refresh',
    });
    assert.equal(index.files['meta/101'].source_date, '2026-09-20');
  });

  it('never logs a link or its tokens', () => {
    const text = log.lines.map((l) => l.line).join('\n');
    assert.match(text, /images: since 2026-09-14: 7 to fetch, 3 saved, 4 failed/);
    assert.ok(!/SECRET_TOKEN|scontent|https?:\/\//.test(text), text);
  });

  it('skips ads that already have a file on the next run', async () => {
    const again = await runImages(config, { now: NOW, fetchImpl: cdn.fetchImpl, log: quietLog() });
    assert.equal(again.counts.candidates, 4, 'only the four that failed are tried again');
    assert.equal(again.counts.saved, 0);
    const saved = await listSavedCreatives(config.dataDir);
    assert.deepEqual([...saved.saved].sort(), ['meta:101', 'meta:102', 'tiktok:201']);
    assert.deepEqual(saved.counts, { meta: 2, tiktok: 1 });
    assert.equal((await findCreative(config.dataDir, 'meta', '102')).ext, 'png');
    assert.equal(await findCreative(config.dataDir, 'meta', '../../etc'), null);
  });

  it('a slow image is cut off by the timeout and counted', async () => {
    const r2 = await tempRoot();
    const c2 = makeConfig(r2.dir);
    await writePartition(c2.dataDir, 'meta', '2026-09-20', [metaRow('2026-09-20', '301', `${CDN}/hang.jpg?oh=T`)]);
    const { counts } = await runImages(c2, {
      now: NOW, log: quietLog(), fetchImpl: (url, init) => cdn.fetchImpl(url, { ...init, signal: AbortSignal.timeout(300) }),
    });
    assert.deepEqual(counts.failures, { timeout: 1 });
    await r2.cleanup();
  });

  it('the next snapshot marks saved ads image: true and the others with the reason', async () => {
    await buildSnapshot(config, { now: NOW, log: quietLog() });
    const snap = await loadSnapshot(config.dataDir, (await readCurrent(config.dataDir)).version);
    const ad = (id) => snap.dataset.ads.find((a) => a.id === id);
    assert.equal(ad('101').image, true);
    assert.equal(ad('102').image, true);
    assert.equal(ad('103').image, false);
    assert.equal(ad('103').image_reason, 'not_saved');
    assert.equal(ad('106').image_reason, 'no_url');
    assert.deepEqual(snap.meta.creatives.meta, { ads: 8, saved: 2, no_url: 1, not_saved: 5 });
  });
});

describe('seed-creatives', () => {
  it('copies real images (any extension, typed by their bytes), skips stubs and non-images, and is safe to repeat', async () => {
    const root = await tempRoot();
    const lib = join(root.dir, 'library');
    mkdirSync(join(lib, 'meta'), { recursive: true });
    mkdirSync(join(lib, 'tiktok'), { recursive: true });
    writeFileSync(join(lib, 'meta', '111.jpg'), jpegBytes(500));
    writeFileSync(join(lib, 'meta', '112.jpg'), pngBytes(500)); // a PNG saved as .jpg
    writeFileSync(join(lib, 'meta', '113.jpg'), Buffer.alloc(50)); // stub
    writeFileSync(join(lib, 'meta', '114.jpg'), Buffer.from('<html>expired</html>'.padEnd(300)));
    writeFileSync(join(lib, 'meta', 'notes.txt'), 'x');
    writeFileSync(join(lib, 'tiktok', '211.jpg'), jpegBytes(500));
    const config = makeConfig(root.dir);
    const log = quietLog();
    const first = await seedCreatives(config, lib, { log, now: NOW });
    assert.equal(first.found, 5);
    assert.equal(first.copied, 3);
    assert.equal(first.invalid, 2);
    assert.deepEqual(first.byPlatform, { meta: 4, tiktok: 1 });
    assert.ok(existsSync(join(config.dataDir, 'creatives', 'meta', '112.png')));
    assert.match(log.lines[0].line, /seed-creatives: 5 files in the library \(meta 4, tiktok 1\) · 3 copied · 0 already saved · 2 skipped \(not an image\) · 0 failed/);
    const second = await seedCreatives(config, lib, { log: quietLog(), now: NOW });
    assert.equal(second.copied, 0);
    assert.equal(second.already, 3);
    const index = JSON.parse(readFileSync(join(config.dataDir, 'creatives', 'index.json'), 'utf8'));
    assert.equal(index.files['meta/112'].source, 'seed');
    await root.cleanup();
  });
});
