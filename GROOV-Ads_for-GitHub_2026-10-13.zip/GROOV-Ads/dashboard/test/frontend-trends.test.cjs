// KPI trend lines (SPEC §4.7) and "where results happen" (SPEC §4.8): node --test test/frontend-trends.test.cjs
//
// Loads the dashboard's classic scripts into a Node `vm` with a fake `window` (as frontend-engine.test.cjs
// does) and checks:
//   - daily / weekly bucket math: Mon–Sun weeks, partial first / last weeks, gaps, the 45-day rule
//   - every bucket's ratio comes from summed numerators / denominators (never an average of ratios),
//     and a whole period as one bucket equals the tile's number
//   - comparison alignment by day number (daily and weekly)
//   - breakdown shares sum to 100% (±0.1), tag thresholds exactly as SPEC, objectives never mixed
//   - panels render with breakdowns missing / unavailable / present / unreachable / loading / error,
//     and no NaN / Infinity / undefined / null reaches the HTML
//   - live /api/breakdowns loading (windows, queue, merge, 404 = not deployed, errors, 401)
// Breakdown fixtures below are synthetic test data (never shipped); real-sample checks run when
// public/data/sample.js carries GROOV_SAMPLE.breakdowns and skip otherwise.
'use strict';

const { describe, test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { sampleBundleText } = require('./sample-bundle.cjs'); // public/data/sample.js, or built from sample/sheets (VPS package)

const PUB = path.join(__dirname, '..', 'public');
const SCRIPTS = ['util.js', 'data.js', 'engine.js', 'model.js', 'charts.js', 'ui.js', 'sidebar.js',
  'views/overview.js', 'views/trends.js', 'views/adset.js', 'views/actions.js', 'views/client.js', 'views/creatives.js', 'views/playbook.js', 'views/health.js', 'app.js'];

function load(opts = {}) {
  const sandbox = { console, location: { protocol: 'file:', hostname: '', hash: '' }, __GROOV_TODAY__: '2026-09-21' };
  sandbox.window = sandbox;
  vm.createContext(sandbox);
  for (const f of ['data/registry.js', 'data/learnings.js', 'data/sample.js']) {
    vm.runInContext(f === 'data/sample.js' ? sampleBundleText() : fs.readFileSync(path.join(PUB, f), 'utf8'), sandbox, { filename: f });
  }
  if (opts.registryPatch) opts.registryPatch(sandbox.GROOV_REGISTRY);
  for (const f of SCRIPTS) vm.runInContext(fs.readFileSync(path.join(PUB, 'assets/js', f), 'utf8'), sandbox, { filename: f });
  const G = sandbox.GROOV;
  const reg = G.data.indexRegistry(sandbox.GROOV_REGISTRY);
  const ds = G.data.indexRows(sandbox.GROOV_SAMPLE.rows, reg);
  return { sandbox, G, reg, ds, meta: sandbox.GROOV_SAMPLE.meta, learn: sandbox.GROOV_LEARNINGS };
}

const ENV = load();
const { G } = ENV;
const U = G.util, D = G.data, E = G.engine, M = G.model, C = G.charts;
const REAL_BD = ENV.sandbox.GROOV_SAMPLE.breakdowns || null;
const HAS_BD = !!(REAL_BD && REAL_BD.available && (REAL_BD.available.placement || REAL_BD.available.audience));
const near = (a, b, tol, label) => assert.ok(Math.abs(a - b) <= tol, `${label}: ${a} vs ${b} (±${tol})`);
const BAD_TEXT = /\b(NaN|Infinity|undefined|null)\b/;
const textOf = (html) => html.replace(/<[^>]*>/g, ' ');
function clean(html, label) {
  assert.equal(typeof html, 'string', label);
  const t = textOf(html), bad = t.match(BAD_TEXT);
  assert.ok(!bad, `${label}: found "${bad && bad[0]}" near …${bad ? t.slice(Math.max(0, t.indexOf(bad[0]) - 80), t.indexOf(bad[0]) + 40) : ''}…`);
  assert.ok(!/="(NaN|undefined|null|Infinity)"/.test(html), `${label}: bad attribute value`);
}
const plain = (x) => JSON.parse(JSON.stringify(x));

function stateOf(env, patch = {}) {
  const s = env.G.sidebar.defaults();
  if (patch.period) Object.assign(s.period, patch.period);
  if (patch.compare) s.compare = patch.compare;
  if (patch.filters) Object.assign(s.filters, patch.filters);
  if (patch.ui) Object.assign(s.ui, patch.ui);
  s.route = patch.route || { page: 'overview', slug: null, params: {} };
  return s;
}
/** A view context like app.ctx(), with breakdowns and an expanded-state map the test controls. */
function ctxFor(env, patch = {}, opts = {}) {
  const st = stateOf(env, patch);
  env.G.model.clearMemo();
  const snap = env.G.model.snapshot({ ds: env.ds, meta: env.meta, reg: env.reg, learn: env.learn, state: st });
  const ex = opts.expanded || new Map();
  const app = { expanded: (id) => { if (!ex.has(id)) ex.set(id, new Set()); return ex.get(id); }, loadMonthly: () => {} };
  env.G.app.expanded = app.expanded;
  env.G.app.loadMonthly = app.loadMonthly;
  env.G.app.state = st;
  return {
    state: st, mode: 'sample', meta: env.meta, ds: env.ds, reg: env.reg, learn: env.learn, snap, buckets: env.G.model.actionBuckets(snap, st, '2026-09-21'),
    badge: 0, build: 'test', loading: false, error: null, session: null, monthly: env.G.data.indexMonthly(env.sandbox.GROOV_SAMPLE.monthly, env.reg),
    monthlyLoading: false, monthlyError: null, app, crumbs: [{ label: 'Overview' }],
    bd: opts.bd === undefined ? null : opts.bd, bdReady: opts.bdReady !== undefined ? opts.bdReady : opts.bd !== undefined, bdLoading: false, bdError: opts.bdError || null
  };
}
const dayObj = (o) => Object.assign(D.zero(), o);

/* =========================================================================================
 * Synthetic breakdown fixture (test data only): one Peak Clinic Messages ad set on 15 Sep (current
 * period) and 8 Sep (comparison), with numbers chosen to hit every tag.
 * ========================================================================================= */
const PEAK_AS = 'meta:120240940877700786';         // The Peak Clinic · TPC3_Adventage+_รายชื่อลูกค้า (Messages)
const PEAK_ACC = '628812601062307';
function fixture(over = {}) {
  const placements = [
    { key: 'facebook|feed', platform: 'facebook', position: 'feed', label: 'Facebook Feed' },
    { key: 'instagram|instagram_stories', platform: 'instagram', position: 'instagram_stories', label: 'Instagram Stories' },
    { key: 'facebook|facebook_reels', platform: 'facebook', position: 'facebook_reels', label: 'Facebook Reels' },
    { key: 'audience_network|an_classic', platform: 'audience_network', position: 'an_classic', label: 'Audience Network' },
    { key: 'threads|threads_feed', platform: 'threads', position: 'threads_feed' },            // no label: title-case fallback
    { key: 'instagram|feed', platform: 'instagram', position: 'feed', label: 'Instagram Feed' }
  ];
  const audiences = [
    { key: '25-34|female', age: '25-34', gender: 'female' }, { key: '35-44|female', age: '35-44', gender: 'female' },
    { key: '25-34|male', age: '25-34', gender: 'male' }, { key: '18-24|unknown', age: '18-24', gender: 'unknown' },
    { key: 'Unknown|female', age: 'Unknown', gender: 'female' }
  ];
  // cols: date, adset, segment, spend, impressions, clicks, link_clicks, video_views, messages, leads
  const placement_rows = [
    ['2026-09-15', 0, 0, 600, 20000, 300, 200, 0, 12, 0],
    ['2026-09-15', 0, 1, 200, 8000, 50, 40, 0, 0, 0],      // 20% of spend, no results  -> Spending, no results
    ['2026-09-15', 0, 2, 150, 6000, 60, 50, 0, 6, 0],      // 15% spend, 33% results    -> Works
    ['2026-09-15', 0, 3, 30, 2000, 5, 5, 0, 0, 0],         // 3% spend, 0 results       -> Weak
    ['2026-09-15', 0, 4, 15, 900, 1, null, null, null, null], // 1.5%, 0 results (nulls = 0)  -> Other
    ['2026-09-15', 0, 5, 5, 300, 0, 0, 0, 0, 0],           // 0.5%, 0 results           -> Other
    ['2026-09-08', 0, 0, 500, 18000, 250, 180, 0, 10, 0],  // comparison
    ['2026-09-08', 0, 1, 300, 9000, 60, 50, 0, 2, 0]
  ];
  const audience_rows = [
    ['2026-09-15', 0, 0, 500, 15000, 200, 150, 0, 10, 0],
    ['2026-09-15', 0, 1, 300, 11000, 100, 80, 0, 6, 0],
    ['2026-09-15', 0, 2, 150, 9000, 80, 60, 0, 2, 0],
    ['2026-09-15', 0, 3, 5, 200, 1, 1, 0, 0, 0],           // unknown gender 0.5% -> hidden
    ['2026-09-15', 0, 4, 45, 2000, 30, 20, 0, 0, 0],       // Unknown age 4.5% -> shown
    ['2026-09-08', 0, 0, 800, 25000, 300, 220, 0, 12, 0]
  ];
  return Object.assign({
    schema: 1, mode: 'sample', range: { from: '2026-09-07', to: '2026-09-20' }, available: { placement: true, audience: true },
    adsets: [{ key: PEAK_AS, id: PEAK_AS.slice(5), account_id: PEAK_ACC }], placements, audiences,
    cols: ['date', 'adset', 'segment', 'spend', 'impressions', 'clicks', 'link_clicks', 'video_views', 'messages', 'leads'],
    placement_rows, audience_rows,
    coverage: { placement: { first_date: '2026-09-08', last_date: '2026-09-15', rows: 8, spend_share: 0.4 }, audience: { first_date: '2026-09-08', last_date: '2026-09-15', rows: 6, spend_share: 0.4 } }
  }, over);
}
const FIX = D.indexBreakdowns(fixture());

/* =========================================================================================== */
describe('trend buckets (SPEC §4.7): daily ≤ 45 days, Mon–Sun weeks beyond, partial weeks labelled', () => {
  test('weekdays and the 45-day rule (with the Daily / Weekly override)', () => {
    assert.equal(D.weekdayMon('2026-09-07'), 0, '7 Sep 2026 is a Monday');
    assert.equal(D.weekdayMon('2026-09-13'), 6, 'Sunday');
    assert.equal(D.weekdayMon('1970-01-01'), 3, 'a Thursday');
    assert.equal(D.trendGran(45), 'daily');
    assert.equal(D.trendGran(46), 'weekly');
    assert.equal(D.trendGran(90, 'daily'), 'daily', 'the toggle overrides');
    assert.equal(D.trendGran(7, 'weekly'), 'weekly');
    assert.equal(D.trendGran(7, 'nonsense'), 'daily');
  });
  test('the Weekly choice needs at least two weeks in the period (one point is not a line)', () => {
    const T = G.views.trend;
    assert.equal(T.gran(ctxFor(ENV, { ui: { trendGran: 'weekly' } })), 'daily', '7 days = one Mon–Sun week: daily');
    assert.equal(T.gran(ctxFor(ENV, { period: { preset: '14d' }, ui: { trendGran: 'weekly' } })), 'weekly', 'two weeks: weekly');
    assert.equal(T.gran(ctxFor(ENV, { period: { preset: 'custom', from: '2026-09-09', to: '2026-09-15' }, ui: { trendGran: 'weekly' } })), 'weekly', 'Wed–Tue spans two partial weeks');
    assert.equal(T.gran(ctxFor(ENV, { period: { preset: '14d' } })), 'daily', 'auto');
  });
  test('daily buckets: one per day', () => {
    const days = U.dateRange('2026-09-14', '2026-09-20');
    const b = D.buckets(days, 'daily');
    assert.equal(b.length, 7);
    b.forEach((x, i) => { assert.equal(x.i0, i); assert.equal(x.i1, i); assert.equal(x.days, 1); assert.equal(x.partial, false); });
  });
  test('weekly buckets: Monday–Sunday, partial first and last weeks', () => {
    const days = U.dateRange('2026-09-09', '2026-09-29'); // Wed → Tue
    const b = plain(D.buckets(days, 'weekly'));
    assert.deepEqual(b.map((x) => [x.from, x.to, x.days, x.partial]), [
      ['2026-09-09', '2026-09-13', 5, true], ['2026-09-14', '2026-09-20', 7, false], ['2026-09-21', '2026-09-27', 7, false], ['2026-09-28', '2026-09-29', 2, true]]);
    assert.equal(b[0].weekFrom, '2026-09-07');
    assert.equal(b[3].weekTo, '2026-10-04');
    assert.equal(b.reduce((s, x) => s + x.days, 0), days.length, 'every day in exactly one bucket');
    for (let i = 1; i < b.length; i++) assert.equal(b[i].i0, b[i - 1].i1 + 1, 'contiguous');
    const full = plain(D.buckets(U.dateRange('2026-09-07', '2026-09-20'), 'weekly'));
    assert.deepEqual(full.map((x) => x.partial), [false, false], 'the sample fortnight is two full weeks');
    assert.equal(D.buckets([], 'weekly').length, 0);
  });
  test('bucket sums skip days past a shorter comparison and leave empty buckets null', () => {
    const b = D.buckets(U.dateRange('2026-09-14', '2026-09-20'), 'daily');
    const objs = [dayObj({ spend: 1 }), dayObj({ spend: 2 }), dayObj({ spend: 3 })];
    const s = D.bucketSums(objs, b);
    assert.deepEqual(plain(s.slice(0, 3).map((x) => x.o.spend)), [1, 2, 3]);
    assert.equal(s[3], null);
    const w = D.bucketSums(objs, D.buckets(U.dateRange('2026-09-14', '2026-09-20'), 'weekly'));
    assert.equal(w[0].o.spend, 6);
    assert.equal(w[0].days, 3, 'only the days that exist are summed (and counted)');
  });
});

/* =========================================================================================== */
describe('trend values come from summed numerators and denominators', () => {
  const days = U.dateRange('2026-09-07', '2026-09-20');
  const objs = days.map((d, i) => dayObj({ spend: 100 + i * 10, impressions: i === 3 ? 0 : 1000 + i * 100, clicks: i === 3 ? 0 : 20 + i,
    link_clicks: i === 5 ? 0 : 10 + i, reach: i === 3 ? 0 : 400 + i * 10, messages: i % 4 === 0 ? 0 : i, roas_value: i === 2 ? 0 : 50 }));
  const tdOf = (gran) => { const buckets = D.buckets(days, gran); return { gran, buckets, cur: D.bucketSums(objs, buckets), cmp: null }; };

  test('daily cost per conversation = day spend ÷ day conversations; no conversations = a gap', () => {
    const v = M.trendValues(tdOf('daily'), M.KPI.cpmsg);
    objs.forEach((o, i) => {
      if (o.messages === 0) assert.equal(v.cur[i], null, 'day ' + i + ' has no conversations: gap, never ฿0 or ∞');
      else near(v.cur[i], o.spend / o.messages, 1e-9, 'day ' + i);
    });
    assert.deepEqual(v.nCur.map((x) => x), objs.map((o) => o.messages), 'n per bucket');
  });
  test('weekly cost per conversation = Σ spend ÷ Σ conversations, not the average of daily ratios', () => {
    const td = tdOf('weekly');
    const v = M.trendValues(td, M.KPI.cpmsg);
    td.buckets.forEach((b, i) => {
      const part = objs.slice(b.i0, b.i1 + 1);
      const spend = part.reduce((s, o) => s + o.spend, 0), msg = part.reduce((s, o) => s + o.messages, 0);
      near(v.cur[i], spend / msg, 1e-9, 'week ' + i);
      const avg = part.filter((o) => o.messages).reduce((s, o) => s + o.spend / o.messages, 0) / part.filter((o) => o.messages).length;
      assert.ok(Math.abs(v.cur[i] - avg) > 1e-6, 'differs from the mean of daily ratios');
    });
  });
  test('CTR, CPM, link CTR, frequency, reach/day and ROAS per bucket', () => {
    const d = M.trendValues(tdOf('daily'), M.KPI.ctr), cpm = M.trendValues(tdOf('daily'), M.KPI.cpm), lc = M.trendValues(tdOf('daily'), M.KPI.link_ctr);
    assert.equal(d.cur[3], null, 'no impressions: CTR gap');
    assert.equal(cpm.cur[3], null, 'no impressions: CPM gap');
    near(d.cur[0], 20 / 1000 * 100, 1e-9, 'CTR day 0');
    assert.equal(lc.cur[5], null, 'clicks without link clicks = not reported: gap, not 0%');
    const w = M.trendValues(tdOf('weekly'), M.KPI.reach_day), td = tdOf('weekly');
    td.buckets.forEach((b, i) => near(w.cur[i], objs.slice(b.i0, b.i1 + 1).reduce((s, o) => s + o.reach, 0) / b.days, 1e-9, 'reach/day week ' + i));
    const f = M.trendValues(td, M.KPI.freq);
    td.buckets.forEach((b, i) => {
      const p = objs.slice(b.i0, b.i1 + 1);
      near(f.cur[i], p.reduce((s, o) => s + o.impressions, 0) / p.reduce((s, o) => s + o.reach, 0), 1e-9, 'freq week ' + i);
    });
    const roas = M.trendValues(tdOf('daily'), M.KPI.roas);
    near(roas.cur[2], 0, 1e-12, 'a day with spend and no purchase value is 0× (the period does track value)');
    near(roas.cur[0], 50 / 100, 1e-12, 'ROAS day 0');
    const none = { gran: 'daily', buckets: D.buckets(days, 'daily'), cur: D.bucketSums(objs.map((o) => dayObj({ spend: o.spend })), D.buckets(days, 'daily')), cmp: null };
    const nt = M.trendValues(none, M.KPI.roas);
    assert.ok(nt.cur.every((x) => x === null), 'no value in the whole period: "Not tracked", no line');
    assert.equal(nt.tracked, false);
  });
  test('the whole period as one bucket equals the tile value (every client KPI tile on the sample)', () => {
    const ctx = ctxFor(ENV, {});
    const P = ctx.snap.P;
    let checked = 0;
    ENV.ds.clients.forEach((c) => {
      const d = M.clientDetail(ctx.snap, ENV.ds, c.slug, 'all');
      if (!d || !d.camps.length) return;
      d.groups.forEach((g) => {
        (G.views.trend.TILES[g.type] || []).filter((it) => it.kpi).forEach((it) => {
          const kpi = M.KPI[it.kpi];
          const td = M.trendData(ctx.snap, ENV.ds, { key: 'test:' + c.slug + ':' + g.type, camps: g.rows }, 'daily');
          const sum = D.zero();
          td.cur.forEach((b) => D.addInto(sum, b.o));
          D.METRICS.forEach((m) => near(sum[m], g.cur[m], 1e-6, `${c.slug} ${g.type} Σ daily ${m}`));
          const whole = M.kpiValue(kpi, sum, P.curLen), tile = M.kpiValue(kpi, g.cur, P.curLen);
          if (tile === null) assert.equal(whole, null);
          else near(whole, tile, 1e-9, `${c.slug} ${it.kpi}`);
          checked++;
        });
      });
    });
    assert.ok(checked > 60, 'checked ' + checked + ' tiles');
  });
  test('tile numbers match the values the existing views showed (cost per conversation, reach/day, ROAS gate)', () => {
    const k = E.kpis({ spend: 1000, messages: 8, impressions: 50000, reach: 20000, clicks: 300, link_clicks: 200 });
    near(M.kpiValue(M.KPI.cpmsg, { spend: 1000, messages: 8 }, 7), k.cpmsg, 1e-12, 'cpmsg');
    near(M.kpiValue(M.KPI.reach_day, dayObj({ reach: 7000 }), 7), 1000, 1e-12, 'reach/day = Σ daily reach ÷ days');
    assert.equal(M.kpiValue(M.KPI.roas, dayObj({ spend: 500 }), 7), null, 'not tracked');
    assert.equal(M.kpiValue(M.KPI.link_ctr, dayObj({ impressions: 100, clicks: 5, link_clicks: 0 }), 1), null);
  });
  test('daily cost per conversation for a real client matches the raw sample rows', () => {
    const ctx = ctxFor(ENV, {});
    const d = M.clientDetail(ctx.snap, ENV.ds, 'the-peak-clinic', 'all');
    const g = d.groups.find((x) => x.type === 'Messages');
    const td = M.trendData(ctx.snap, ENV.ds, { key: 'raw-check', camps: g.rows }, 'daily');
    const v = M.trendValues(td, M.KPI.cpmsg);
    const keys = new Set(g.rows.map((r) => r.i));
    const raw = ENV.sandbox.GROOV_SAMPLE.rows.rows;
    td.days.forEach((day, i) => {
      let spend = 0, msg = 0;
      raw.forEach((r) => { if (r[0] === day && keys.has(r[1])) { spend += r[4]; msg += r[10]; } });
      if (msg === 0) assert.equal(v.cur[i], null, day);
      else near(v.cur[i], spend / msg, 1e-9, day);
    });
  });
});

/* =========================================================================================== */
describe('comparison aligned by day number', () => {
  test('daily: bucket i of the comparison is comparison day i', () => {
    const ctx = ctxFor(ENV, {});
    const P = ctx.snap.P;
    const scoped = ctx.snap.scoped;
    const td = M.trendData(ctx.snap, ENV.ds, { key: 'cmp-align', camps: scoped }, 'daily');
    assert.equal(td.cmpDays[0], P.cmp.from);
    const raw = ENV.sandbox.GROOV_SAMPLE.rows.rows, idx = new Set(scoped.map((r) => r.i));
    td.buckets.forEach((b, i) => {
      const day = U.addDays(P.cmp.from, i);
      const spend = raw.reduce((s, r) => s + (r[0] === day && idx.has(r[1]) ? r[4] : 0), 0);
      near(td.cmp[i].o.spend, spend, 1e-6, 'comparison ' + day);
    });
  });
  test('weekly: a comparison bucket covers the same day indexes as its current bucket', () => {
    const days = U.dateRange('2026-09-09', '2026-09-22'), cmpDays = U.dateRange('2026-08-26', '2026-09-08');
    const buckets = D.buckets(days, 'weekly');
    const cmpObjs = cmpDays.map((d, i) => dayObj({ spend: i + 1, messages: 1 }));
    const sums = D.bucketSums(cmpObjs, buckets);
    buckets.forEach((b, i) => {
      let s = 0;
      for (let k = b.i0; k <= b.i1; k++) s += k + 1;
      assert.equal(sums[i].o.spend, s, 'week ' + i + ' = comparison days ' + b.i0 + '…' + b.i1);
      assert.equal(sums[i].days, b.days);
    });
  });
  test('no baseline: no comparison line and a muted end marker', () => {
    const ctx = ctxFor(ENV, { period: { preset: '14d' } });
    assert.equal(ctx.snap.P.noBaseline, true);
    const td = M.trendData(ctx.snap, ENV.ds, { key: 'nb', camps: ctx.snap.scoped }, 'daily');
    assert.equal(td.cmp, null);
    assert.equal(M.trendDir(M.KPI.spend, 100, null, false), 'muted');
  });
  test('end-marker direction follows the tile Δ (lower is better for costs)', () => {
    assert.equal(M.trendDir(M.KPI.cpmsg, 90, 100, false), 'good');
    assert.equal(M.trendDir(M.KPI.cpmsg, 110, 100, false), 'bad');
    assert.equal(M.trendDir(M.KPI.messages, 110, 100, false), 'good');
    assert.equal(M.trendDir(M.KPI.messages, 110, 100, true), 'muted', 'low n');
    assert.equal(M.trendDir(M.KPI.spend, 150, 100, false), 'neutral', 'spend is never judged');
    assert.equal(M.trendDir(M.KPI.cpm, 100.2, 100, false), 'neutral', 'under 0.5% is no move');
  });
  test('series are computed once per state (memoized on the snapshot)', () => {
    const ctx = ctxFor(ENV, {});
    const sc = { key: 'memo', camps: ctx.snap.scoped };
    assert.equal(M.trendData(ctx.snap, ENV.ds, sc, 'daily'), M.trendData(ctx.snap, ENV.ds, sc, 'daily'));
    const a = ctx.snap.adsets[0];
    const x = D.adsetDays(ENV.ds, '2026-09-14', '2026-09-20', [a.i]);
    assert.equal(D.adsetDays(ENV.ds, '2026-09-14', '2026-09-20', [a.i]), x, 'ad set day scan memoized on the dataset');
    const s = D.zero();
    x[0].forEach((o) => D.addInto(s, o));
    near(s.spend, a.cur.spend, 1e-6, 'ad set daily spend sums to its period spend');
  });
});

/* =========================================================================================== */
describe('expanded chart splits', () => {
  const ctx = ctxFor(ENV, {});
  const snap = ctx.snap;
  test('By platform, Top 5 campaigns (by spend for costs, by the KPI for counts), Top 5 ad sets', () => {
    const scope = { key: 'ov', camps: snap.scoped, multiClient: true };
    const pl = M.trendSplit(snap, ENV.ds, scope, M.KPI.cpm, 'daily', 'platform');
    assert.deepEqual(plain(pl.series.map((s) => s.key)), ['meta', 'tiktok', 'google']);
    const tc = M.trendSplit(snap, ENV.ds, scope, M.KPI.cpm, 'daily', 'campaigns');
    assert.equal(tc.series.length, 5);
    assert.equal(tc.rankBy, 'spend');
    const bySpend = snap.scoped.slice().sort((a, b) => b.cur.spend - a.cur.spend).slice(0, 5).map((r) => r.key);
    assert.deepEqual(plain(tc.series.map((s) => s.key)), plain(bySpend));
    const tm = M.trendSplit(snap, ENV.ds, scope, M.KPI.messages, 'daily', 'campaigns');
    const byMsg = snap.scoped.filter((r) => r.cur.messages > 0).sort((a, b) => b.cur.messages - a.cur.messages || b.cur.spend - a.cur.spend).slice(0, 5).map((r) => r.key);
    assert.deepEqual(plain(tm.series.map((s) => s.key)), plain(byMsg), 'counts rank by the KPI itself');
    const ta = M.trendSplit(snap, ENV.ds, scope, M.KPI.spend, 'weekly', 'adsets');
    assert.equal(ta.series.length, 5);
    assert.equal(new Set(ta.series.map((s) => s.label)).size, 5, 'labels are distinct');
    ta.series.forEach((s) => assert.ok(s.values.cur.every((v) => v === null || Number.isFinite(v))));
    const one = M.trendSplit(snap, ENV.ds, { key: 'as:x', adsets: [snap.adsets[0]] }, M.KPI.spend, 'daily', 'platform');
    assert.equal(one.mode, 'total', 'an ad set scope only has Total');
  });
  test('repeated ad set names get their campaign, then the id, so lines never look alike', () => {
    const at = snap.adsets.filter((a) => a.clientSlug === 'at-ease-clinic' && a.name === 'Broad 5 km + Clinic');
    assert.ok(at.length >= 5, 'AT EASE has many "Broad 5 km + Clinic" ad sets');
    const camps = U.uniq(at.map((a) => a.campaign.i)).map((i) => snap.campByIdx[i]);
    const s = M.trendSplit(snap, ENV.ds, { key: 'at', camps }, M.KPI.spend, 'daily', 'adsets');
    assert.equal(new Set(s.series.map((x) => x.label)).size, s.series.length);
  });
});

/* =========================================================================================== */
describe('share tags (SPEC §4.8), exact thresholds', () => {
  const t = (s, r, n, tot) => { const x = E.bdTag(s, r, n, tot); return x ? x.tag + (x.tag === 'directional' ? ':' + x.lean : '') : null; };
  test('Works: share of results ≥ 1.2 × share of spend, with ≥ 3 results', () => {
    assert.equal(t(0.5, 0.6, 3, 20), 'works', 'exactly 1.2×');
    assert.equal(t(0.5, 0.6, 2, 20), null, 'only 2 results');
    assert.equal(t(0.5, 0.599, 30, 100), null, 'just under 1.2×');
    assert.equal(t(0.15, 6 / 18, 6, 18), 'works');
  });
  test('Weak: share of results ≤ 0.8 × share of spend', () => {
    assert.equal(t(0.5, 0.4, 8, 20), 'weak', 'exactly 0.8×');
    assert.equal(t(0.5, 0.401, 8, 20), null, 'just over 0.8×');
    assert.equal(t(0.03, 0, 0, 18), 'weak', 'under 10% of spend with no results is weak, not "spending, no results"');
  });
  test('Spending, no results: ≥ 10% of spend and 0 results', () => {
    assert.equal(t(0.10, 0, 0, 18), 'nores', 'exactly 10%');
    assert.equal(t(0.0999, 0, 0, 18), 'weak');
    assert.equal(t(0.4, null, 0, 0), 'directional:nores', 'a block with no results at all: directional');
  });
  test('Directional: under 10 results in the block, no tag is stronger', () => {
    assert.equal(t(0.5, 0.8, 4, 9), 'directional:works');
    assert.equal(t(0.5, 0.8, 4, 10), 'works', '10 results is enough');
    assert.equal(t(0.5, 0.1, 1, 9), 'directional:weak');
    assert.equal(t(0.3, 0, 0, 9), 'directional:nores');
    assert.equal(t(0.5, 0.5, 5, 9), null, 'in line with spend: no tag at all');
    assert.equal(t(null, 0.5, 5, 20), null);
  });
  test('result metric by objective (SPEC §4.8.5)', () => {
    assert.equal(E.bdResult('Messages').key, 'messages');
    assert.equal(E.bdResult('Lead generation').key, 'leads');
    assert.equal(E.bdResult('Engagement').key, 'video_views');
    assert.equal(E.bdResult('Traffic').key, 'link_clicks');
    assert.equal(E.bdResult('Awareness').key, 'impressions');
    assert.equal(E.bdResult('Awareness').per, 1000, 'cost = CPM');
    assert.equal(E.bdResult('Conversions').sharesOnly, true, 'Meta ROAS: spend and impression shares only');
  });
});

/* =========================================================================================== */
describe('breakdown blocks: shares, Other placements, audience rows, coverage', () => {
  const ctx = ctxFor(ENV, {});
  const a = ctx.snap.adsets.find((x) => x.key === PEAK_AS);
  const res = E.bdResult(a.objective);
  const pl = M.bdBlock(FIX, ctx.snap.P, [a], 'placement', res);
  const au = M.bdBlock(FIX, ctx.snap.P, [a], 'audience', res);
  const sum = (list, f) => list.reduce((s, r) => s + (r[f] || 0), 0);

  test('placement shares sum to 100% and the tags land where the numbers say', () => {
    near(sum(pl.rows, 'spendShare') * 100, 100, 0.1, '% of spend');
    near(sum(pl.rows, 'resShare') * 100, 100, 0.1, '% of results');
    assert.equal(pl.total.spend, 1000);
    assert.equal(pl.total.results, 18);
    const by = Object.fromEntries(pl.rows.map((r) => [r.label, r]));
    assert.equal(by['Facebook Feed'].tag, null, '67% of results on 60% of spend: no tag');
    assert.equal(by['Instagram Stories'].tag.tag, 'nores');
    assert.equal(by['Facebook Reels'].tag.tag, 'works');
    assert.equal(by['Audience Network'].tag.tag, 'weak');
    near(by['Facebook Feed'].cpr, 50, 1e-9, 'cost per conversation');
    assert.equal(pl.lowN, false);
  });
  test('placements under 2% of spend with 0 results fold into an expandable "Other placements" row', () => {
    const other = pl.rows[pl.rows.length - 1];
    assert.equal(other.isOther, true);
    assert.deepEqual(plain(other.children.map((r) => r.key).sort()), ['instagram|feed', 'threads|threads_feed']);
    near(other.spendShare, 0.02, 1e-12, 'Other = 1.5% + 0.5%');
    assert.equal(other.children.find((r) => r.key === 'threads|threads_feed').label, 'Threads Feed', 'title-case fallback label');
    const reels = pl.rows.find((r) => r.key === 'facebook|facebook_reels');
    assert.ok(!reels.isOther);
  });
  test('Δ vs comparison in percentage points when the comparison has breakdown data', () => {
    assert.equal(pl.hasPrev, true);
    const feed = pl.rows.find((r) => r.key === 'facebook|feed');
    near(feed.dSpend, (0.6 - 500 / 800) * 100, 1e-9, 'Δ % of spend');
    near(feed.dRes, (12 / 18 - 10 / 12) * 100, 1e-9, 'Δ % of results');
    const reels = pl.rows.find((r) => r.key === 'facebook|facebook_reels');
    near(reels.dSpend, 15, 1e-9, 'absent in the comparison = 0% then');
  });
  test('audience cells and marginals sum to 100%; 13-17 hidden when empty, Unknown only from 1% of spend', () => {
    near(sum(au.cells, 'spendShare') * 100, 100, 0.1, 'cells % of spend');
    near(sum(au.cells, 'resShare') * 100, 100, 0.1, 'cells % of results');
    const ages = au.ages.concat(au.hidden.filter((h) => h.age));
    near(sum(ages, 'spendShare') * 100, 100, 0.1, 'age marginals');
    const genders = au.genders.concat(au.hidden.filter((h) => h.gender));
    near(sum(genders, 'spendShare') * 100, 100, 0.1, 'gender marginals');
    assert.deepEqual(plain(au.grid.genders), ['female', 'male'], 'unknown gender (0.5% of spend) hidden');
    assert.ok(au.grid.ages.includes('Unknown'), 'Unknown age (4.5% of spend) shown');
    assert.ok(!au.grid.ages.includes('13-17'), 'no 13-17 row without spend');
    assert.ok(!au.grid.ages.includes('18-24'), 'an age with no cell left to show has no heatmap row');
    assert.deepEqual(plain(au.hidden.map((h) => h.label)), ['Unknown gender']);
    assert.equal(au.grid.cell('25-34', 'female').label, 'Women 25–34');
  });
  test('coverage is breakdown spend ÷ Sheet 1 spend of the same ad sets; shown capped at 100%', () => {
    near(pl.coverage.cur, 1000 / a.cur.spend, 1e-9, 'fixture covers part of the week');
    assert.equal(M.coverageText(1.0005), '100%');
    assert.equal(M.coverageText(1.02), '100%');
    assert.equal(M.coverageText(0.998), '99.8%');
    assert.equal(M.coverageText(0), '0%');
    assert.equal(M.coverageText(null), '—');
  });
  test('sentence from the numbers only', () => {
    const s = M.bdSentence(pl, au, res);
    assert.match(s, /^Facebook Feed took 60% of spend and brought 67% of conversations \(฿50 each\)\./);
    assert.match(s, /Instagram Stories took 20% of spend with no conversations\./);
    assert.match(s, /Women 25–34 brought 56% of conversations at ฿50; men brought 11% at ฿75\./);
    assert.ok(!BAD_TEXT.test(s));
    assert.equal(M.bdSentence(null, null, res), '');
  });
  test('Conversions (Meta ROAS): spend and impression shares only, never result counts', () => {
    const conv = E.bdResult('Conversions');
    const b = M.bdBlock(FIX, ctx.snap.P, [a], 'placement', conv);
    assert.equal(b.sharesOnly, true);
    b.rows.forEach((r) => { assert.equal(r.results, null); assert.equal(r.resShare, null); assert.equal(r.tag, null); });
    near(sum(b.rows, 'impShare') * 100, 100, 0.1, '% of impressions');
    assert.match(M.bdSentence(b, null, conv), /of impressions \(CPM ฿/);
  });
  test('few results: low n and every tag directional', () => {
    const small = D.indexBreakdowns(fixture({ placement_rows: [['2026-09-15', 0, 0, 600, 20000, 300, 200, 0, 5, 0], ['2026-09-15', 0, 1, 400, 8000, 50, 40, 0, 1, 0]] }));
    const b = M.bdBlock(small, ctx.snap.P, [a], 'placement', res);
    assert.equal(b.lowN, true);
    b.rows.forEach((r) => assert.ok(!r.tag || r.tag.tag === 'directional'));
    assert.match(M.bdSentence(b, null, res), /Only 6 conversations in total, so treat these splits as directional\./);
  });
});

/* =========================================================================================== */
describe('client "Where results happen": objectives are never mixed', () => {
  const ctx = ctxFor(ENV, {});
  const d = M.clientDetail(ctx.snap, ENV.ds, 'at-ease-clinic', 'all');
  test('only objectives present, the one with the most spend first and by default', () => {
    const W = M.whereResults(ctx.snap, ENV.ds, d, FIX, {});
    assert.deepEqual(plain(W.types.map((x) => x.type)), ['Messages', 'Traffic', 'Awareness']);
    assert.equal(W.type.type, 'Messages');
    assert.ok(W.adsets.length > 0);
    W.adsets.forEach((a) => assert.equal(a.prim.type, 'Messages', a.name));
    near(W.types.reduce((s, x) => s + x.share, 0), 1, 1e-9, 'objective shares');
  });
  test('switching objective switches every block to that result type only', () => {
    const W = M.whereResults(ctx.snap, ENV.ds, d, FIX, { type: 'Traffic' });
    assert.equal(W.res.key, 'link_clicks');
    W.adsets.forEach((a) => assert.equal(a.prim.type, 'Traffic'));
    const bogus = M.whereResults(ctx.snap, ENV.ds, d, FIX, { type: 'Lead generation' });
    assert.equal(bogus.type.type, 'Messages', 'an objective not present falls back to the default');
  });
  test('campaign filter narrows to one campaign of that objective', () => {
    const all = M.whereResults(ctx.snap, ENV.ds, d, FIX, {});
    const camp = all.camps[0];
    const one = M.whereResults(ctx.snap, ENV.ds, d, FIX, { camp: camp.key });
    assert.equal(one.camp, camp);
    one.adsets.forEach((a) => assert.equal(a.campaign, camp));
    const other = M.whereResults(ctx.snap, ENV.ds, d, FIX, { type: 'Traffic', camp: camp.key });
    assert.equal(other.camp, null, 'a campaign of another objective is ignored');
  });
  test('by ad set (Sheet 1): % of spend and % of results each sum to 100%', () => {
    const W = M.whereResults(ctx.snap, ENV.ds, d, FIX, {});
    near(W.byAdset.rows.reduce((s, r) => s + r.spendShare, 0) * 100, 100, 0.1, 'spend');
    near(W.byAdset.rows.reduce((s, r) => s + (r.resShare || 0), 0) * 100, 100, 0.1, 'results');
    const msgs = W.adsets.filter((a) => a.cur.spend > 0).reduce((s, a) => s + a.cur.messages, 0);
    assert.equal(W.byAdset.total.results, msgs, 'conversations only: no link clicks or impressions mixed in');
  });
  test('"% of results" in the campaigns table: an ad set’s share of the client’s results for its type', () => {
    const share = M.resultShare(d.camps);
    const types = U.uniq(ctx.snap.adsets.filter((a) => a.clientSlug === 'at-ease-clinic').map((a) => a.prim.type));
    types.forEach((t) => {
      const rows = ctx.snap.adsets.filter((a) => a.clientSlug === 'at-ease-clinic' && a.prim.type === t);
      const tot = rows.reduce((s, a) => s + (share(a) || 0), 0);
      assert.ok(tot <= 1 + 1e-9, t + ' never above 100%');
      if (t !== 'Awareness') near(tot, 1, 1e-6, t + ': Meta ad sets carry all of the campaigns’ results');
    });
    assert.equal(share(d.camps[0]) === null || Number.isFinite(share(d.camps[0])), true);
  });
});

/* =========================================================================================== */
describe('panels render honestly in every breakdown state, with no bad values', () => {
  const V = G.views;
  const peak = { route: { page: 'client', slug: 'the-peak-clinic', params: {} } };
  const sheetFor = (slug, key) => ({ route: { page: 'client', slug, params: { as: key } } });
  const unavailable = D.indexBreakdowns(fixture({ available: { placement: false, audience: false }, placement_rows: [], audience_rows: [] }));
  const missing = D.indexBreakdowns(null);

  test('missing Sheets or unavailable: the exact SPEC empty-state copy, and nothing else from breakdowns', () => {
    const EMPTY = 'Placement and audience splits appear once the two Meta breakdown exports run (see sheets-export.md)';
    assert.equal(V.adset.EMPTY, EMPTY);
    for (const bd of [missing, unavailable]) {
      const html = V.client.render(ctxFor(ENV, peak, { bd }));
      clean(html, 'client');
      assert.ok(html.includes('<p class="empty bd-empty">' + EMPTY + '</p>'));
      assert.ok(!html.includes('By placement</h3>'), 'no empty tables');
      const sh = V.adset.sheet(ctxFor(ENV, sheetFor('the-peak-clinic', PEAK_AS), { bd }));
      clean(sh, 'sheet');
      assert.ok(sh.includes(EMPTY));
    }
  });
  test('present: placement table, heatmap, sentence, coverage note and Δ in points', () => {
    const sh = V.adset.sheet(ctxFor(ENV, sheetFor('the-peak-clinic', PEAK_AS), { bd: FIX }));
    clean(sh, 'sheet');
    for (const s of ['By placement', 'By audience', 'Other placements', 'Spending, no results', 'Works', 'Weak', 'class="hm"', 'class="bd-sent"', 'pts', 'Covers ']) assert.ok(sh.includes(s), s);
    assert.match(sh, /This ad set brought <b>\d+%<\/b> of The Peak Clinic’s messages/);
    const one = D.indexBreakdowns(fixture({ available: { placement: true, audience: false } }));
    const sh2 = V.adset.sheet(ctxFor(ENV, sheetFor('the-peak-clinic', PEAK_AS), { bd: one }));
    assert.ok(sh2.includes('Audience splits appear once the Meta audience breakdown export runs'));
    assert.ok(sh2.includes('By placement'));
  });
  test('an account with no breakdown rows while its ad set spends: the Windsor reconnect note', () => {
    const ctx = ctxFor(ENV, { route: { page: 'client', slug: 'at-ease-clinic', params: {} } }, { bd: FIX });
    const html = V.client.render(ctx);
    clean(html, 'at-ease');
    assert.ok(html.includes('No placement/audience data for this account — it isn’t reachable in Windsor; reconnect it there.'));
    const at = ctx.snap.adsets.find((a) => a.clientSlug === 'at-ease-clinic' && a.platform === 'meta' && a.cur.spend > 0);
    const sh = V.adset.sheet(ctxFor(ENV, sheetFor('at-ease-clinic', at.key), { bd: FIX }));
    assert.ok(sh.includes('isn’t reachable in Windsor'));
  });
  test('breakdowns that cover other dates say so (not "unreachable")', () => {
    const old = D.indexBreakdowns(fixture({ placement_rows: [['2026-08-01', 0, 0, 10, 100, 1, 1, 0, 1, 0]], audience_rows: [] }));
    const sh = V.adset.sheet(ctxFor(ENV, sheetFor('the-peak-clinic', PEAK_AS), { bd: old }));
    assert.ok(sh.includes('No placement or audience rows in 14–20 Sep 2026: the breakdown exports cover 1 Aug 2026.'));
  });
  test('loading, error and stale states', () => {
    const loading = V.client.render(ctxFor(ENV, peak, { bdReady: false }));
    assert.ok(loading.includes('Loading placement and audience splits'));
    const err = V.client.render(ctxFor(ENV, peak, { bdReady: false, bdError: 'Request failed (500)' }));
    assert.ok(err.includes('could not load: Request failed (500)') && err.includes('data-act="bd-retry"'));
    const stale = V.client.render(ctxFor(ENV, peak, { bd: FIX, bdReady: false, bdError: 'timeout' }));
    assert.ok(stale.includes('Showing the breakdown data that loaded earlier'));
    clean(stale, 'stale');
  });
  test('Meta-only: the platform filter or switch away from Meta says so', () => {
    const g = ctxFor(ENV, {}).snap.camps.find((r) => r.platform === 'google' && r.cur.spend > 0);
    const route = { route: { page: 'client', slug: g.clientSlug, params: {} } };
    const off = V.client.render(ctxFor(ENV, Object.assign({ filters: { platforms: ['google'] } }, route), { bd: FIX }));
    assert.ok(off.includes('Placement and audience splits are Meta-only, and the sidebar Platforms filter excludes Meta.'));
    const sw = V.client.render(ctxFor(ENV, Object.assign({ ui: { clientPlatform: 'google' } }, route), { bd: FIX }));
    assert.ok(sw.includes('the platform switch is on Google'));
    const ctx = ctxFor(ENV, {}, { bd: FIX });
    const tt = ctx.snap.adsets.find((a) => a.platform === 'tiktok');
    const sh = V.adset.sheet(ctxFor(ENV, sheetFor(tt.clientSlug, tt.key), { bd: FIX }));
    assert.ok(sh.includes('Meta-only: this is a TikTok ad group'));
    clean(sh, 'tiktok sheet');
  });
  test('campaigns table: "% of results" on ad set rows, and ad set rows open the panel', () => {
    const html = V.client.render(ctxFor(ENV, peak, { bd: FIX, expanded: new Map([['campaigns', new Set(ENV.ds.campaigns.map((c) => 'campaign:' + c.key))]]) }));
    assert.ok(html.includes('% of results'));
    assert.ok(html.includes('data-row-act="adset-open" data-v="' + PEAK_AS + '"'));
    assert.ok(html.includes('data-act="adset-open" data-v="' + PEAK_AS + '"'));
    assert.match(html, /<td class="num "><span class="v">30%<\/span><\/td>/, 'TPC3 ad set: 33 of 109 conversations');
  });
  test('every client view and every ad set panel, daily and weekly, renders without bad values', () => {
    const bd = HAS_BD ? D.indexBreakdowns(REAL_BD) : FIX;
    for (const gran of ['daily', 'weekly']) {
      for (const c of ENV.ds.clients) {
        clean(V.client.render(ctxFor(ENV, { ui: { trendGran: gran }, route: { page: 'client', slug: c.slug, params: {} } }, { bd })), `client ${c.slug} ${gran}`);
      }
    }
    const ctx = ctxFor(ENV, {}, { bd });
    ctx.snap.adsets.forEach((a) => {
      clean(V.adset.sheet(ctxFor(ENV, sheetFor(a.clientSlug, a.key), { bd })), 'sheet ' + a.key);
    });
    clean(V.adset.sheet(ctxFor(ENV, sheetFor('the-peak-clinic', 'meta:does-not-exist'), { bd })), 'unknown ad set');
    clean(V.adset.sheet(ctxFor(ENV, Object.assign({ period: { preset: 'lastmonth' } }, sheetFor('the-peak-clinic', PEAK_AS)), { bd })), 'no data period');
  });
  test('every expanded chart: overview cards × splits, client tiles × granularity, ad set tiles', () => {
    for (const kpi of ['spend', 'impressions', 'link_clicks', 'messages', 'leads', 'conversions']) {
      for (const split of M.TREND_SPLITS) {
        const html = V.overview.render(ctxFor(ENV, { ui: { trendSplit: split } }, { expanded: new Map([['kpi', new Set(['ov|' + kpi])]]) }));
        assert.ok(html.includes('id="kx-ov"'), kpi);
        clean(html, `overview ${kpi} ${split}`);
      }
    }
    // one client per result type present in the sample (every objective group's tiles)
    const snap0 = ctxFor(ENV, {}).snap, groups = {};
    ENV.ds.clients.forEach((c) => {
      const d = M.clientDetail(snap0, ENV.ds, c.slug, 'all');
      (d ? d.groups : []).forEach((g) => { if (!Object.values(groups).some((x) => x.type === g.type)) groups[c.slug + '|' + g.type] = { slug: c.slug, type: g.type }; });
    });
    assert.ok(Object.keys(groups).length >= 6, 'Messages, Lead generation, Awareness, Traffic, Engagement, Conversions');
    for (const { slug, type } of Object.values(groups)) {
      const strip = 'cg-' + U.slugify(type);
      const d = M.clientDetail(snap0, ENV.ds, slug, 'all');
      const g = d.groups.find((x) => x.type === type);
      for (const it of G.views.trend.TILES[g.type].filter((x) => x.kpi)) {
        for (const gran of ['daily', 'weekly']) {
          for (const preset of ['7d', '14d']) {
            const html = V.client.render(ctxFor(ENV, { period: { preset }, ui: { trendGran: gran, trendSplit: 'adsets' }, route: { page: 'client', slug, params: {} } },
              { expanded: new Map([['kpi', new Set([strip + '|' + it.kpi])]]) }));
            assert.ok(html.includes('id="kx-' + strip + '"'), `${slug} ${it.kpi}`);
            clean(html, `${slug} ${it.kpi} ${gran} ${preset}`);
          }
        }
      }
    }
    const sh = V.adset.sheet(ctxFor(ENV, sheetFor('the-peak-clinic', PEAK_AS), { bd: FIX, expanded: new Map([['kpi', new Set(['as|cpmsg'])]]) }));
    assert.ok(sh.includes('id="kx-as"'));
    clean(sh, 'sheet chart');
  });
  test('benchmark band and registry target line on cost-per-result charts only', () => {
    const env = load({ registryPatch: (reg) => { reg.clients.find((c) => c.client === 'The Peak Clinic').targets = { Messages: 120 }; } });
    const ctx = ctxFor(env, { route: { page: 'client', slug: 'the-peak-clinic', params: {} } }, { expanded: new Map([['kpi', new Set(['cg-messages|cpmsg'])]]) });
    const specs = [];
    const orig = env.G.charts.slot;
    env.G.charts.slot = (spec, cls) => { specs.push(spec); return orig(spec, cls); };
    env.G.views.client.render(ctx);
    env.G.charts.slot = orig;
    const big = specs.find((s) => s.type === 'trendx');
    assert.ok(big.band && big.band.low === 87 && big.band.high === 1205, 'Clinic cost per message range (L-003)');
    assert.equal(big.target.value, 120);
    const svg = env.G.charts.render(big, 900);
    assert.ok(svg.includes('class="bband"') && svg.includes('class="tgt-line"') && svg.includes('Target ฿120'));
    const ctx2 = ctxFor(env, { route: { page: 'client', slug: 'the-peak-clinic', params: {} } }, { expanded: new Map([['kpi', new Set(['cg-messages|cpm'])]]) });
    const specs2 = [];
    env.G.charts.slot = (spec, cls) => { specs2.push(spec); return orig(spec, cls); };
    env.G.views.client.render(ctx2);
    env.G.charts.slot = orig;
    const cpm = specs2.find((s) => s.type === 'trendx');
    assert.equal(cpm.band, null, 'CPM is not this group’s cost per result');
    assert.equal(cpm.target, null);
  });
  test('Meta Conversions (ROAS) ad sets: tiles without counts, splits of spend and impressions only', () => {
    const env = load();
    const camp = env.ds.campaigns[env.ds.adsets[env.ds.adsetByKey.get(PEAK_AS)].campaign];
    camp.rawObjective = 'OUTCOME_SALES'; // classify as Conversions (Meta ROAS) for this render only
    const ctx = ctxFor(env, sheetFor('the-peak-clinic', PEAK_AS), { bd: FIX });
    const a = ctx.snap.adsets.find((x) => x.key === PEAK_AS);
    assert.equal(a.prim.type, 'Conversions·value');
    const sh = env.G.views.adset.sheet(ctx);
    clean(sh, 'conversions sheet');
    assert.ok(sh.includes('Meta conversion counts are not in the data'));
    assert.ok(sh.includes('ROAS*') && sh.includes('Not tracked'), 'no purchase value in the sample: ROAS not tracked');
    assert.ok(sh.includes('spend and impression shares only'));
    assert.ok(!sh.includes('class="btag'), 'no tags without result counts');
    const html = env.G.views.client.render(ctxFor(env, { route: { page: 'client', slug: 'the-peak-clinic', params: {} } }, { bd: FIX }));
    clean(html, 'conversions client');
    assert.ok(html.includes('Conversions (Meta ROAS)'));
  });
  test('names stay escaped in the new panels (hostile ad set name)', () => {
    const env = load();
    const s = env.ds.adsets.find((x) => x.key === PEAK_AS);
    s.name = 'Evil <img src=x onerror=alert(1)> "q"';
    const html = env.G.views.adset.sheet(ctxFor(env, sheetFor('the-peak-clinic', PEAK_AS), { bd: FIX }));
    assert.ok(html.includes('Evil &lt;img src=x onerror=alert(1)&gt; &quot;q&quot;'));
    assert.ok(!html.includes('<img src=x'));
  });
});

/* =========================================================================================== */
describe('charts: trend tiles and the expanded chart never draw bad coordinates', () => {
  test('gaps, single points, all-empty, band and target', () => {
    const tips = [[['Mon']], [['Tue']], [['Wed']]];
    const svgs = [
      C.render({ type: 'trend', cur: [1, null, 3], cmp: [2, 2, null], dir: 'good', provIdx: 1, tips }, 160),
      C.render({ type: 'trend', cur: [null, 5, null], cmp: null, dir: 'muted', provIdx: -1, tips }, 160),
      C.render({ type: 'trend', cur: [null, null, null], cmp: null, dir: 'muted', provIdx: -1, tips }, 160),
      C.render({ type: 'trend', cur: [4, 4, 4], cmp: [4, 4, 4], dir: 'neutral', provIdx: 2, tips }, 40),
      C.render({ type: 'trendx', labels: ['14 Sep', '15', '16'], partial: [true, false, true], series: [{ label: 'A', color: 'var(--copper)', values: [10, null, 30] }],
        cmp: [12, 13, null], fmt: 'money', dir: 'bad', provIdx: 2, band: { low: 87, high: 1205, label: 'Observed ฿87–1,205 · L-003' }, target: { value: 120, label: 'Target ฿120' }, tips }, 380),
      C.render({ type: 'trendx', labels: ['a'], partial: [false], series: [{ label: 'A', color: '#fff', values: [0] }], cmp: null, fmt: 'pct', provIdx: -1, tips: [[['a']]] }, 300),
      C.render({ type: 'trendx', labels: ['a', 'b'], partial: [false, false], series: [{ label: 'A', color: '#fff', values: [null, null] }], cmp: null, fmt: 'count', tips }, 300)
    ];
    svgs.forEach((s, i) => assert.ok(!/NaN|Infinity|undefined|could not be drawn/.test(s), 'chart ' + i + ': ' + s.slice(0, 120)));
    assert.ok(svgs[0].includes('tr-cur') && svgs[0].includes('tr-cmp') && svgs[0].includes('tr-end good') && svgs[0].includes('class="prov"'));
    assert.ok(svgs[1].includes('tr-cur-dot'), 'an isolated value is drawn as a dot');
    assert.ok(svgs[4].includes('>partial<'), 'partial weeks are labelled');
    assert.ok(svgs[6].includes('class="empty small"'), 'no value at all: an empty note, not an empty plot');
  });
});

/* =========================================================================================== */
describe('breakdown data: index, merge, live loading', () => {
  test('index: null metrics count as 0, bad references are skipped, labels fall back to title case', () => {
    const b = D.indexBreakdowns(fixture({ placement_rows: fixture().placement_rows.concat([['2026-09-15', 9, 0, 1, 1, 1, 1, 1, 1, 1], ['bad', 0, 0, 1, 1, 1, 1, 1, 1, 1]]) }));
    assert.equal(b.placement.n, 8, 'unknown ad set index and bad date skipped');
    assert.equal(b.placements[4].label, 'Threads Feed');
    assert.equal(D.placementLabel('facebook', 'facebook_reels'), 'Facebook Reels');
    assert.equal(D.placementLabel('audience_network', 'rewarded_video'), 'Audience Network');
    assert.equal(D.placementLabel('messenger', 'messenger_inbox'), 'Messenger Inbox');
    const agg = D.bdSum(b, 'placement', '2026-09-15', '2026-09-15', [PEAK_AS]);
    assert.equal(D.bdObj(agg.seg, 4).link_clicks, 0, 'null link clicks summed as 0');
    assert.equal(agg.withRows, 1);
    const none = D.indexBreakdowns(null);
    assert.deepEqual(plain(none.available), { placement: false, audience: false });
    assert.equal(none.present, false);
    const implicit = D.indexBreakdowns(Object.assign(fixture(), { available: undefined }));
    assert.deepEqual(plain(implicit.available), { placement: true, audience: true }, 'rows present = available when the flag is missing');
  });
  test('merge: entities by key, rows de-duplicated, availability ORed', () => {
    const a = fixture(), b = fixture({ available: { placement: false, audience: false }, placement_rows: [['2026-09-16', 0, 0, 10, 100, 1, 1, 0, 1, 0]], audience_rows: [] });
    b.placements = [a.placements[0]];
    const m = D.mergeBreakdowns([a, a, b]);
    assert.equal(m.placement_rows.length, a.placement_rows.length + 1, 'the repeated payload adds nothing');
    assert.deepEqual(plain(m.available), { placement: true, audience: true });
    const ix = D.indexBreakdowns(m);
    near(D.bdSum(ix, 'placement', '2026-09-07', '2026-09-20', [PEAK_AS]).seg[0], 600 + 500 + 10, 1e-9, 'Facebook Feed spend across payloads');
    assert.equal(D.mergeBreakdowns([{ not_deployed: true, available: { placement: false, audience: false } }]).not_deployed, true);
  });
  test('the windows a panel needs: current + comparison with a baseline', () => {
    const meta = { data_through: '2026-09-20', history_from: '2026-09-07' };
    assert.deepEqual(plain(D.bdRanges(D.periods(meta, { preset: '7d' }, 'prev'))), [{ from: '2026-09-07', to: '2026-09-20' }]);
    assert.deepEqual(plain(D.bdRanges(D.periods(meta, { preset: '14d' }, 'prev'))), [{ from: '2026-09-07', to: '2026-09-20' }], 'no baseline: current only');
    const later = { data_through: '2026-12-20', history_from: '2026-01-01' };
    assert.deepEqual(plain(D.bdRanges(D.periods(later, { preset: '7d' }, 'year'))), [{ from: '2025-12-14', to: '2025-12-20' }, { from: '2026-12-14', to: '2026-12-20' }].filter((r) => r.from >= '2026-01-01'));
  });
  test('sample mode: GROOV_SAMPLE.breakdowns, or "not available" when it is missing', async () => {
    const src = D.createSource('sample', { GROOV_SAMPLE: { meta: ENV.meta, rows: ENV.sandbox.GROOV_SAMPLE.rows } }, ENV.reg);
    assert.equal(src.coversBreakdowns([{ from: '2026-09-14', to: '2026-09-20' }]), false);
    await src.ensureBreakdowns([{ from: '2026-09-14', to: '2026-09-20' }]);
    assert.equal(src.bd.present, false);
    assert.equal(src.coversBreakdowns([{ from: '2026-09-14', to: '2026-09-20' }]), true);
    const src2 = D.createSource('sample', { GROOV_SAMPLE: { meta: ENV.meta, rows: ENV.sandbox.GROOV_SAMPLE.rows, breakdowns: fixture() } }, ENV.reg);
    await src2.ensureBreakdowns([]);
    assert.equal(src2.bd.placement.n, 8);
  });
  test('live: /api/breakdowns for the missing windows only, queued; 404 = not deployed; errors reject; 401 signs out', async () => {
    const calls = [];
    let mode = 'ok';
    const json = (status, body) => ({ status, ok: status >= 200 && status < 300, text: async () => (body === null ? '' : JSON.stringify(body)) });
    ENV.sandbox.fetch = async (url) => {
      calls.push(url);
      const u = new URL(url, 'https://x.test');
      if (u.pathname !== '/api/breakdowns') return json(404, { error: 'nope' });
      if (mode === '500') return json(500, { error: 'Sheets API quota' });
      if (mode === '404') return json(404, { error: 'not found' });
      if (mode === '401') return json(401, { error: 'signed out' });
      return json(200, fixture({ range: { from: u.searchParams.get('from'), to: u.searchParams.get('to') } }));
    };
    let unauthorized = 0;
    const onU = D.onUnauthorized;
    D.onUnauthorized = () => { unauthorized++; };
    try {
      const src = D.createSource('live', ENV.sandbox, ENV.reg);
      const need = [{ from: '2026-09-07', to: '2026-09-13' }, { from: '2026-09-14', to: '2026-09-20' }];
      await Promise.all([src.ensureBreakdowns(need), src.ensureBreakdowns(need)]);
      assert.equal(calls.length, 1, 'adjacent windows merge into one request, and the queued second call finds them loaded');
      assert.match(calls[0], /\/api\/breakdowns\?from=2026-09-07&to=2026-09-20/);
      assert.ok(src.coversBreakdowns(need));
      assert.equal(await src.ensureBreakdowns(need), false, 'nothing new to load');
      await src.ensureBreakdowns([{ from: '2026-08-31', to: '2026-09-06' }]);
      assert.equal(calls.length, 2);
      assert.match(calls[1], /from=2026-08-31&to=2026-09-06/);
      assert.equal(src.bd.placement.n, 8, 'payloads merged: the same rows are not counted twice');
      mode = '500';
      await assert.rejects(src.ensureBreakdowns([{ from: '2026-08-01', to: '2026-08-05' }]), (e) => e.status === 500 && /quota/.test(e.message));
      assert.ok(src.bd, 'what loaded stays');
      mode = '404';
      const s404 = D.createSource('live', ENV.sandbox, ENV.reg);
      await s404.ensureBreakdowns(need);
      assert.deepEqual(plain(s404.bd.available), { placement: false, audience: false }, 'not deployed = not available (empty state)');
      assert.equal(s404.bd.notDeployed, true);
      mode = '401';
      const s401 = D.createSource('live', ENV.sandbox, ENV.reg);
      await assert.rejects(s401.ensureBreakdowns(need), (e) => e.status === 401);
      assert.equal(unauthorized, 1, 'a 401 sends the browser to /login.html');
    } finally {
      D.onUnauthorized = onU;
    }
  });
});

/* =========================================================================================== */
describe('URL and stored state', () => {
  test('the ad set panel is in the hash (shareable; Back closes it)', () => {
    G.app.state = G.sidebar.sanitize({ period: { preset: '7d' }, compare: 'prev', route: { page: 'client', slug: 'the-peak-clinic', params: { as: PEAK_AS } } });
    assert.equal(G.app.buildHash(), '#/client/the-peak-clinic?p=7d&c=prev&as=meta%3A120240940877700786');
    assert.equal(G.app.parseHash('#/client/the-peak-clinic?p=7d&as=meta%3A120240940877700786').params.as, PEAK_AS);
    G.app.state = G.sidebar.sanitize({ route: { page: 'creatives', slug: null, params: { as: PEAK_AS } } });
    assert.match(G.app.buildHash(), /&as=meta%3A120240940877700786$/, 'on any page');
  });
  test('Daily / Weekly and split choices are sanitised', () => {
    const s = G.sidebar.sanitize({ ui: { trendGran: 'monthly', trendSplit: 'everything' } });
    assert.equal(s.ui.trendGran, 'auto');
    assert.equal(s.ui.trendSplit, 'total');
    const ok = G.sidebar.sanitize({ ui: { trendGran: 'weekly', trendSplit: 'adsets' } });
    assert.equal(ok.ui.trendGran, 'weekly');
    assert.equal(ok.ui.trendSplit, 'adsets');
  });
});

/* =========================================================================================== */
describe('real breakdown sample (when public/data/sample.js carries it)', { skip: !HAS_BD && 'no GROOV_SAMPLE.breakdowns in sample.js' }, () => {
  const bd = HAS_BD ? D.indexBreakdowns(REAL_BD) : null;
  test('every ad set key joins the rows payload', () => {
    bd.adsets.forEach((a) => assert.ok(ENV.ds.adsetByKey.has(a.key), a.key));
  });
  test('every Meta ad set with rows: placement and audience shares sum to 100% (±0.1)', () => {
    let n = 0;
    for (const preset of ['7d', '14d']) {
      const ctx = ctxFor(ENV, { period: { preset } });
      ctx.snap.adsets.filter((a) => a.platform === 'meta' && a.cur.spend > 0).forEach((a) => {
        const res = E.bdResult(a.objective);
        const pl = M.bdBlock(bd, ctx.snap.P, [a], 'placement', res), au = M.bdBlock(bd, ctx.snap.P, [a], 'audience', res);
        if (pl.empty) return;
        n++;
        const s = (l, f) => l.reduce((t, r) => t + (r[f] || 0), 0) * 100;
        near(s(pl.rows, 'spendShare'), 100, 0.1, a.key + ' placement spend');
        if (pl.total.results > 0) near(s(pl.rows, 'resShare'), 100, 0.1, a.key + ' placement results');
        near(s(au.cells, 'spendShare'), 100, 0.1, a.key + ' audience spend');
        if (au.total.results > 0) near(s(au.cells, 'resShare'), 100, 0.1, a.key + ' audience results');
        near(s(au.ages.concat(au.hidden.filter((h) => h.age)), 'spendShare'), 100, 0.1, a.key + ' ages');
        near(s(au.genders.concat(au.hidden.filter((h) => h.gender)), 'spendShare'), 100, 0.1, a.key + ' genders');
        assert.ok(pl.coverage.cur > 0.95 && pl.coverage.cur < 1.05, a.key + ' coverage ' + pl.coverage.cur);
      });
    }
    assert.ok(n > 60, n + ' ad sets checked');
  });
  test('The Peak Clinic TPC3 ad set: Facebook Feed leads, women 25–34 bring the most conversations', () => {
    const ctx = ctxFor(ENV, {});
    const a = ctx.snap.adsets.find((x) => x.key === PEAK_AS);
    const res = E.bdResult(a.objective);
    const pl = M.bdBlock(bd, ctx.snap.P, [a], 'placement', res), au = M.bdBlock(bd, ctx.snap.P, [a], 'audience', res);
    assert.equal(pl.rows[0].label, 'Facebook Feed');
    const best = au.cells.slice().sort((x, y) => y.results - x.results)[0];
    assert.equal(best.label, 'Women 25–34');
    assert.match(M.bdSentence(pl, au, res), /^Facebook Feed took \d+% of spend and brought \d+% of conversations/);
  });
  test('accounts not reachable in Windsor are told apart from ad sets without rows', () => {
    const ctx = ctxFor(ENV, {});
    const rena = ctx.snap.adsets.filter((a) => a.clientSlug === 'rena-yakiniku' && a.platform === 'meta' && a.cur.spend > 0);
    assert.ok(rena.length);
    const r = M.bdReach(bd, ENV.ds, rena, ctx.snap.P.cur.from, ctx.snap.P.cur.to);
    assert.equal(r.reachable.length, 0);
    assert.equal(r.unreachable.length, rena.length);
    const html = G.views.client.render(ctxFor(ENV, { route: { page: 'client', slug: 'rena-yakiniku', params: {} } }, { bd }));
    assert.ok(html.includes('isn’t reachable in Windsor'));
  });
  test('client sections: every block’s shares sum to 100% and no objective is mixed', () => {
    const ctx = ctxFor(ENV, {});
    ENV.ds.clients.forEach((c) => {
      const d = M.clientDetail(ctx.snap, ENV.ds, c.slug, 'all');
      if (!d) return;
      const W0 = M.whereResults(ctx.snap, ENV.ds, d, bd, {});
      W0.types.forEach((t) => {
        const W = M.whereResults(ctx.snap, ENV.ds, d, bd, { type: t.type });
        W.adsets.forEach((a) => assert.equal(a.prim.type, t.type));
        if (W.placement && !W.placement.empty) near(W.placement.rows.reduce((s, r) => s + r.spendShare, 0) * 100, 100, 0.1, c.slug + ' ' + t.type);
        if (W.audience && !W.audience.empty && W.audience.total.results > 0) near(W.audience.cells.reduce((s, r) => s + r.resShare, 0) * 100, 100, 0.1, c.slug + ' ' + t.type + ' audience');
        assert.ok(!BAD_TEXT.test(W.sentence), W.sentence);
      });
    });
  });
});
