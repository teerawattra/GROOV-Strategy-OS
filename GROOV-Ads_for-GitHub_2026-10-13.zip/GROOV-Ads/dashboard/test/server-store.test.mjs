// Raw partitions (server/store.mjs) and the pull jobs that write them (server/refresh.mjs): file layout, gzip,
// atomic overwrite of exactly the days of a complete chunk, resumable backfill, the shrink guard and the spend > 0
// filter of the breakdown datasets.

import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { mkdirSync, readdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { gunzipSync } from 'node:zlib';
import { DATASET_IDS } from '../lib/datasets.mjs';
import { backfill, refresh } from '../server/refresh.mjs';
import { listDates, partitionPath, readPartition, readRows, spendOf, StoreError, writePartition, groupByDate } from '../server/store.mjs';
import { startMockWindsor } from './mock-windsor.mjs';
import { NOW, makeConfig, noSleep, offlineFetch, quietLog, readSample, tempRoot } from './server-helpers.mjs';

function filesUnder(dir) {
  const out = [];
  const walk = (d) => {
    for (const e of readdirSync(d, { withFileTypes: true })) {
      if (e.isDirectory()) walk(join(d, e.name));
      else out.push(join(d, e.name));
    }
  };
  walk(dir);
  return out;
}

describe('partitions', () => {
  let root;
  before(async () => {
    root = await tempRoot();
  });
  after(async () => {
    await root.cleanup();
  });

  it('writes one gzip file per dataset and day under data/raw/<dataset>/<YYYY>/', async () => {
    const dataDir = join(root.dir, 'data');
    const rows = [{ date: '2026-09-14', ad_id: '1', spend: 12.5 }, { date: '2026-09-14', ad_id: '2', spend: null }];
    const path = await writePartition(dataDir, 'meta', '2026-09-14', rows, { fetched_at: '2026-09-21T00:15:00.000Z' });
    assert.equal(path, join(dataDir, 'raw', 'meta', '2026', '2026-09-14.json.gz'));
    const envelope = JSON.parse(gunzipSync(readFileSync(path)).toString('utf8'));
    assert.deepEqual(envelope.rows, rows, 'rows exactly as given');
    assert.equal(envelope.dataset, 'meta');
    assert.equal(envelope.date, '2026-09-14');
    assert.equal(envelope.connector, 'facebook');
    assert.equal(envelope.rows_count, 2);
    assert.deepEqual((await readPartition(dataDir, 'meta', '2026-09-14')).rows, rows);
    assert.equal(await readPartition(dataDir, 'meta', '2026-09-15'), null, 'never pulled');
    await writePartition(dataDir, 'meta', '2025-12-31', []);
    await writePartition(dataDir, 'meta', '2026-01-02', [{ date: '2026-01-02', spend: '1.25' }]);
    assert.deepEqual(await listDates(dataDir, 'meta'), ['2025-12-31', '2026-01-02', '2026-09-14']);
    assert.equal((await readRows(dataDir, 'meta', { from: '2026-01-01' })).length, 3);
    assert.equal(spendOf(await readRows(dataDir, 'meta')), 13.75);
    assert.ok(!filesUnder(join(dataDir, 'raw')).some((f) => f.includes('.tmp-')), 'no temp files left');
  });

  it('refuses unknown datasets and non-dates (no path tricks)', async () => {
    const dataDir = join(root.dir, 'data');
    assert.throws(() => partitionPath(dataDir, '../etc', '2026-09-14'), StoreError);
    assert.throws(() => partitionPath(dataDir, 'meta', '2026-02-30'), StoreError);
    assert.throws(() => partitionPath(dataDir, 'meta', '../../x'), StoreError);
  });

  it('names a damaged file and the command that re-pulls it', async () => {
    const dataDir = join(root.dir, 'data');
    mkdirSync(dirname(partitionPath(dataDir, 'tiktok', '2026-09-01')), { recursive: true });
    writeFileSync(partitionPath(dataDir, 'tiktok', '2026-09-01'), 'not gzip');
    await assert.rejects(readPartition(dataDir, 'tiktok', '2026-09-01'), (e) => e instanceof StoreError && /backfill --from 2026-09-01 --to 2026-09-01 --datasets tiktok --force/.test(e.message));
  });

  it('groups an answer by day; rows outside the days are counted, zero-spend breakdown rows dropped', () => {
    const rows = [
      { date: '2026-09-14', spend: 1 }, { date: '2026-09-15', spend: 0 }, { date: '2026-09-16', spend: 2 }, { date: 'bad', spend: 3 },
    ];
    const keep = (d, r) => r.spend > 0;
    const g = groupByDate('meta_placements', rows, '2026-09-14', '2026-09-15', keep);
    assert.deepEqual([...g.byDate.keys()], ['2026-09-14']);
    assert.equal(g.unplaced, 2);
    assert.equal(g.droppedBy.get('2026-09-15'), 1);
  });
});

describe('backfill and refresh write partitions', () => {
  let mock;
  let root;
  let config;
  const opts = () => ({ now: NOW, log: quietLog(), sleep: noSleep, imageFetchImpl: offlineFetch });

  before(async () => {
    mock = await startMockWindsor();
    root = await tempRoot();
    config = makeConfig(root.dir, { WINDSOR_BASE_URL: mock.url, WINDSOR_API_KEY: mock.key });
  });
  after(async () => {
    await mock.close();
    await root.cleanup();
  });

  it('stores every day of the range (14 files per dataset), rows exactly as Windsor returned them', async () => {
    const status = await backfill(config, { ...opts(), from: '2026-09-07', to: '2026-09-13' });
    assert.equal(status.state, 'ok', status.error);
    for (const d of DATASET_IDS) assert.equal((await listDates(config.dataDir, d)).length, 7, d);
    const csv = readSample('meta').filter((r) => r.date === '2026-09-10');
    const stored = (await readPartition(config.dataDir, 'meta', '2026-09-10')).rows;
    assert.equal(stored.length, csv.length);
    assert.deepEqual(stored.map((r) => r.ad_id), csv.map((r) => r.ad_id), 'same rows, same order');
    assert.equal(stored[0].spend, csv[0].spend === '' ? null : Number(csv[0].spend));
  });

  it('resumes: only the days not stored yet are pulled; --force pulls everything again', async () => {
    mock.resetRequests();
    const status = await backfill(config, { ...opts(), from: '2026-09-07', to: '2026-09-20' });
    assert.equal(status.state, 'ok', status.error);
    assert.equal(mock.requests.length, 5, 'one 7-day chunk per dataset');
    assert.ok(mock.requests.every((r) => r.date_from === '2026-09-14' && r.date_to === '2026-09-20'));
    assert.deepEqual(status.todo.meta, { missing: 7, stored: 7 });

    mock.resetRequests();
    const again = await backfill(config, { ...opts(), from: '2026-09-07', to: '2026-09-20' });
    assert.equal(again.state, 'ok');
    assert.equal(mock.requests.length, 0, 'nothing left to pull');

    const forced = await backfill(config, { ...opts(), from: '2026-09-07', to: '2026-09-20', datasets: ['google'], force: true });
    assert.equal(forced.state, 'ok');
    assert.equal(mock.requests.length, 2, 'google only, both chunks');
  });

  it('a failed chunk leaves its stored days untouched; complete chunks overwrite exactly their days', async () => {
    const before7 = (await readPartition(config.dataDir, 'tiktok', '2026-09-07')).fetched_at;
    const before14 = (await readPartition(config.dataDir, 'tiktok', '2026-09-14')).fetched_at;
    mock.resetRequests();
    mock.addFault({ kind: 'status', status: 500, times: 99, match: { table: 'tiktok', date_from: '2026-09-14' } });
    const later = new Date(NOW.getTime() + 3600_000);
    const status = await refresh(config, { ...opts(), now: later, days: 14, datasets: ['tiktok'] });
    mock.clearFaults();
    assert.equal(status.state, 'error');
    assert.match(status.error, /Windsor pull failed for tiktok \(1 of 2 chunks\)/);
    assert.match(status.error, /previous snapshot keeps serving/);
    assert.notEqual((await readPartition(config.dataDir, 'tiktok', '2026-09-07')).fetched_at, before7, 'the complete chunk was rewritten');
    assert.equal((await readPartition(config.dataDir, 'tiktok', '2026-09-14')).fetched_at, before14, 'the failed chunk kept its days');
    assert.ok(!filesUnder(join(config.dataDir, 'raw')).some((f) => f.includes('.tmp-')));
  });

  it('an interrupted backfill is finished by running it again', async () => {
    const r2 = await tempRoot();
    const c2 = makeConfig(r2.dir, { WINDSOR_BASE_URL: mock.url, WINDSOR_API_KEY: mock.key });
    mock.addFault({ kind: 'status', status: 503, times: 99, match: { table: 'meta', date_from: '2026-09-14' } });
    const first = await backfill(c2, { ...opts(), from: '2026-09-07', to: '2026-09-20', datasets: ['meta', 'google'] });
    mock.clearFaults();
    assert.equal(first.state, 'error');
    assert.deepEqual(await listDates(c2.dataDir, 'meta'), ['2026-09-07', '2026-09-08', '2026-09-09', '2026-09-10', '2026-09-11', '2026-09-12', '2026-09-13']);
    mock.resetRequests();
    const second = await backfill(c2, { ...opts(), from: '2026-09-07', to: '2026-09-20', datasets: ['meta', 'google'] });
    assert.equal(second.state, 'ok', second.error);
    assert.deepEqual(mock.requests.map((r) => `${r.table} ${r.date_from}`), ['meta 2026-09-14']);
    assert.equal((await listDates(c2.dataDir, 'meta')).length, 14);
    await r2.cleanup();
  });

  it('keeps stored days when Windsor suddenly returns far fewer rows, unless forced', async () => {
    const stored = (await readRows(config.dataDir, 'meta', { from: '2026-09-14', to: '2026-09-20' })).length;
    mock.addFault({ kind: 'empty', times: 1, match: { table: 'meta', date_from: '2026-09-14' } });
    const log = quietLog();
    const status = await refresh(config, { ...opts(), log, days: 7, datasets: ['meta'] });
    assert.equal(status.state, 'ok', status.error);
    assert.equal((await readRows(config.dataDir, 'meta', { from: '2026-09-14', to: '2026-09-20' })).length, stored, 'kept');
    assert.ok(status.warnings.some((w) => /Windsor returned 0 rows where \d+ are stored, so the stored days were kept/.test(w)), status.warnings.join('\n'));
    assert.equal(status.pulls.meta.days_kept, 7);

    mock.addFault({ kind: 'empty', times: 1, match: { table: 'meta', date_from: '2026-09-14' } });
    const forced = await refresh(config, { ...opts(), days: 7, datasets: ['meta'], force: true });
    assert.equal(forced.state, 'ok');
    assert.equal((await readRows(config.dataDir, 'meta', { from: '2026-09-14', to: '2026-09-20' })).length, 0, 'forced: the empty answer is accepted');
    await refresh(config, { ...opts(), days: 7, datasets: ['meta'], force: true }); // restore
  });

  it('breakdown datasets keep only rows with spend > 0', async () => {
    const r3 = await tempRoot();
    const tables = { ...mock.tables, meta_placements: [...mock.tables.meta_placements] };
    const zero = { ...tables.meta_placements.find((r) => r.date === '2026-09-20'), spend: '0', impressions: '5' };
    tables.meta_placements.push(zero);
    const m2 = await startMockWindsor({ tables });
    const c3 = makeConfig(r3.dir, { WINDSOR_BASE_URL: m2.url, WINDSOR_API_KEY: m2.key });
    const status = await backfill(c3, { ...opts(), from: '2026-09-20', to: '2026-09-20', datasets: ['meta_placements'] });
    assert.equal(status.state, 'ok', status.error);
    const envelope = await readPartition(c3.dataDir, 'meta_placements', '2026-09-20');
    assert.equal(envelope.dropped_zero_spend, 1);
    assert.equal(envelope.rows.length, readSample('meta_placements').filter((r) => r.date === '2026-09-20').length);
    assert.equal(status.pulls.meta_placements.dropped_zero_spend, 1);
    await m2.close();
    await r3.cleanup();
  });

  it('checks its arguments before pulling', async () => {
    const bad = await backfill(config, { ...opts(), from: '2026-09-20', to: '2026-09-07' });
    assert.equal(bad.state, 'error');
    assert.equal(bad.usage, true);
    assert.match(bad.error, /--from 2026-09-20 is after --to 2026-09-07/);
    const unknown = await backfill(config, { ...opts(), from: '2026-09-07', datasets: ['meta', 'shopify'] });
    assert.match(unknown.error, /Unknown dataset\(s\): shopify/);
    const none = await backfill(makeConfig(root.dir, { WINDSOR_API_KEY: 'x' }), { ...opts() });
    assert.match(none.error, /needs --from/);
    const future = await backfill(config, { ...opts(), from: '2026-09-20', to: '2026-12-31', datasets: ['google'] });
    assert.equal(future.state, 'ok');
    assert.deepEqual(future.range, { from: '2026-09-20', to: '2026-09-20' }, 'never past yesterday');
  });
});
