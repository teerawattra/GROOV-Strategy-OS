// Test doubles shared by the backend tests (not a test file itself): a fake Google OAuth + Sheets API served
// through a mocked fetch, a service-account key, sample-sheet loaders and image bytes. No network.
import { generateKeyPairSync, verify } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { parseCsv, parseCsvRecords } from '../lib/csv.mjs';

export const SECRET = 'unit-test-session-secret-0123456789abcdef';

const pair = generateKeyPairSync('rsa', { modulusLength: 2048 });
export const SA_PUBLIC_KEY = pair.publicKey;
export const SERVICE_ACCOUNT = {
  type: 'service_account',
  project_id: 'groov-test',
  private_key_id: 'abc123keyid',
  private_key: pair.privateKey.export({ type: 'pkcs8', format: 'pem' }),
  client_email: 'sheets-reader@groov-test.iam.gserviceaccount.com',
  client_id: '1234567890',
  token_uri: 'https://oauth2.googleapis.com/token',
};
export const SERVICE_ACCOUNT_JSON = JSON.stringify(SERVICE_ACCOUNT, null, 2);

export const SHEET_IDS = {
  meta: 'sheet-meta-0001', tiktok: 'sheet-tiktok-0002', google: 'sheet-google-0003',
  placements: 'sheet-meta-placements-0004', audience: 'sheet-meta-audience-0005', // the two OPTIONAL breakdown Sheets
};
export const TITLES = {
  meta: 'GROOV Ads · Meta', tiktok: "GROOV Ads · TikTok's", google: 'GROOV Ads · Google',
  placements: 'GROOV Ads · Meta placements', audience: 'GROOV Ads · Meta audience',
};

export const sampleText = (platform) => readFileSync(fileURLToPath(new URL(`../sample/sheets/${platform}.csv`, import.meta.url)), 'utf8');
export const sampleRows = (platform) => parseCsv(sampleText(platform));
export const sampleGrid = (platform) => parseCsvRecords(sampleText(platform));
export const loadSampleSheets = () => ({ meta: sampleRows('meta'), tiktok: sampleRows('tiktok'), google: sampleRows('google') });

export function sheetsEnv(extra = {}) {
  return {
    GOOGLE_SERVICE_ACCOUNT_JSON: SERVICE_ACCOUNT_JSON,
    SHEET_ID_META: SHEET_IDS.meta,
    SHEET_ID_TIKTOK: SHEET_IDS.tiktok,
    SHEET_ID_GOOGLE: SHEET_IDS.google,
    SESSION_SECRET: SECRET,
    GOOGLE_CLIENT_ID: 'client-123.apps.googleusercontent.com',
    ALLOWED_DOMAINS: 'groovstrategy.co',
    ALLOWED_EMAILS: 'friend.of.groov@gmail.com',
    OWNER_EMAILS: 'finn@groovstrategy.co',
    ...extra,
  };
}

const json = (status, body, headers = {}) => new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json', ...headers } });

const isEmpty = (v) => v === '' || v === null || v === undefined;

/** What the real API does: drop trailing empty cells in a row and trailing empty rows in the range. */
function trimGrid(rows) {
  const out = rows.map((r) => {
    const row = r.slice();
    while (row.length && isEmpty(row[row.length - 1])) row.pop();
    return row;
  });
  while (out.length && out[out.length - 1].length === 0) out.pop();
  return out;
}

function columnNumber(letters) {
  let n = 0;
  for (const ch of letters) n = n * 26 + (ch.charCodeAt(0) - 64);
  return n;
}

/**
 * Fake Google APIs.
 * @param {object} o
 * @param {Record<string, {title: string, grid: any[][], rowCount?: number, columnCount?: number, extraTabs?: string[], tabs?: Record<string, any[][]>}>} o.spreadsheets
 *   `extraTabs` are more tabs that all show the same `grid`; `tabs` maps a tab title to its own grid (the first tab, `title`, keeps `grid`)
 * @param {(url: URL, init: object) => Response|undefined} [o.override]  return a Response to short-circuit
 * @param {(url: URL, init: object) => Promise<Response>|undefined} [o.other]  non-Google URLs (images, background job)
 */
export function fakeGoogle({ spreadsheets = {}, override, other } = {}) {
  const calls = [];
  let inFlight = 0;
  let maxInFlight = 0;

  async function fetchImpl(input, init = {}) {
    const url = new URL(String(input));
    calls.push({ url: url.href, method: init.method ?? 'GET', headers: new Headers(init.headers ?? {}) });
    const forced = override?.(url, init);
    if (forced) return forced;

    if (url.href === 'https://oauth2.googleapis.com/token') {
      const form = new URLSearchParams(String(init.body));
      if (form.get('grant_type') !== 'urn:ietf:params:oauth:grant-type:jwt-bearer') return json(400, { error: 'unsupported_grant_type' });
      const [h, p, s] = String(form.get('assertion')).split('.');
      const ok = verify('RSA-SHA256', Buffer.from(`${h}.${p}`), SA_PUBLIC_KEY, Buffer.from(s, 'base64url'));
      if (!ok) return json(400, { error: 'invalid_grant', error_description: 'Invalid JWT Signature.' });
      const claims = JSON.parse(Buffer.from(p, 'base64url').toString('utf8'));
      if (claims.aud !== 'https://oauth2.googleapis.com/token' || !String(claims.scope).includes('spreadsheets.readonly')) return json(400, { error: 'invalid_scope' });
      return json(200, { access_token: 'ya29.fake-access-token', expires_in: 3599, token_type: 'Bearer' });
    }

    if (url.hostname === 'sheets.googleapis.com') {
      if (new Headers(init.headers ?? {}).get('authorization') !== 'Bearer ya29.fake-access-token') return json(401, { error: { code: 401, message: 'unauthenticated' } });
      inFlight++;
      maxInFlight = Math.max(maxInFlight, inFlight);
      try {
        await new Promise((resolve) => setImmediate(resolve));
        const m = /^\/v4\/spreadsheets\/([^/]+)(?:\/values\/(.+))?$/.exec(url.pathname);
        const sheet = m && spreadsheets[decodeURIComponent(m[1])];
        if (!sheet) return json(404, { error: { code: 404, message: 'Requested entity was not found.' } });
        const gridOf = (tabTitle) => (sheet.tabs && Object.hasOwn(sheet.tabs, tabTitle) ? sheet.tabs[tabTitle] : sheet.grid);
        const sizeOf = (tabTitle) => {
          const g = gridOf(tabTitle);
          let widest = 1;
          for (const row of g) if (row.length > widest) widest = row.length;
          return { rowCount: sheet.rowCount ?? g.length, columnCount: sheet.columnCount ?? widest };
        };
        if (!m[2]) {
          const names = [sheet.title, ...(sheet.extraTabs ?? []), ...Object.keys(sheet.tabs ?? {})];
          const tabs = names.map((t, i) => ({ title: t, index: i, sheetId: i }));
          return json(200, { sheets: tabs.map((t) => ({ properties: { ...t, gridProperties: sizeOf(t.title) } })) });
        }
        if (url.searchParams.get('valueRenderOption') !== 'UNFORMATTED_VALUE' || url.searchParams.get('dateTimeRenderOption') !== 'FORMATTED_STRING') {
          return json(400, { error: { code: 400, message: 'unexpected render options' } });
        }
        const range = decodeURIComponent(m[2]);
        const r = /^'((?:[^']|'')*)'!A(\d+):([A-Z]+)(\d+)$/.exec(range);
        if (!r) return json(400, { error: { code: 400, message: `Unable to parse range: ${range}` } });
        const title = r[1].replace(/''/g, "'");
        if (title !== sheet.title && !(sheet.extraTabs ?? []).includes(title) && !Object.hasOwn(sheet.tabs ?? {}, title)) {
          return json(400, { error: { code: 400, message: `Unable to parse range: ${range}` } });
        }
        const start = Number(r[2]);
        const lastCol = columnNumber(r[3]);
        const end = Number(r[4]);
        const slice = gridOf(title).slice(start - 1, end).map((row) => row.slice(0, lastCol));
        const values = trimGrid(slice);
        return json(200, values.length ? { range, majorDimension: 'ROWS', values } : { range, majorDimension: 'ROWS' });
      } finally {
        inFlight--;
      }
    }

    const handled = await other?.(url, init);
    if (handled) return handled;
    throw new TypeError(`fakeGoogle: unexpected fetch ${url.href}`);
  }

  return { fetch: fetchImpl, calls, get maxInFlight() { return maxInFlight; } };
}

/** The three sample CSVs as fake spreadsheets (grid rows as strings, like CSV cells). */
export function sampleSpreadsheets(transform = (platform, grid) => grid) {
  const out = {};
  for (const platform of ['meta', 'tiktok', 'google']) {
    out[SHEET_IDS[platform]] = { title: TITLES[platform], grid: transform(platform, sampleGrid(platform)) };
  }
  return out;
}

// ---------------------------------------------------------------------------------------------------------
// The two optional Meta breakdown Sheets (DATA_CONTRACT.md Sheets 4 and 5), derived from the sample Meta Sheet
// ---------------------------------------------------------------------------------------------------------

// Headers written out from the contract on purpose (not imported from lib/breakdowns.mjs), so a wrong constant there fails a test.
const BD_METRICS = ['spend', 'impressions', 'clicks', 'link_clicks', 'actions_video_view', 'actions_onsite_conversion_messaging_conversation_started_7d', 'actions_lead'];
export const PLACEMENT_HEADER = ['date', 'account_id', 'adset_id', 'publisher_platform', 'platform_position', ...BD_METRICS];
export const AUDIENCE_HEADER = ['date', 'account_id', 'adset_id', 'age', 'gender', ...BD_METRICS];

/** Split a non-negative integer into integer parts with the given percentages; the last part takes the remainder, so the sum is exact. */
function splitInt(total, percents) {
  const parts = [];
  let left = total;
  for (let i = 0; i < percents.length - 1; i++) {
    const part = Math.floor((total * percents[i]) / 100);
    parts.push(part);
    left -= part;
  }
  parts.push(left);
  return parts;
}

/**
 * Placement and audience Sheets (grids as strings, header first) built from the sample Meta Sheet: every ad set and day
 * is split into 3 placements / 4 age-gender cells in integer units, so spend reconciles with Sheet 1 to the last digit.
 * Like Windsor's `spend > 0` filter, cells without spend are left out.
 * @param {{ skipAdsets?: string[], skipDates?: string[] }} [o]  ad sets / days to leave out, to make the Sheets incomplete
 * @returns {{ placements: string[][], audience: string[][], adsetDays: number, spend: number }}
 */
export function syntheticBreakdownGrids({ skipAdsets = [], skipDates = [] } = {}) {
  const totals = new Map(); // date|adset -> { date, account, adset, units, counts[6] }
  for (const r of sampleRows('meta')) {
    if (!r.adset_id || skipAdsets.includes(r.adset_id) || skipDates.includes(r.date)) continue;
    const key = `${r.date}|${r.adset_id}`;
    let t = totals.get(key);
    if (!t) {
      t = { date: r.date, account: r.account_id, adset: r.adset_id, units: 0, counts: new Array(6).fill(0) };
      totals.set(key, t);
    }
    t.units += Math.round(Number(r.spend || 0) * 10000);
    BD_METRICS.slice(1).forEach((h, i) => { t.counts[i] += Number(r[h] || 0); });
  }
  const PLACEMENTS = [['facebook', 'feed', 60], ['instagram', 'instagram_reels', 30], ['facebook', 'facebook_stories', 10]];
  const AUDIENCES = [['25-34', 'female', 40], ['25-34', 'male', 30], ['35-44', 'female', 20], ['Unknown', 'unknown', 10]];
  const placements = [PLACEMENT_HEADER];
  const audience = [AUDIENCE_HEADER];
  let spend = 0;
  const ordered = [...totals.values()].sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : a.adset < b.adset ? -1 : 1));
  for (const t of ordered) {
    if (t.units <= 0) continue;
    spend += t.units;
    const fill = (spec, header, sink) => {
      const percents = spec.map((x) => x[2]);
      const units = splitInt(t.units, percents);
      const counts = t.counts.map((c) => splitInt(c, percents));
      spec.forEach((cell, i) => {
        if (units[i] <= 0) return;
        sink.push([t.date, t.account, t.adset, cell[0], cell[1], String(units[i] / 10000), ...counts.map((c) => String(c[i]))]);
      });
    };
    fill(PLACEMENTS, PLACEMENT_HEADER, placements);
    fill(AUDIENCES, AUDIENCE_HEADER, audience);
  }
  return { placements, audience, adsetDays: totals.size, spend: spend / 10000 };
}

/** The two breakdown grids as fake spreadsheets, keyed by SHEET_IDS.placements / SHEET_IDS.audience. */
export function breakdownSpreadsheets(grids = syntheticBreakdownGrids()) {
  return {
    [SHEET_IDS.placements]: { title: TITLES.placements, grid: grids.placements },
    [SHEET_IDS.audience]: { title: TITLES.audience, grid: grids.audience },
  };
}

/** Env vars that switch the two optional Sheets on (two separate spreadsheets). */
export const breakdownEnv = (extra = {}) => ({ SHEET_ID_META_PLACEMENTS: SHEET_IDS.placements, SHEET_ID_META_AUDIENCE: SHEET_IDS.audience, ...extra });

/** Bytes that sniff as JPEG (FF D8 FF ...), padded to `size`. */
export function jpegBytes(size = 2048, fill = 7) {
  const b = new Uint8Array(size).fill(fill);
  b.set([0xff, 0xd8, 0xff, 0xe0, 0x00, 0x10, 0x4a, 0x46, 0x49, 0x46, 0x00, 0x01]);
  return b;
}

export function pngBytes(size = 512) {
  const b = new Uint8Array(size).fill(1);
  b.set([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0, 0, 0, 13]);
  return b;
}

export const quietLog = { log() {}, warn() {}, error() {} };
