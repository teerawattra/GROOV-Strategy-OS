// A stand-in for the Windsor REST API (https://connectors.windsor.ai/<connector>) for the tests and the end-to-end
// check: node:http on 127.0.0.1, answering from the sample CSVs (sample/sheets, real Sep 2026 data).
//
//   GET /<facebook|tiktok|google_ads>?api_key=…&fields=a,b,…&date_from=YYYY-MM-DD&date_to=YYYY-MM-DD&_max_rows=N
//
// - The table is picked like Windsor would: facebook + publisher_platform -> placements, facebook + age -> audience,
//   facebook otherwise -> ad rows; tiktok; google_ads.
// - Rows are filtered to the dates, projected to the requested fields and typed like Windsor's JSON: ids, dates, names,
//   statuses and links stay strings, metrics become numbers, blanks become null. At most _max_rows rows are returned.
// - The answer is {"data": [...]} (or a bare array with shape: 'array').
// - Faults for the tests: { kind: 'status', status, times, body } | { kind: 'hang', times } | { kind: 'pending', times }
//   | { kind: 'garbage', times } | { kind: 'empty', times }, each optionally limited by `match` ({ connector, table, date_from }).
// - A wrong api_key gets 401 with the key echoed back in the body, like a careless API would, so the tests can prove
//   the client never repeats it.
//
// Standalone (end-to-end check):  node test/mock-windsor.mjs [--port 8790] [--key KEY] [--sheets DIR]

import http from 'node:http';
import { existsSync, readFileSync, realpathSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { parseCsv } from '../lib/csv.mjs';

export const MOCK_KEY = 'mock-windsor-key-0123456789abcdef';
export const DEFAULT_SHEETS = fileURLToPath(new URL('../sample/sheets/', import.meta.url));
export const TABLES = Object.freeze(['meta', 'tiktok', 'google', 'meta_placements', 'meta_audience']);

/** Fields Windsor returns as text; every other field is a metric (number or null). */
const TEXT_FIELDS = new Set([
  'date', 'account_name', 'campaign', 'campaign_objective', 'adset_name', 'ad_name', 'effective_status', 'image_url', 'ad_preview_shareable_link',
  'objective_type', 'campaign_status', 'adgroup_name', 'video_thumbnail_url', 'advertising_channel_type', 'ad_group_name', 'ad_group_status',
  'publisher_platform', 'platform_position', 'age', 'gender',
]);
const NUMBER = /^[+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?$/;

export function loadTables(sheetsDir = DEFAULT_SHEETS) {
  const tables = {};
  for (const name of TABLES) {
    const file = join(sheetsDir, `${name}.csv`);
    tables[name] = existsSync(file) ? parseCsv(readFileSync(file, 'utf8')) : [];
  }
  return tables;
}

export function tableFor(connector, fields) {
  if (connector === 'facebook') return fields.includes('publisher_platform') ? 'meta_placements' : fields.includes('age') ? 'meta_audience' : 'meta';
  if (connector === 'tiktok') return 'tiktok';
  if (connector === 'google_ads') return 'google';
  return null;
}

/** A CSV cell as Windsor's JSON would carry it. */
export function typed(field, value) {
  if (value === undefined || value === null) return null;
  const s = String(value);
  if (s.trim() === '') return null;
  if (TEXT_FIELDS.has(field) || field.endsWith('_id')) return s;
  return NUMBER.test(s.trim()) ? Number(s) : s;
}

const isIso = (s) => typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s);

function matches(fault, rec) {
  const m = fault.match ?? {};
  return Object.entries(m).every(([k, v]) => rec[k] === v);
}

/**
 * @param {{ sheetsDir?: string, key?: string, shape?: 'data'|'array', host?: string, port?: number, faults?: object[], tables?: object }} [o]
 */
export async function startMockWindsor({ sheetsDir = DEFAULT_SHEETS, key = MOCK_KEY, shape = 'data', host = '127.0.0.1', port = 0, faults = [], tables = null } = {}) {
  const data = tables ?? loadTables(sheetsDir);
  const requests = [];
  const state = { shape, faults: faults.map((f) => ({ ...f, remaining: f.times ?? Infinity })) };
  const sockets = new Set();
  const hanging = new Set();

  const server = http.createServer((req, res) => {
    const url = new URL(req.url, 'http://mock.invalid');
    const connector = decodeURIComponent(url.pathname.replace(/^\/+/, ''));
    const q = url.searchParams;
    const fields = (q.get('fields') ?? '').split(',').filter(Boolean);
    const rec = {
      connector, table: tableFor(connector, fields), date_from: q.get('date_from'), date_to: q.get('date_to'),
      max_rows: q.has('_max_rows') ? Number(q.get('_max_rows')) : null, key_ok: q.get('api_key') === key, fields, status: 200, rows: 0,
    };
    requests.push(rec);
    const fault = state.faults.find((f) => f.remaining > 0 && matches(f, rec));
    const json = (status, body) => {
      rec.status = status;
      res.writeHead(status, { 'content-type': 'application/json' });
      res.end(typeof body === 'string' ? body : JSON.stringify(body));
    };
    if (fault) {
      fault.remaining--;
      rec.fault = fault.kind;
      if (fault.kind === 'hang') {
        hanging.add(res);
        return;
      }
      if (fault.kind === 'status') return json(fault.status ?? 500, fault.body ?? { error: 'mock failure' });
      if (fault.kind === 'pending') return json(200, { status: 'pending', message: 'report is being prepared' });
      if (fault.kind === 'garbage') {
        rec.status = 200;
        res.writeHead(200, { 'content-type': 'text/html' });
        return res.end('<html><body>Bad gateway</body></html>');
      }
      if (fault.kind === 'empty') return json(200, state.shape === 'array' ? [] : { data: [] });
    }
    if (!rec.key_ok) return json(401, { error: `Invalid api_key ${q.get('api_key')} for ${req.url}` });
    if (!rec.table) return json(404, { error: `Unknown connector ${connector}` });
    if (!isIso(rec.date_from) || !isIso(rec.date_to)) return json(400, { error: 'date_from and date_to are required' });
    let rows = data[rec.table]
      .filter((r) => r.date >= rec.date_from && r.date <= rec.date_to)
      .map((r) => Object.fromEntries(fields.map((f) => [f, typed(f, r[f])])));
    if (rec.max_rows && rows.length > rec.max_rows) rows = rows.slice(0, rec.max_rows);
    rec.rows = rows.length;
    return json(200, state.shape === 'array' ? rows : { data: rows });
  });
  server.on('connection', (s) => {
    sockets.add(s);
    s.on('close', () => sockets.delete(s));
  });
  await new Promise((resolveListen) => server.listen(port, host, resolveListen));
  const actual = server.address().port;
  return {
    url: `http://${host}:${actual}`,
    port: actual,
    key,
    requests,
    tables: data,
    setShape(s) {
      state.shape = s;
    },
    addFault(f) {
      state.faults.push({ ...f, remaining: f.times ?? Infinity });
    },
    clearFaults() {
      state.faults.length = 0;
    },
    resetRequests() {
      requests.length = 0;
    },
    async close() {
      for (const res of hanging) res.destroy();
      for (const s of sockets) s.destroy();
      await new Promise((r) => server.close(() => r()));
    },
  };
}

// Standalone: node test/mock-windsor.mjs [--port N] [--key K] [--sheets DIR]
if (process.argv[1] && realpathSync(resolve(process.argv[1])) === realpathSync(fileURLToPath(import.meta.url))) {
  const arg = (name, fallback) => {
    const i = process.argv.indexOf(`--${name}`);
    return i !== -1 && process.argv[i + 1] ? process.argv[i + 1] : fallback;
  };
  const mock = await startMockWindsor({ port: Number(arg('port', '0')), key: arg('key', MOCK_KEY), sheetsDir: resolve(arg('sheets', DEFAULT_SHEETS)) });
  console.log(`mock-windsor: listening on ${mock.url} (sample sheets; use WINDSOR_BASE_URL=${mock.url} and the test key)`);
  const stop = () => mock.close().then(() => process.exit(0));
  process.on('SIGTERM', stop);
  process.on('SIGINT', stop);
}
