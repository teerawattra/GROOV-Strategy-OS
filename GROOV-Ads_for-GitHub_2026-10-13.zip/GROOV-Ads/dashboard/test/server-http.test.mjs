// The HTTP layer (server/routes.mjs, server/auth.mjs): Tailscale identity, allow-list and owners, the AUTH_MODE=none
// guard, the built-in login page, static files and their security headers, /data/*.js, /img, the never-served sample
// bundle, fetch-metadata and same-origin checks, and the 503 before the first snapshot.

import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { existsSync, mkdirSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { ConfigError, checkServeSafety, isLoopbackHost } from '../server/config.mjs';
import { decodeHeaderValue } from '../server/auth.mjs';
import { createDashboardServer } from '../server/server.mjs';
import { backfill } from '../server/refresh.mjs';
import { startMockWindsor } from './mock-windsor.mjs';
import { NOW, jpegBytes, makeConfig, noSleep, offlineFetch, pngBytes, quietLog, request, tempRoot } from './server-helpers.mjs';

const FINN = { 'tailscale-user-login': 'finn@groovstrategy.co', 'tailscale-user-name': 'Finn' };
const PAGE = { accept: 'text/html,application/xhtml+xml', 'sec-fetch-mode': 'navigate', 'sec-fetch-dest': 'document', 'sec-fetch-site': 'none' };

describe('settings guard', () => {
  it('knows loopback addresses', () => {
    for (const h of ['127.0.0.1', '127.1.2.3', '::1', '[::1]', 'localhost', '::ffff:127.0.0.1']) assert.equal(isLoopbackHost(h), true, h);
    for (const h of ['0.0.0.0', '::', '100.101.102.103', '192.168.1.10', 'example.com', '']) assert.equal(isLoopbackHost(h), false, h);
  });

  it('AUTH_MODE=none refuses to start on a non-loopback address; so does tailscale mode (headers could be forged)', async () => {
    const root = await tempRoot();
    for (const mode of ['none', 'tailscale']) {
      const config = makeConfig(root.dir, { AUTH_MODE: mode, HOST: '0.0.0.0' });
      assert.throws(() => checkServeSafety(config), (e) => e instanceof ConfigError && /HOST=0\.0\.0\.0 is not a loopback address/.test(e.message));
      assert.throws(() => createDashboardServer(config, { log: quietLog() }), ConfigError);
    }
    assert.doesNotThrow(() => checkServeSafety(makeConfig(root.dir, { AUTH_MODE: 'none', HOST: '127.0.0.1' })));
    assert.throws(() => makeConfig(root.dir, { AUTH_MODE: 'google' }), /AUTH_MODE must be "tailscale" or "none"/);
    await root.cleanup();
  });

  it('decodes RFC 2047 names the way Tailscale sends them', () => {
    assert.equal(decodeHeaderValue('=?utf-8?q?Fi=C3=B1n_Th=C3=A1i?='), 'Fiñn Thái');
    assert.equal(decodeHeaderValue('=?utf-8?b?4Lif4Li04LiZ?='), 'ฟิน');
    assert.equal(decodeHeaderValue('=?utf-8?q?A?= =?utf-8?q?B?='), 'AB');
    assert.equal(decodeHeaderValue('Plain Name'), 'Plain Name');
  });
});

describe('server over HTTP', () => {
  let mock;
  let root;
  let servers = [];
  let ts; // tailscale mode, allow-list + owner
  let open; // tailscale mode, any tailnet user
  let none; // AUTH_MODE=none
  let empty; // no snapshot yet

  async function start(env, { dataDir } = {}) {
    const config = makeConfig(root.dir, { WINDSOR_BASE_URL: mock.url, WINDSOR_API_KEY: mock.key, ...env, ...(dataDir ? { DATA_DIR: dataDir } : {}) });
    const app = createDashboardServer(config, { log: quietLog([mock.key]), imageFetchImpl: offlineFetch, sleep: noSleep });
    const { port } = await app.listen();
    servers.push({ app });
    return { app, config, base: `http://127.0.0.1:${port}` };
  }

  before(async () => {
    mock = await startMockWindsor();
    root = await tempRoot();
    const config = makeConfig(root.dir, { WINDSOR_BASE_URL: mock.url, WINDSOR_API_KEY: mock.key });
    const status = await backfill(config, { from: '2026-09-14', to: '2026-09-20', now: NOW, log: quietLog(), sleep: noSleep, imageFetchImpl: offlineFetch });
    assert.equal(status.state, 'ok', status.error);
    mkdirSync(join(config.dataDir, 'creatives', 'meta'), { recursive: true });
    mkdirSync(join(config.dataDir, 'creatives', 'tiktok'), { recursive: true });
    writeFileSync(join(config.dataDir, 'creatives', 'meta', '120249786888520484.jpg'), jpegBytes(800));
    writeFileSync(join(config.dataDir, 'creatives', 'tiktok', '1875842506466882.png'), pngBytes(800));
    writeFileSync(join(config.dataDir, 'creatives', 'meta', '555.jpg'), Buffer.from('<svg onload=alert(1)>'.padEnd(200, ' ')));
    ts = await start({ AUTH_MODE: 'tailscale', ALLOWED_USERS: 'finn@groovstrategy.co, Team@GROOVstrategy.co', OWNER_USERS: 'finn@groovstrategy.co' });
    open = await start({ AUTH_MODE: 'tailscale', ALLOWED_USERS: '', OWNER_USERS: '' });
    none = await start({ AUTH_MODE: 'none' });
    empty = await start({ AUTH_MODE: 'none' }, { dataDir: join(root.dir, 'empty-data') });
  });
  after(async () => {
    for (const s of servers) await s.app.close();
    await mock.close();
    await root.cleanup();
  });

  describe('AUTH_MODE=tailscale', () => {
    it('refuses a request without a Tailscale identity: 401 JSON for fetches, the login page for page loads', async () => {
      const api = await request(`${ts.base}/api/meta`);
      assert.equal(api.status, 401);
      assert.match(api.json().error, /Open this dashboard through its Tailscale address/);
      const curl = await request(`${ts.base}/`);
      assert.equal(curl.status, 401, 'a direct curl of / is refused');
      const page = await request(`${ts.base}/`, { headers: PAGE });
      assert.equal(page.status, 401);
      assert.match(page.headers['content-type'], /^text\/html/);
      assert.match(page.text, /Open this dashboard through your Tailscale address; your Tailscale account must be on the allow-list/);
      assert.ok(!/<script/i.test(page.text), 'the login page runs no script');
      assert.equal((await request(`${ts.base}/data/registry.js`)).status, 401);
      assert.equal((await request(`${ts.base}/img/meta/120249786888520484`)).status, 401);
    });

    it('serves an allowed user and says who they are on /api/session', async () => {
      const res = await request(`${ts.base}/api/session`, { headers: FINN });
      assert.equal(res.status, 200);
      assert.deepEqual(res.json(), { email: 'finn@groovstrategy.co', name: 'Finn', expires: null, owner: true, mode: 'tailscale' });
      const team = await request(`${ts.base}/api/session`, { headers: { 'tailscale-user-login': 'team@groovstrategy.co', 'tailscale-user-name': '=?utf-8?q?Tea=C3=B1m?=' } });
      assert.deepEqual(team.json(), { email: 'team@groovstrategy.co', name: 'Teañm', expires: null, owner: false, mode: 'tailscale' }, 'allow-list is case-insensitive');
      assert.equal((await request(`${ts.base}/api/meta`, { headers: FINN })).status, 200);
      assert.equal((await request(`${ts.base}/`, { headers: { ...FINN, ...PAGE } })).status, 200);
    });

    it('refuses a tailnet user who is not on ALLOWED_USERS (403), and Funnel requests', async () => {
      const other = { 'tailscale-user-login': 'stranger@gmail.com' };
      const api = await request(`${ts.base}/api/meta`, { headers: other });
      assert.equal(api.status, 403);
      assert.match(api.json().error, /stranger@gmail\.com\) is not on this dashboard's allow-list/);
      const page = await request(`${ts.base}/`, { headers: { ...other, ...PAGE } });
      assert.equal(page.status, 403);
      assert.match(page.text, /stranger@gmail\.com<\/b> is not on this dashboard's allow-list/);
      const funnel = await request(`${ts.base}/api/meta`, { headers: { ...FINN, 'tailscale-funnel-request': '?1' } });
      assert.equal(funnel.status, 403);
      const forged = await request(`${ts.base}/api/meta`, { headers: { 'tailscale-user-login': 'a@b.co, finn@groovstrategy.co' } });
      assert.equal(forged.status, 401, 'a doubled header is not an identity');
    });

    it('with ALLOWED_USERS empty, any tailnet user gets in (not as owner)', async () => {
      const res = await request(`${open.base}/api/session`, { headers: { 'tailscale-user-login': 'someone@github' } });
      assert.deepEqual(res.json(), { email: 'someone@github', name: null, expires: null, owner: false, mode: 'tailscale' });
    });

    it('lets only owners start a refresh, and only from the dashboard itself', async () => {
      const team = { 'tailscale-user-login': 'team@groovstrategy.co' };
      const notOwner = await request(`${ts.base}/api/refresh`, { method: 'POST', headers: { ...team, 'sec-fetch-site': 'same-origin' } });
      assert.equal(notOwner.status, 403);
      assert.match(notOwner.json().error, /Only the dashboard owner/);
      const crossSite = await request(`${ts.base}/api/refresh`, { method: 'POST', headers: { ...FINN, 'sec-fetch-site': 'cross-site', 'sec-fetch-mode': 'cors', origin: 'https://evil.example' } });
      assert.equal(crossSite.status, 403);
      const foreignOrigin = await request(`${ts.base}/api/refresh`, { method: 'POST', headers: { ...FINN, origin: 'https://evil.example' } });
      assert.equal(foreignOrigin.status, 403);
      assert.equal((await request(`${ts.base}/api/refresh`, { headers: team })).json().can_refresh, false);
      const ok = await request(`${ts.base}/api/refresh`, { method: 'POST', headers: { ...FINN, 'sec-fetch-site': 'same-origin', origin: ts.base } });
      assert.equal(ok.status, 202, ok.text);
      const status = await ts.app.lastRefresh;
      assert.equal(status.state, 'ok', status.error);
      assert.equal(status.requested_by, 'finn@groovstrategy.co');
    });

    it('/login.html is public and tells a signed-in user who they are', async () => {
      const anon = await request(`${ts.base}/login.html`);
      assert.equal(anon.status, 200);
      assert.match(anon.text, /Open this dashboard through your Tailscale address/);
      const me = await request(`${ts.base}/login.html`, { headers: FINN });
      assert.match(me.text, /Signed in via Tailscale as <b>finn@groovstrategy\.co<\/b>/);
      assert.equal((await request(`${ts.base}/assets/groov-logo.png`)).status, 200, 'the logo is public');
      assert.equal((await request(`${ts.base}/healthz`)).json().ok, true);
    });
  });

  describe('files and data scripts', () => {
    it('serves the dashboard with the security headers (self-only CSP, no Google sources)', async () => {
      const res = await request(`${none.base}/`, { headers: PAGE });
      assert.equal(res.status, 200);
      assert.match(res.text, /<title>GROOV Ads Command Center<\/title>/);
      const csp = res.headers['content-security-policy'];
      assert.match(csp, /default-src 'self'; script-src 'self';/);
      assert.ok(!csp.includes('google'), csp);
      assert.match(csp, /frame-ancestors 'none'/);
      assert.equal(res.headers['x-frame-options'], 'DENY');
      assert.equal(res.headers['x-content-type-options'], 'nosniff');
      assert.equal(res.headers['cross-origin-resource-policy'], 'same-origin');
      assert.equal(res.headers['cache-control'], 'private, no-cache');
      assert.ok(res.headers.etag);
      const again = await request(`${none.base}/`, { headers: { 'if-none-match': res.headers.etag } });
      assert.equal(again.status, 304);
    });

    it('compresses scripts and styles as the browser asks', async () => {
      const br = await request(`${none.base}/assets/js/app.js`, { headers: { 'accept-encoding': 'br' } });
      assert.equal(br.headers['content-encoding'], 'br');
      assert.equal(br.headers['content-type'], 'text/javascript; charset=utf-8');
      const plain = await request(`${none.base}/assets/js/app.js`);
      assert.equal(plain.headers['content-encoding'], undefined);
      assert.equal(br.text, plain.text);
      assert.equal((await request(`${none.base}/assets/app.css`, { headers: { 'accept-encoding': 'gzip' } })).headers['content-encoding'], 'gzip');
    });

    it('never serves data/sample.js (even if it exists), the Google sign-in files, dotfiles or paths outside public/', async () => {
      if (existsSync(join(none.config.publicDir, 'data', 'sample.js'))) assert.ok(true, 'the file exists here and must still be refused');
      for (const path of ['/data/sample.js', '/data/sample.json', '/data/SAMPLE.js', '/assets/login.js', '/assets/login.css', '/.env', '/assets/.DS_Store', '/data/other.js']) {
        const res = await request(`${none.base}${path}`);
        assert.equal(res.status, 404, path);
      }
      assert.equal((await request(`${none.base}/login.html`)).text.includes('gsi'), false, 'the built-in login page, not the Google one');
      assert.equal((await request(`${none.base}/..%2fpackage.json`)).status, 400);
      const dotted = await request(`${none.base}/assets/%2e%2e/%2e%2e/package.json`);
      assert.ok([400, 404].includes(dotted.status), `status ${dotted.status}`);
      assert.ok(!dotted.text.includes('"scripts"'), 'never a file outside public/');
    });

    it('serves /data/registry.js, learnings.js and modules.js', async () => {
      for (const name of ['registry', 'learnings', 'modules']) {
        const res = await request(`${none.base}/data/${name}.js`);
        assert.equal(res.status, 200, name);
        assert.equal(res.headers['content-type'], 'text/javascript; charset=utf-8');
        assert.match(res.text, new RegExp(`^window\\.GROOV_${name.toUpperCase()} = `));
      }
    });

    it('refuses cross-site sub-resource requests but allows a link to the dashboard', async () => {
      const script = await request(`${none.base}/data/registry.js`, { headers: { 'sec-fetch-site': 'cross-site', 'sec-fetch-mode': 'no-cors', 'sec-fetch-dest': 'script' } });
      assert.equal(script.status, 403);
      const img = await request(`${none.base}/img/meta/120249786888520484`, { headers: { 'sec-fetch-site': 'same-site', 'sec-fetch-mode': 'no-cors', 'sec-fetch-dest': 'image' } });
      assert.equal(img.status, 403);
      const link = await request(`${none.base}/`, { headers: { ...PAGE, 'sec-fetch-site': 'cross-site' } });
      assert.equal(link.status, 200);
    });

    it('/img serves saved creatives as images only, with a sandbox CSP and a 1-day private cache', async () => {
      const jpg = await request(`${none.base}/img/meta/120249786888520484`);
      assert.equal(jpg.status, 200);
      assert.equal(jpg.headers['content-type'], 'image/jpeg');
      assert.equal(jpg.headers['content-security-policy'], "default-src 'none'; sandbox");
      assert.equal(jpg.headers['cache-control'], 'private, max-age=86400');
      assert.equal(jpg.body.length, 800);
      assert.equal((await request(`${none.base}/img/meta/120249786888520484`, { headers: { 'if-none-match': jpg.headers.etag } })).status, 304);
      assert.equal((await request(`${none.base}/img/tiktok/1875842506466882`)).headers['content-type'], 'image/png');
      assert.equal((await request(`${none.base}/img/meta/555`)).headers['content-type'], 'application/octet-stream', 'not an image: never served as one');
      assert.equal((await request(`${none.base}/img/meta/999`)).status, 404);
      assert.equal((await request(`${none.base}/img/google/1`)).status, 400);
      assert.equal((await request(`${none.base}/img/meta/12a`)).status, 400);
    });

    it('answers 503 with what to do before the first snapshot, 404 for unknown API routes', async () => {
      const res = await request(`${empty.base}/api/meta`);
      assert.equal(res.status, 503);
      assert.match(res.json().error, /No data yet: the first data pull hasn't finished/);
      assert.equal((await request(`${empty.base}/api/rows?from=2026-09-14&to=2026-09-20`)).status, 503);
      assert.equal((await request(`${none.base}/api/config`)).status, 404);
      assert.equal((await request(`${none.base}/api/nope`)).status, 404);
    });

    it('/api/session in AUTH_MODE=none says so; DELETE answers 204; POST is not a thing here', async () => {
      assert.deepEqual((await request(`${none.base}/api/session`)).json(), { email: null, name: null, expires: null, owner: true, mode: 'none' });
      assert.equal((await request(`${none.base}/api/session`, { method: 'DELETE' })).status, 204);
      assert.equal((await request(`${none.base}/api/session`, { method: 'POST' })).status, 405);
      assert.equal((await request(`${none.base}/`, { method: 'PUT' })).status, 405);
    });
  });
});
