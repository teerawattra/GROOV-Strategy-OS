// The data job (lib/refresh.mjs + lib/creatives-job.mjs) end to end against the fake Sheets API and fake image
// CDNs, plus the scheduled and background functions. No network.
import { after, before, beforeEach, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { gunzipSync } from 'node:zlib';
import { meta, normalize } from '../lib/normalize.mjs';
import {
  CREATIVES_STORE,
  DATASET_STORE,
  MANIFEST_KEY,
  cleanupOldVersions,
  createMemoryStore,
  listSavedCreatives,
  memoryStoreFactory,
  newVersionId,
  readStatus,
  setStoreFactory,
  toArrayBuffer,
  versionTime,
  writeStatus,
} from '../lib/blobs-store.mjs';
import { bangkokDayMinus, downloadImage, isSafeImageUrl, pickImageCandidates, runImageJob, sniffImageType } from '../lib/creatives-job.mjs';
import { BACKGROUND_PATH, buildBreakdowns, datasetWarnings, factRowsByPlatform, runRefresh, shrinkProblems, triggerBackgroundRefresh } from '../lib/refresh.mjs';
import { breakdownsHealth, normaliseBreakdowns } from '../lib/breakdowns.mjs';
import { mintInternalToken, verifyInternalToken } from '../lib/session.mjs';
import { clearTokenCache, rowsToObjects } from '../lib/sheets.mjs';
import refreshData from '../netlify/functions/refresh-data.mjs';
import refreshBackground from '../netlify/functions/refresh-background.mjs';
import {
  AUDIENCE_HEADER,
  PLACEMENT_HEADER,
  SECRET,
  SHEET_IDS,
  TITLES,
  breakdownEnv,
  breakdownSpreadsheets,
  fakeGoogle,
  jpegBytes,
  pngBytes,
  sampleGrid,
  sampleRows,
  sampleSpreadsheets,
  sheetsEnv,
  syntheticBreakdownGrids,
} from './backend-fakes.mjs';

const CLOCK = Date.parse('2026-09-21T00:15:00Z'); // 07:15 Bangkok on 21 Sep, the morning after the sample ends
const SINCE = '2026-09-14';
const ENV = sheetsEnv();
const noSleep = { retry: { sleep: async () => {}, baseDelayMs: 0 } };
const TOKEN_MARK = 'SIGNED-TOKEN-123';
/** The /api/meta `breakdowns` block when neither optional Sheet is configured. */
const UNCONFIGURED = Object.fromEntries(['placement', 'audience'].map((kind) => [kind, {
  available: false, configured: false, rows: 0, first_date: null, last_date: null, spend_share_last_28d: null, all_meta_spend_share_last_28d: null,
  duplicates: 0, columns_missing: [], error: null,
}]));

// ---- sample sheets with image links on every row from SINCE on, plus six ads that exercise the failure paths ----

function adsInWindow(platform) {
  const grid = sampleGrid(platform);
  const [header, ...rows] = grid;
  const iDate = header.indexOf('date');
  const iAd = header.indexOf('ad_id');
  return [...new Set(rows.filter((r) => r[iDate] >= SINCE && r[iAd]).map((r) => r[iAd]))];
}
const META_ADS = adsInWindow('meta');
const TIKTOK_ADS = adsInWindow('tiktok');
const [EXPIRED, HTML, HUGE, REDIRECT_OK, REDIRECT_BAD, INSECURE, PRESAVED] = META_ADS;

function withImageUrls(platform, grid) {
  if (platform === 'google') return grid;
  const [header, ...rows] = grid;
  const col = header.indexOf(platform === 'meta' ? 'image_url' : 'video_thumbnail_url');
  const iDate = header.indexOf('date');
  const iAd = header.indexOf('ad_id');
  const out = [header];
  for (const row of rows) {
    const r = row.slice();
    if (r[iDate] >= SINCE && r[iAd]) {
      const id = r[iAd];
      r[col] = platform === 'tiktok'
        ? `https://p16-common-sign.fake-tiktokcdn.com/${id}/${r[iDate]}.image?x-signature=${TOKEN_MARK}`
        : id === INSECURE ? `http://insecure.fake-cdn.net/${id}.jpg` : `https://scontent.fake-cdn.net/v/${id}/${r[iDate]}.jpg?oh=${TOKEN_MARK}`;
    }
    out.push(r);
  }
  return out;
}

/** Image CDNs: JPEG / WebP by default; the special ads misbehave. Records every URL fetched. */
function imageCdn() {
  const fetched = [];
  const webp = (() => {
    const b = new Uint8Array(600).fill(3);
    b.set([0x52, 0x49, 0x46, 0x46, 0, 0, 0, 0, 0x57, 0x45, 0x42, 0x50]);
    return b;
  })();
  async function other(url) {
    fetched.push(url.href);
    if (url.hostname === 'p16-common-sign.fake-tiktokcdn.com') return new Response(webp, { headers: { 'content-type': 'image/webp' } });
    if (url.hostname === 'redirect-target.fake-cdn.net') return new Response(pngBytes(800), { headers: { 'content-type': 'image/png' } });
    if (url.hostname !== 'scontent.fake-cdn.net') return undefined;
    const id = url.pathname.split('/')[2];
    if (id === EXPIRED) return new Response('URL signature expired', { status: 403 });
    if (id === HTML) return new Response('<html>login</html>', { headers: { 'content-type': 'text/html' } });
    if (id === HUGE) return new Response(jpegBytes(64), { headers: { 'content-type': 'image/jpeg', 'content-length': String(6 * 1024 * 1024) } });
    if (id === REDIRECT_OK) return new Response(null, { status: 302, headers: { location: 'https://redirect-target.fake-cdn.net/final.png' } });
    if (id === REDIRECT_BAD) return new Response(null, { status: 302, headers: { location: 'http://127.0.0.1:9001/2018-06-01/runtime/invocation/next' } });
    return new Response(jpegBytes(1500), { headers: { 'content-type': 'image/jpeg' } });
  }
  return { other, fetched };
}

function captureLog() {
  const lines = [];
  const push = (...args) => lines.push(args.map(String).join(' '));
  return { lines, log: { log: push, warn: push, error: push } };
}

function setupJob(spreadsheets = sampleSpreadsheets(withImageUrls), googleOptions = {}) {
  const cdn = imageCdn();
  const google = fakeGoogle({ spreadsheets, other: cdn.other, ...googleOptions });
  const datasetStore = createMemoryStore('dataset');
  const creativesStore = createMemoryStore('creatives');
  const { lines, log } = captureLog();
  const run = (extra = {}) => runRefresh({
    datasetStore, creativesStore, env: ENV, fetchImpl: google.fetch, clock: () => CLOCK, trigger: 'schedule', log, sheetsOptions: noSleep, ...extra,
  });
  return { cdn, google, datasetStore, creativesStore, lines, run };
}

const readDataset = async (store, manifest) => JSON.parse(gunzipSync(Buffer.from(await store.get(manifest.keys.dataset, { type: 'arrayBuffer' }))).toString('utf8'));

beforeEach(() => clearTokenCache());

describe('runRefresh: Sheets -> normalise -> Blobs -> images', () => {
  it('writes the dataset, saves fresh creatives, marks them image: true and records the run', async () => {
    const job = setupJob();
    await job.creativesStore.set(`meta/${PRESAVED}`, toArrayBuffer(jpegBytes(200)), { metadata: { contentType: 'image/jpeg' } });
    const status = await job.run();

    assert.equal(status.state, 'ok', status.error);
    assert.equal(status.trigger, 'schedule');
    assert.equal(status.data.data_through, '2026-09-20');
    const candidates = META_ADS.length - 1 + TIKTOK_ADS.length; // all ads with links in the window, minus the pre-saved one
    assert.equal(status.images.candidates, candidates);
    assert.deepEqual(status.images.failures, { expired_or_gone: 1, not_image: 1, too_large: 1, unsafe_url: 2 });
    assert.equal(status.images.saved, candidates - 5);
    assert.equal(status.images.deferred, 0);

    // The pre-saved creative was not downloaded again; the insecure and the bad redirect target were never fetched.
    assert.ok(!job.cdn.fetched.some((u) => u.includes(`/${PRESAVED}/`)));
    assert.ok(!job.cdn.fetched.some((u) => u.startsWith('http://')));

    // Creatives store: keys and metadata.
    const saved = await listSavedCreatives(job.creativesStore);
    assert.equal(saved.size, candidates - 5 + 1);
    const redirected = await job.creativesStore.getWithMetadata(`meta/${REDIRECT_OK}`, { type: 'arrayBuffer' });
    assert.equal(redirected.metadata.contentType, 'image/png');
    assert.equal(redirected.metadata.sourceDate, '2026-09-20');
    assert.equal(redirected.metadata.source, 'refresh');
    const tiktok = await job.creativesStore.getWithMetadata(`tiktok/${TIKTOK_ADS[0]}`);
    assert.equal(tiktok.metadata.contentType, 'image/webp');

    // The manifest points at a dataset that equals normalize() with the final saved set.
    const manifest = await job.datasetStore.get(MANIFEST_KEY, { type: 'json' });
    assert.equal(manifest.version, status.data.version);
    const sheets = Object.fromEntries(['meta', 'tiktok', 'google'].map((p) => [p, sampleGrid(p)]));
    const expected = normalize(Object.fromEntries(Object.entries(sheets).map(([p, g]) => [p, withImageUrls(p, g)])), { savedCreatives: saved, mode: 'live', now: new Date(CLOCK) });
    // /api/meta = the main payload + the breakdown block, which says "not configured" here (no SHEET_ID_META_PLACEMENTS / _AUDIENCE)
    assert.deepEqual(manifest.meta, JSON.parse(JSON.stringify({ ...meta(expected), breakdowns: UNCONFIGURED })));
    assert.equal(manifest.keys.breakdowns, undefined, 'no breakdown Sheet, no breakdown blob');
    const stored = await readDataset(job.datasetStore, manifest);
    assert.deepEqual(stored.ads, JSON.parse(JSON.stringify(expected.ads)));
    const byKey = new Map(stored.ads.map((a) => [a.key, a]));
    assert.equal(byKey.get(`meta:${REDIRECT_OK}`).image, true);
    assert.equal(byKey.get(`meta:${EXPIRED}`).image_reason, 'not_saved');
    assert.equal(manifest.fact_rows.meta, factRowsByPlatform(expected).meta);

    // Nothing secret or URL-like in the logs or the stored status.
    const statusText = JSON.stringify(await readStatus(job.datasetStore));
    for (const text of [...job.lines, statusText]) {
      assert.ok(!text.includes(TOKEN_MARK), `leaked: ${text.slice(0, 120)}`);
      assert.ok(!/https?:\/\//.test(text), `URL in: ${text.slice(0, 120)}`);
      assert.ok(!text.includes('PRIVATE KEY'));
    }
  });

  it('keeps the cached data when a Sheet suddenly shrinks, unless forced', async () => {
    const job = setupJob();
    await job.datasetStore.setJSON(MANIFEST_KEY, { version: 'previous', fact_rows: { meta: 100_000, tiktok: 0, google: 0 } });
    const status = await job.run();
    assert.equal(status.state, 'error');
    assert.match(status.error, /The meta Sheet now has \d+ usable rows, down from 100000/);
    assert.equal((await job.datasetStore.get(MANIFEST_KEY, { type: 'json' })).version, 'previous', 'manifest untouched');
    const forced = await job.run({ force: true });
    assert.equal(forced.state, 'ok');
    assert.equal(forced.force, true);
  });

  it('skips while another run is in progress (lock), but not when that run is stale', async () => {
    const job = setupJob();
    await writeStatus(job.datasetStore, { state: 'running', started_at: new Date(CLOCK - 60_000).toISOString() });
    assert.deepEqual(await job.run(), { state: 'skipped', reason: 'already_running', started_at: new Date(CLOCK - 60_000).toISOString() });
    assert.equal(job.google.calls.length, 0);
    await writeStatus(job.datasetStore, { state: 'running', started_at: new Date(CLOCK - 30 * 60_000).toISOString() });
    assert.equal((await job.run()).state, 'ok');
  });

  it('records a Sheets failure and writes nothing else', async () => {
    const spreadsheets = sampleSpreadsheets(withImageUrls);
    delete spreadsheets[SHEET_IDS.tiktok];
    const job = setupJob(spreadsheets);
    const status = await job.run();
    assert.equal(status.state, 'error');
    assert.match(status.error, /TikTok Sheet was not found/);
    assert.equal(await job.datasetStore.get(MANIFEST_KEY), null);
    assert.equal((await readStatus(job.datasetStore)).state, 'error');
  });

  it('stops starting downloads at the deadline and leaves the rest for the next run', async () => {
    const job = setupJob();
    const status = await job.run({ budgetMs: -1 });
    assert.equal(status.state, 'ok');
    assert.equal(status.images.attempted, 0);
    assert.equal(status.images.deferred, status.images.candidates);
    assert.ok(status.images.candidates > 0);
  });
});

describe('runRefresh: the optional Meta breakdown Sheets', () => {
  const grids = syntheticBreakdownGrids();
  const bdEnv = { ...ENV, ...breakdownEnv() };
  const bdSheets = (extra = {}) => ({ ...sampleSpreadsheets(withImageUrls), ...breakdownSpreadsheets(grids), ...extra });
  const rowsOf = (grid) => rowsToObjects(grid).rows;
  const mainRows = () => Object.fromEntries(['meta', 'tiktok', 'google'].map((p) => [p, rowsOf(sampleGrid(p))]));
  const readBlob = async (store, key) => JSON.parse(gunzipSync(Buffer.from(await store.get(key, { type: 'arrayBuffer' }))).toString('utf8'));
  const manifestOf = (job) => job.datasetStore.get(MANIFEST_KEY, { type: 'json' });

  it('stores the breakdown dataset in the same version as the main dataset and puts its health into /api/meta', async () => {
    const job = setupJob(bdSheets());
    const status = await job.run({ env: bdEnv });
    assert.equal(status.state, 'ok', status.error);
    assert.deepEqual(status.warnings, []);

    const manifest = await manifestOf(job);
    assert.equal(manifest.keys.breakdowns, `v/${manifest.version}/breakdowns.json.gz`);
    assert.ok(manifest.keys.dataset.startsWith(`v/${manifest.version}/`) && manifest.keys.monthly.startsWith(`v/${manifest.version}/`));

    // the stored dataset is exactly what lib/breakdowns.mjs makes of the two Sheets and the main dataset
    const now = new Date(CLOCK);
    const main = normalize(mainRows(), { mode: 'live', now });
    const expected = normaliseBreakdowns({ placements: rowsOf(grids.placements), audience: rowsOf(grids.audience) }, { mode: 'live', now, main });
    const stored = await readBlob(job.datasetStore, manifest.keys.breakdowns);
    assert.deepEqual(stored, JSON.parse(JSON.stringify(expected)));
    assert.equal(stored.available.placement && stored.available.audience, true);
    assert.deepEqual(manifest.breakdown_rows, { placement: expected.placement_rows.length, audience: expected.audience_rows.length });
    assert.ok(manifest.sizes.breakdowns_gz > 0 && manifest.sizes.breakdowns_json > manifest.sizes.breakdowns_gz);

    // /api/meta: the usual fields untouched, plus `breakdowns`
    const health = breakdownsHealth(expected, main, { configured: { placements: true, audience: true } });
    assert.deepEqual(manifest.meta.breakdowns, JSON.parse(JSON.stringify(health)));
    assert.deepEqual(manifest.meta.breakdowns.placement, {
      available: true, configured: true, rows: grids.placements.length - 1, first_date: '2026-09-07', last_date: '2026-09-20',
      spend_share_last_28d: 1, all_meta_spend_share_last_28d: 1, duplicates: 0, columns_missing: [], error: null,
    });
    assert.equal(manifest.meta.breakdowns.audience.rows, grids.audience.length - 1);
    assert.deepEqual(Object.keys(manifest.meta).slice(0, 7), ['schema', 'mode', 'generated_at', 'sheets', 'data_through', 'history_from', 'creatives']);
    assert.equal(manifest.meta.data_through, '2026-09-20');

    // the status shows the counts, and the logs stay free of URLs and keys
    assert.deepEqual(status.data.breakdown_rows, manifest.breakdown_rows);
    assert.deepEqual(Object.keys(status.data.breakdown_sheets), ['placements', 'audience']);
    assert.ok(job.lines.some((l) => /refresh: breakdown sheets \(placements \d+ rows \/ 1 chunks, audience \d+ rows \/ 1 chunks\)/.test(l)));
    for (const text of [...job.lines, JSON.stringify(await readStatus(job.datasetStore))]) {
      assert.ok(!/https?:\/\//.test(text) && !text.includes('PRIVATE KEY') && !text.includes(TOKEN_MARK), text.slice(0, 120));
    }
  });

  it('writes the breakdown blob into EVERY version the run writes, so main and breakdowns always switch together', async () => {
    const job = setupJob(bdSheets());
    const status = await job.run({ env: bdEnv });
    assert.equal(status.state, 'ok', status.error);
    assert.ok(status.images.saved > 0, 'a second version is written once images are saved');
    const keys = (await job.datasetStore.list({ prefix: 'v/' })).blobs.map((b) => b.key);
    const versions = [...new Set(keys.map((k) => k.split('/')[1]))].sort();
    assert.equal(versions.length, 2, 'the data first, then the data again with the new images');
    for (const v of versions) {
      assert.deepEqual(keys.filter((k) => k.startsWith(`v/${v}/`)).map((k) => k.split('/')[2]).sort(), ['breakdowns.json.gz', 'dataset.json.gz', 'monthly.json']);
    }
    const [first, second] = await Promise.all(versions.map((v) => readBlob(job.datasetStore, `v/${v}/breakdowns.json.gz`)));
    assert.deepEqual(first, second, 'both versions carry the same breakdown dataset');
    // (the run's clock is fixed, so the two ids differ only in their random suffix: which one is current is read from the manifest)
    const manifest = await manifestOf(job);
    assert.ok(versions.includes(manifest.version));
    assert.equal(manifest.keys.breakdowns, `v/${manifest.version}/breakdowns.json.gz`, 'the current version points at its own copy');
    assert.equal(manifest.sizes.breakdowns_gz > 0, true);
    // so deleting the other version later can never take the current breakdown dataset with it
    assert.ok(await job.datasetStore.get(manifest.keys.breakdowns, { type: 'arrayBuffer' }));
    const other = versions.find((v) => v !== manifest.version);
    assert.equal(await cleanupOldVersions(job.datasetStore, { keepVersion: manifest.version, now: CLOCK + 3 * 3600_000 }), 3, 'the older version goes entirely');
    assert.equal(await job.datasetStore.get(`v/${other}/breakdowns.json.gz`), null);
    assert.ok(await job.datasetStore.get(manifest.keys.breakdowns, { type: 'arrayBuffer' }), 'the current one stays');
  });

  it('without SHEET_ID_META_PLACEMENTS / _AUDIENCE nothing is requested, no blob is written, and /api/meta says "not configured"', async () => {
    const job = setupJob(bdSheets()); // the Sheets exist, but the env vars do not point at them
    const status = await job.run();
    assert.equal(status.state, 'ok', status.error);
    const manifest = await manifestOf(job);
    assert.equal(manifest.keys.breakdowns, undefined);
    assert.equal(manifest.breakdown_rows, undefined);
    assert.deepEqual(manifest.meta.breakdowns, UNCONFIGURED);
    assert.ok(job.google.calls.every((c) => !c.url.includes(SHEET_IDS.placements) && !c.url.includes(SHEET_IDS.audience)));
    assert.deepEqual(status.warnings, []);
    assert.ok(job.lines.some((l) => l.includes('breakdown sheets (placements not configured, audience not configured)')));
    assert.equal((await job.datasetStore.list({ prefix: 'v/' })).blobs.some((b) => b.key.endsWith('breakdowns.json.gz')), false);
  });

  it('one Sheet that cannot be read switches only that breakdown off, with a fix-it warning; the refresh still succeeds', async () => {
    const spreadsheets = bdSheets();
    delete spreadsheets[SHEET_IDS.audience];
    const job = setupJob(spreadsheets);
    const status = await job.run({ env: bdEnv });
    assert.equal(status.state, 'ok', status.error);
    const manifest = await manifestOf(job);
    const stored = await readBlob(job.datasetStore, manifest.keys.breakdowns);
    assert.deepEqual(stored.available, { placement: true, audience: false });
    assert.deepEqual(manifest.meta.breakdowns.audience, { ...UNCONFIGURED.audience, configured: true, error: manifest.meta.breakdowns.audience.error });
    assert.match(manifest.meta.breakdowns.audience.error, /The Meta audience Sheet was not found\. Check SHEET_ID_META_AUDIENCE/);
    assert.equal(manifest.meta.breakdowns.placement.available, true);
    assert.ok(status.warnings.some((w) => /^audience: The Meta audience Sheet was not found\..* shows no audience splits until this is fixed\./.test(w)), status.warnings.join('\n'));
    assert.equal(manifest.meta.data_through, '2026-09-20', 'the main data is unaffected');
  });

  it('a Sheet that is not shared with the service account is explained, not fatal', async () => {
    const job = setupJob(bdSheets(), { override: (url) => (url.pathname.includes(SHEET_IDS.placements) ? new Response('{}', { status: 403 }) : undefined) });
    const status = await job.run({ env: bdEnv });
    assert.equal(status.state, 'ok', status.error);
    const manifest = await manifestOf(job);
    assert.match(manifest.meta.breakdowns.placement.error, /sheets-reader@groov-test\.iam\.gserviceaccount\.com.*Meta placements Sheet.*Share/);
    assert.equal(manifest.meta.breakdowns.placement.available, false);
    assert.equal(manifest.meta.breakdowns.audience.available, true);
    assert.equal((await readBlob(job.datasetStore, manifest.keys.breakdowns)).available.placement, false);
  });

  it('empty or header-only Sheets mean "not available yet": configured, no error, no blob', async () => {
    const job = setupJob(bdSheets({ ...breakdownSpreadsheets({ placements: [PLACEMENT_HEADER], audience: [AUDIENCE_HEADER] }) }));
    const status = await job.run({ env: bdEnv });
    assert.equal(status.state, 'ok', status.error);
    assert.deepEqual(status.warnings, []);
    const manifest = await manifestOf(job);
    assert.equal(manifest.keys.breakdowns, undefined);
    for (const kind of ['placement', 'audience']) assert.deepEqual(manifest.meta.breakdowns[kind], { ...UNCONFIGURED[kind], configured: true });
  });

  it('ignores a breakdown Sheet that is really the main Meta tab (key columns missing) and says so', async () => {
    const job = setupJob(bdSheets());
    const status = await job.run({ env: { ...bdEnv, SHEET_ID_META_PLACEMENTS: SHEET_IDS.meta, SHEET_TAB_META_PLACEMENTS: TITLES.meta } });
    assert.equal(status.state, 'ok', status.error);
    assert.ok(status.warnings.includes('placements: columns missing from the Sheet: publisher_platform, platform_position. The Sheet was ignored.'), status.warnings.join('\n'));
    const manifest = await manifestOf(job);
    assert.equal(manifest.meta.breakdowns.placement.available, false);
    assert.deepEqual(manifest.meta.breakdowns.placement.columns_missing, ['publisher_platform', 'platform_position']);
    assert.ok(manifest.meta.breakdowns.placement.rows > 2000, 'the rows that were read are still counted');
    assert.equal(manifest.meta.breakdowns.audience.available, true, 'the audience Sheet is unaffected');
  });

  it('works with the two breakdown Sheets as tabs of the Meta spreadsheet', async () => {
    const spreadsheets = bdSheets();
    spreadsheets[SHEET_IDS.meta] = { ...spreadsheets[SHEET_IDS.meta], tabs: { Placements: grids.placements, Audience: grids.audience } };
    const job = setupJob(spreadsheets);
    const env = { ...ENV, SHEET_ID_META_PLACEMENTS: SHEET_IDS.meta, SHEET_TAB_META_PLACEMENTS: 'Placements', SHEET_ID_META_AUDIENCE: SHEET_IDS.meta, SHEET_TAB_META_AUDIENCE: 'Audience' };
    const status = await job.run({ env });
    assert.equal(status.state, 'ok', status.error);
    assert.deepEqual(status.warnings, []);
    const manifest = await manifestOf(job);
    assert.deepEqual([manifest.meta.breakdowns.placement.available, manifest.meta.breakdowns.audience.available], [true, true]);
    assert.equal(manifest.meta.breakdowns.placement.rows, grids.placements.length - 1);
    assert.equal(manifest.meta.sheets.meta.rows, 2564, 'the first tab is still the main Meta Sheet');
  });

  it('forgetting the tab name of a breakdown Sheet inside the Meta spreadsheet is caught before anything is read', async () => {
    const job = setupJob(bdSheets());
    const status = await job.run({ env: { ...ENV, SHEET_ID_META_PLACEMENTS: SHEET_IDS.meta } });
    assert.equal(status.state, 'ok', status.error);
    const manifest = await manifestOf(job);
    assert.match(manifest.meta.breakdowns.placement.error, /SHEET_TAB_META_PLACEMENTS is not set/);
    assert.ok(status.warnings.some((w) => w.startsWith('placements: SHEET_TAB_META_PLACEMENTS is not set')));
  });

  it('warns when the Sheets cover too little of the Meta spend (an export that misses ad sets), without failing', async () => {
    const bySpend = new Map();
    for (const r of sampleRows('meta')) bySpend.set(r.adset_id, (bySpend.get(r.adset_id) ?? 0) + Number(r.spend || 0));
    const biggest = [...bySpend.entries()].sort((a, b) => b[1] - a[1]).slice(0, 25).map(([id]) => id);
    const partial = syntheticBreakdownGrids({ skipAdsets: biggest });
    const job = setupJob(bdSheets(breakdownSpreadsheets(partial)));
    const status = await job.run({ env: bdEnv });
    assert.equal(status.state, 'ok', status.error);
    const { placement } = (await manifestOf(job)).meta.breakdowns;
    assert.equal(placement.spend_share_last_28d, 1, 'the ad sets it has are complete');
    assert.ok(placement.all_meta_spend_share_last_28d < 0.9, String(placement.all_meta_spend_share_last_28d));
    assert.ok(status.warnings.some((w) => /^placements: the Sheet covers only \d+(\.\d)?% of the Meta spend of the last 28 days\./.test(w)), status.warnings.join('\n'));
  });

  it('a stalled export shows up in the share: the last day is missing from the Sheets', async () => {
    const stalled = syntheticBreakdownGrids({ skipDates: ['2026-09-20'] });
    const job = setupJob(bdSheets(breakdownSpreadsheets(stalled)));
    const status = await job.run({ env: bdEnv });
    assert.equal(status.state, 'ok', status.error);
    const { placement } = (await manifestOf(job)).meta.breakdowns;
    assert.equal(placement.last_date, '2026-09-19');
    assert.ok(placement.spend_share_last_28d < 1 && placement.spend_share_last_28d > 0.85, String(placement.spend_share_last_28d));
  });

  it('is not subject to the shrink safety valve: a smaller Sheet replaces the older one (the valve guards Sheets 1-3 only)', async () => {
    const job = setupJob(bdSheets());
    await job.datasetStore.setJSON(MANIFEST_KEY, { version: 'previous', fact_rows: { meta: 0, tiktok: 0, google: 0 }, breakdown_rows: { placement: 1_000_000, audience: 1_000_000 } });
    const status = await job.run({ env: bdEnv });
    assert.equal(status.state, 'ok', status.error);
  });

  it('buildBreakdowns never throws: unusable input leaves the breakdowns unavailable and says why', () => {
    const main = normalize(mainRows(), { mode: 'live', now: new Date(CLOCK) });
    const out = buildBreakdowns({ sheets: { placements: 'not an array' }, configured: { placements: true, audience: false }, errors: {}, stats: {} }, main, new Date(CLOCK));
    assert.equal(out.store, false);
    assert.deepEqual(out.bds.available, { placement: false, audience: false });
    assert.match(out.health.placement.error, /could not be processed \(TypeError: Sheet rows must be an array\)/);
    assert.equal(out.health.audience.error, null, 'a Sheet that is not configured gets no error');
    assert.ok(out.warnings.some((w) => w.startsWith('placements: ')));
  });
});

describe('image candidates and downloads', () => {
  const sheets = Object.fromEntries(['meta', 'tiktok', 'google'].map((p) => [p, sampleGrid(p)]));
  const withUrls = Object.fromEntries(Object.entries(sheets).map(([p, g]) => [p, withImageUrls(p, g)]));
  // Row objects like the Sheets reader produces.
  const asRows = (grid) => {
    const [header, ...rows] = grid;
    const out = rows.map((r) => Object.fromEntries(header.map((h, i) => [h, r[i] ?? ''])));
    Object.defineProperty(out, 'columns', { value: header, enumerable: false });
    return out;
  };
  const rowSheets = { meta: asRows(withUrls.meta), tiktok: asRows(withUrls.tiktok), google: asRows(withUrls.google) };

  it('picks the newest link per unsaved ad in the window, with keys that match the dataset', () => {
    const list = pickImageCandidates(rowSheets, { saved: new Set([`meta:${PRESAVED}`]), since: SINCE });
    assert.equal(list.length, META_ADS.length - 1 + TIKTOK_ADS.length);
    const ds = normalize(rowSheets, { mode: 'live', now: new Date(CLOCK) });
    const adKeys = new Set(ds.ads.map((a) => a.key));
    assert.ok(list.every((c) => adKeys.has(`${c.platform}:${c.adId}`)));
    assert.ok(list.every((c, i) => i === 0 || list[i - 1].date >= c.date), 'newest first');
    const one = list.find((c) => c.adId === REDIRECT_OK);
    assert.equal(one.date, '2026-09-20');
    assert.ok(one.url.includes('/2026-09-20.jpg'));
    assert.equal(pickImageCandidates(rowSheets, { since: '2026-09-21' }).length, 0, 'nothing newer than the window');
  });

  it('computes the 7-day window in Bangkok time', () => {
    assert.equal(bangkokDayMinus(new Date('2026-09-21T00:15:00Z'), 7), '2026-09-14');
    assert.equal(bangkokDayMinus(new Date('2026-09-20T18:00:00Z'), 7), '2026-09-14'); // 01:00 on 21 Sep in Bangkok
  });

  it('accepts only https URLs on public host names', () => {
    for (const ok of ['https://scontent.xx.fbcdn.net/v/t45/x.jpg?oh=1', 'https://p16-common-sign.tiktokcdn.com/a~tplv.image', 'https://cdn.example.com:443/a.jpg']) assert.equal(isSafeImageUrl(ok), true, ok);
    for (const bad of ['http://scontent.xx.fbcdn.net/x.jpg', 'https://127.0.0.1/x', 'https://2130706433/x', 'https://[::1]/x', 'https://localhost/x', 'https://intranet/x',
      'https://db.internal/x', 'https://cdn.example.com:8443/a.jpg', 'https://user:pw@cdn.example.com/x', 'file:///etc/passwd', 'not a url']) {
      assert.equal(isSafeImageUrl(bad), false, bad);
    }
  });

  it('sniffs only browser-renderable raster formats', () => {
    assert.equal(sniffImageType(jpegBytes(64)), 'image/jpeg');
    assert.equal(sniffImageType(pngBytes(64)), 'image/png');
    assert.equal(sniffImageType(new TextEncoder().encode('GIF89a......')), 'image/gif');
    assert.equal(sniffImageType(new TextEncoder().encode('<svg xmlns="http://www.w3.org/2000/svg"/>')), null);
    assert.equal(sniffImageType(new TextEncoder().encode('<!doctype html><html>')), null);
    assert.equal(sniffImageType(new Uint8Array([0xff, 0xd8])), null);
  });

  it('times out after the limit and caps streamed bodies without a Content-Length', async () => {
    const hang = (url, init) => new Promise((_, reject) => init.signal.addEventListener('abort', () => reject(init.signal.reason)));
    assert.deepEqual(await downloadImage('https://slow.example.com/x.jpg', { fetchImpl: hang, timeoutMs: 30 }), { ok: false, reason: 'timeout' });
    const endless = async () => new Response(new ReadableStream({
      pull(controller) { controller.enqueue(jpegBytes(64 * 1024)); },
    }), { headers: { 'content-type': 'image/jpeg' } });
    assert.deepEqual(await downloadImage('https://big.example.com/x.jpg', { fetchImpl: endless, maxBytes: 256 * 1024 }), { ok: false, reason: 'too_large' });
    let hops = 0;
    const loop = async () => {
      hops++;
      return new Response(null, { status: 302, headers: { location: `https://loop.example.com/${hops}` } });
    };
    assert.deepEqual(await downloadImage('https://loop.example.com/0', { fetchImpl: loop }), { ok: false, reason: 'too_many_redirects' });
    assert.equal(hops, 4);
  });

  it('runImageJob stores with metadata and counts failures by reason', async () => {
    const store = createMemoryStore();
    const fetchImpl = async (url) => (String(url).includes('bad') ? new Response('gone', { status: 410 }) : new Response(jpegBytes(900), { headers: { 'content-type': 'image/jpeg' } }));
    const { counts, savedKeys } = await runImageJob({
      store, fetchImpl, clock: () => CLOCK, concurrency: 2,
      candidates: [
        { platform: 'meta', adId: '1', url: 'https://cdn.example.com/good.jpg', date: '2026-09-20' },
        { platform: 'tiktok', adId: '2', url: 'https://cdn.example.com/bad.jpg', date: '2026-09-19' },
      ],
    });
    assert.deepEqual(savedKeys, ['meta:1']);
    assert.deepEqual({ ...counts, failures: { ...counts.failures } }, { candidates: 2, attempted: 2, saved: 1, failed: 1, deferred: 0, bytes: 900, failures: { expired_or_gone: 1 } });
    const entry = await store.getMetadata('meta/1');
    assert.deepEqual(entry.metadata, { contentType: 'image/jpeg', savedAt: new Date(CLOCK).toISOString(), sourceDate: '2026-09-20', bytes: 900, source: 'refresh' });
  });
});

describe('data-job helpers', () => {
  it('shrink guard ignores small sheets and normal growth', () => {
    assert.deepEqual(shrinkProblems(null, { meta: 0, tiktok: 0, google: 0 }), []);
    assert.deepEqual(shrinkProblems({ fact_rows: { meta: 80, tiktok: 5000, google: 100 } }, { meta: 0, tiktok: 5100, google: 50 }), []);
    assert.equal(shrinkProblems({ fact_rows: { meta: 5000, tiktok: 0, google: 0 } }, { meta: 2400, tiktok: 0, google: 0 }).length, 1);
  });

  it('warns about unreadable dates and IDs that lost precision', () => {
    const grid = sampleGrid('google').map((r, i) => (i === 0 ? r : [`14/09/2026`, ...r.slice(1)]));
    const ds = normalize({ meta: [], tiktok: [], google: grid }, { mode: 'live', now: new Date(CLOCK) });
    const warnings = datasetWarnings(ds, { meta: { unsafe_id_cells: 12 } });
    assert.ok(warnings.some((w) => /google: \d+ of \d+ rows have a date/.test(w)));
    assert.ok(warnings.some((w) => /meta: 12 ID cells are stored as numbers/.test(w)));
  });

  it('cleans up versions the manifest no longer uses once they are 2 hours old', async () => {
    const store = createMemoryStore();
    const old = newVersionId(new Date(CLOCK - 5 * 3600_000));
    const recent = newVersionId(new Date(CLOCK - 10 * 60_000));
    const current = newVersionId(new Date(CLOCK - 3 * 3600_000));
    for (const v of [old, recent, current]) {
      await store.set(`v/${v}/dataset.json.gz`, 'x');
      await store.set(`v/${v}/monthly.json`, '{}');
    }
    assert.equal(versionTime(old), CLOCK - 5 * 3600_000);
    assert.equal(await cleanupOldVersions(store, { keepVersion: current, now: CLOCK }), 2);
    assert.deepEqual((await store.list({ prefix: 'v/' })).blobs.map((b) => b.key.split('/')[1]).sort(), [current, current, recent, recent].sort());
  });
});

describe('scheduled function -> background function', () => {
  let savedEnv;
  let savedFetch;
  before(() => {
    savedEnv = { ...process.env };
    savedFetch = globalThis.fetch;
    Object.assign(process.env, ENV);
  });
  after(() => {
    for (const k of Object.keys(process.env)) if (!(k in savedEnv)) delete process.env[k];
    Object.assign(process.env, savedEnv);
    globalThis.fetch = savedFetch;
    setStoreFactory(null);
  });

  it('refresh-data posts a signed trigger to the background function on the site URL', async () => {
    const posts = [];
    globalThis.fetch = async (url, init) => {
      posts.push({ url: String(url), init });
      return new Response(null, { status: 202 });
    };
    setStoreFactory(memoryStoreFactory());
    await refreshData(new Request('https://ads.example.test/.netlify/functions/refresh-data', { method: 'POST', body: JSON.stringify({ next_run: '2026-10-13T00:15:00.000Z' }) }), { site: { url: 'https://ads.example.test' } });
    assert.equal(posts.length, 1);
    assert.equal(posts[0].url, `https://ads.example.test${BACKGROUND_PATH}`);
    const token = new Headers(posts[0].init.headers).get('x-groov-refresh');
    assert.equal(verifyInternalToken(token, { secret: SECRET, trigger: 'schedule' }), true);
    assert.deepEqual(JSON.parse(posts[0].init.body), { trigger: 'schedule', force: false, requested_by: null });
  });

  it('refresh-data records an error status when the background job cannot be reached', async () => {
    globalThis.fetch = async () => { throw new TypeError('fetch failed'); };
    const factory = memoryStoreFactory();
    setStoreFactory(factory);
    await refreshData(new Request('https://x.test/', { method: 'POST' }), { site: { url: 'https://ads.example.test' } });
    const status = await readStatus(factory(DATASET_STORE));
    assert.equal(status.state, 'error');
    assert.match(status.error, /could not start the background job/);
  });

  it('refresh-background ignores requests without a valid token and runs the job with one', async () => {
    const cdn = imageCdn();
    const google = fakeGoogle({ spreadsheets: sampleSpreadsheets(withImageUrls), other: cdn.other });
    globalThis.fetch = google.fetch;
    const factory = memoryStoreFactory();
    setStoreFactory(factory);
    const body = JSON.stringify({ trigger: 'manual', force: false, requested_by: 'finn@groovstrategy.co' });
    const call = (token) => refreshBackground(new Request(`https://ads.example.test${BACKGROUND_PATH}`, { method: 'POST', headers: { 'content-type': 'application/json', ...(token ? { 'x-groov-refresh': token } : {}) }, body }));

    await call(null);
    await call(mintInternalToken({ secret: SECRET, trigger: 'schedule' })); // signed for another trigger
    await call(mintInternalToken({ secret: `${SECRET}-other`, trigger: 'manual' }));
    assert.equal(await readStatus(factory(DATASET_STORE)), null, 'nothing ran');
    assert.equal(google.calls.length, 0);

    await call(mintInternalToken({ secret: SECRET, trigger: 'manual' }));
    const status = await readStatus(factory(DATASET_STORE));
    assert.equal(status.state, 'ok', status.error);
    assert.equal(status.trigger, 'manual');
    assert.equal(status.requested_by, 'finn@groovstrategy.co');
    assert.equal(status.data.data_through, '2026-09-20');
    assert.ok(await factory(DATASET_STORE).get(MANIFEST_KEY, { type: 'json' }));
    // The function runs on the real clock: the sample's September links are older than the 7-day window, so no
    // image is attempted (exactly what should happen to expired links).
    assert.equal(status.images.candidates, 0);
    assert.equal((await listSavedCreatives(factory(CREATIVES_STORE))).size, 0);
  });

  it('triggerBackgroundRefresh explains failures', async () => {
    assert.match((await triggerBackgroundRefresh({ baseUrl: '', trigger: 'schedule', env: ENV })).error, /site URL is unknown/);
    assert.match((await triggerBackgroundRefresh({ baseUrl: 'https://x.test', trigger: 'schedule', env: { ...ENV, SESSION_SECRET: '' } })).error, /SESSION_SECRET/);
    const refused = await triggerBackgroundRefresh({ baseUrl: 'https://x.test', trigger: 'schedule', env: ENV, fetchImpl: async () => new Response('no', { status: 404 }) });
    assert.deepEqual(refused, { ok: false, status: 404, error: 'The background job answered HTTP 404.' });
  });
});
