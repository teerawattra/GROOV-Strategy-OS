// The command line (server/cli.mjs) and settings (server/config.mjs): status (and that it never shows the key), env
// files the way systemd and `set -a; . file` read them, rollback, seed-creatives, build-static (tools/build_static.py,
// with and without python3), modules.js, and the exit codes.

import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { cpSync, existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { cleanValue, loadConfig, loadEnvFile, parseEnvFile } from '../server/config.mjs';
import { main } from '../server/cli.mjs';
import { readCurrent } from '../server/snapshot.mjs';
import { startMockWindsor } from './mock-windsor.mjs';
import { NOW, jpegBytes, makeConfig, noSleep, offlineFetch, quietLog, tempRoot } from './server-helpers.mjs';

const ROOT = fileURLToPath(new URL('..', import.meta.url));
const SECRET = 'FAKE-TEST-ONLY-CLI-SENTINEL-9f8e7d6c5b4a';

/** Run main() like the shell would, with the given environment; collects stdout lines and log lines. */
async function cli(argv, env, extra = {}) {
  const out = [];
  const log = quietLog([SECRET]);
  const code = await main(argv, { env: { ...env }, cwd: extra.cwd ?? ROOT, log, out: (s) => out.push(s), now: NOW, sleep: noSleep, imageFetchImpl: offlineFetch, ...extra });
  return { code, out: out.join('\n'), log: log.lines.map((l) => l.line).join('\n') };
}

function findRealConfig() {
  for (const base of [join(ROOT, 'config'), join(ROOT, '..')]) {
    const registry = join(base, 'accounts', 'registry.json');
    const learnings = join(base, 'learnings');
    if (existsSync(registry) && ['LOG.md', 'PLAYBOOK.md', 'rules.json'].every((f) => existsSync(join(learnings, f)))) return { registry, learnings };
  }
  return null;
}
const HAVE_PYTHON = spawnSync('python3', ['--version']).status === 0;

describe('settings', () => {
  it('parses env files like systemd and sh: comments on their own line, optional quotes and export', () => {
    const env = parseEnvFile([
      '# comment', '', 'A=1', 'export B="two words"', "C='x # not a comment'", 'D=   # empty, systemd would keep "# empty"', 'E=2025-10-01  # trailing note',
      'not a line', 'F=a=b',
    ].join('\n'));
    assert.deepEqual(env, { A: '1', B: 'two words', C: 'x # not a comment', D: '', E: '2025-10-01', F: 'a=b' });
    assert.equal(cleanValue('# anyone in the tailnet'), '', 'systemd passes inline comments through; the server drops them');
    assert.equal(cleanValue('2025-10-01  # how far back'), '2025-10-01');
  });

  it('GROOV_ENV_FILE never overrides what is already set, and reports names only', async () => {
    const root = await tempRoot();
    const file = join(root.dir, 'groov.env');
    writeFileSync(file, `PORT=9999\nTZ_REPORT=Asia/Bangkok\nWINDSOR_API_KEY=${SECRET}\n`);
    const env = { PORT: '8787' };
    const set = loadEnvFile(file, env);
    assert.deepEqual(set, ['TZ_REPORT', 'WINDSOR_API_KEY']);
    assert.equal(env.PORT, '8787');
    assert.throws(() => loadEnvFile(join(root.dir, 'missing.env'), {}), /GROOV_ENV_FILE points at/);
    await root.cleanup();
  });

  it('config/groov.env.example documents every setting and has no inline comments or real values', () => {
    const text = readFileSync(join(ROOT, 'config', 'groov.env.example'), 'utf8');
    for (const name of ['WINDSOR_API_KEY', 'MCP_WINDSOR_API_KEY', 'DATA_DIR', 'CONFIG_DIR', 'HOST', 'PORT', 'AUTH_MODE', 'ALLOWED_USERS', 'OWNER_USERS', 'TZ_REPORT',
      'REFRESH_DAYS', 'ENABLE_BREAKDOWNS', 'BACKFILL_FROM', 'GROOV_ENV_FILE', 'WINDSOR_BASE_URL', 'WINDSOR_CHUNK_DAYS', 'WINDSOR_MAX_ROWS', 'WINDSOR_TIMEOUT_MS', 'WINDSOR_CONCURRENCY', 'PYTHON']) {
      assert.match(text, new RegExp(`\\b${name}\\b`), name);
    }
    for (const line of text.split('\n')) {
      if (/^[A-Z_]+=/.test(line)) assert.ok(!/\s#/.test(line), `inline comment: ${line}`);
    }
    const values = parseEnvFile(text);
    assert.equal(values.WINDSOR_API_KEY, undefined, 'no key in the example');
    const config = loadConfig({ env: values, cwd: '/opt/data/groov-cc/app' });
    assert.equal(config.dataDir, '/opt/data/groov-cc/data');
    assert.equal(config.configDir, '/opt/data/groov-cc/config');
    assert.equal(config.host, '127.0.0.1');
    assert.equal(config.port, 8787);
    assert.equal(config.authMode, 'tailscale');
    assert.equal(config.refreshDays, 28);
    assert.equal(config.enableBreakdowns, true);
  });

  it('keeps the key off everything that can be printed', () => {
    const config = loadConfig({ env: { MCP_WINDSOR_API_KEY: SECRET }, cwd: ROOT });
    assert.equal(config.windsorKey, SECRET);
    assert.equal(config.keySource, 'MCP_WINDSOR_API_KEY');
    assert.ok(!JSON.stringify(config).includes(SECRET));
    assert.ok(!Object.keys(config).includes('windsorKey'));
    const placeholder = loadConfig({ env: { MCP_WINDSOR_API_KEY: 'replace_with_your_private_key' }, cwd: ROOT });
    assert.equal(placeholder.hasWindsorKey, false, 'the .env.example placeholder is not a key');
  });

  it('rejects bad values with a fix-it message', () => {
    assert.throws(() => loadConfig({ env: { PORT: 'http' } }), /PORT must be a whole number/);
    assert.throws(() => loadConfig({ env: { TZ_REPORT: 'Mars/Olympus' } }), /TZ_REPORT must be an IANA timezone/);
    assert.throws(() => loadConfig({ env: { BACKFILL_FROM: '01/10/2025' } }), /BACKFILL_FROM must be a date/);
    assert.throws(() => loadConfig({ env: { ENABLE_BREAKDOWNS: 'maybe' } }), /ENABLE_BREAKDOWNS must be 1 or 0/);
    assert.throws(() => loadConfig({ env: { WINDSOR_BASE_URL: 'http://connectors.windsor.ai' } }), /must use https/);
    assert.doesNotThrow(() => loadConfig({ env: { WINDSOR_BASE_URL: 'http://127.0.0.1:8790' } }));
  });
});

describe('commands', () => {
  let mock;
  let root;
  let env;

  before(async () => {
    mock = await startMockWindsor();
    root = await tempRoot();
    env = { DATA_DIR: join(root.dir, 'data'), CONFIG_DIR: join(root.dir, 'config'), WINDSOR_BASE_URL: mock.url, WINDSOR_API_KEY: mock.key, AUTH_MODE: 'tailscale' };
  });
  after(async () => {
    await mock.close();
    await root.cleanup();
  });

  it('backfill builds the first snapshot; status shows datasets, the snapshot and no secret', async () => {
    const b = await cli(['backfill', '--from', '2026-09-07', '--to', '2026-09-20'], env);
    assert.equal(b.code, 0, b.log);
    assert.match(b.log, /backfill: ok in .* · 70 days stored · snapshot \d{8}T\d{6}Z-[0-9a-f]{6} · data through 2026-09-20/);
    const s = await cli(['status'], { ...env, WINDSOR_API_KEY: SECRET });
    assert.equal(s.code, 0);
    assert.match(s.out, /Windsor key set \(WINDSOR_API_KEY\)/);
    assert.match(s.out, /meta {16}2026-09-07 {2}2026-09-20 {5}14 {5}2,564 {2}\d+ \/ ฿[\d,.]+ +complete/);
    assert.match(s.out, /meta_audience {7}2026-09-07 {2}2026-09-20 {5}14 {4}13,082/);
    assert.match(s.out, /current {6}\d{8}T\d{6}Z-[0-9a-f]{6} · built .* · data through 2026-09-20 · 2,930 fact rows · breakdowns 6,919 \+ 13,082 rows/);
    assert.match(s.out, /Last run {5}backfill ok/);
    assert.match(s.out, /Lock {9}free/);
    assert.ok(!s.out.includes(SECRET) && !s.log.includes(SECRET));
    assert.ok(!s.out.includes(mock.url));
  });

  it('status --json is machine-readable and lists what is missing in the last 60 days', async () => {
    const s = await cli(['status', '--json'], env);
    const j = JSON.parse(s.out);
    assert.equal(j.datasets.meta.partitions, 14);
    assert.equal(j.datasets.meta.rows, 2564);
    assert.equal(j.datasets.meta.last_day.date, '2026-09-20');
    assert.equal(j.datasets.google.missing_last_60_days.not_pulled.length, 0, 'window starts at the first stored day');
    assert.equal(j.complete_through, '2026-09-20');
    assert.equal(j.snapshot.current.data_through, '2026-09-20');
    assert.equal(j.creatives.total, 0);
  });

  it('status tells the first day Windsor had rows from the first day pulled', async () => {
    const b = await cli(['backfill', '--from', '2026-09-03', '--to', '2026-09-06', '--datasets', 'google'], env);
    assert.equal(b.code, 0, b.log);
    const j = JSON.parse((await cli(['status', '--json'], env)).out);
    assert.equal(j.datasets.google.first_date, '2026-09-03');
    assert.equal(j.datasets.google.first_date_with_rows, '2026-09-07');
    assert.equal(j.datasets.google.partitions, 18);
    assert.ok(j.datasets.google.missing_last_60_days.no_rows.every((d) => d >= '2026-09-07'), 'days before the history starts are not gaps');
    const s = await cli(['status'], env);
    assert.match(s.out, /google {14}2026-09-07 {2}2026-09-20 {5}18 {7}113 .*\(pulled from 2026-09-03; earlier days had no rows\)/);
  });

  it('refresh exits 0, keeps the previous snapshot as "previous", and rollback switches back', async () => {
    const before = (await readCurrent(env.DATA_DIR)).version;
    const r = await cli(['refresh', '--days', '7'], env);
    assert.equal(r.code, 0, r.log);
    const after1 = await readCurrent(env.DATA_DIR);
    assert.notEqual(after1.version, before);
    assert.equal(after1.previous, before);
    const s = await cli(['status'], env);
    assert.match(s.out, new RegExp(`previous {5}${before}`));
    assert.match(s.out, /roll back {4}node server\/cli\.mjs rollback/);
    const rb = await cli(['rollback'], env);
    assert.equal(rb.code, 0, rb.log);
    assert.match(rb.log, new RegExp(`rollback: now serving ${before} \\(was ${after1.version}\\)`));
    assert.equal((await readCurrent(env.DATA_DIR)).version, before);
    const fwd = await cli(['rollback', '--to', after1.version], env);
    assert.equal(fwd.code, 0);
    assert.equal((await readCurrent(env.DATA_DIR)).version, after1.version);
    assert.equal((await cli(['rollback', '--to', 'nope'], env)).code, 1);
  });

  it('seed-creatives copies the library and rebuilds the snapshot so the ads show their image', async () => {
    const lib = join(root.dir, 'library');
    mkdirSync(join(lib, 'meta'), { recursive: true });
    mkdirSync(join(lib, 'tiktok'), { recursive: true });
    writeFileSync(join(lib, 'meta', '120249786888520484.jpg'), jpegBytes(500));
    const r = await cli(['seed-creatives', 'library'], env, { cwd: root.dir });
    assert.equal(r.code, 0, r.log);
    assert.match(r.log, /seed-creatives: 1 files in the library \(meta 1, tiktok 0\) · 1 copied/);
    const s = JSON.parse((await cli(['status', '--json'], env)).out);
    assert.equal(s.creatives.meta, 1);
    assert.equal(s.snapshot.current.reason, 'seed-creatives');
    assert.equal((await cli(['seed-creatives', 'nowhere'], env, { cwd: root.dir })).code, 1, 'an empty folder is an error');
  });

  it('a second job while one runs exits 75 (systemd: SuccessExitStatus=75)', async () => {
    writeFileSync(join(env.DATA_DIR, 'refresh.lock'), JSON.stringify({ pid: process.pid, started_at: new Date().toISOString(), command: 'refresh' }));
    assert.equal((await cli(['refresh'], env)).code, 75);
    assert.equal((await cli(['snapshot'], env)).code, 75);
    const s = await cli(['status'], env);
    assert.match(s.out, /Lock {9}held by refresh/);
    writeFileSync(join(env.DATA_DIR, 'refresh.lock'), JSON.stringify({ pid: 999_999_999, started_at: new Date().toISOString(), command: 'refresh' }));
    assert.equal((await cli(['snapshot'], env)).code, 0, 'a lock left by a dead process is taken over');
  });

  it('usage errors exit 2 with the usage text', async () => {
    for (const argv of [['bogus'], ['refresh', '--days'], ['refresh', '--days', 'x'], ['backfill', '--from', '2026-13-01'], ['status', '--force'], ['seed-creatives']]) {
      const r = await cli(argv, env);
      assert.equal(r.code, 2, argv.join(' '));
    }
    assert.equal((await cli([], env)).code, 2);
    const help = await cli(['help'], env);
    assert.equal(help.code, 0);
    assert.match(help.out, /backfill --from YYYY-MM-DD/);
  });

  it('runs as a real process with the env loaded the way HERMES.md does (set -a; . env files; set +a)', () => {
    const dir = join(root.dir, 'shell');
    mkdirSync(dir, { recursive: true });
    writeFileSync(join(dir, 'secrets.env'), `MCP_WINDSOR_API_KEY=${SECRET}\n`);
    writeFileSync(join(dir, 'groov.env'), `DATA_DIR=${env.DATA_DIR}\nCONFIG_DIR=${env.CONFIG_DIR}\nALLOWED_USERS=            # empty = anyone\nBACKFILL_FROM=2026-09-07  # note\n`);
    // Only what a shell needs: no setting from the environment the tests run in (it may have groov.env loaded).
    const clean = { PATH: process.env.PATH, HOME: process.env.HOME ?? '/', LANG: process.env.LANG ?? 'C.UTF-8' };
    const run = spawnSync('/bin/sh', ['-c', `set -a; . "${join(dir, 'secrets.env')}"; . "${join(dir, 'groov.env')}"; set +a; "${process.execPath}" server/cli.mjs status`], { cwd: ROOT, env: clean, encoding: 'utf8' });
    assert.equal(run.status, 0, run.stderr);
    assert.match(run.stdout, /Windsor key set \(MCP_WINDSOR_API_KEY\)/);
    assert.ok(!run.stdout.includes(SECRET) && !run.stderr.includes(SECRET));
    const viaFile = spawnSync(process.execPath, ['server/cli.mjs', 'status', '--json'], { cwd: ROOT, env: { ...clean, GROOV_ENV_FILE: join(dir, 'groov.env') }, encoding: 'utf8' });
    assert.equal(viaFile.status, 0, viaFile.stderr);
    const j = JSON.parse(viaFile.stdout);
    assert.equal(j.config.backfill_from, '2026-09-07', 'the inline note is not part of the value');
    assert.equal(j.config.windsor_key, 'missing');
  });
});

describe('build-static', () => {
  const real = findRealConfig();

  it('writes registry.js and learnings.js with tools/build_static.py, and modules.js from config/modules.json', { skip: !real ? 'no registry / learning log to build from' : !HAVE_PYTHON ? 'python3 is not installed' : false }, async () => {
    const root = await tempRoot();
    const configDir = join(root.dir, 'config');
    mkdirSync(join(configDir, 'accounts'), { recursive: true });
    cpSync(real.registry, join(configDir, 'accounts', 'registry.json'));
    cpSync(real.learnings, join(configDir, 'learnings'), { recursive: true });
    writeFileSync(join(configDir, 'modules.json'), JSON.stringify({ modules: [{ id: 'ads', label: 'Ads', enabled: true, route: '#/overview' }, { id: 'kol', label: 'KOL', enabled: true, route: '#/kol' }] }));
    const r = await cli(['build-static'], { DATA_DIR: join(root.dir, 'data'), CONFIG_DIR: configDir });
    assert.equal(r.code, 0, r.log);
    assert.match(r.log, /registry python, learnings python, modules config/);
    const out = (n) => readFileSync(join(root.dir, 'data', 'static', n), 'utf8');
    assert.ok(out('registry.js').startsWith('window.GROOV_REGISTRY = '));
    assert.ok(out('learnings.js').startsWith('window.GROOV_LEARNINGS = '));
    assert.match(out('modules.js'), /"id":"kol","label":"KOL","enabled":true/);
    const registry = JSON.parse(readFileSync(real.registry, 'utf8'));
    const js = out('registry.js');
    assert.deepEqual(JSON.parse(js.slice(js.indexOf('=') + 1).trim().replace(/;\s*$/, '')), registry);
    await root.cleanup();
  });

  it('without python3: learnings fall back to the shipped public/data/learnings.js (with a warning), the registry is written from the JSON', { skip: !real ? 'no registry to build from' : false }, async () => {
    const root = await tempRoot();
    const configDir = join(root.dir, 'config');
    mkdirSync(join(configDir, 'accounts'), { recursive: true });
    cpSync(real.registry, join(configDir, 'accounts', 'registry.json'));
    cpSync(real.learnings, join(configDir, 'learnings'), { recursive: true });
    const r = await cli(['build-static'], { DATA_DIR: join(root.dir, 'data'), CONFIG_DIR: configDir, PYTHON: join(root.dir, 'no-such-python3') });
    assert.equal(r.code, 0, r.log);
    assert.match(r.log, /was not found, so the learning log could not be rebuilt: serving the learnings shipped in public\/data\/learnings\.js/);
    assert.match(r.log, /registry json, learnings shipped/);
    assert.equal(readFileSync(join(root.dir, 'data', 'static', 'learnings.js'), 'utf8'), readFileSync(join(ROOT, 'public', 'data', 'learnings.js'), 'utf8'));
    await root.cleanup();
  });

  it('without a config folder the shipped files are served (and said so)', async () => {
    const root = await tempRoot();
    const r = await cli(['build-static'], { DATA_DIR: join(root.dir, 'data'), CONFIG_DIR: join(root.dir, 'none') });
    assert.equal(r.code, 0);
    assert.match(r.log, /is missing; serving the registry and learnings shipped in public\/data/);
    assert.equal(readFileSync(join(root.dir, 'data', 'static', 'registry.js'), 'utf8'), readFileSync(join(ROOT, 'public', 'data', 'registry.js'), 'utf8'));
    await root.cleanup();
  });

  it('tools/build_static.py keeps its defaults and takes --registry / --learnings-dir / --out-dir', { skip: !HAVE_PYTHON ? 'python3 is not installed' : false }, () => {
    const help = spawnSync('python3', [join(ROOT, 'tools', 'build_static.py'), '--help'], { encoding: 'utf8' });
    assert.equal(help.status, 0);
    for (const flag of ['--registry', '--learnings-dir', '--out-dir']) assert.match(help.stdout, new RegExp(flag));
    assert.match(help.stdout, /default:\s+Ads\/accounts\/registry\.json/);
    assert.match(help.stdout, /default:\s+dashboard\/public\/data/);
  });
});
