// Route handlers with an in-memory Blobs store holding the normalised sample: /api/rows (auth, date validation,
// payload = sliceRows, compression, caching), /api/meta, /api/monthly, /img, /api/config, /api/refresh. No network.
import { after, before, beforeEach, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { brotliDecompressSync, gunzipSync } from 'node:zlib';
import { meta, monthly, normalize, sliceRows } from '../lib/normalize.mjs';
import { breakdownsHealth, normaliseBreakdowns, sliceBreakdowns } from '../lib/breakdowns.mjs';
import {
  CREATIVES_STORE,
  DATASET_STORE,
  MANIFEST_KEY,
  memoryStoreFactory,
  resetReadCaches,
  setStoreFactory,
  toArrayBuffer,
  writeDatasetVersion,
  writeStatus,
} from '../lib/blobs-store.mjs';
import { NO_DATA_MESSAGE } from '../lib/api-data.mjs';
import { bodyResponse, createLru, negotiateEncoding, prepareJsonBody, sameOrigin, validateRange } from '../lib/http.mjs';
import { mintSession, verifyInternalToken } from '../lib/session.mjs';
import { rowsToObjects } from '../lib/sheets.mjs';
import rowsHandler, { resetRowsCache } from '../netlify/functions/api-rows.mjs';
import metaHandler from '../netlify/functions/api-meta.mjs';
import monthlyHandler, { resetMonthlyCache } from '../netlify/functions/api-monthly.mjs';
import breakdownsHandler, { resetBreakdownsCache } from '../netlify/functions/api-breakdowns.mjs';
import imgHandler from '../netlify/functions/img.mjs';
import configHandler from '../netlify/functions/api-config.mjs';
import { createRefreshHandler } from '../netlify/functions/api-refresh.mjs';
import { SECRET, jpegBytes, loadSampleSheets, sheetsEnv, syntheticBreakdownGrids } from './backend-fakes.mjs';

const ENV = sheetsEnv();
const BASE = 'https://ads.example.test';
const NOW = new Date('2026-10-12T00:05:00Z');
const dataset = normalize(loadSampleSheets(), { mode: 'live', now: NOW });
const FIRST = dataset.rows[0][0];
const LAST = dataset.rows.at(-1)[0];

let factory;
let savedEnv;
const cookieFor = (email) => `groov_session=${mintSession(email, { secret: SECRET, now: Date.now() }).token}`;
const FINN = cookieFor('finn@groovstrategy.co');
const FRIEND = cookieFor('friend.of.groov@gmail.com');
const get = (path, { cookie = FINN, headers = {} } = {}) => new Request(`${BASE}${path}`, { headers: { ...(cookie ? { cookie } : {}), ...headers } });

async function bodyJson(res) {
  const buf = Buffer.from(await res.arrayBuffer());
  const enc = res.headers.get('content-encoding');
  const text = enc === 'br' ? brotliDecompressSync(buf) : enc === 'gzip' ? gunzipSync(buf) : buf;
  return JSON.parse(text.toString('utf8'));
}

async function publish() {
  return writeDatasetVersion(factory(DATASET_STORE), {
    dataset, metaPayload: meta(dataset), monthlyPayload: monthly(dataset), now: NOW, extra: { fact_rows: { meta: 1, tiktok: 1, google: 1 } },
  });
}

before(() => {
  savedEnv = { ...process.env };
  Object.assign(process.env, ENV);
  delete process.env.API_COMPRESSION;
});
after(() => {
  for (const k of Object.keys(process.env)) if (!(k in savedEnv)) delete process.env[k];
  Object.assign(process.env, savedEnv);
  setStoreFactory(null);
});
beforeEach(() => {
  factory = memoryStoreFactory();
  setStoreFactory(factory);
  resetReadCaches();
  resetRowsCache();
  resetMonthlyCache();
  resetBreakdownsCache();
});

describe('/api/rows', () => {
  it('401 without a session cookie, or with a forged one', async () => {
    await publish();
    const res = await rowsHandler(get(`/api/rows?from=${FIRST}&to=${LAST}`, { cookie: null }));
    assert.equal(res.status, 401);
    assert.deepEqual(await res.json(), { error: 'Not signed in.' });
    // Flip a character in the MIDDLE of the signature: that always changes the MAC bytes. (Flipping the last
    // character is not a forgery test: its 2 low bits are padding, see the canonical-encoding test.)
    const at = FINN.indexOf('.') + 10;
    const forged = FINN.slice(0, at) + (FINN[at] === 'A' ? 'B' : 'A') + FINN.slice(at + 1);
    assert.equal((await rowsHandler(get(`/api/rows?from=${FIRST}&to=${LAST}`, { cookie: forged }))).status, 401);
    assert.equal((await rowsHandler(get(`/api/rows?from=${FIRST}&to=${LAST}`, { cookie: cookieFor('stranger@gmail.com') }))).status, 401);
  });

  it('401 for a non-canonical spelling of a valid signature (same MAC bytes, different text)', async () => {
    await publish();
    const ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
    const last = FINN[FINN.length - 1];
    const twin = ALPHABET[ALPHABET.indexOf(last) ^ 1]; // differs only in a padding bit
    const variant = FINN.slice(0, -1) + twin;
    assert.notEqual(variant, FINN);
    assert.equal((await rowsHandler(get(`/api/rows?from=${FIRST}&to=${LAST}`, { cookie: variant }))).status, 401);
  });

  it('validates the dates: required, real, ordered, at most 800 days', async () => {
    await publish();
    const cases = [
      ['', /Both from and to are required/],
      [`?from=${FIRST}`, /Both from and to are required/],
      ['?from=2026-9-1&to=2026-09-20', /from must be a real date/],
      ['?from=2026-09-01&to=20260920', /to must be a real date/],
      ['?from=2026-02-30&to=2026-03-01', /from must be a real date/],
      ['?from=2026-09-20&to=2026-09-01', /from must be on or before to/],
      ['?from=2024-07-12&to=2026-09-20', /801 days requested, the maximum is 800/],
      ['?from=<script>&to=x', /from must be a real date/],
    ];
    for (const [query, pattern] of cases) {
      const res = await rowsHandler(get(`/api/rows${query}`));
      assert.equal(res.status, 400, query);
      assert.match((await res.json()).error, pattern, query);
    }
    assert.equal((await rowsHandler(get('/api/rows?from=2024-07-13&to=2026-09-20'))).status, 200, '800 days inclusive is allowed');
  });

  it('returns exactly sliceRows(dataset, from, to), brotli-compressed, private and uncached', async () => {
    const manifest = await publish();
    const res = await rowsHandler(get(`/api/rows?from=${FIRST}&to=${LAST}`, { headers: { 'accept-encoding': 'gzip, deflate, br, zstd' } }));
    assert.equal(res.status, 200);
    assert.equal(res.headers.get('content-encoding'), 'br');
    assert.equal(res.headers.get('content-type'), 'application/json; charset=utf-8');
    assert.equal(res.headers.get('cache-control'), 'private, no-store');
    assert.equal(res.headers.get('x-content-type-options'), 'nosniff');
    assert.equal(res.headers.get('x-data-version'), manifest.version);
    const payload = await bodyJson(res);
    assert.deepEqual(payload, JSON.parse(JSON.stringify(sliceRows(dataset, FIRST, LAST))));
    assert.equal(payload.rows.length, dataset.rows.length);
    assert.equal(payload.mode, 'live');
  });

  it('serves a sub-range with re-indexed entities; gzip and identity encodings too', async () => {
    await publish();
    const expected = JSON.parse(JSON.stringify(sliceRows(dataset, '2026-09-14', '2026-09-20')));
    const gz = await rowsHandler(get('/api/rows?from=2026-09-14&to=2026-09-20', { headers: { 'accept-encoding': 'gzip' } }));
    assert.equal(gz.headers.get('content-encoding'), 'gzip');
    assert.deepEqual(await bodyJson(gz), expected);
    const plain = await rowsHandler(get('/api/rows?from=2026-09-14&to=2026-09-20'));
    assert.equal(plain.headers.get('content-encoding'), null);
    assert.deepEqual(await plain.json(), expected);
    const refused = await rowsHandler(get('/api/rows?from=2026-09-14&to=2026-09-20', { headers: { 'accept-encoding': 'br;q=0, gzip;q=0' } }));
    assert.equal(refused.headers.get('content-encoding'), null);
    const outside = await bodyJson(await rowsHandler(get('/api/rows?from=2020-01-01&to=2020-01-31')));
    assert.deepEqual([outside.rows.length, outside.campaigns.length, outside.range], [0, 0, { from: '2020-01-01', to: '2020-01-31' }]);
  });

  it('loads the dataset blob once per instance and version, and repeats come from the LRU', async () => {
    await publish();
    const store = factory(DATASET_STORE);
    await rowsHandler(get(`/api/rows?from=${FIRST}&to=${LAST}`));
    const reads = store.calls.get;
    await rowsHandler(get(`/api/rows?from=${FIRST}&to=${LAST}`));
    await rowsHandler(get('/api/rows?from=2026-09-10&to=2026-09-12'));
    assert.ok(store.calls.get - reads <= 2, 'only manifest checks, no second dataset download');
    await publish(); // a refresh writes a new version
    resetReadCaches();
    const res = await rowsHandler(get('/api/rows?from=2026-09-10&to=2026-09-12'));
    assert.equal(res.status, 200);
  });

  it('503 with a clear message before the first refresh; 405 for POST', async () => {
    const res = await rowsHandler(get(`/api/rows?from=${FIRST}&to=${LAST}`));
    assert.equal(res.status, 503);
    assert.equal((await res.json()).error, NO_DATA_MESSAGE);
    assert.equal((await rowsHandler(new Request(`${BASE}/api/rows`, { method: 'POST', headers: { cookie: FINN } }))).status, 405);
  });
});

// ---- the optional Meta breakdown Sheets, derived from the sample so they reconcile with Sheet 1 ----

const rowsOf = (grid) => rowsToObjects(grid).rows;
const breakdownDatasetFor = (grids, main = dataset) => normaliseBreakdowns({ placements: rowsOf(grids.placements), audience: rowsOf(grids.audience) }, { mode: 'live', now: NOW, main });
const bds = breakdownDatasetFor(syntheticBreakdownGrids());
const healthOf = (b, main = dataset) => breakdownsHealth(b, main, { configured: { placements: true, audience: true } });

/** A version with the main dataset and (optionally) its breakdown dataset, like the data job writes it. */
async function publishBreakdowns(b = bds, { main = dataset, at = NOW } = {}) {
  return writeDatasetVersion(factory(DATASET_STORE), {
    dataset: main, metaPayload: { ...meta(main), ...(b ? { breakdowns: healthOf(b, main) } : {}) }, monthlyPayload: monthly(main), breakdowns: b, now: at,
  });
}

describe('/api/breakdowns', () => {
  const range = `from=${FIRST}&to=${LAST}`;

  it('401 without a session cookie, with a forged one, or for an account that is no longer on the allow-list', async () => {
    await publishBreakdowns();
    const res = await breakdownsHandler(get(`/api/breakdowns?${range}`, { cookie: null }));
    assert.equal(res.status, 401);
    assert.deepEqual(await res.json(), { error: 'Not signed in.' });
    const at = FINN.indexOf('.') + 10;
    const forged = FINN.slice(0, at) + (FINN[at] === 'A' ? 'B' : 'A') + FINN.slice(at + 1);
    assert.equal((await breakdownsHandler(get(`/api/breakdowns?${range}`, { cookie: forged }))).status, 401);
    assert.equal((await breakdownsHandler(get(`/api/breakdowns?${range}`, { cookie: cookieFor('stranger@gmail.com') }))).status, 401);
    assert.equal((await breakdownsHandler(get(`/api/breakdowns?${range}`, { cookie: FRIEND }))).status, 200, 'an allow-listed non-owner may read');
  });

  it('validates the dates exactly like /api/rows: required, real, ordered, at most 800 days', async () => {
    await publishBreakdowns();
    const cases = [
      ['', /Both from and to are required/],
      [`?from=${FIRST}`, /Both from and to are required/],
      ['?from=2026-9-1&to=2026-09-20', /from must be a real date/],
      ['?from=2026-09-01&to=20260920', /to must be a real date/],
      ['?from=2026-02-30&to=2026-03-01', /from must be a real date/],
      ['?from=2026-09-20&to=2026-09-01', /from must be on or before to/],
      ['?from=2024-07-12&to=2026-09-20', /801 days requested, the maximum is 800/],
      ['?from=<script>&to=x', /from must be a real date/],
    ];
    for (const [query, pattern] of cases) {
      const res = await breakdownsHandler(get(`/api/breakdowns${query}`));
      assert.equal(res.status, 400, query);
      assert.match((await res.json()).error, pattern, query);
      const asRows = await rowsHandler(get(`/api/rows${query}`));
      assert.equal(asRows.status, 400);
      assert.equal((await asRows.json()).error, (await (await breakdownsHandler(get(`/api/breakdowns${query}`))).json()).error, 'the same message as /api/rows');
    }
    assert.equal((await breakdownsHandler(get('/api/breakdowns?from=2024-07-13&to=2026-09-20'))).status, 200, '800 days inclusive is allowed');
  });

  it('returns exactly sliceBreakdowns(bds, from, to): brotli-compressed, private and uncached', async () => {
    const manifest = await publishBreakdowns();
    const res = await breakdownsHandler(get(`/api/breakdowns?${range}`, { headers: { 'accept-encoding': 'gzip, deflate, br, zstd' } }));
    assert.equal(res.status, 200);
    assert.equal(res.headers.get('content-encoding'), 'br');
    assert.equal(res.headers.get('content-type'), 'application/json; charset=utf-8');
    assert.equal(res.headers.get('cache-control'), 'private, no-store');
    assert.equal(res.headers.get('x-content-type-options'), 'nosniff');
    assert.equal(res.headers.get('x-data-version'), manifest.version);
    const payload = await bodyJson(res);
    assert.deepEqual(payload, JSON.parse(JSON.stringify(sliceBreakdowns(bds, FIRST, LAST))));
    assert.deepEqual(Object.keys(payload), ['schema', 'mode', 'range', 'available', 'adsets', 'placements', 'audiences', 'cols', 'placement_rows', 'audience_rows', 'coverage']);
    assert.equal(payload.mode, 'live');
    assert.deepEqual(payload.available, { placement: true, audience: true });
    assert.deepEqual(payload.range, { from: FIRST, to: LAST });
    assert.ok(payload.placement_rows.length > 1000 && payload.audience_rows.length > 1000);
    // the share comes from the spend stored with the breakdowns: no main dataset was loaded for this route
    assert.deepEqual(payload.coverage.placement.spend_share, 1);
    assert.equal(payload.coverage.placement.rows, payload.placement_rows.length);
    assert.equal(factory(DATASET_STORE).entries.get(manifest.keys.dataset) !== undefined, true);
    assert.equal(factory(DATASET_STORE).calls.get <= 3, true, 'manifest, then the breakdown blob only');
  });

  it('joins the rows payload on adsets[].key: every ad set is a "meta:<id>" key that /api/rows knows for the same range', async () => {
    await publishBreakdowns();
    const payload = await bodyJson(await breakdownsHandler(get(`/api/breakdowns?${range}`)));
    const rows = await bodyJson(await rowsHandler(get(`/api/rows?${range}`)));
    const known = new Set(rows.adsets.map((a) => a.key));
    assert.ok(payload.adsets.length > 50);
    for (const a of payload.adsets) assert.ok(known.has(a.key), a.key);
    assert.ok(payload.adsets.every((a) => a.key === `meta:${a.id}` && /^\d+$/.test(a.account_id)));
  });

  it('serves a sub-range with re-indexed entities; gzip and identity encodings too', async () => {
    await publishBreakdowns();
    const expected = JSON.parse(JSON.stringify(sliceBreakdowns(bds, '2026-09-14', '2026-09-20')));
    const gz = await breakdownsHandler(get('/api/breakdowns?from=2026-09-14&to=2026-09-20', { headers: { 'accept-encoding': 'gzip' } }));
    assert.equal(gz.headers.get('content-encoding'), 'gzip');
    assert.deepEqual(await bodyJson(gz), expected);
    const plain = await breakdownsHandler(get('/api/breakdowns?from=2026-09-14&to=2026-09-20'));
    assert.equal(plain.headers.get('content-encoding'), null);
    assert.deepEqual(await plain.json(), expected);
    const refused = await breakdownsHandler(get('/api/breakdowns?from=2026-09-14&to=2026-09-20', { headers: { 'accept-encoding': 'br;q=0, gzip;q=0' } }));
    assert.equal(refused.headers.get('content-encoding'), null);
    const whole = JSON.parse(JSON.stringify(sliceBreakdowns(bds, FIRST, LAST)));
    assert.ok(expected.placement_rows.length < whole.placement_rows.length && expected.adsets.length <= whole.adsets.length);
    const outside = await bodyJson(await breakdownsHandler(get('/api/breakdowns?from=2020-01-01&to=2020-01-31')));
    assert.deepEqual([outside.placement_rows.length, outside.audience_rows.length, outside.adsets.length, outside.range], [0, 0, 0, { from: '2020-01-01', to: '2020-01-31' }]);
    assert.deepEqual(outside.available, { placement: true, audience: true }, 'the Sheets exist; the range is just empty');
    assert.deepEqual(outside.coverage.placement, { first_date: null, last_date: null, rows: 0, spend_share: null }, 'no Sheet 1 spend in that range either, so no share');
  });

  it('downloads the breakdown blob once per instance and version; repeats come from the LRU', async () => {
    await publishBreakdowns();
    const store = factory(DATASET_STORE);
    await breakdownsHandler(get(`/api/breakdowns?${range}`));
    const reads = store.calls.get;
    await breakdownsHandler(get(`/api/breakdowns?${range}`));
    await breakdownsHandler(get('/api/breakdowns?from=2026-09-10&to=2026-09-12'));
    assert.ok(store.calls.get - reads <= 2, 'only manifest checks, no second blob download');
    await publishBreakdowns(bds, { at: new Date(NOW.getTime() + 60_000) }); // a refresh writes a new version
    resetReadCaches();
    const res = await breakdownsHandler(get('/api/breakdowns?from=2026-09-10&to=2026-09-12'));
    assert.equal(res.status, 200);
  });

  it('with no breakdown Sheet configured: 200, available false / false and empty arrays, never an error', async () => {
    const manifest = await publishBreakdowns(null);
    assert.equal(manifest.keys.breakdowns, undefined);
    assert.equal(manifest.meta.breakdowns, undefined, 'this manifest knows nothing about breakdowns, like one written before they existed');
    const res = await breakdownsHandler(get(`/api/breakdowns?${range}`, { headers: { 'accept-encoding': 'br' } }));
    assert.equal(res.status, 200);
    assert.equal(res.headers.get('x-data-version'), manifest.version);
    const payload = await bodyJson(res);
    assert.deepEqual(payload, {
      schema: 1, mode: 'live', range: { from: FIRST, to: LAST }, available: { placement: false, audience: false },
      adsets: [], placements: [], audiences: [],
      cols: ['date', 'adset', 'segment', 'spend', 'impressions', 'clicks', 'link_clicks', 'video_views', 'messages', 'leads'],
      placement_rows: [], audience_rows: [],
      coverage: {
        placement: { first_date: null, last_date: null, rows: 0, spend_share: null },
        audience: { first_date: null, last_date: null, rows: 0, spend_share: null },
      },
    });
    // the same rules still apply: a session, valid dates
    assert.equal((await breakdownsHandler(get(`/api/breakdowns?${range}`, { cookie: null }))).status, 401);
    assert.equal((await breakdownsHandler(get('/api/breakdowns?from=nope&to=nope'))).status, 400);
    assert.equal((await breakdownsHandler(get('/api/breakdowns'))).status, 400);
  });

  it('mode follows the manifest ("sample" stays "sample") when there is nothing to serve', async () => {
    await writeDatasetVersion(factory(DATASET_STORE), { dataset: { ...dataset, mode: 'sample' }, metaPayload: meta(dataset), monthlyPayload: monthly(dataset), now: NOW });
    assert.equal((await bodyJson(await breakdownsHandler(get(`/api/breakdowns?${range}`)))).mode, 'sample');
  });

  it('503 with a clear message before the first refresh; 405 for POST', async () => {
    const res = await breakdownsHandler(get(`/api/breakdowns?${range}`));
    assert.equal(res.status, 503);
    assert.equal((await res.json()).error, NO_DATA_MESSAGE);
    assert.equal((await breakdownsHandler(new Request(`${BASE}/api/breakdowns`, { method: 'POST', headers: { cookie: FINN } }))).status, 405);
  });

  it('a missing blob is a generic 500 (no internals), and the next request tries again', async () => {
    const manifest = await publishBreakdowns();
    const store = factory(DATASET_STORE);
    const saved = store.entries.get(manifest.keys.breakdowns);
    store.entries.delete(manifest.keys.breakdowns);
    const originalError = console.error;
    const logged = [];
    console.error = (...args) => logged.push(args.join(' '));
    try {
      const res = await breakdownsHandler(get(`/api/breakdowns?${range}`));
      assert.equal(res.status, 500);
      assert.match((await res.json()).error, /^Something went wrong on the server\./);
      assert.ok(logged.some((l) => l.includes('breakdowns blob') && l.includes('is missing')));
    } finally {
      console.error = originalError;
    }
    store.entries.set(manifest.keys.breakdowns, saved);
    assert.equal((await breakdownsHandler(get(`/api/breakdowns?${range}`))).status, 200, 'the failed load was not cached');
  });

  it('/api/meta carries the breakdowns health block of the same version', async () => {
    const manifest = await publishBreakdowns();
    const res = await metaHandler(get('/api/meta'));
    const payload = await bodyJson(res);
    assert.equal(res.headers.get('x-data-version'), manifest.version);
    assert.deepEqual(payload.breakdowns, JSON.parse(JSON.stringify(healthOf(bds))));
    assert.equal(payload.breakdowns.placement.available, true);
    assert.deepEqual(Object.keys(payload).slice(0, 7), ['schema', 'mode', 'generated_at', 'sheets', 'data_through', 'history_from', 'creatives'], 'existing fields first and unchanged');
  });

  it('a refresh in flight is invisible until the manifest flips: rows, meta and breakdowns always agree on one version', async () => {
    // version 1: the whole sample. Version 2: one day less, in BOTH datasets, so each route's answer shows which version it came from.
    const v1 = await publishBreakdowns();
    const sheets2 = loadSampleSheets();
    for (const p of Object.keys(sheets2)) sheets2[p] = Object.assign(sheets2[p].filter((r) => r.date <= '2026-09-19'), { columns: sheets2[p].columns });
    const main2 = normalize(sheets2, { mode: 'live', now: new Date(NOW.getTime() + 3_600_000) });
    const bds2 = breakdownDatasetFor(syntheticBreakdownGrids({ skipDates: ['2026-09-20'] }), main2);
    assert.equal(main2.health.data_through, '2026-09-19');

    const store = factory(DATASET_STORE);
    let release;
    const gate = new Promise((resolve) => { release = resolve; });
    const realSetJSON = store.setJSON.bind(store);
    store.setJSON = async (key, value, options) => {
      if (key === MANIFEST_KEY) await gate; // hold the commit point
      return realSetJSON(key, value, options);
    };
    const writing = writeDatasetVersion(store, {
      dataset: main2, metaPayload: { ...meta(main2), breakdowns: healthOf(bds2, main2) }, monthlyPayload: monthly(main2), breakdowns: bds2, now: new Date(NOW.getTime() + 3_600_000),
    });
    // wait until all of version 2's blobs are in place (only the manifest write is held back)
    for (let i = 0; i < 200 && ![...store.entries.keys()].some((k) => k.endsWith('breakdowns.json.gz') && !k.includes(v1.version)); i++) await new Promise((r) => setImmediate(r));
    const v2Keys = [...store.entries.keys()].filter((k) => !k.includes(v1.version) && k.startsWith('v/'));
    assert.equal(v2Keys.length, 3, 'dataset, monthly and breakdowns of version 2 exist already');

    const snapshot = async () => {
      resetReadCaches(); // so the route reads the store's manifest now, not a cached copy
      const [rows, metaRes, bd] = await Promise.all([
        rowsHandler(get('/api/rows?from=2026-09-07&to=2026-09-20')),
        metaHandler(get('/api/meta')),
        breakdownsHandler(get('/api/breakdowns?from=2026-09-07&to=2026-09-20')),
      ]);
      const [rowsBody, metaBody, bdBody] = await Promise.all([bodyJson(rows), bodyJson(metaRes), bodyJson(bd)]);
      return {
        versions: [rows.headers.get('x-data-version'), metaRes.headers.get('x-data-version'), bd.headers.get('x-data-version')],
        lastRowDate: rowsBody.rows.at(-1)[0], dataThrough: metaBody.data_through, healthLast: metaBody.breakdowns.placement.last_date, breakdownLast: bdBody.coverage.placement.last_date,
      };
    };

    const before = await snapshot();
    assert.deepEqual(before.versions, [v1.version, v1.version, v1.version], 'all three answer from version 1 while version 2 is half-written');
    assert.deepEqual([before.lastRowDate, before.dataThrough, before.healthLast, before.breakdownLast], ['2026-09-20', '2026-09-20', '2026-09-20', '2026-09-20']);

    release();
    const v2 = await writing;
    const after = await snapshot();
    assert.deepEqual(after.versions, [v2.version, v2.version, v2.version], 'after the flip all three answer from version 2');
    assert.deepEqual([after.lastRowDate, after.dataThrough, after.healthLast, after.breakdownLast], ['2026-09-19', '2026-09-19', '2026-09-19', '2026-09-19']);
    assert.notEqual(v1.version, v2.version);

    // an instance that already holds the manifest keeps one consistent snapshot, never a mix
    await publishBreakdowns(bds, { at: new Date(NOW.getTime() + 7_200_000) }); // version 3 appears in the store...
    const mixed = await Promise.all([rowsHandler(get('/api/rows?from=2026-09-07&to=2026-09-20')), breakdownsHandler(get('/api/breakdowns?from=2026-09-07&to=2026-09-20'))]); // ...but this instance cached the v2 manifest
    assert.equal(mixed[0].headers.get('x-data-version'), mixed[1].headers.get('x-data-version'));
    assert.equal(mixed[0].headers.get('x-data-version'), v2.version);
  });
});

describe('/api/meta and /api/monthly', () => {
  it('/api/meta returns the contract meta payload', async () => {
    await publish();
    const res = await metaHandler(get('/api/meta'));
    assert.equal(res.status, 200);
    assert.deepEqual(await bodyJson(res), JSON.parse(JSON.stringify(meta(dataset))));
    assert.equal((await metaHandler(get('/api/meta', { cookie: null }))).status, 401);
  });

  it('/api/monthly returns the contract monthly payload', async () => {
    await publish();
    const res = await monthlyHandler(get('/api/monthly', { headers: { 'accept-encoding': 'br' } }));
    assert.equal(res.status, 200);
    assert.deepEqual(await bodyJson(res), JSON.parse(JSON.stringify(monthly(dataset))));
    assert.equal((await monthlyHandler(get('/api/monthly', { cookie: null }))).status, 401);
  });
});

describe('/img/:platform/:id', () => {
  const img = (path, opts) => imgHandler(get(path, opts), { params: /^\/img\/([^/]+)\/([^/]+)$/.exec(path) ? { platform: path.split('/')[2], id: path.split('/')[3] } : {} });

  it('streams a saved creative with its type, private 1-day caching and an ETag; 304 when unchanged', async () => {
    const bytes = jpegBytes(3000);
    await factory(CREATIVES_STORE).set('meta/120249786888520484', toArrayBuffer(bytes), { metadata: { contentType: 'image/jpeg', savedAt: NOW.toISOString(), sourceDate: '2026-09-20' } });
    const res = await img('/img/meta/120249786888520484');
    assert.equal(res.status, 200);
    assert.equal(res.headers.get('content-type'), 'image/jpeg');
    assert.equal(res.headers.get('cache-control'), 'private, max-age=86400');
    assert.equal(res.headers.get('x-content-type-options'), 'nosniff');
    assert.deepEqual(new Uint8Array(await res.arrayBuffer()), bytes);
    const etag = res.headers.get('etag');
    assert.ok(etag);
    const again = await img('/img/meta/120249786888520484', { headers: { 'if-none-match': etag } });
    assert.equal(again.status, 304);
  });

  it('validates platform and id, 404s a missing image, and requires a session', async () => {
    assert.equal((await img('/img/google/123')).status, 400);
    assert.equal((await img('/img/meta/12a3')).status, 400);
    assert.equal((await img('/img/meta/..%2Fdataset')).status, 400);
    assert.equal((await img('/img/tiktok/999')).status, 404);
    assert.equal((await img('/img/meta/123', { cookie: null })).status, 401);
    // Without context.params the path is parsed from the URL.
    assert.equal((await imgHandler(get('/img/tiktok/999'), {})).status, 404);
  });

  it('never serves a non-raster type as an image', async () => {
    await factory(CREATIVES_STORE).set('tiktok/42', '<svg onload="alert(1)"/>', { metadata: { contentType: 'image/svg+xml' } });
    const res = await img('/img/tiktok/42');
    assert.equal(res.headers.get('content-type'), 'application/octet-stream');
    assert.match(res.headers.get('content-security-policy'), /sandbox/);
  });
});

describe('/api/config', () => {
  it('is public and returns the Google client id', async () => {
    const res = await configHandler(new Request(`${BASE}/api/config`));
    assert.equal(res.status, 200);
    assert.deepEqual(await res.json(), { google_client_id: ENV.GOOGLE_CLIENT_ID });
  });
});

describe('/api/refresh', () => {
  const NOW_MS = Date.now();
  function setupRefresh(status = 202) {
    const posts = [];
    const fetchImpl = async (url, init) => {
      posts.push({ url: String(url), init });
      return new Response(null, { status });
    };
    return { posts, handler: createRefreshHandler({ getEnv: () => ENV, fetchImpl, clock: () => NOW_MS }) };
  }
  const post = (path = '/api/refresh', cookie = FINN, headers = {}) => new Request(`${BASE}${path}`, { method: 'POST', headers: { cookie, origin: BASE, ...headers } });

  it('GET shows the last run to any signed-in user, with can_refresh for owners only', async () => {
    await writeStatus(factory(DATASET_STORE), { state: 'ok', started_at: new Date(NOW_MS - 600_000).toISOString() });
    const { handler } = setupRefresh();
    const owner = await bodyJson(await handler(get('/api/refresh')));
    assert.equal(owner.status.state, 'ok');
    assert.equal(owner.can_refresh, true);
    const friend = await bodyJson(await handler(get('/api/refresh', { cookie: FRIEND })));
    assert.equal(friend.can_refresh, false);
    assert.equal((await handler(get('/api/refresh', { cookie: null }))).status, 401);
  });

  it('POST by the owner starts the background job with a valid signed trigger', async () => {
    const { handler, posts } = setupRefresh();
    const res = await handler(post('/api/refresh?force=1'));
    assert.equal(res.status, 202);
    assert.equal((await bodyJson(res)).force, true);
    assert.equal(posts.length, 1);
    assert.equal(posts[0].url, `${BASE}/.netlify/functions/refresh-background`);
    const body = JSON.parse(posts[0].init.body);
    assert.deepEqual(body, { trigger: 'manual', force: true, requested_by: 'finn@groovstrategy.co' });
    const token = new Headers(posts[0].init.headers).get('x-groov-refresh');
    assert.equal(verifyInternalToken(token, { secret: SECRET, trigger: 'manual', force: true, now: NOW_MS }), true);
  });

  it('POST is refused for non-owners, cross-site origins, and while a run is in progress', async () => {
    const { handler, posts } = setupRefresh();
    assert.equal((await handler(post('/api/refresh', FRIEND))).status, 403);
    assert.equal((await handler(post('/api/refresh', FINN, { origin: 'https://evil.example' }))).status, 403);
    await writeStatus(factory(DATASET_STORE), { state: 'running', started_at: new Date(NOW_MS - 60_000).toISOString() });
    const busy = await handler(post());
    assert.equal(busy.status, 409);
    assert.match((await busy.json()).error, /already running/);
    assert.equal(posts.length, 0);
    // A "running" status older than the 15-minute limit is stale and does not block.
    await writeStatus(factory(DATASET_STORE), { state: 'running', started_at: new Date(NOW_MS - 20 * 60_000).toISOString() });
    assert.equal((await handler(post())).status, 202);
  });

  it('POST reports a background job that could not be started', async () => {
    const { handler } = setupRefresh(500);
    const res = await handler(post());
    assert.equal(res.status, 502);
    assert.match((await res.json()).error, /HTTP 500/);
  });
});

describe('lib/http.mjs helpers', () => {
  it('sameOrigin: no Origin is fine, a matching host is fine, anything else is refused', () => {
    const req = (url, headers) => new Request(url, { method: 'POST', headers });
    assert.equal(sameOrigin(req(`${BASE}/api/session`, {})), true);
    assert.equal(sameOrigin(req(`${BASE}/api/session`, { origin: BASE })), true);
    assert.equal(sameOrigin(req(`${BASE}/api/session`, { origin: 'https://ADS.example.test' })), true);
    assert.equal(sameOrigin(req(`${BASE}/api/session`, { origin: 'https://evil.example' })), false);
    assert.equal(sameOrigin(req(`${BASE}/api/session`, { origin: 'null' })), false);
    // The platform may hand the function an internal URL; the forwarded host is what the browser used.
    assert.equal(sameOrigin(req('http://internal.lambda/api/session', { origin: BASE, 'x-forwarded-host': 'ads.example.test' })), true);
    assert.equal(sameOrigin(req('http://internal.lambda/api/session', { origin: 'https://evil.example', 'x-forwarded-host': 'ads.example.test' })), false);
  });

  it('negotiateEncoding prefers br, then gzip, honours q=0 and the off switch', () => {
    assert.equal(negotiateEncoding('gzip, deflate, br, zstd'), 'br');
    assert.equal(negotiateEncoding('gzip'), 'gzip');
    assert.equal(negotiateEncoding('br;q=0, gzip;q=0.8'), 'gzip');
    assert.equal(negotiateEncoding('identity'), null);
    assert.equal(negotiateEncoding(null), null);
    assert.equal(negotiateEncoding('br', { compression: 'off' }), null);
  });

  it('validateRange counts days inclusively', () => {
    assert.deepEqual(validateRange('2026-09-20', '2026-09-20'), { ok: true, from: '2026-09-20', to: '2026-09-20', days: 1 });
    assert.equal(validateRange('2024-02-29', '2024-03-01').days, 2, 'leap day');
    assert.equal(validateRange('2023-02-29', '2023-03-01').ok, false);
    assert.equal(validateRange('2026-01-01', '2026-12-31', 365).ok, true);
    assert.equal(validateRange('2025-12-31', '2026-12-31', 365).ok, false);
  });

  it('streams large uncompressed bodies and keeps small ones buffered', async () => {
    const big = prepareJsonBody(JSON.stringify({ rows: 'x'.repeat(5 * 1024 * 1024) }), null);
    const res = bodyResponse(big);
    assert.ok(res.body instanceof ReadableStream);
    assert.equal((await res.text()).length, big.rawLength);
    const small = prepareJsonBody('{"a":1}', 'br');
    assert.equal(small.encoding, null, 'too small to compress');
  });

  it('createLru evicts the least recently used entry', () => {
    const lru = createLru(2);
    lru.set('a', 1);
    lru.set('b', 2);
    lru.get('a');
    lru.set('c', 3);
    assert.deepEqual([lru.get('a'), lru.get('b'), lru.get('c'), lru.size], [1, undefined, 3, 2]);
  });
});
