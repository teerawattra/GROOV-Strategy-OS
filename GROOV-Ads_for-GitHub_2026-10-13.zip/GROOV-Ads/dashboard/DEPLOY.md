# Putting the GROOV Ads Command Center online (Netlify)

This guide takes the dashboard from your Mac to a private website that only GROOV Google accounts can open. It
refreshes itself every morning from the three Windsor Google Sheets (plus, if you set them up, two optional Meta
Sheets for placement and audience splits). Follow the parts in order; each step says exactly where to click or what
to paste into Terminal. Plan about an hour the first time.

```
Windsor 06:00 ─► 3 Google Sheets ─► 07:15 Netlify data job ─► Netlify Blobs (cache + ad images) ─► dashboard
                  (private; read by a          (refresh-data, then             ▲
                   Google service account)      refresh-background)    sign in with Google (allow-list)
```

**What you need first**
- The three Windsor exports running (`Ads/command-center/sheets-export.md`), so the Sheets have data.
- Optional: the two Meta breakdown exports (`sheets-export.md` §2b) for placement and audience splits. Without them
  the rest of the dashboard works as usual (see step 3b).
- A Google account that can create a Google Cloud project (your GROOV Workspace account is best).
- A Netlify account (free is fine).
- Node.js 22 or newer on the Mac. Check in Terminal: `node --version` (you have 24).
- Python 3 (`python3 --version`); it builds the registry and learning files on each deploy.

Everything you paste into Netlify below is secret unless it says otherwise. Never paste a key into chat, a
document, Slack, or a file inside this folder.

---

## Part 1 · Google Cloud: a robot account that can read the three Sheets

The data job reads the Sheets as a *service account*: a Google identity that only has the access you share with
it. The Sheets themselves stay private.

1. Open https://console.cloud.google.com and sign in with your GROOV Google account.
2. **Create a project.** Click the project picker at the top left → **New project** → name it
   `groov-ads-dashboard` → **Create**. Make sure it is selected in the picker afterwards.
3. **Turn on the Sheets API.** Menu ☰ → **APIs & Services** → **Library** → search `Google Sheets API` → open it
   → **Enable**.
4. **Create the service account.** Menu ☰ → **IAM & Admin** → **Service Accounts** → **+ Create service account**.
   - Name: `groov-sheets-reader` → **Create and continue**.
   - "Grant this service account access to project": leave empty → **Continue** → **Done**.
   - Copy its email address from the list (it looks like
     `groov-sheets-reader@groov-ads-dashboard.iam.gserviceaccount.com`). This address is not secret.
5. **Create its key.** Click the service account → tab **Keys** → **Add key** → **Create new key** → **JSON** →
   **Create**. A `.json` file downloads to your Downloads folder. This file is the password of the robot account:
   keep it out of this project folder, and delete it after Part 3, step 4.
   - *"Service account key creation is disabled"?* New Google Cloud organisations block keys by default
     (organisation policy `iam.disableServiceAccountKeyCreation`). A Workspace admin opens **IAM & Admin** →
     **Organization Policies** → "Disable service account key creation" → **Manage policy** → for this project
     choose **Override parent's policy** → **Not enforced** → **Set policy**. Then repeat step 5.
6. **Share each Sheet with the robot, read-only.** In Google Sheets open `GROOV Ads · Meta` → **Share** → paste the
   service-account email → role **Viewer** → untick **Notify people** → **Share**. Repeat for
   `GROOV Ads · TikTok` and `GROOV Ads · Google`. If you use the optional breakdown Sheets, share
   `GROOV Ads · Meta placements` and `GROOV Ads · Meta audience` the same way (or the spreadsheet that holds their tabs).
7. **Copy the three Sheet IDs.** In each Sheet's address bar the ID is the long part between `/d/` and `/edit`:
   `https://docs.google.com/spreadsheets/d/`**`1AbC…xyz`**`/edit`. Note which ID belongs to which platform (and the
   IDs of the two optional breakdown Sheets). (Not secret, but no need to share them.)

## Part 2 · Google sign-in: an OAuth client for the login button

1. In the same Cloud project: Menu ☰ → **APIs & Services** → **OAuth consent screen** (Google now calls this area
   **Google Auth Platform**). If asked to set it up, fill in:
   - **Branding / App information:** app name `GROOV Ads Command Center`, user support email: yours.
   - **Audience:**
     - **Internal** if everyone who will sign in has a GROOV Google Workspace account. Only your organisation can
       then sign in at all, which is the safest choice.
     - **External** if you also want to let in personal Gmail accounts (listed in `ALLOWED_EMAILS`). Then set
       the publishing status to **In production** (**Audience** → **Publish app**). While it says "Testing", only
       listed test users can sign in. The dashboard asks only for name and email, so Google needs no review.
   - **Contact information:** your email → **Create** / **Save**.
2. Go to **Google Auth Platform** → **Clients** (or **APIs & Services** → **Credentials** → **+ Create
   credentials** → **OAuth client ID**) → **Create client**.
   - Application type: **Web application**. Name: `GROOV Ads dashboard`.
   - **Authorized JavaScript origins** → **+ Add URI**, one per address the dashboard will use. Exactly the scheme and
     host, with no path and no trailing slash:
     - `https://groov-ads.netlify.app` (the Netlify address you will create in Part 3; you can add it later)
     - your own domain if you use one, e.g. `https://ads.groovstrategy.co`
     - optional, for local testing: `http://localhost:8888` and `http://localhost`
   - **Authorized redirect URIs:** leave empty (the login uses a pop-up, not redirects).
   - **Create**. Copy the **Client ID** (ends in `.apps.googleusercontent.com`). It is not secret: every visitor's
     browser sees it. You do **not** need the client secret.

## Part 3 · Netlify: create the site, add the settings, deploy

### 1. Connect this folder to a new Netlify project (once)
Open Terminal and paste these lines one at a time:

```sh
cd path/to/Ads/dashboard
npm install
npx --yes netlify-cli@27 login
npx netlify-cli@27 sites:create --name groov-ads
```
- `npm install` fetches the one library the server code needs (`@netlify/blobs`).
- `login` opens your browser: click **Authorize**.
- `sites:create` asks which team; pick yours. If the name `groov-ads` is taken, choose another and use that name
  wherever this guide says `groov-ads`. The folder is now linked to the project (this creates a hidden `.netlify`
  folder, which is never uploaded).

Your address is now `https://groov-ads.netlify.app`. If you skipped it in Part 2, add it to the OAuth client's
**Authorized JavaScript origins** now.

### 2. Make two secrets on your Mac
In Terminal (each command puts the result on your clipboard, so nothing is printed on screen):

- **Session secret** (signs the login cookie): `openssl rand -hex 32 | pbcopy`. Paste it in step 3 as
  `SESSION_SECRET`.
- **Service-account key** as one line: `base64 -i ~/Downloads/groov-ads-dashboard-*.json | pbcopy` (use the real
  file name of the key from Part 1, step 5). Paste it in step 3 as `GOOGLE_SERVICE_ACCOUNT_JSON`. Pasting the raw
  file contents also works; one line avoids copy-paste damage.

### 3. Add the settings in Netlify
https://app.netlify.com → your project → **Project configuration** → **Environment variables** → **Add a
variable** → **Add a single variable**. For each row: type the key, paste the value, keep **Same value for all
deploy contexts**, and set **Scopes** to **All scopes** (at least **Functions**: the sign-in check at the edge
reads `SESSION_SECRET`, `ALLOWED_DOMAINS` and `ALLOWED_EMAILS` from that scope). Tick **Contains secret values**
for the secret ones if your plan offers it. Then **Create variable**.

| Key | Value | Secret? |
|---|---|---|
| `GOOGLE_SERVICE_ACCOUNT_JSON` | the base64 key from step 2 | **yes** |
| `SHEET_ID_META` | ID of `GROOV Ads · Meta` | no |
| `SHEET_ID_TIKTOK` | ID of `GROOV Ads · TikTok` | no |
| `SHEET_ID_GOOGLE` | ID of `GROOV Ads · Google` | no |
| `GOOGLE_CLIENT_ID` | the Client ID from Part 2 | no |
| `SESSION_SECRET` | the 64-character secret from step 2 | **yes** |
| `ALLOWED_DOMAINS` | `groovstrategy.co` (comma-separated if several) | no |
| `ALLOWED_EMAILS` | extra people, e.g. `someone@gmail.com, partner@client.com` (may be empty) | no |
| `OWNER_EMAILS` | who may start a refresh by hand, e.g. `finn@groovstrategy.co` | no |

Optional: `SHEET_TAB_META` / `SHEET_TAB_TIKTOK` / `SHEET_TAB_GOOGLE` if the data is not on the first tab of a
Sheet; `API_COMPRESSION=off` only if Netlify support asks you to turn off the server's own compression. The
placement and audience Sheets have their own optional settings: step 3b.

About the allow-list:
- `ALLOWED_DOMAINS` admits Google **Workspace** accounts of that domain. Google vouches for those (the sign-in
  carries an `hd` claim). A personal Google account someone registered with a `@groovstrategy.co` address is
  **not** let in by the domain rule.
- `ALLOWED_EMAILS` admits exactly the addresses listed. Gmail addresses are safe to list. For an address on
  another company's domain, list it only if you trust whoever controls that Google account.
- Changes take effect on the next deploy (step 4). Removing someone locks them out on that deploy, even if their
  7-day login is still running.

### 3b. Optional: placement and audience splits (two more Meta Sheets)
Skip this and the dashboard works exactly as described above. Do it when you want the ad set panels and the client
view to show **where results happen**: each placement's and each age × gender group's share of spend and of results.

1. Create the two Windsor exports (`Ads/command-center/sheets-export.md` §2b). Each lands in its own spreadsheet with
   one tab (`GROOV Ads · Meta placements`, `GROOV Ads · Meta audience`), or in two extra tabs of the
   `GROOV Ads · Meta` spreadsheet.
2. Share them with the robot as **Viewer** (Part 1, step 6): the two spreadsheets or, if they are tabs, the Meta
   spreadsheet you have already shared.
3. Add these settings in Netlify, the same way as in step 3. Then run `npm run deploy` (step 4) and
   `refresh-data` → **Run now** (step 6).

| Key | Value | Secret? |
|---|---|---|
| `SHEET_ID_META_PLACEMENTS` | ID of `GROOV Ads · Meta placements` | no |
| `SHEET_ID_META_AUDIENCE` | ID of `GROOV Ads · Meta audience` | no |
| `SHEET_TAB_META_PLACEMENTS` | tab name; only needed when the Sheet is a tab of a spreadsheet that has other tabs | no |
| `SHEET_TAB_META_AUDIENCE` | the same, for the audience Sheet | no |

- **Two separate spreadsheets:** set the two IDs and nothing else. This is the recommended setup: each of the two
  grows by about 2 million cells a year, far below Google's 10-million-cell limit.
- **Tabs inside the Meta spreadsheet:** set both IDs to the **same ID as `SHEET_ID_META`** and name each tab in
  `SHEET_TAB_META_PLACEMENTS` / `SHEET_TAB_META_AUDIENCE`. The tab names are required then. Without them the job would
  read the first tab, which is the main Meta Sheet, so it refuses and says so in `/api/refresh`.
- You can set one of the two alone; the other stays off.

**What the dashboard shows without them:** nothing is broken and nothing else is hidden. The ad set panels and the
"Where results happen" section show "Placement and audience splits appear once the two Meta breakdown exports run
(see sheets-export.md)" and nothing else. `GET /api/breakdowns` answers `available: false` for both, `/api/meta`
says `configured: false`, and the refresh log reads "breakdown sheets (placements not configured, audience not
configured)". Leaving a Sheet out later switches its panels off again on the next refresh.

**Check that it works:** after the refresh, open `https://groov-ads.netlify.app/api/meta` while signed in.
`breakdowns.placement.available` and `breakdowns.audience.available` must be `true`. `spend_share_last_28d` should be
close to 1 (0.99 to 1.01). `all_meta_spend_share_last_28d` is the share of **all** Meta spend the Sheet covers: if it is
clearly below 1, the Windsor export misses some ad accounts (`/api/refresh` then lists a warning).

**If a breakdown Sheet cannot be read** (not shared, wrong ID or tab, key columns removed), the refresh still succeeds.
That one breakdown switches off until the next successful run, and the reason appears in `/api/refresh` under
`warnings` and in `/api/meta` as `breakdowns.<placement|audience>.error`. The three main Sheets are never affected,
and the data of one version (main data and breakdowns) always switches over together.

### 4. Deploy
```sh
cd path/to/Ads/dashboard
npm run deploy
```
This (a) regenerates `public/data/registry.js` and `learnings.js` from `Ads/accounts` and `Ads/learnings`, (b)
copies `public/` to `dist/` **without** `public/data/sample.js` (the local preview file with real client numbers is
never uploaded), (c) packages the server functions and the sign-in check, and (d) publishes to production. The
last lines show `Deployed to production URL: https://groov-ads.netlify.app`.

Delete the downloaded key file now (Finder → Downloads → move the `.json` key to the Bin and empty it). Netlify
holds the only copy you need. You can always create a new key in Part 1, step 5.

Run `npm run deploy` again whenever the dashboard code, the registry, the learning log or a Netlify setting changes.
(Netlify settings only reach the server code on the next deploy.)

### 5. Copy the existing ad images into Netlify (once)
The image library in `Ads/command-center/creatives/` (about 360 images) is uploaded once. After that, the daily
job saves new ads' images by itself.

1. Make a temporary Netlify token: avatar (bottom left) → **User settings** → **Applications** → **Personal access
   tokens** → **New access token** → description `seed creatives`, expiration **7 days** → **Generate token** →
   **Copy**.
2. In Terminal:
   ```sh
   cd path/to/Ads/dashboard
   npm run seed:creatives
   ```
   It finds the project by itself (from the link in step 1) and asks for the token. Paste it and press Enter. The
   token is not shown while you paste, and it is not saved anywhere.
3. It ends with a line like `364 files in the library · 362 uploaded · 0 already in Netlify · 2 skipped (not an
   image) · 0 failed`. Running it again is safe: images already in Netlify are skipped.
4. Delete the token: **Personal access tokens** → the token → **Delete**.

### 6. Run the first data refresh
The job runs by itself every day at **07:15 Bangkok** (after Windsor's 06:00 export). To run it now:
Netlify → your project → **Logs & metrics** → **Functions** → `refresh-data` → **Run now**. It starts
`refresh-background`, which does the work in 1–3 minutes.

To follow it: open `https://groov-ads.netlify.app/api/refresh` in a browser where you are signed in (step 7).
`"state": "running"` turns into `"ok"` with row counts, image counts and any warnings, or `"error"` with the reason.
The function logs (same **Functions** page → `refresh-background`) show the same story line by line.

### 7. Check it works
1. Open `https://groov-ads.netlify.app` in a private window. You land on **Sign in**.
2. Click **Sign in with Google** and pick your GROOV account. You arrive at the dashboard.
3. **Data health** shows the three Sheets with today's dates; the top-left pill says "Data through <yesterday>"
   and **Live**.
4. **Creatives** shows real images.
5. Try an account that is not on the list (a private Gmail). It must see "This Google account isn't on the
   allow-list. Ask Finn to add it."
6. Optional technical check in Terminal: `curl -sI https://groov-ads.netlify.app/api/meta` must answer
   `HTTP/2 401`, and `curl -sI https://groov-ads.netlify.app/login.html | grep -i content-security` must print the
   security policy.

**Custom domain (optional):** Netlify → **Domain management** → **Add a domain** → e.g. `ads.groovstrategy.co` →
follow the DNS instructions. Then add `https://ads.groovstrategy.co` to the OAuth client's **Authorized JavaScript
origins** (Part 2) and wait a few minutes.

---

## Part 4 · Daily operation and troubleshooting

**Every day, automatically**
- 06:00 Windsor rewrites the last 28 days in each Sheet.
- 07:15 `refresh-data` starts `refresh-background`. That job:
  1. reads the three Sheets (and the two optional breakdown Sheets, if set up) and rebuilds the data;
  2. saves the dashboard's cache;
  3. stores the images of ads that delivered in the last 7 days and have no saved image yet (their links expire
     within days, so this is the only chance to keep them).
- The dashboard's **Refresh** button only re-reads that cache. To pull from the Sheets right away, use **Run now**
  (Part 3, step 6) or, as an owner, run `fetch('/api/refresh', {method: 'POST'})` in the browser console of the
  dashboard.

**Where to look:** the dashboard's **Data health** page, then `https://<your-site>/api/refresh` (last run), then
the Netlify function logs.

| What you see | What it means | What to do |
|---|---|---|
| Every section says "No data yet: the first data refresh hasn't finished" | No refresh has completed since setup | Run `refresh-data` → **Run now** and wait 3 minutes |
| Data health: freshness amber/red, "last date" stuck on an old day, while `/api/refresh` says `ok` | Windsor stopped exporting | Check the three Windsor tasks and their schedules |
| `/api/refresh`: `error` "…can't open the Meta Sheet. … Share" | The service account lost access to that Sheet | Share the Sheet again as Viewer (Part 1, step 6) |
| `/api/refresh`: "The Google Sheet was not found. Check SHEET_ID_GOOGLE" | Wrong or changed Sheet ID | Fix the variable, then `npm run deploy` |
| `/api/refresh`: "Google refused the service-account sign-in (invalid_grant)" | The key was deleted or replaced | New key (Part 1, step 5), update `GOOGLE_SERVICE_ACCOUNT_JSON`, deploy |
| `/api/refresh`: "The meta Sheet now has 0 usable rows, down from 41,200 … the cached data was kept" | A Sheet was cleared or half-written; the dashboard kept yesterday's data on purpose | Check the Sheet. If you trimmed it deliberately, run `fetch('/api/refresh?force=1', {method: 'POST'})` as an owner |
| `/api/refresh` warnings "…rows have a date the dashboard can't read" | The date column is formatted as a date in a local style | In that Sheet select column A → **Format** → **Number** → **Custom date and time** → `yyyy-mm-dd`, or **Plain text** |
| `/api/refresh` warnings "…ID cells are stored as numbers and have lost their last digits" | Google turned long IDs into numbers | Format the ID columns as **Plain text** and re-run the Windsor export |
| `/api/refresh` warning "placements: …can't open the Meta placements Sheet. … Share" (or "audience: …") | The service account can't open that optional breakdown Sheet | Share it (or the spreadsheet that holds its tab) as Viewer (step 3b) |
| `/api/refresh` warning "placements: The Meta placements Sheet was not found. Check SHEET_ID_META_PLACEMENTS" | Wrong or changed ID | Fix the variable, then `npm run deploy` |
| `/api/refresh` warning "placements: SHEET_TAB_META_PLACEMENTS is not set, but …" or "…has no tab named …" | The Sheet is a tab of a spreadsheet with other tabs and its tab name is missing or misspelled | Set the tab name exactly as it is in the spreadsheet, then deploy |
| `/api/refresh` warning "placements: columns missing from the Sheet: publisher_platform, … The Sheet was ignored." | The variable points at the wrong tab, or the Windsor fields are not those of `DATA_CONTRACT.md` §1 (Sheets 4 and 5) | Point it at the right tab and restore the fields |
| `/api/refresh` warning "placements: the Sheet covers only 71% of the Meta spend of the last 28 days" | The Windsor export misses accounts, or its date range is shorter than 28 days | Set the export to all accounts and "last 28 days" |
| The panels say "Placement and audience splits appear once…" although the Sheets have data | The two ID variables are not set or not deployed yet, or the Sheets are still empty | Set them (step 3b), deploy, run the refresh; `/api/meta` `breakdowns.<kind>` shows `configured`, `available` and `error` |
| Data health: "columns missing: …" | A Windsor task's field list changed | Restore the fields from `DATA_CONTRACT.md` §1 |
| Data health: missing dates | Windsor skipped a day | Re-run that Windsor task for the date range |
| Data health: duplicates | Windsor appends instead of upserting | Set the upsert keys (`sheets-export.md`) |
| Creative coverage: "not saved" growing | Image links expired before a run, or downloads failed | `/api/refresh` → `images.failures` shows why. An ad keeps being retried for 7 days; older ones show a labelled blank tile |
| Sign-in: "This Google account isn't on the allow-list. Ask Finn to add it." | Not listed, or a non-Workspace account with a GROOV address | Add to `ALLOWED_EMAILS` (or fix `ALLOWED_DOMAINS`), then `npm run deploy` |
| Sign-in: "Sign-in isn't set up yet…" | `GOOGLE_CLIENT_ID` is missing | Add it, deploy |
| The Google pop-up shows an error, or the button never appears; the browser console mentions "origin is not allowed" | This address is not an authorised JavaScript origin | Add it to the OAuth client (Part 2) and wait 5 minutes |
| The login page says "…the dashboard sent you back here…", or a page reads "The dashboard is not configured: SESSION_SECRET…" | The edge check can't read the settings | Set those variables' scopes to **All scopes**, then `npm run deploy` |
| Everybody is suddenly signed out | `SESSION_SECRET` changed (expected after a rotation) | Sign in again |
| `refresh-background` is missing or not marked **Background** on the Functions page | Your Netlify plan lacks background functions (old "Starter" plans) | Move the team to a current plan (Free, Personal or Pro all include them) |

---

## Part 5 · Security notes (why it is built this way)

- **The Sheets are never public.** Only the service account can read them, read-only (`spreadsheets.readonly`
  scope, Viewer share). Its key lives only in a Netlify environment variable, which Netlify encrypts. It is not in
  this folder, in git or in the website. To rotate it: create a new key, update the variable, deploy, then delete
  the old key in Google Cloud (**Service account** → **Keys** → 🗑).
- **Nothing is reachable without signing in.** An edge check runs in front of every page, script, data call and
  image, and each server function checks the session again on its own. The only public items are the login page
  (with its stylesheet, script and logo), `/api/config` (it returns only the OAuth client ID) and `/api/session`
  (sign-in itself). The local preview file `public/data/sample.js` is never uploaded and is blocked even if it ever
  were.
- **The login cookie** (`groov_session`) holds just your email and an expiry 7 days out, signed with
  `SESSION_SECRET` (HMAC-SHA256), so it can't be forged or edited. It is `HttpOnly` (page scripts can't read it),
  `Secure` (HTTPS only) and `SameSite=Lax` (other sites can't use it to send changes).
- **Rotating `SESSION_SECRET`** (new `openssl rand -hex 32`, update the variable, `npm run deploy`) signs everyone
  out at once. Do it when someone leaves or a laptop is lost. Removing someone from the allow-list also locks them
  out on the next deploy.
- **The allow-list** is checked against Google's verified sign-in (`email_verified`, and `hd` for the domain rule),
  and checked again on every request.
- **Owner-only refresh:** only `OWNER_EMAILS` can start a refresh by hand. The scheduled job starts the background
  job with a short-lived signed token, so nobody else can trigger it.
- **Browser protections:** a strict Content-Security-Policy (only the site's own scripts plus Google's sign-in
  library), no framing (clickjacking), `nosniff`, `noindex`, private caching. Ad images are copied into Netlify Blobs
  only after the server confirms they really are JPEG/PNG/WebP/GIF/AVIF images from a public HTTPS address.
- **Logs** contain counts and plain-language errors only. Never keys, tokens, cookies or the (signed) image links.
- **The dashboard is read-only.** It never changes ads.
- **Why Google sign-in and not Netlify Identity:** everyone already has a GROOV Google account, so there are no
  extra passwords or invitations, and the allow-list lives in two settings. Netlify announced the deprecation of
  its Identity product in February 2025. It reversed that on 19 February 2026 and supports it again, but this setup
  does not depend on it either way.

---

## Reference

**Routes**

| Route | Who | What |
|---|---|---|
| `/login.html` | anyone | sign-in page |
| `GET /api/config` | anyone | `{google_client_id}` |
| `POST /api/session` | anyone | `{credential}` from Google → sets the cookie → `{email, expires, owner}` |
| `GET /api/session` | signed in | `{email, expires, owner}`; 401 otherwise |
| `DELETE /api/session` | anyone | signs out (clears the cookie), 204 |
| `GET /api/meta` | signed in | sheet health, `data_through`, creative coverage, breakdown health (`DATA_CONTRACT.md` §2.4) |
| `GET /api/rows?from=YYYY-MM-DD&to=YYYY-MM-DD` | signed in | fact rows, at most 800 days inclusive (§2.2) |
| `GET /api/monthly` | signed in | campaign × month history (§2.3) |
| `GET /api/breakdowns?from=YYYY-MM-DD&to=YYYY-MM-DD` | signed in | placement and age × gender splits per ad set, at most 800 days inclusive (§2.5). Without the optional Sheets: 200 with `available` false / false and empty arrays |
| `GET /img/<meta|tiktok>/<ad_id>` | signed in | saved ad image, private 1-day browser cache |
| `GET /api/refresh` | signed in | last data-job run |
| `POST /api/refresh[?force=1]` | owners | start the data job now |
| `refresh-data` | Netlify scheduler, 00:15 UTC = 07:15 Bangkok | starts `refresh-background` |
| `refresh-background` | started by the two above (signed token) | Sheets → cache → images (up to 15 minutes) |

**Files**

| Path | Role |
|---|---|
| `netlify.toml` | build command, publish folder `dist/`, function folders, security headers |
| `netlify/edge-functions/auth.js` | the sign-in check in front of everything |
| `netlify/functions/*.mjs` | the routes above |
| `lib/session-token.mjs`, `lib/session.mjs` | cookie format and checks (shared by the edge check and the functions) |
| `lib/google-id-token.mjs` | Google sign-in verification and the allow-list |
| `lib/sheets.mjs` | reading the Sheets with the service account (the three main ones, and the two optional breakdown Sheets) |
| `lib/breakdowns.mjs` | the optional placement and audience Sheets → `/api/breakdowns` payload, coverage and health |
| `lib/refresh.mjs`, `lib/creatives-job.mjs` | the daily data job and the image saver |
| `lib/blobs-store.mjs` | the cache layout in Netlify Blobs (stores `dataset` and `creatives`) |
| `public/login.html`, `public/assets/login.*` | the sign-in page |
| `scripts/prebuild.mjs` | build step: fresh registry/learnings + `dist/` without the sample file |
| `scripts/seed-creatives.mjs` | one-time image upload |

**Commands** (run inside `Ads/dashboard`)

| Command | What it does |
|---|---|
| `npm run deploy` | build and publish to production |
| `npm run build` | only build `dist/` (to inspect what would be published) |
| `npm run build:static` | only regenerate `public/data/registry.js` and `learnings.js` |
| `npm run seed:creatives` | upload the image library (skips images already uploaded) |
| `npm run test:backend` | the server tests (`npm test` runs every test) |
| `npx netlify-cli@27 dev` | run the whole site locally at http://localhost:8888 with your Netlify settings and a separate local image/data store (needs the `localhost` origins from Part 2) |

**The cache:** the store `dataset` keeps `manifest.json` (which version is current, plus the `/api/meta` answer),
one folder per version under `v/<version>/` with the full normalised data (`dataset.json.gz`), the monthly
history and, when the breakdown Sheets are set up, their data (`breakdowns.json.gz`), and `status.json` (the last
run). Everything of one version is written first and `manifest.json` last, so the dashboard never mixes two refreshes. Old versions are deleted two hours after they are replaced. The store
`creatives` keeps one image per ad: `meta/<ad_id>` and `tiktok/<ad_id>`. You can browse both in Netlify under
**Blobs**. Deleting something there is safe: data comes back on the next refresh. A deleted image only comes back
while the ad is still delivering.
