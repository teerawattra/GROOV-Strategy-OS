# GROOV Ads Command Center

A read-only dashboard for every GROOV ad account: Meta, TikTok and Google. Its data comes from 3 core Google Sheets that Windsor fills daily, plus 2 optional Meta breakdown Sheets (placement, age × gender). It's hosted on Netlify behind Google sign-in.

| Read | For |
|---|---|
| `SPEC.md` | what every page and sidebar control does, the calculations, and the acceptance checks |
| `DATA_CONTRACT.md` | the 3 Sheets' columns and the JSON the dashboard reads |
| `DEPLOY.md` | step-by-step Google Cloud, OAuth and Netlify setup for Finn |
| `research/features-research.md` | the research behind the v1 refinements |
| `../SYSTEM.md` | where this sits in the wider GROOV Ads system, and current status |

## Try it locally (real Sep 2026 sample data)
```
npm run build:sample
npm run build:static
```
Then double-click `public/index.html`, or serve the `Ads/` folder and open `/dashboard/public/`.
- **Sample mode** turns on only from `file:` or localhost and shows an amber "SAMPLE DATA" banner.
- `npm run build:sample` regenerates `public/data/sample.js`.
- `npm run build:static` regenerates `public/data/registry.js` and `public/data/learnings.js` from `../accounts` and `../learnings`.

## Test
```
npm test
```
This runs about 625 tests: the normaliser and breakdowns, the backend (sessions, Google sign-in, Sheets, API, atomic data versions), the VPS server and the frontend engine.

The parity check covers 14–20 Sep 2026 vs 7–13 Sep 2026:
- 21 delivering accounts, ฿91,303.10.
- Decisions 3 / 9 / 4 / 5. These differ from Hermes's 3 / 10 / 2 / 6 only because decisions now judge exactly the KPIs on screen (SPEC §5). Changed: GAIA, Rena Yakiniku (Meta) and Pakasai.

## Layout
- `public/`: the frontend. Classic scripts under `window.GROOV`, no build step, no external dependencies.
  - `index.html`
  - `assets/js/`: util, data, engine, model, charts, ui, sidebar, views/*, app
  - `login.html`
- `lib/`: pure modules shared by the tools and the Netlify functions.
  - `csv`, `normalize` (3 core Sheets → contract JSON), `breakdowns` (optional Meta placement and audience Sheets → `/api/breakdowns`)
  - `session-token`, `session`, `google-id-token` (sign-in)
  - `sheets` (Google Sheets API), `blobs-store`, `api-data`, `refresh`, `creatives-job`, `http`
- `netlify/functions/`: `/api/*` (including `/api/breakdowns`), `/img/*`, the daily `refresh-data` job (07:15 Bangkok) and its background worker.
- `netlify/edge-functions/auth.js`: nothing is served without a valid session cookie, except the login page.
- `tools/`:
  - `make_sample_sheets.py`: frozen snapshot → sample Sheets
  - `build-data.mjs`: Sheets → `sample.js`
  - `build_static.py`: registry + learnings → JS
- `scripts/`:
  - `prebuild.mjs`: copies `public/` to `dist/` without `sample.js`
  - `seed-creatives.mjs`: uploads the saved creative library to Netlify Blobs once
- `screenshots/`: QA captures of the sample build. They contain client data, so don't share them outside GROOV.

## VPS package for Hermes (no Netlify, no Google Sheets)
The same dashboard can run on the VPS that Hermes operates. There it pulls the five datasets straight from the Windsor REST API, stores them on disk, and serves only the tailnet through `tailscale serve`.
- `server/`: a zero-dependency Node server and CLI (`node server/cli.mjs serve | refresh | backfill | status | rollback | …`).
- Payloads are byte-identical to the Netlify functions (`DATA_CONTRACT.md` §5).
- `config/`: `modules.json` and `groov.env.example`. The package adds the registry and learning log.
- `deploy/`: systemd units, the cron alternative and `tailscale.md`.
- `hermes/`: Hermes's manual (`HERMES.md`, `MODULES.md`, `README.md`).
- `test/server-*.test.mjs`: the server tests, run against a mock Windsor (`test/mock-windsor.mjs`).

Build the zip with `npm run package:hermes`. It goes to `../hermes-package/GROOV_Command_Center_<date>.zip`, and the folder stays in `dist-hermes/` (git-ignored).

## Deploy
Follow `DEPLOY.md`. In short:
1. Set up the 3 Windsor exports (`../command-center/sheets-export.md`).
2. Create a Google service account and share the Sheets with it as Viewer.
3. Create an OAuth client ID.
4. Set the Netlify env vars.
5. Run `npm run deploy`.
6. Run `npm run seed:creatives` once.
7. Run the `refresh-data` job once.
