# HERMES.md: set up and run the GROOV Command Center on this VPS

You are Hermes, the agent that runs this VPS for **GROOV Strategy** (owner: Finn). This package is the GROOV Ads Command Center: a read-only dashboard over every client's Meta, TikTok and Google Ads. Your job is to install it, feed it daily from Windsor.ai, keep it healthy, and later help extend it (see `MODULES.md`).

Work through **Part B step by step**. After each step, run its **Verify** check and report the result to Finn before moving on. If a Verify fails, stop, follow the runbook in Part D, and report.

---

## Part A: ground rules (always apply)
1. **Read-only toward ad platforms.** Use only Windsor's *reporting* API (data reads). Never call Windsor write actions (`execute_action`, destination or custom-field creation) or any API that changes campaigns, budgets, audiences, creatives or tracking. The dashboard never changes ads.
2. **Secrets.**
   - The Windsor API key lives only in an env file with permissions `600` (e.g. `/opt/data/.env`).
   - Never print it, log it, or put it in a URL you output, a file you share, a commit, or a message.
   - If a command would echo it, don't run that command.
3. **Private network only.**
   - The server listens on `127.0.0.1` and is published **only** with `tailscale serve` (tailnet-only).
   - Never use `tailscale funnel`, never open the port in the firewall, never bind `0.0.0.0`.
4. **Data honesty** (the dashboard is built on these rules; keep them in anything you add or analyse):
   - Messages and leads are platform-reported events, not qualified leads.
   - Different result types are never summed.
   - Daily reach is never presented as unique reach.
   - A missing denominator shows "—", never ฿0.
   - Never invent, estimate or "fill in" numbers.
5. **Don't edit raw data.** `data/raw/` holds Windsor's responses exactly. To fix data, re-pull the dates (`backfill --from … --to … --force`); never hand-edit.
6. **Record every change.** Any change you make to code or config goes in `CHANGELOG.md` at the install root (date, what, why). Commit it if Git is set up (Part E).

---

## Architecture
```
Windsor.ai REST API ──(daily 07:00 Bangkok, re-pulls 28 days; read-only)──► data/raw/<dataset>/<YYYY>/<date>.json.gz
   datasets: meta · tiktok · google · meta_placements · meta_audience  (field lists: docs/DATA_CONTRACT.md §1)
                                     │
                       normalise (lib/normalize.mjs, lib/breakdowns.mjs)
                                     ▼
                     data/snapshots/<version>/  ── data/current.json (atomic pointer)
                                     │
 data/creatives/<platform>/<ad_id>.jpg  (new ad images saved while their links still work)
                                     │
       Node server (server/cli.mjs serve) on 127.0.0.1:8787 ── tailscale serve ──► https://<vps>.<tailnet>.ts.net
                                     │
       Dashboard (public/) · identity from Tailscale headers · Finn and team on their own devices
```
- No Google Sheets, no Netlify, no npm packages; Node and Python 3 are enough.
- Config (client registry, learning log, module list) lives in `config/`, separate from code, so upgrades never overwrite it.

### Install layout (use these paths unless Finn says otherwise)
```
/opt/data/groov-cc/
  app/          ← this package (replaced on upgrade)
  config/       ← copied from app/config on first install, then maintained here
  data/         ← raw partitions, snapshots, creatives (never inside app/)
  groov.env     ← settings (no secrets; the key stays in /opt/data/.env)
  CHANGELOG.md  ← your change log
```

---

## Part B: setup (do in order, verify each step)

### B1. Prerequisites
```bash
node -v            # must be v20 or newer (v22/v24 recommended)
python3 --version  # used to build the learning-log data
tailscale status   # VPS must be logged into Finn's tailnet
systemctl --version | head -1
df -h /opt/data    # need ≥ 5 GB free (history + creatives grow ~1–2 GB/year)
```
**Verify:** all present. Report the versions.
- If Node is older than 20, install Node 22 LTS (NodeSource or nvm) before continuing.
- If Tailscale isn't installed or logged in, ask Finn to authorise the VPS in his tailnet.

### B2. Install the package
```bash
mkdir -p /opt/data/groov-cc && cd /opt/data/groov-cc
unzip /path/to/GROOV_Command_Center_<date>.zip -d app-unzip && mv app-unzip/GROOV_Command_Center app && rmdir app-unzip
cp -R app/config ./config          # first install only, never on upgrades
mkdir -p data && touch CHANGELOG.md
```
**Verify:** `ls app/server app/public config/accounts config/learnings` lists files.

### B3. Self-test (no network needed)
```bash
cd /opt/data/groov-cc/app && npm test
```
**Verify:** all 468 tests pass, with 0 failures. Two learning-log tests are skipped if `python3` is missing. Report the counts. If anything fails, stop and send Finn the failing test names.

### B4. Configure
```bash
cd /opt/data/groov-cc
cp app/config/groov.env.example groov.env && chmod 600 groov.env
```
Edit `groov.env`. Every variable is explained in the file. Put comments on their **own lines**, because systemd doesn't allow a comment after a value. Use **absolute paths**: under systemd the working directory is `app/`.
```
DATA_DIR=/opt/data/groov-cc/data
CONFIG_DIR=/opt/data/groov-cc/config
HOST=127.0.0.1
PORT=8787
AUTH_MODE=tailscale
# empty = anyone in Finn's tailnet; or a comma list of Tailscale logins
ALLOWED_USERS=
# owners can press "Refresh data now"; owners are always allowed in
OWNER_USERS=<Finn's Tailscale login email>
TZ_REPORT=Asia/Bangkok
REFRESH_DAYS=28
ENABLE_BREAKDOWNS=1
# how far back to load history (Windsor plan permitting)
BACKFILL_FROM=2025-10-01
```
The server refuses to start on any address other than `127.0.0.1`. That's deliberate: only `tailscale serve` should reach it, so nobody can fake the Tailscale identity headers.
- The Windsor key stays where it already is: `/opt/data/.env` as `MCP_WINDSOR_API_KEY` (or `WINDSOR_API_KEY`). Make sure that file is `chmod 600`.
- Never copy the key into `groov.env`, the code, or a message.

**Verify:** `stat -c %a groov.env /opt/data/.env` prints `600` for both.

### B5. Seed the saved creatives
```bash
cd /opt/data/groov-cc/app
set -a; . /opt/data/.env; . ../groov.env; set +a
node server/cli.mjs seed-creatives seed/creatives
```
**Verify:** the output reads `seed-creatives: 364 files in the library (meta 349, tiktok 15) · 364 copied · 0 already saved …`.

### B6. First pull, small (last 7 days) to prove the connection
```bash
node server/cli.mjs backfill --from "$(date -d '7 days ago' +%F)"
node server/cli.mjs status
```
**Verify:**
- `status` shows the 5 datasets with rows for the last 7 days and a snapshot version.
- Then cross-check one number against Windsor directly. For Meta, the **"last day: rows / spend"** column in `status` must equal the Windsor total for the same day and accounts, within ฿1. Report both numbers.

Known issue: as of 2026-10-13, three Meta accounts are **not reachable** in this Windsor connection: Birdiepoolvilla (2329133337532593), Rena Yakiniku (1342233060015249) and Vistro Bangkok (1638002137420134). If they're still missing, tell Finn: they must be reconnected in Windsor, and it's not something you can fix.

### B7. Full history
```bash
node server/cli.mjs backfill          # --from defaults to BACKFILL_FROM
node server/cli.mjs status
```
- This can take a while: it pulls in date chunks.
- It's **resumable**: if it stops, run the same command again, and dates already stored are skipped.

**Verify:**
- In `status`, **first** is the first day Windsor had rows. It notes when earlier days were pulled but came back empty, which is normal when an account started later.
- **last 60 days** should read "complete", or list the days that are missing.
- Report the date span and row counts per dataset.

### B8. Run the server and the daily refresh (systemd)
Copy and adapt the units in `app/deploy/`:
- Replace `User=`/`Group=CHANGE_ME` with the user that owns `/opt/data/groov-cc`.
- If `node` is not in `/usr/bin` or `/usr/local/bin` (for example an nvm install), put its **full path** in `ExecStart`.
- The units already have WorkingDirectory `/opt/data/groov-cc/app` and the two `EnvironmentFile=` lines: `/opt/data/.env` and `/opt/data/groov-cc/groov.env`.
- Run manual CLI commands as that same user, so file ownership stays consistent.
- The refresh unit treats exit code 75 ("another refresh is already running") as success.

```bash
sudo cp app/deploy/groov-cc.service app/deploy/groov-cc-refresh.service app/deploy/groov-cc-refresh.timer /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now groov-cc.service groov-cc-refresh.timer
systemctl status groov-cc.service --no-pager
systemctl list-timers groov-cc-refresh.timer --no-pager
curl -s -o /dev/null -w "%{http_code}\n" http://127.0.0.1:8787/   # expect 401 in tailscale mode (no Tailscale identity on a direct curl)
```
**Verify:**
- the service is active;
- the timer shows the next run at 07:00 Bangkok;
- the direct curl returns 401. That proves non-Tailscale access is refused.

- Check the timer's timezone support with `systemd-analyze calendar '*-*-* 07:00:00 Asia/Bangkok'`.
- If it's refused, use `app/deploy/groov-cc-refresh.cron` instead (00:00 UTC = 07:00 Bangkok).
- A public `GET /healthz` answers without sign-in, for monitoring.

### B9. Publish privately with Tailscale
Follow `app/deploy/tailscale.md`:
```bash
sudo tailscale serve --bg --https=443 http://127.0.0.1:8787
tailscale serve status
```
**Verify:**
- `tailscale serve status` shows the HTTPS address (`https://<vps>.<tailnet>.ts.net`).
- From a tailnet device, the dashboard loads and the sidebar footer says "Signed in via Tailscale as …".
- **Never** run `tailscale funnel`.

### B10. Final check and report to Finn
Open the dashboard (or ask Finn to) and confirm:
- the **Data health** page shows all datasets fresh (last date = yesterday);
- **Overview** totals look sane;
- a client page opens with images;
- an ad set panel shows placement and audience splits;
- `journalctl -u groov-cc -n 50` has no errors.

Send Finn:
- the Tailscale URL
- the output of `node server/cli.mjs status`
- test counts
- the Windsor spend cross-check from B6
- any accounts missing from Windsor

---

## Part C: daily operation
- **07:00 Bangkok:** the timer re-pulls the last 28 days, rebuilds the snapshot and saves new creatives. The server hot-reloads the new snapshot; no restart is needed.
- **Each morning after 07:15:** run `node server/cli.mjs status`. If the snapshot is older than today, or any dataset's last date is older than yesterday, follow Part D and tell Finn.
- **On demand:** Finn (an owner) can press "Refresh data now" in the dashboard, or you can run `node server/cli.mjs refresh`.
- **Re-pull a period** (for example after Windsor fixes data): `node server/cli.mjs backfill --from 2026-09-01 --to 2026-09-30 --force`.
- **Disk:** check `du -sh data/*` weekly. Snapshots keep the last 3 versions; raw partitions and creatives grow slowly and are kept forever.
- **Backups:** nightly, `tar -czf /opt/data/backups/groov-cc-$(date +%F).tgz -C /opt/data/groov-cc config data/raw data/creatives`. Keep 14. Snapshots can always be rebuilt from raw.

## Part D: runbooks
| Symptom | Likely cause | What to do |
|---|---|---|
| Refresh fails with 401/403 from Windsor | key missing, wrong or expired | Check the env file is loaded (not its value). Ask Finn to issue a new key in Windsor if needed. |
| An account disappears or shows "not available" | its Windsor connection broke | Tell Finn which account and since when. He reconnects it in Windsor. Then run `backfill --from <first missing date> --force`. |
| A dataset's last date isn't advancing | Windsor delay or a refresh error | `journalctl -u groov-cc-refresh -n 100`. Run `node server/cli.mjs refresh` manually and report the error text (never the key). |
| Dashboard shows old data after a refresh | snapshot build failed (the previous one keeps serving) | Check the refresh logs. Fix and rerun. `node server/cli.mjs snapshot` rebuilds from stored data without pulling. |
| A new snapshot is wrong | bad source data or a code regression | `node server/cli.mjs rollback` serves the previous version. `rollback --to <version>` picks any kept version, listed by `status`. Then investigate. |
| Re-pull refused with a "shrink" warning | Windsor returned less than half the rows already stored for those days | The stored days are kept on purpose. Check Windsor (account disconnected?). Use `--force` only when the drop is real. |
| Dashboard unreachable | service down or Tailscale serve off | `systemctl restart groov-cc`; `tailscale serve status`. |
| 401 page from a tailnet device | user not on `ALLOWED_USERS`, or opened the raw IP instead of the Tailscale HTTPS name | Use the `https://<vps>.<tailnet>.ts.net` address; add the user's Tailscale login to `ALLOWED_USERS` if Finn approves. |
| Ads show "Creative not saved yet" | image link expired before the job saved it | Normal for ads that ran only before the server existed. New ads are saved daily (`node server/cli.mjs images` runs the job by hand). |
| Disk filling | snapshots not pruning, or very large backfill | Check `du`. Only delete snapshot versions older than the current and previous one. Never delete `data/raw`. |

## Part E: maintenance and change control
- **Upgrades** (Finn sends a newer zip):
  1. Unzip to `app.new/`.
  2. Run `npm test` there.
  3. `mv app app.prev && mv app.new app`.
  4. `systemctl restart groov-cc`.
  5. Merge any *new* keys from `app/config/groov.env.example` into `groov.env`.

  Never overwrite `config/` or `data/`. Keep `app.prev` until the new version has run one daily refresh cleanly.
- **Client registry** (`config/accounts/registry.json`): add new clients and accounts here when Finn signs them. The account IDs must match Windsor's.
  - Edits in `config/` are picked up on the next page load.
  - `node server/cli.mjs build-static` applies them immediately.
- **Access changes:** changing `ALLOWED_USERS` or `OWNER_USERS` in `groov.env` needs `sudo systemctl restart groov-cc`.
- **Learning log** (`config/learnings/`: `PLAYBOOK.md`, `LOG.md`, `rules.json`): the dashboard reads it and runs `rules.json` checks live.
  - When you analyse performance for Finn, follow the rules at the top of `LOG.md`: an L-entry with exact numbers and IDs, the sample size, a confidence level (Observation → Tested → Proven), never deleting history, and Proven only with Finn's OK.
  - Then run `node server/cli.mjs build-static`.
- **Git (recommended).** Run `git init` in `/opt/data/groov-cc` and track `config/`, `CHANGELOG.md` and your deploy edits. Never track `data/`, `groov.env` or `/opt/data/.env`.
  - If Finn creates a private repository, push there. It becomes the single source of truth that both you and Claude (on Finn's Mac) work from.
  - Until then, Finn's Mac copy (`Ads/dashboard`, `Ads/accounts`, `Ads/learnings`) and your `config/` can drift. Note every config change in `CHANGELOG.md` so Finn can sync it.
- **Read the docs before changing behaviour:** `docs/SPEC.md` (features, decision rules, acceptance checks) and `docs/DATA_CONTRACT.md` (fields, payloads). They're authoritative. Change code and docs together, and keep `npm test` green.

## Part F: extending (KOL, Content, CRM)
Read `MODULES.md`. Every new module:
- plugs into the same layout: datasets → raw partitions → pure normaliser with tests → `/api/<module>/*` routes → views under `#/<module>/…` → an entry in `config/modules.json`;
- joins on the client registry.

Build one module at a time. Show Finn a sample-data version before wiring the daily pull.
