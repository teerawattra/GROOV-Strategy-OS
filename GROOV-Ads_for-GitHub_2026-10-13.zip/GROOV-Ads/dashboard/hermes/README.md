# GROOV Command Center: VPS package

This zip is the whole GROOV Ads Command Center, ready for **Hermes** to install on the VPS:
- the dashboard
- its server
- the account registry
- the learning log
- 364 saved ad creatives
- the setup instructions

## What happens after Hermes sets it up
- **Every morning at 07:00 Bangkok,** Hermes's server pulls the last 28 days from Windsor (Meta, TikTok, Google, plus the Meta placement and audience splits). It stores them on the VPS, keeps full history, and saves new ad images.
- **You open the dashboard** at a private Tailscale address such as `https://groov-vps.<your-tailnet>.ts.net`, on any device logged into your Tailscale. Nobody outside your tailnet can reach it, and there's no password to remember.
- **The dashboard is read-only.** It never changes ads.

## How to hand it over
1. Send Hermes the zip (`GROOV_Command_Center_<date>.zip`).
2. Send this message:

> Please set up the GROOV Command Center from this zip. Follow HERMES.md exactly, step by step, and report back after each verification step. Use your existing Windsor API key; never print it. When it's running, send me the Tailscale URL and the output of `status`.

3. Install Tailscale on your Mac and phone (tailscale.com/download) and log in with the same account the VPS uses.

## What's inside
| File / folder | What it is |
|---|---|
| `HERMES.md` | the agent's setup and operating manual (start here) |
| `MODULES.md` | the blueprint for adding KOL, Content and CRM modules later |
| `docs/SPEC.md` | every dashboard feature and how it works |
| `docs/DATA_CONTRACT.md` | the exact Windsor fields and the data format |
| `config/` | client registry, learning log, module list, settings template |
| `public/`, `server/`, `lib/`, `deploy/` | the dashboard, the VPS server, shared code, and the service files |
| `seed/creatives/` | ad images saved so far, so older ads show their creative |
| `sample/` | September test data, used by the self-tests |

## Before go-live
Reconnect these 3 accounts in Windsor; they're currently unreachable: Birdie Pool Villa, Rena Yakiniku (Meta) and Vistro Bangkok.
