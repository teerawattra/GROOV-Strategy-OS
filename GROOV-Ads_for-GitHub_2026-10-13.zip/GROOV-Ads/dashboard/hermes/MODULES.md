# MODULES.md: adding KOL, Content and CRM next to Ads

Blueprint for Hermes and a developer. Read `HERMES.md` Part A (ground rules) and `SPEC.md` §1 first. Modules are read-only toward platforms, add no npm packages, and use the `HERMES.md` install layout.

## 0. Verified 2026-10-13 (catalog only: `get_connectors`, `get_fields`, `get_options`; no `get_data`)
- **Connected in this Windsor account:** `facebook` (19 accounts), `google_ads` (14), `tiktok` (12), nothing else. Every module needs new connectors (the owner authorises each client in Windsor's onboarding) or manual input.
- No influencer-platform connector exists among Windsor's 366 slugs. Closest: `instagram_public`, `apify_dataset`, `googlesheets`, `file`.
- Tags: **[L]** confirmed live with `get_fields`. **[D]** listed on windsor.ai/data-field/<connector> only; the connector is not connected, so `get_fields` errors: re-run it after connecting, before coding. **[?]** unverified. **[ours]** a manual column we define.

## 1. Module contract
Eight parts. A module may add files but never changes another module's datasets, payloads or tests.

| # | Part | Rule |
|---|---|---|
| 1 | Registration | **Built today:** `config/modules.json` entries are `{id, label, enabled, route}`, and the sidebar switcher appears once more than one module is enabled. **Add in the framework step:** `requires[], datasets[], allowed_users[]`. These are accepted but unused now; per-module allow-lists aren't built yet, and CRM needs them for revenue data. Array order = sidebar order. An empty `allowed_users` will inherit `ALLOWED_USERS`. |
| 2 | Datasets | **Built today:** `lib/datasets.mjs` holds the 5 Ads datasets as `{id, label, connector, fields, kind, input, positiveSpendOnly}`. Field lists are imported from the normalisers, so they're never copied. **Extend the same objects** for new modules with `module, mode, grain, key[], refreshDays`, keeping Ads entries valid. Ids come from `get_fields`, never guessed. Only listed fields are stored. Add a lint test that rejects PII ids (email, phone, name, address, reviewer, message text). |
| 3 | Modes | `daily`: dated rows, re-pull the last N days, upsert on key. `snapshot`: state as of the pull day (post-grain: window by created date). `manual`: a snapshot from a Google Sheet via Windsor `googlesheets` (header row becomes the fields [D]) or a CSV in `data/manual/<module>/` via `cli.mjs ingest-manual` (to build in the framework step). |
| 4 | Raw store | `data/raw/<module>/<dataset>/<YYYY>/<YYYY-MM-DD>.json.gz`: metric date for `daily`, Bangkok pull date otherwise, so every sheet edit is kept. Ads keeps its flat `data/raw/<dataset>/` path; do not migrate. Never hand-edit. |
| 5 | Normaliser | Pure `lib/<module>/*.mjs` (no I/O, injected `today`). Tests `test/<module>-*.test.mjs` on synthetic `sample/<module>/` fixtures: numeric strings, blanks, duplicates, missing columns, registry joins, totals reconcile to source. A failed build keeps the previous snapshot serving and sets `stale`. |
| 6 | API | GET only. `/api/<module>/meta` (rows, first/last date, missing dates, `columns_missing`, `error`, `data_through`) and `/api/<module>/<payload>?from&to` in the Ads envelope (`schema`, `mode`, `cols`+`rows`, `X-Data-Version`). Cross-module: `/api/x/<name>`. |
| 7 | Frontend | **Built today:** the switcher lives in `public/assets/js/sidebar.js` and reads `window.GROOV_MODULES` (served from `config/modules.json`). A new module's pages must be registered in `sidebar.js` and the router in `app.js`. **Framework step:** move to `public/assets/js/modules/<module>/`, where each module registers `{id, label, routes, sidebar, clientSection}`. Routes are `#/<module>/<view>`; Ads routes stay as aliases. `#/client/<slug>` is the hub, with one section per module. Action queue and Data health stay global. Period, compare and vertical filters are shared; views count back from their module's `data_through`. |
| 8 | Docs | Same edit: chapter `M<n>` in `DATA_CONTRACT.md` and `SPEC.md`, a `CHANGELOG.md` line. Show Finn sample data before wiring the daily pull. |

**Honesty rules (extend SPEC §1)**
1. Every figure carries a source label (`platform`, `crm`, `manual`, `kol-reported`); labels are never blended or summed.
2. Reach is not additive across days or posts; views and counts are.
3. Every rate names its denominator (engagement rate defaults to per reach). Missing denominator shows "—". No estimates. Show n; "low n" under 10.
4. Platform messages and leads are not qualified leads. CRM source tags are claims: show attribution coverage beside any cost per outcome.
5. Recent days are provisional. Meta organic "day" buckets may follow Pacific time [?], so compare organic with ads by week.
6. No PII requested or stored. No posting, offline-conversion upload or Windsor write actions.

**Registry as the join key** (additive; Ads ignores unknown keys). Every client gets a frozen `slug` (renames must not break sheet joins) and a `code` (its token in campaign names). Content adds `instagram[{id, handle}]`, `facebook_pages[{id}]`, `tiktok_organic[{id, handle}]`, `gbp[{location_id}]` (ids as Windsor lists them once connected [?]). CRM adds `crm{system, account_id, stage_map{<crm stage id>: lead|qualified|booked|showed|sold|lost}, stage_map_version, outcome_lag_days}` and optional cost-per-qualified-lead `targets`. KOL adds nothing per client: the roster is agency-wide (`kol_roster`) and bookings join by `client_slug`.

## 2. KOL module
**Purpose.** Rebook, renegotiate or drop each KOL; judge fee against results; choose posts to amplify; catch usage-rights breaches. Fees, deliverables and KOL-owned insights are not in Windsor, so inputs are mostly manual; the paid side is measurable.

| Dataset (mode) | Source | Grain / key | Fields | Re-pull |
|---|---|---|---|---|
| `kol_roster` (manual) | sheet | KOL / `kol_id` | `kol_id, name_token, display_name, ig_handle, tiktok_handle, tier, rate_card_thb, status` [ours] | daily |
| `kol_deliverables` (manual) | sheet | deliverable / `deliverable_id` | `deliverable_id, client_slug, kol_id, platform, format, fee_thb, due_date, posted_date, post_url, post_media_id, usage_rights_days, promo_code, reported_views, reported_reach` [ours] | daily |
| `meta_ad_links` (snapshot, Ads add-on) | `facebook` | ad / `account_id, ad_id` | `account_id, ad_id, ad_name, campaign_id, creative_id, ad_labels, instagram_actor_id, source_instagram_media_id, instagram_permalink_url, effective_instagram_media_id, effective_instagram_media__shortcode, effective_instagram_media__username, effective_object_story_id` [L] | 28d window, daily |
| `tiktok_ad_links` (snapshot, Ads add-on) | `tiktok` | ad / `account_id, ad_id` | `account_id, ad_id, ad_name, campaign_id, identity_type, identity_id, item_id, video_id` [L] | 28d window, daily |

Spend and results of linked ads come from existing Ads facts, joined on `platform:ad_id`.

**Identifying KOL ads (best first; store `match_method`)**
1. TikTok: `identity_type` other than `CUSTOMIZED_USER` marks a Spark Ad (catalog text); `item_id` is the post, matched to `post_media_id`.
2. Meta: none of the 858 `facebook` fields names partnership, branded content, creator or sponsor. Match `effective_instagram_media__shortcode` (or the shortcode in `instagram_permalink_url`) to `post_url`. An `effective_instagram_media__username` other than the client's handle is a candidate; whether it is filled for third-party posts needs one sample pull [?].
3. `ad_labels` containing `kol:<kol_id>`, set by the team in Ads Manager.
4. Campaign name `<KOLTOKEN>_<CLIENTCODE>_<OBJ>_<DDMMYY>` (`CLAUDE.md`). Weakest.

Unmatched candidates go to a review list; a human confirms in the sheet. Nothing links silently.

**KPIs**
- Paid and organic stay separate. All-in cost = fee + amplification spend; all-in cost per result = that ÷ paid results of one objective (objectives never merged). Organic results are not attributable; cards say so.
- Cost per 1,000 views = fee ÷ views × 1,000, with `measured` and `kol-reported` views in separate columns.
- On-time rate. Usage-rights days left = `posted_date` + `usage_rights_days` − today; alert if a linked ad runs past expiry.
- With CRM data: all-in cost per qualified lead by `kol_id`. Confidence labels as in Ads: directional 5–24 results, confident 25+.

**MVP (M):** sheets, link datasets, scorecard, rights alerts. **Later:** `instagram_public` refresh (`profile_followers_count, media_like_count` [D]; how usernames are supplied is [?]); TikTok `organic_video_views` [L]. **Not from Windsor:** fees, contracts, rights, promo-code redemptions, insights of KOL-owned posts. Ask KOLs to post as an Instagram Collab with the client (`media_collaborators` [D]); whether it then shows in the client's media insights is [?]: test with the first one.

## 3. Content module
**Purpose.** Per client: which formats and hooks to repeat or stop, which organic posts to boost, whether cadence matches plan, and local demand signals (calls, directions, reviews) for restaurants and clinics.

| Dataset (mode) | Source | Grain / key | Fields [D] | Re-pull |
|---|---|---|---|---|
| `ig_media` (snapshot) | `instagram` | post / `account_id, media_id` | `account_id, media_id, media_shortcode, media_permalink, media_product_type, timestamp, media_caption, media_collaborators, media_like_count, media_comments_count, media_reach, media_views, media_saved, media_shares, media_reel_avg_watch_time, media_reel_skip_rate` | posts <90 days daily, <180 weekly, then frozen |
| `ig_account_daily` (daily) | `instagram` | account × day / `date, account_id` | `date, account_id, followers_count, follower_count, reach, views, accounts_engaged, profile_links_taps` | 7d |
| `fb_posts` (snapshot) | `facebook_organic` | post / `page_id, post_id` | `page_id, post_id, post_created_time, permalink_url, media_type, post_message, post_total_media_view_unique, post_reactions_total, post_comments_total, post_clicks, post_engagements, post_video_views` | as `ig_media` |
| `fb_page_daily` (daily) | `facebook_organic` | page × day / `date, page_id` | `date, page_id, page_follows, page_total_media_view_unique` | 7d |
| `gbp_daily` (daily) | `google_my_business` | location × day / `date, location_id` | `date, location_id, impressions_desktop_maps, impressions_desktop_search, impressions_mobile_maps, impressions_mobile_search, call_clicks, direction_requests, website_clicks, business_bookings, conversations` | 14d |
| `gbp_reviews` (snapshot) | `google_my_business` | review / `location_id, review_id` | `location_id, review_id, review_star_rating, review_create_time, review_update_time, review_reply_update_time` (never `review_reviewer` or comment texts) | daily, full |

**Gotchas**
- `followers_count` is today's value, not per date: keep only the pull-day value and build history by snapshotting from day one; `follower_count` (daily change) fills the gap.
- Whether `date_from/date_to` filters post-grain rows by post date is [?]; test with a known post.
- Meta deprecated parts of the Facebook impression metrics: the connector lists legacy `post_impressions_unique` beside `*_total_media_view_unique`; keep whichever is non-null.
- `review_star_rating` is TEXT: map words to 1–5. GBP data lags a few days (background knowledge), hence 14d.
- **Later [D]:** `tiktok_organic` (`video_id, video_views_count, video_reach, video_likes, video_shares`; account: `date, followers_count, profile_views`); Instagram stories (24-hour life, so missed days are lost: background knowledge); `youtube` (`video, views`).

**KPIs**
- `media_reach` is a post's lifetime unique reach: comparable across posts, never summed. Account daily `reach` is a day value: show the series and average, never "monthly reach = sum". Views add up.
- Engagement rate = (likes + comments + saves + shares) ÷ reach per post, labelled "per reach"; per followers only after the first follower snapshot. Rank by median within client × format; under 8 posts is "directional"; posts under 7 days old are excluded.
- Cadence: posts per ISO week vs plan, days since last post. Reels: watch time, skip rate.
- GBP `call_clicks`, `direction_requests`, `website_clicks`, `business_bookings` and Instagram `profile_links_taps` are platform-reported intent actions: shown separately, never added or called leads.
- Reviews: rating, count, new in 28 days, reply rate, hours to reply; unanswered ≤3-star older than 48 hours go to the Action queue.

**Link to Ads.** Became an ad: join on Instagram shortcode (`media_shortcode` ↔ `effective_instagram_media__shortcode`; legacy and new media ids differ), Facebook `post_id` ↔ `effective_object_story_id` [?], TikTok organic `video_id` ↔ ad `item_id` [?]; show the ad's spend, results and first date beside organic numbers (dark posts do not join). Boost candidates: mature posts with per-reach ER in the client's top quartile for the format (n ≥ 8), not matched to an ad, not a KOL post past its rights; data only, humans check licensing.

**MVP (L):** Instagram, Facebook Page, GBP for pilot clients. **Not from Windsor:** content calendar (an optional manual `content_plan` sheet: `plan_id, client_slug, planned_date, platform, format, pillar, post_url`), creative tags (manual or AI-labelled), competitors, LINE OA chats (`line` returns only aggregate followers, blocks and message-delivery counts [D]), history before the first pull.

## 4. CRM module
**Purpose.** What spend becomes after the click. Decide on cost per qualified lead (CPQL), not cost per message; find follow-up leaks; test L-004 (broad vs treatment ads) with outcomes. This closes the gap `CLAUDE.md` names: message-based learnings say nothing about quality.

**Stages** (fixed enum; per-client map in the registry): `lead` → `qualified` → `booked` → `showed` (optional) → `sold`, plus `lost`. Defaults for the owner to confirm: qualified = fits need, budget, location; booked = appointment, reservation, site visit or stay confirmed; sold = paid, in THB.

**Tiers.** Most SME clients live in LINE OA, Meta inbox or spreadsheets, which Windsor cannot read: T1 manual weekly ledger (MVP, counts only); T2 Windsor CRM connector where one exists; T3 lead-level hashed ids (later).

| Dataset (mode) | Source | Grain / key | Fields | Re-pull |
|---|---|---|---|---|
| `crm_ledger` (manual) | sheet | week × client × source × ref / `week_start, client_slug, source, ref` | `week_start, client_slug, source, ref, leads, qualified, booked, showed, sold, lost, revenue_thb, entered_by` [ours]. `source`: meta_ads, tiktok_ads, google_ads, kol, organic_social, gbp, line_oa_direct, referral, walk_in, unknown. `ref`: `kol_id` or campaign code | daily |
| `crm_ghl_opps` (snapshot) | `gohighlevel` | opportunity / `account_id, opportunity_id` | `account_id, opportunity_id, opportunity_created_at, opportunity_pipeline_id, opportunity_pipeline_stage_id, opportunity_status, opportunity_monetary_value, opportunity_last_stage_change_at, opportunity_source, opportunity_first_attribution_campaign_id, opportunity_first_attribution_utm_source` [D]; stages from `pipeline_id, pipeline_name, pipeline_stages` [D] | daily, full |
| `crm_hs_deals` (snapshot) | `hubspot` | deal / `deal_hs_object_id` | `deal_hs_object_id, deal_pipeline, deal_dealstage, deal_amount, deal_createdate, deal_closedate, deal_hs_is_closed_won, deal_closed_lost_reason, deal_hs_analytics_source, deal_hs_analytics_source_data_1` [D] | daily, full |
| `crm_hs_contacts` (snapshot) | `hubspot` | contact / `contact_hs_object_id` | `contact_hs_object_id, contact_createdate, contact_lifecyclestage, contact_hs_analytics_source, contact_hs_lifecyclestage_lead_date, contact_hs_lifecyclestage_marketingqualifiedlead_date, contact_hs_lifecyclestage_salesqualifiedlead_date, contact_hs_lifecyclestage_opportunity_date, contact_hs_lifecyclestage_customer_date` [D] | daily, full |

**Gotchas**
- GoHighLevel exposes the current stage and last-change times only; its field list has no appointments, calendars or stage history: keep daily snapshots and diff them. HubSpot lifecycle dates give stage entry directly; HubSpot stage labels are [?].
- Never request `contact_email`, `contact_phone`, `contact_first_name`, `opportunity_contact_*`, `deal_dealname`, or Instant-Form `email`, `full_name`, `phone_number` (`facebook_leads` [D]; `id, created_time, form_id, campaign_id` are non-PII).
- Meta pixel events `conversions_schedule_total` and `conversions_contact_total` [L] are platform-reported: comparison only.

**KPIs**
- CPQL = Ads spend on the ledger's ad-source platforms ÷ qualified from those sources, same client and period. If `unknown` exceeds 10% of leads show a range [spend ÷ (ad sources + unknown), spend ÷ ad sources]; always show attribution coverage = 1 − unknown share.
- Cost per booking and per sale, same method. CRM ROAS = `revenue_thb` ÷ spend, labelled "CRM revenue", only when logged.
- Stage ratios are ratios of period counts, not cohort conversion (cohorts need T3). The last `outcome_lag_days` (14 clinic and real estate, 7 F&B and hotel) are shaded provisional and excluded from decisions.
- Platform messages and lead actions sit beside CRM leads; no ratio unless the client runs one result type.

**Link to Ads.** CPQL per client and platform from Ads facts; per campaign only where `ref`, UTM or attribution carries a campaign id. The Ads client view gets a "Downstream" line; `rules.json` predicates (e.g. `cpql_gt`) fire only with ≥ 10 qualified.

**MVP (M):** ledger template, CPQL/booking views, coverage, client section; 3 pilots (clinic first). **Next:** GoHighLevel, HubSpot (M each). **Later:** hashed cohorts, speed-to-lead. **Not from Windsor:** LINE OA and Meta inbox chats, clinic/POS/PMS records, revenue, who is qualified.

## 5. Cross-module features
1. **Outcome ledger view** (Ads + CRM): spend → platform result → qualified → booked → sold per client, source-labelled, with coverage. Ship first.
2. **KOL ROI** (KOL + Ads + CRM): all-in cost vs paid results and CRM outcomes by `kol_id`; Observation until ≥ 3 deliverables or 20 results.
3. **Organic-to-paid pipeline** (Content + Ads): became-an-ad list, boost candidates, replacements when Ads flags fatigue.
4. **Monthly export and learning hooks:** per-client CSV/JSON for the monthly deck (never auto-sent). Modules propose Observations; Hermes writes `L-` entries and `rules.json` predicates. New Action-queue items: rights expired, deliverable overdue, unanswered low-star review, ledger older than 10 days, coverage drop, disconnected connector.

## 6. Build order and open questions
Effort: S ≤ 2 days, M 3–7, L 8+ (developer plus agent).

| Step | What | Effort | Why |
|---|---|---|---|
| 0 | Framework: parts 1–8, `lib/datasets.mjs`, manual ingest, switcher, registry `slug`/`code` | M | All depend on it; Ads tests stay green |
| 1 | Ads add-ons `meta_ad_links`, `tiktok_ad_links` | S | KOL and Content join on them |
| 2 | CRM ledger MVP | M | Biggest decision gap; no connector |
| 3 | KOL MVP | M | Mostly manual; ROI improves after 2 |
| 4 | Content MVP (Instagram, Facebook Page, GBP) | L | Per-client OAuth, post-grain snapshots |
| 5 | CRM connectors (GoHighLevel, HubSpot) | M each | Only where used |
| 6 | Content TikTok, stories, YouTube; KOL `instagram_public` | M | Lowest priority |

Start owner tasks now (they take calendar time): connect pilot clients' Instagram, Facebook Pages, TikTok and GBP in Windsor; create the ledger and KOL sheets; agree stage definitions. Pilot 3 clients (clinic, F&B, hotel or real estate). Per module: `get_fields` → fixtures → tests → sample UI to Finn → connect and `backfill` → enable in `modules.json`.

**Open questions for the owner**
1. Which lead system does each client use (LINE OA, Meta inbox, GoHighLevel, HubSpot, spreadsheet, clinic/POS/PMS software, none)?
2. What are qualified, booked and sold per vertical, is revenue (THB) visible to us, and who enters the weekly ledger (can it be a retainer obligation)?
3. Where is the KOL tracker today? Are KOL prefixes used consistently in campaign names? Do KOLs give Spark codes, partnership approval or Collab posts?
4. Which clients will authorise Instagram, Facebook Page, TikTok and GBP in Windsor, are their Instagram accounts Business accounts, and what does the Windsor plan allow?
5. Which attribution aids exist (promo codes, KOL links or QR, "how did you hear")?
6. PDPA: are hashed lead ids acceptable on the VPS, and who may see CRM revenue? Which pilot clients, and what minimum spend puts a client in CPQL?
