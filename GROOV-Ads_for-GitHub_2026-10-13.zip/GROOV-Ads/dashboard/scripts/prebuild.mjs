#!/usr/bin/env node
// Netlify build step (netlify.toml: command = "node scripts/prebuild.mjs", publish = "dist").
//
//   1. On Finn's Mac the parent Ads/ folder is present: regenerate public/data/registry.js and learnings.js with
//      tools/build_static.py, so every deploy carries the current registry and learning log.
//      (Skipped when Ads/accounts/registry.json is not there, e.g. a git build of this folder alone; then the
//      committed files are used. SKIP_BUILD_STATIC=1 or --skip-static skips it on purpose.)
//   2. Check that the dashboard and its generated data files exist.
//   3. Copy public/ to a fresh dist/, leaving out public/data/sample.* (the local preview bundle with real client
//      numbers; it must never be deployed) and dot-files such as .DS_Store.
//   4. Fail if anything named sample.* ended up in dist/data anyway.
//
// Why a copy instead of publishing public/ directly: deleting sample.js from public/ would break the local preview
// after every deploy, and publishing public/ would upload it whenever the build step was skipped.

import { spawnSync } from 'node:child_process';
import { cpSync, existsSync, readdirSync, realpathSync, rmSync, statSync } from 'node:fs';
import { dirname, join, relative, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const REQUIRED = ['index.html', join('data', 'registry.js'), join('data', 'learnings.js')];

/** True for files that must never be published. `rel` is relative to the source folder. */
export function isExcluded(rel) {
  const parts = rel.split(sep).filter(Boolean);
  if (parts.some((p) => p.startsWith('.'))) return true; // .DS_Store, .netlify, editor files
  return parts.length === 2 && parts[0] === 'data' && /^sample\./i.test(parts[1]);
}

/**
 * Copy `src` to a fresh `out`, skipping excluded files. Returns counts. Throws when a required file is missing
 * or a sample bundle is found in the result.
 */
export function buildDist({ src = join(ROOT, 'public'), out = join(ROOT, 'dist'), required = REQUIRED } = {}) {
  const missing = required.filter((f) => !existsSync(join(src, f)));
  if (missing.length) {
    throw new Error(`Missing in ${relative(ROOT, src) || src}: ${missing.join(', ')}. `
      + 'index.html is the dashboard; data/registry.js and data/learnings.js come from "npm run build:static" on the Mac that has the Ads/ folder.');
  }
  rmSync(out, { recursive: true, force: true });
  const skipped = [];
  cpSync(src, out, {
    recursive: true,
    filter: (source) => {
      const rel = relative(src, source);
      if (rel === '') return true;
      if (isExcluded(rel)) {
        skipped.push(rel);
        return false;
      }
      return true;
    },
  });
  const dataDir = join(out, 'data');
  if (existsSync(dataDir) && readdirSync(dataDir).some((f) => /^sample\./i.test(f))) {
    throw new Error('dist/data contains a sample bundle; refusing to continue.');
  }
  let files = 0;
  let bytes = 0;
  const walk = (dir) => {
    for (const name of readdirSync(dir)) {
      const p = join(dir, name);
      const st = statSync(p);
      if (st.isDirectory()) walk(p);
      else {
        files++;
        bytes += st.size;
      }
    }
  };
  walk(out);
  return { files, bytes, skipped };
}

/** Run tools/build_static.py when the parent Ads/ folder is available. Returns "ran" | "skipped: <why>". */
export function buildStatic({ root = ROOT, skip = false } = {}) {
  if (skip) return 'skipped: SKIP_BUILD_STATIC / --skip-static';
  if (!existsSync(resolve(root, '..', 'accounts', 'registry.json'))) return 'skipped: ../accounts/registry.json not found (using the committed data files)';
  const result = spawnSync('python3', [join(root, 'tools', 'build_static.py')], { stdio: 'inherit', cwd: root });
  if (result.error) throw new Error(`Could not run python3 (${result.error.code ?? result.error.message}). Install Python 3, or set SKIP_BUILD_STATIC=1 to deploy the existing data files.`);
  if (result.status !== 0) throw new Error(`tools/build_static.py failed (exit ${result.status}).`);
  return 'ran';
}

function main(argv) {
  const skip = argv.includes('--skip-static') || process.env.SKIP_BUILD_STATIC === '1';
  const outArg = argv.indexOf('--out');
  const out = outArg !== -1 ? resolve(argv[outArg + 1]) : join(ROOT, 'dist');
  const staticResult = buildStatic({ skip });
  console.log(`prebuild: registry/learnings ${staticResult}`);
  const { files, bytes, skipped } = buildDist({ out });
  const shown = relative(process.cwd(), out);
  console.log(`prebuild: ${shown && !shown.startsWith('..') ? shown : out} ready, ${files} files, ${(bytes / 1024).toFixed(0)} KB`
    + (skipped.length ? `; left out: ${skipped.join(', ')}` : ''));
}

if (process.argv[1] && realpathSync(resolve(process.argv[1])) === realpathSync(fileURLToPath(import.meta.url))) {
  try {
    main(process.argv.slice(2));
  } catch (err) {
    console.error(`prebuild failed: ${err.message}`);
    process.exitCode = 1;
  }
}
