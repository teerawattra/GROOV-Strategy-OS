#!/usr/bin/env node
// One-time upload of the existing creative library into the Netlify Blobs store "creatives".
//
//   npm run seed:creatives                     upload (asks for anything not set in the environment)
//   node scripts/seed-creatives.mjs --dry-run  only count what would be uploaded (no Netlify access needed)
//   options: --dir <library folder>  (default ../command-center/creatives)   --concurrency <n> (default 6)
//
// Reads <dir>/meta/<ad_id>.jpg and <dir>/tiktok/<ad_id>.jpg (the library built by command-center/creatives.py),
// skips files of 100 bytes or less and anything that is not really an image, skips keys that already exist in
// the store, and uploads the rest as "meta/<ad_id>" / "tiktok/<ad_id>" with metadata
// { contentType, savedAt, sourceDate: null, bytes, source: "seed" }.
//
// Netlify access (never printed, never written to disk):
//   NETLIFY_SITE_ID     the site's Project ID; if unset, read from .netlify/state.json (written by `netlify link`)
//   NETLIFY_AUTH_TOKEN  a Netlify personal access token; if unset you are asked for it with hidden input

import { existsSync, readFileSync, readdirSync, realpathSync, statSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { createInterface } from 'node:readline';
import { fileURLToPath } from 'node:url';
import { CREATIVES_STORE, CREATIVE_PLATFORMS, creativeKey, listSavedCreatives, openStore, toArrayBuffer } from '../lib/blobs-store.mjs';
import { sniffImageType } from '../lib/creatives-job.mjs';
import { mapLimit } from '../lib/sheets.mjs';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
export const DEFAULT_LIBRARY = resolve(ROOT, '..', 'command-center', 'creatives');
const FILE_RE = /^(\d{1,30})\.(jpe?g|png|webp|gif)$/i;

/** Local library -> { files: [{platform, adId, path}], invalid } (sizes checked; bytes read at upload time). */
export function scanLibrary(dir) {
  const files = [];
  let invalid = 0;
  for (const platform of CREATIVE_PLATFORMS) {
    const folder = join(dir, platform);
    if (!existsSync(folder)) continue;
    for (const name of readdirSync(folder).sort()) {
      const m = FILE_RE.exec(name);
      if (!m) continue;
      const path = join(folder, name);
      if (statSync(path).size <= 100) {
        invalid++;
        continue;
      }
      files.push({ platform, adId: m[1], path });
    }
  }
  return { files, invalid };
}

/**
 * Upload every library file whose key is not in the store yet.
 * @returns {Promise<{found: number, already: number, uploaded: number, invalid: number, failed: number}>}
 */
export async function seedCreatives({ store, dir = DEFAULT_LIBRARY, concurrency = 6, now = () => new Date(), dryRun = false }) {
  const { files, invalid } = scanLibrary(dir);
  const counts = { found: files.length + invalid, already: 0, uploaded: 0, invalid, failed: 0 };
  if (dryRun) return { ...counts, would_upload: files.length };
  const existing = await listSavedCreatives(store);
  const todo = files.filter((f) => {
    if (existing.has(`${f.platform}:${f.adId}`)) {
      counts.already++;
      return false;
    }
    return true;
  });
  await mapLimit(todo, concurrency, async (f) => {
    const bytes = readFileSync(f.path);
    const contentType = sniffImageType(bytes);
    if (!contentType) {
      counts.invalid++;
      return;
    }
    try {
      await store.set(creativeKey(f.platform, f.adId), toArrayBuffer(bytes), {
        metadata: { contentType, savedAt: now().toISOString(), sourceDate: null, bytes: bytes.length, source: 'seed' },
      });
      counts.uploaded++;
    } catch {
      counts.failed++;
    }
  });
  return counts;
}

// ---------------------------------------------------------------------------------------------------------
// CLI
// ---------------------------------------------------------------------------------------------------------

function siteIdFromLink() {
  try {
    const state = JSON.parse(readFileSync(join(ROOT, '.netlify', 'state.json'), 'utf8'));
    return typeof state.siteId === 'string' ? state.siteId : '';
  } catch {
    return '';
  }
}

function ask(question) {
  const rl = createInterface({ input: process.stdin, output: process.stdout });
  return new Promise((resolveAnswer) => rl.question(question, (answer) => {
    rl.close();
    resolveAnswer(answer.trim());
  }));
}

/** Read a line without echoing it (for the access token). */
function askHidden(question) {
  if (!process.stdin.isTTY) return Promise.reject(new Error('NETLIFY_AUTH_TOKEN is not set and there is no terminal to ask for it.'));
  process.stdout.write(question);
  return new Promise((resolveAnswer, reject) => {
    const stdin = process.stdin;
    let value = '';
    const cleanup = () => {
      stdin.setRawMode(false);
      stdin.pause();
      stdin.off('data', onData);
      process.stdout.write('\n');
    };
    function onData(chunk) {
      for (const ch of chunk) {
        if (ch === '\r' || ch === '\n') {
          cleanup();
          resolveAnswer(value.trim());
          return;
        }
        if (ch === '\u0003') {
          cleanup();
          reject(new Error('Cancelled.'));
          return;
        }
        if (ch === '\u007f' || ch === '\b') value = value.slice(0, -1);
        else value += ch;
      }
    }
    stdin.setRawMode(true);
    stdin.setEncoding('utf8');
    stdin.resume();
    stdin.on('data', onData);
  });
}

function option(argv, name, fallback) {
  const i = argv.indexOf(name);
  return i !== -1 && i + 1 < argv.length ? argv[i + 1] : fallback;
}

async function main(argv) {
  const dir = resolve(option(argv, '--dir', DEFAULT_LIBRARY));
  const concurrency = Math.max(1, Math.min(16, Number(option(argv, '--concurrency', 6)) || 6));
  if (!existsSync(dir)) throw new Error(`Creative library not found: ${dir}`);

  if (argv.includes('--dry-run')) {
    const counts = await seedCreatives({ store: null, dir, dryRun: true });
    console.log(`seed-creatives (dry run): ${counts.would_upload} image files ready, ${counts.invalid} too small to be images, in ${dir}`);
    return;
  }

  const siteID = process.env.NETLIFY_SITE_ID?.trim() || siteIdFromLink() || (await ask('Netlify Project ID (Project configuration > General): '));
  const token = process.env.NETLIFY_AUTH_TOKEN?.trim() || (await askHidden('Netlify personal access token (input hidden): '));
  if (!siteID || !token) throw new Error('Both the Netlify Project ID and a personal access token are needed.');

  const store = await openStore(CREATIVES_STORE, { siteID, token });
  const started = Date.now();
  const counts = await seedCreatives({ store, dir, concurrency });
  console.log(`seed-creatives: ${counts.found} files in the library · ${counts.uploaded} uploaded · ${counts.already} already in Netlify`
    + ` · ${counts.invalid} skipped (not an image) · ${counts.failed} failed · ${((Date.now() - started) / 1000).toFixed(1)} s`);
  if (counts.failed) process.exitCode = 1;
}

if (process.argv[1] && realpathSync(resolve(process.argv[1])) === realpathSync(fileURLToPath(import.meta.url))) {
  main(process.argv.slice(2)).catch((err) => {
    console.error(`seed-creatives failed: ${err?.message ?? err}`);
    process.exitCode = 1;
  });
}
