#!/usr/bin/env node
// Build the VPS package for Hermes:  npm run package:hermes
//
//   dist-hermes/GROOV_Command_Center/        the folder (inspect it before sending)
//   ../hermes-package/GROOV_Command_Center_<YYYY-MM-DD>.zip   what Finn sends to Hermes
//
// Contents:
//   public/          the dashboard, WITHOUT data/sample.js (real client numbers) and WITHOUT the Google sign-in files
//                    (login.html, assets/login.js, assets/login.css): the server has its own /login.html. data/registry.js
//                    and data/learnings.js are rebuilt from ../accounts and ../learnings with tools/build_static.py, and
//                    data/modules.js from config/modules.json (they are the fallback the server ships with)
//   lib/             only the modules the package imports (computed from the import graph: no Netlify, Blobs, Google or
//                    session-cookie code)
//   server/ deploy/  the VPS server, CLI, systemd units, cron alternative, tailscale notes
//   config/          accounts/registry.json and learnings/{PLAYBOOK.md,LOG.md,rules.json} copied from ../accounts and
//                    ../learnings, plus modules.json and groov.env.example
//   tools/           build_static.py (learning log -> JS) and build-data.mjs (sample bundle for the frontend tests)
//   seed/creatives/  the saved creative library (../command-center/creatives/{meta,tiktok}, image files only)
//   sample/sheets/   the Sep 2026 sample CSVs (the tests use them)
//   test/            the tests that run without Netlify (normaliser, breakdowns, frontend engine with Hermes parity,
//                    VPS server) and their helpers, including the mock Windsor
//   docs/            SPEC.md, DATA_CONTRACT.md, research/
//   package.json     no dependencies; scripts test, serve, refresh, backfill, status
//   HERMES.md MODULES.md README.md   from hermes/ (a placeholder when one is not written yet)
//
// Options: --no-zip (folder only), --date YYYY-MM-DD (zip name), --out <dir> (zip folder).

import { spawnSync } from 'node:child_process';
import { cpSync, existsSync, mkdirSync, readdirSync, readFileSync, realpathSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { dirname, join, relative, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { modulesJs } from '../server/static-data.mjs';
import { todayIn } from '../server/util.mjs';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const ADS = resolve(ROOT, '..');
export const PACKAGE_NAME = 'GROOV_Command_Center';

/** Tests that run on the VPS (no Netlify, Blobs or Google code), and the helpers they import. */
export const PACKAGE_TESTS = Object.freeze([
  'csv.test.mjs', 'normalize.test.mjs', 'breakdowns.test.mjs', 'build-data.test.mjs',
  'frontend-engine.test.cjs', 'frontend-trends.test.cjs', 'frontend-modules.test.cjs',
]);
export const TEST_HELPERS = Object.freeze(['backend-fakes.mjs', 'sample-bundle.cjs', 'mock-windsor.mjs', 'server-helpers.mjs']);
const HERMES_DOCS = Object.freeze(['HERMES.md', 'MODULES.md', 'README.md']);

/** public/ paths (relative, "/" separated) that never go into the package. */
export function excludedFromPublic(rel) {
  const parts = rel.split('/').filter(Boolean);
  if (parts.some((p) => p.startsWith('.'))) return true;
  if (parts.length === 2 && parts[0] === 'data' && /^sample\./i.test(parts[1])) return true;
  return ['login.html', 'assets/login.js', 'assets/login.css'].includes(parts.join('/'));
}

const IMPORT_RES = [
  /(?:^|[\s;])(?:import|export)\s[^'"`]*?\sfrom\s*['"](\.{1,2}\/[^'"]+)['"]/g,
  /(?:^|[\s;])import\s*['"](\.{1,2}\/[^'"]+)['"]/g,
  /\bimport\(\s*['"](\.{1,2}\/[^'"]+)['"]\s*\)/g,
  /\brequire\(\s*['"](\.{1,2}\/[^'"]+)['"]\s*\)/g,
];

/** Relative imports of a source file (static, dynamic with a literal, and require). */
export function relativeImports(text) {
  const out = new Set();
  for (const re of IMPORT_RES) for (const m of text.matchAll(re)) out.add(m[1]);
  return [...out];
}

/** Every file reachable from `entries` through relative imports (absolute paths). */
export function importClosure(entries) {
  const seen = new Set();
  const stack = [...entries];
  while (stack.length) {
    const file = stack.pop();
    if (seen.has(file)) continue;
    seen.add(file);
    for (const spec of relativeImports(readFileSync(file, 'utf8'))) {
      const target = resolve(dirname(file), spec);
      if (!existsSync(target)) throw new Error(`${relative(ROOT, file)} imports ${spec}, which does not exist`);
      stack.push(target);
    }
  }
  return seen;
}

function walk(dir) {
  const out = [];
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    const p = join(dir, entry.name);
    if (entry.isDirectory()) out.push(...walk(p));
    else out.push(p);
  }
  return out;
}

function copyFile(from, to) {
  mkdirSync(dirname(to), { recursive: true });
  cpSync(from, to);
}

function placeholder(name) {
  return `# ${name}\n\nPlaceholder: this file is written by the main session (Ads/dashboard/hermes/${name}). Re-run \`npm run package:hermes\` once it exists.\n`;
}

export function vpsPackageJson(version) {
  return {
    name: 'groov-command-center',
    version,
    private: true,
    type: 'module',
    description: 'GROOV Ads Command Center on a VPS: Windsor REST -> raw partitions -> normalised snapshots -> dashboard over Tailscale. No dependencies.',
    engines: { node: '>=20' },
    scripts: {
      test: 'node --test test/*.test.mjs test/*.test.cjs',
      serve: 'node server/cli.mjs serve',
      refresh: 'node server/cli.mjs refresh',
      backfill: 'node server/cli.mjs backfill',
      status: 'node server/cli.mjs status',
    },
  };
}

/**
 * Assemble the package folder. Returns { dir, files, bytes, notes }.
 * @param {{ outParent?: string, date?: string, python?: string, log?: (s: string) => void }} [o]
 */
export function assemble({ outParent = join(ROOT, 'dist-hermes'), date = todayIn('Asia/Bangkok'), python = 'python3', log = console.log } = {}) {
  const pkg = join(outParent, PACKAGE_NAME);
  const notes = [];
  rmSync(pkg, { recursive: true, force: true });
  mkdirSync(pkg, { recursive: true });
  const put = (rel, from) => copyFile(from, join(pkg, rel));

  // public/
  cpSync(join(ROOT, 'public'), join(pkg, 'public'), {
    recursive: true,
    filter: (source) => {
      const rel = relative(join(ROOT, 'public'), source).split(sep).join('/');
      return rel === '' || !excludedFromPublic(rel);
    },
  });
  const run = spawnSync(python, [join(ROOT, 'tools', 'build_static.py'), '--registry', join(ADS, 'accounts', 'registry.json'), '--learnings-dir', join(ADS, 'learnings'), '--out-dir', join(pkg, 'public', 'data')], { encoding: 'utf8' });
  if (run.error || run.status !== 0) notes.push(`public/data/registry.js and learnings.js copied as they are (tools/build_static.py did not run: ${run.error ? run.error.code ?? run.error.message : `exit ${run.status}: ${(run.stderr || '').trim().split('\n').pop()}`})`);
  writeFileSync(join(pkg, 'public', 'data', 'modules.js'), modulesJs(JSON.parse(readFileSync(join(ROOT, 'config', 'modules.json'), 'utf8'))));

  // server/, deploy/, tools/
  for (const f of walk(join(ROOT, 'server'))) if (!f.split(sep).some((p) => p.startsWith('.'))) put(relative(ROOT, f), f);
  for (const f of walk(join(ROOT, 'deploy'))) if (!f.split(sep).some((p) => p.startsWith('.'))) put(relative(ROOT, f), f);
  put('tools/build_static.py', join(ROOT, 'tools', 'build_static.py'));
  put('tools/build-data.mjs', join(ROOT, 'tools', 'build-data.mjs'));

  // test/
  const serverTests = readdirSync(join(ROOT, 'test')).filter((f) => /^server-.*\.test\.mjs$/.test(f)).sort();
  const tests = [...PACKAGE_TESTS, ...serverTests];
  for (const f of [...tests, ...TEST_HELPERS]) put(`test/${f}`, join(ROOT, 'test', f));

  // lib/: exactly what the package imports
  const entries = [
    ...walk(join(ROOT, 'server')).filter((f) => f.endsWith('.mjs')),
    join(ROOT, 'tools', 'build-data.mjs'),
    ...[...tests, ...TEST_HELPERS].map((f) => join(ROOT, 'test', f)),
  ];
  const libFiles = [...importClosure(entries)].filter((f) => f.startsWith(join(ROOT, 'lib') + sep)).sort();
  for (const f of libFiles) put(relative(ROOT, f), f);

  // config/
  put('config/modules.json', join(ROOT, 'config', 'modules.json'));
  put('config/groov.env.example', join(ROOT, 'config', 'groov.env.example'));
  put('config/accounts/registry.json', join(ADS, 'accounts', 'registry.json'));
  for (const f of ['PLAYBOOK.md', 'LOG.md', 'rules.json']) put(`config/learnings/${f}`, join(ADS, 'learnings', f));

  // seed/creatives/: image files only
  const library = join(ADS, 'command-center', 'creatives');
  let seeded = 0;
  for (const platform of ['meta', 'tiktok']) {
    const dir = join(library, platform);
    if (!existsSync(dir)) continue;
    for (const name of readdirSync(dir).sort()) {
      if (!/^\d{1,30}\.(jpe?g|png|webp|gif|avif)$/i.test(name)) continue;
      put(`seed/creatives/${platform}/${name}`, join(dir, name));
      seeded++;
    }
  }
  if (!seeded) notes.push(`no creatives found in ${library}; seed/creatives is empty`);

  // sample/sheets, docs/
  for (const f of readdirSync(join(ROOT, 'sample', 'sheets')).filter((n) => n.endsWith('.csv'))) put(`sample/sheets/${f}`, join(ROOT, 'sample', 'sheets', f));
  put('docs/SPEC.md', join(ROOT, 'SPEC.md'));
  put('docs/DATA_CONTRACT.md', join(ROOT, 'DATA_CONTRACT.md'));
  for (const f of walk(join(ROOT, 'research'))) if (!f.split(sep).some((p) => p.startsWith('.'))) put(`docs/${relative(ROOT, f)}`, f);

  // package.json + Hermes docs
  writeFileSync(join(pkg, 'package.json'), `${JSON.stringify(vpsPackageJson(`1.0.0-${date}`), null, 2)}\n`);
  for (const name of HERMES_DOCS) {
    const src = join(ROOT, 'hermes', name);
    if (existsSync(src)) put(name, src);
    else {
      writeFileSync(join(pkg, name), placeholder(name));
      notes.push(`${name}: placeholder (hermes/${name} is not written yet)`);
    }
  }

  // checks
  const files = walk(pkg);
  const rels = files.map((f) => relative(pkg, f).split(sep).join('/'));
  const forbidden = rels.filter((r) => /(^|\/)\.(env|DS_Store|netlify)/.test(r) || /^public\/data\/sample\./i.test(r) || r === 'public/login.html'
    || /^public\/assets\/login\./.test(r) || r.startsWith('netlify/') || r.includes('node_modules/') || /^lib\/(blobs-store|sheets|session|session-token|google-id-token|api-data|refresh)\.mjs$/.test(r));
  if (forbidden.length) throw new Error(`refusing to package: ${forbidden.join(', ')}`);
  for (const f of files.filter((p) => /\.(mjs|cjs)$/.test(p))) {
    for (const spec of relativeImports(readFileSync(f, 'utf8'))) {
      const target = resolve(dirname(f), spec);
      if (!target.startsWith(pkg + sep) || !existsSync(target)) throw new Error(`${relative(pkg, f)} imports ${spec}, which is not in the package`);
    }
  }
  for (const r of ['public/index.html', 'public/data/registry.js', 'public/data/learnings.js', 'public/data/modules.js', 'server/cli.mjs', 'config/accounts/registry.json']) {
    if (!existsSync(join(pkg, r))) throw new Error(`missing in the package: ${r}`);
  }
  const bytes = files.reduce((n, f) => n + statSync(f).size, 0);
  log(`package-hermes: ${relative(process.cwd(), pkg) || pkg} · ${files.length} files · ${(bytes / 1024 / 1024).toFixed(1)} MB · lib: ${libFiles.map((f) => relative(join(ROOT, 'lib'), f)).join(', ')} · ${tests.length} test files · ${seeded} seed creatives`);
  for (const n of notes) log(`package-hermes: note: ${n}`);
  return { dir: pkg, files: rels, bytes, notes, libFiles: libFiles.map((f) => relative(ROOT, f)), tests };
}

/** Zip the folder with the system zip (no .DS_Store, no extra attributes). Returns { path, bytes }. */
export function zipPackage({ outParent, zipDir, date }) {
  mkdirSync(zipDir, { recursive: true });
  const path = join(zipDir, `${PACKAGE_NAME}_${date}.zip`);
  rmSync(path, { force: true });
  const run = spawnSync('zip', ['-r', '-X', '-q', path, PACKAGE_NAME, '-x', '*.DS_Store', '-x', '*/.DS_Store'], { cwd: outParent, encoding: 'utf8' });
  if (run.error || run.status !== 0) throw new Error(`zip failed: ${run.error ? run.error.message : run.stderr.trim()}`);
  return { path, bytes: statSync(path).size };
}

function main(argv) {
  const arg = (name) => {
    const i = argv.indexOf(`--${name}`);
    return i === -1 ? null : argv[i + 1];
  };
  const date = arg('date') ?? todayIn('Asia/Bangkok');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) throw new Error('--date must be YYYY-MM-DD');
  const outParent = join(ROOT, 'dist-hermes');
  assemble({ outParent, date });
  if (argv.includes('--no-zip')) return;
  const zip = zipPackage({ outParent, zipDir: resolve(arg('out') ?? join(ADS, 'hermes-package')), date });
  console.log(`package-hermes: wrote ${zip.path} (${(zip.bytes / 1024 / 1024).toFixed(1)} MB)`);
}

if (process.argv[1] && realpathSync(resolve(process.argv[1])) === realpathSync(fileURLToPath(import.meta.url))) {
  try {
    main(process.argv.slice(2));
  } catch (err) {
    console.error(`package-hermes failed: ${err.message}`);
    process.exitCode = 1;
  }
}
