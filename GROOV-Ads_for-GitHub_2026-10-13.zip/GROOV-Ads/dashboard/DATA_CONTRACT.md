# Data contract: 3 Google Sheets → dashboard JSON

The single source of truth for how ad data flows into the GROOV Ads Command Center. Every component (the Windsor exports, the Netlify data job, the local sample builder and the frontend) must follow this file. If you change it, update all of them.

```
Windsor (daily) ─► 3 Google Sheets ─► normaliser (lib/normalize.mjs) ─► contract JSON ─► dashboard
                                         ▲                                    ▲
                    sample/sheets/*.csv ─┘ (local preview)        Netlify Blobs cache (production)
```

## 1. The three Sheets (lean)

One spreadsheet per platform, **one tab each**. The header row holds Windsor field ids exactly as below, in this order. Full history is kept in each.

### Sheet 1: `GROOV Ads · Meta` (ad × day)
| # | Windsor field | Meaning |
|---|---|---|
| 1 | `date` | YYYY-MM-DD (account timezone, Bangkok) |
| 2 | `account_id` | ad account id, numeric string |
| 3 | `account_name` | |
| 4 | `campaign_id` | |
| 5 | `campaign` | campaign name |
| 6 | `campaign_objective` | e.g. OUTCOME_LEADS, OUTCOME_ENGAGEMENT, OUTCOME_AWARENESS, OUTCOME_TRAFFIC, OUTCOME_SALES |
| 7 | `adset_id` | |
| 8 | `adset_name` | |
| 9 | `ad_id` | |
| 10 | `ad_name` | |
| 11 | `effective_status` | ad effective status at export time (ACTIVE, PAUSED, CAMPAIGN_PAUSED, ADSET_PAUSED, DISAPPROVED, …) |
| 12 | `spend` | THB |
| 13 | `impressions` | |
| 14 | `reach` | daily reach. **Never summed across days for unique reach.** |
| 15 | `clicks` | all clicks |
| 16 | `link_clicks` | |
| 17 | `actions_video_view` | 3-second video plays |
| 18 | `actions_onsite_conversion_messaging_conversation_started_7d` | messaging conversations started (platform-reported) |
| 19 | `actions_lead` | platform-reported lead actions |
| 20 | `purchase_roas_omni_purchase` | purchase ROAS, blank when not tracked |
| 21 | `image_url` | creative image or video thumbnail link (**expires within days**) |
| 22 | `ad_preview_shareable_link` | fb.me preview link |

Upsert key: `date, ad_id`.

### Sheet 2: `GROOV Ads · TikTok` (ad × day)
| # | Windsor field | Meaning |
|---|---|---|
| 1 | `date` | |
| 2 | `account_id` | advertiser id |
| 3 | `account_name` | |
| 4 | `campaign_id` | |
| 5 | `campaign` | |
| 6 | `objective_type` | REACH, TRAFFIC, VIDEO_VIEWS, ENGAGEMENT, LEAD_GENERATION, CONVERSIONS, … |
| 7 | `campaign_status` | CAMPAIGN_STATUS_ENABLE / CAMPAIGN_STATUS_DISABLE / … |
| 8 | `adgroup_id` | |
| 9 | `adgroup_name` | |
| 10 | `ad_id` | |
| 11 | `ad_name` | |
| 12 | `spend` | |
| 13 | `impressions` | |
| 14 | `reach` | daily reach |
| 15 | `clicks` | destination clicks |
| 16 | `total_play` | video plays |
| 17 | `messaging_total_conversation_tiktok_direct_message` | conversations in TikTok direct messages |
| 18 | `messaging_total_conversation_instant_messaging_app` | conversations started in WhatsApp / Messenger / Zalo from TikTok ads |
| 19 | `onsite_form` | TikTok instant-form leads (**not** `total_sales_lead`, which Windsor defines as *app* leads) |
| 20 | `conversions` | |
| 21 | `complete_payment_roas` | |
| 22 | `video_thumbnail_url` | thumbnail link (expires in ~1 day) |

Upsert key: `date, ad_id`.

### Sheet 3: `GROOV Ads · Google` (ad group × day)
| # | Windsor field | Meaning |
|---|---|---|
| 1 | `date` | |
| 2 | `account_id` | e.g. 206-171-2197 |
| 3 | `account_name` | |
| 4 | `campaign_id` | |
| 5 | `campaign` | |
| 6 | `advertising_channel_type` | SEARCH, PERFORMANCE_MAX, DISPLAY, VIDEO, … |
| 7 | `campaign_status` | ENABLED / PAUSED / REMOVED |
| 8 | `ad_group_id` | blank for Performance Max |
| 9 | `ad_group_name` | |
| 10 | `ad_group_status` | |
| 11 | `spend` | |
| 12 | `impressions` | |
| 13 | `clicks` | |
| 14 | `conversions` | platform-reported conversions (can be fractional) |
| 15 | `conversion_value` | THB |

Upsert key: `date, campaign_id, ad_group_id`. Google has no reach and no ad-level rows in this design; search ads are text-only.

### Optional breakdown Sheets (Meta): where results happen inside each ad set
These two are **add-ons**. The 3 core Sheets above stay unchanged, and the dashboard works without these. When they exist, the ad set panels and the client view show placement and audience splits. Each is its own spreadsheet with one tab. A tab inside the Meta spreadsheet also works (the backend only needs the spreadsheet ID and tab name), but separate files keep each one far below Google's 10-million-cell limit. These two grow by about 4 million cells a year together.

The data job finds them through the optional env vars `SHEET_ID_META_PLACEMENTS` and `SHEET_ID_META_AUDIENCE`, plus `SHEET_TAB_META_PLACEMENTS` / `SHEET_TAB_META_AUDIENCE` when a Sheet is a tab of a spreadsheet that holds other Sheets (`DEPLOY.md`). Unset, empty or unreadable means "not available", never an error for the rest of the dashboard.

#### Sheet 4: `GROOV Ads · Meta placements` (ad set × day × placement)
| # | Windsor field | Meaning |
|---|---|---|
| 1 | `date` | |
| 2 | `account_id` | |
| 3 | `adset_id` | names come from Sheet 1, so they aren't repeated here |
| 4 | `publisher_platform` | facebook, instagram, messenger, audience_network, threads |
| 5 | `platform_position` | feed, facebook_reels, facebook_stories, instream_video, instagram_reels, instagram_stories, search, … |
| 6 | `spend` | |
| 7 | `impressions` | |
| 8 | `clicks` | |
| 9 | `link_clicks` | |
| 10 | `actions_video_view` | |
| 11 | `actions_onsite_conversion_messaging_conversation_started_7d` | |
| 12 | `actions_lead` | |

Upsert key: `date, adset_id, publisher_platform, platform_position`. Filter: `spend > 0`.

#### Sheet 5: `GROOV Ads · Meta audience` (ad set × day × age × gender)
| # | Windsor field | Meaning |
|---|---|---|
| 1 | `date` | |
| 2 | `account_id` | |
| 3 | `adset_id` | |
| 4 | `age` | 13-17, 18-24, 25-34, 35-44, 45-54, 55-64, 65+, Unknown |
| 5 | `gender` | female, male, unknown |
| 6–12 | same metrics as Sheet 4 (`spend` … `actions_lead`) | |

Upsert key: `date, adset_id, age, gender`. Filter: `spend > 0`.

Verified with a real Windsor pull on 2026-10-13: messaging conversations and leads are reported under both breakdowns.

**Windsor export settings (all 3):** daily at 06:00 Bangkok · all accounts · date range "last 28 days" (Meta stops revising insights 28 days after they're reported, so re-pulling 28 days catches every late conversion) · upsert on the key above · first-run backfill as far as the plan allows.

**Values:** numbers may arrive as numbers, numeric strings, or blank. Blank, `null` and `None` mean "not reported". A blank metric counts as 0 when summing and is shown as "—" when it is the denominator.

## 2. Normalised contract JSON (`schema: 1`)

Produced by `lib/normalize.mjs` (the optional Sheets 4–5 by `lib/breakdowns.mjs`, which reads numbers, ids and dates by the same rules). The same shape comes from the API (`/api/rows`, `/api/monthly`, `/api/meta`, `/api/breakdowns`) and from the local sample (`public/data/sample.js`, which sets `window.GROOV_SAMPLE`).

### 2.1 Entities (dictionaries, referenced by index)
```jsonc
"accounts":  [{ "key": "meta:1329660951861233", "platform": "meta", "id": "1329660951861233", "name": "GROOV_Strategy_IH" }],
"campaigns": [{ "key": "meta:120248983993170527", "account": 0, "id": "120248983993170527", "name": "Groov_TOF_LeadGen_F&B_17AUG26",
                "objective": "OUTCOME_LEADS", "channel": null, "status": "ACTIVE" }],
"adsets":    [{ "key": "meta:120249…", "campaign": 0, "id": "120249…", "name": "Bangkok_Advantage+", "status": "ACTIVE" }],
"ads":       [{ "key": "meta:120249…", "campaign": 0, "adset": 0, "id": "120249…", "name": "VDO_DA", "status": "ACTIVE",
                "raw_status": "ACTIVE", "preview": "https://fb.me/…", "image": true, "image_reason": null }]
```
- `platform`: `meta` | `tiktok` | `google`.
- `key` is `platform:id`, which is globally unique.
- `objective`: Meta `campaign_objective` / TikTok `objective_type` / Google `null`.
- `channel`: Google `advertising_channel_type`, otherwise `null`.
- **Status** is normalised to `ACTIVE` | `PAUSED` | `DISAPPROVED` | `IN_REVIEW` | `REMOVED` | `UNKNOWN`. It comes from the row with the latest date for that entity.
  - **Meta:** each ad uses its own `effective_status`. `CAMPAIGN_PAUSED`, `ADSET_PAUSED` and `PAUSED` all become `PAUSED`. `raw_status` keeps the original value.
    - An ad set is `ACTIVE` if any of its ads is `ACTIVE`, otherwise `PAUSED` (or `UNKNOWN` when no status data exists).
    - A campaign follows the same rule over its ad sets.
  - **TikTok:** `campaign_status` `…ENABLE` becomes `ACTIVE` and `…DISABLE` becomes `PAUSED`. Ad groups and ads inherit the campaign status (TikTok supplies only campaign status in this design).
  - **Google:** `ENABLED` becomes `ACTIVE`, `PAUSED` stays `PAUSED`, `REMOVED` stays `REMOVED`. Ad groups use `ad_group_status`, falling back to the campaign's status.
- `first_date` and `last_date` are on every campaign, ad set and ad. They're the first and last dates with spend > 0 or impressions > 0 across the **full history**, not just the requested range. They drive "days since launch", new-ad protection and the creative pipeline.
- `image`: `true` when a saved creative exists for that ad.
  - **Production:** the creative is in the Netlify Blobs store `creatives`, key `meta/<ad_id>` or `tiktok/<ad_id>`.
  - **Sample:** the creative is in `Ads/command-center/creatives/<platform>/<ad_id>.jpg`.
- `image_reason`, when `image` is false:
  - `"no_url"`: the platform supplied no image link for this ad.
  - `"not_saved"`: a link existed but was not saved before it expired.
  - `"text_ad"`: Google; no image by design.
- Google has no ad rows. Its `adsets` are ad groups. Performance Max rows have no ad group, so `adset = -1`.

### 2.2 Facts (`/api/rows?from=YYYY-MM-DD&to=YYYY-MM-DD`)
```jsonc
{
  "schema": 1, "mode": "live" | "sample", "generated_at": "2026-10-12T07:05:00+07:00",
  "range": { "from": "2026-09-07", "to": "2026-09-20" },
  "accounts": [...], "campaigns": [...], "adsets": [...], "ads": [...],       // only entities referenced by rows
  "cols": ["date","campaign","adset","ad","spend","impressions","reach","clicks","link_clicks","video_views",
           "messages","leads","conversions","conv_value","roas_value"],
  "rows": [["2026-09-14", 0, 3, 17, 123.45, 5000, 3200, 40, 25, 300, 2, 0, 0, 0, 0]]
}
```
- **Grain:** one row per entity per day at the lowest available level: Meta and TikTok ad × day, Google ad group × day (`ad = -1`), and Google Performance Max campaign × day (`adset = -1`, `ad = -1`).
- **Metric mapping:**

| Contract column | Meta | TikTok | Google |
|---|---|---|---|
| `link_clicks` | `link_clicks` | `clicks` | `clicks` |
| `video_views` | `actions_video_view` | `total_play` | 0 |
| `messages` | `actions_onsite_conversion_messaging_conversation_started_7d` | `messaging_total_conversation_tiktok_direct_message` + `messaging_total_conversation_instant_messaging_app` | 0 |
| `leads` | `actions_lead` | `onsite_form` | 0 |
| `conversions` | 0 | `conversions` | `conversions` |
| `conv_value` | 0 | 0 | `conversion_value` |
| `roas_value` | `purchase_roas_omni_purchase × spend` | `complete_payment_roas × spend` | 0 (use `conv_value`) |
| `reach` | `reach` | `reach` | `null` (not supplied) |

- **Numbers:** money (`spend`, `conv_value`, `roas_value`) is rounded to 4 decimals. Google reports sub-satang spend, and rounding each ad-group-day to 2 decimals drifted totals. Counts stay integers where the source is an integer; fractional Google conversions keep 2 decimals.
- **Duplicate rows** (same date and entity, e.g. an export without upsert): rows identical in every field are de-duplicated. If several rows for one key differ, the last one in sheet order wins, and the duplicate is reported in `/api/meta` health.

### 2.3 Monthly (`/api/monthly`): full history at campaign × month
```jsonc
{ "schema": 1, "mode": "...", "months": ["2026-04", "...", "2026-09"],
  "accounts": [...], "campaigns": [...],
  "cols": ["month","campaign","spend","impressions","clicks","link_clicks","video_views","messages","leads","conversions","conv_value","roas_value","days"],
  "rows": [["2026-09", 0, 5307.16, 16376, 420, 300, 120, 23, 10, 0, 0, 0, 30]] }
```
`days` is the number of days with delivery in that month. There is no reach column, because unique reach can't be added up across days.

### 2.4 Meta and health (`/api/meta`)
```jsonc
{ "schema": 1, "mode": "live" | "sample", "generated_at": "...",
  "sheets": {
    "meta":   { "rows": 2564, "first_date": "2026-09-07", "last_date": "2026-09-20", "accounts": 17,
                "missing_dates": ["2026-09-12"], "duplicates": 0, "columns_missing": [] },
    "tiktok": { ... }, "google": { ... } },
  "data_through": "2026-09-20",           // latest date present in ALL non-empty sheets (the safe "as of" date)
  "history_from": "2026-09-07",           // earliest date in any sheet
  "creatives": { "meta": { "ads": 334, "saved": 333, "no_url": 1, "not_saved": 0 }, "tiktok": { ... } },
  "breakdowns": {                          // the optional Sheets 4-5 (always present; an older cache may lack it: treat as unavailable)
    "placement": { "available": true, "configured": true, "rows": 6919, "first_date": "2026-09-07", "last_date": "2026-09-20",
                   "spend_share_last_28d": 1.0005, "all_meta_spend_share_last_28d": 0.8864,
                   "duplicates": 0, "columns_missing": [], "error": null },
    "audience":  { ... } } }
```
`missing_dates`: dates within the last 60 days of the sheet (up to `last_date`) that have no rows at all.

`breakdowns.<kind>` describes one optional Sheet:
- `available`: usable rows exist. `configured`: its env var is set. `error`: why a configured Sheet could not be read or used (plain language, e.g. not shared with the service account), otherwise `null`. `configured: true, available: false, error: null` means the Sheet exists but is empty so far.
- `rows` counts the non-blank rows read from the Sheet, like the three main Sheets. `first_date` / `last_date` are the span of the usable rows. `duplicates` and `columns_missing` work as above. A Sheet that lacks a key column (`date`, `adset_id`, `spend`, or `publisher_platform` + `platform_position` / `age` + `gender`) is ignored entirely and `columns_missing` says which.
- `spend_share_last_28d` is the §2.5 `spend_share` over the 28 days that end on the last date of the main Meta Sheet (the Meta ad sets that appear in that breakdown Sheet). `all_meta_spend_share_last_28d` is the same breakdown spend over **all** Meta spend in those 28 days, so ad sets the export misses lower it too (on the sample: 14 of 99 ad sets, 0.886). Both are `null` when the Sheet is not available. Neither is capped, so both can exceed 1.

### 2.5 Breakdowns (`/api/breakdowns?from=YYYY-MM-DD&to=YYYY-MM-DD`), optional Sheets 4–5
```jsonc
{ "schema": 1, "mode": "live" | "sample", "range": { "from": "...", "to": "..." },
  "available": { "placement": true, "audience": true },          // false when that Sheet isn't configured / is empty
  "adsets": [{ "key": "meta:120240940877700786", "id": "120240940877700786", "account_id": "628812601062307" }],
  "placements": [{ "key": "facebook|feed", "platform": "facebook", "position": "feed", "label": "Facebook Feed" }],
  "audiences":  [{ "key": "25-34|female", "age": "25-34", "gender": "female" }],
  "cols": ["date","adset","segment","spend","impressions","clicks","link_clicks","video_views","messages","leads"],
  "placement_rows": [["2026-10-11", 0, 3, 262.23, 1115, 9, 8, 0, 1, 0]],     // segment = index into placements
  "audience_rows":  [["2026-10-11", 0, 1, 1056.03, 4577, 50, 43, 0, 11, 0]], // segment = index into audiences
  "coverage": { "placement": { "first_date": "...", "last_date": "...", "rows": 0, "spend_share": 0.998 },
                "audience":  { "first_date": "...", "last_date": "...", "rows": 0, "spend_share": 0.997 } } }
```
- `adsets[].key` matches `adsets[].key` in the rows payload. The frontend joins on it to get names, campaign and status.
- `label` is a readable placement name, e.g. facebook·facebook_reels → "Facebook Reels", instagram·instagram_stories → "Instagram Stories", messenger·messenger_inbox → "Messenger Inbox", audience_network·an_classic → "Audience Network". The table is `PLACEMENT_LABELS` in `lib/breakdowns.mjs`. It names the 17 pairs seen in the real pull (for example facebook·facebook_reels_overlay → "Facebook Reels overlay ads", facebook·instream_video → "Facebook In-stream video", instagram·instagram_explore_grid_home → "Instagram Explore home", facebook·facebook_notification → "Facebook Notifications") and the other positions Meta documents. The two other Audience Network positions keep a qualifier ("Audience Network rewarded video", "Audience Network in-stream video") so a table never shows the same label twice. Unknown pairs fall back to a title-cased "Platform · Position", e.g. "Facebook · Some New Position".
- `available` describes the Sheets, not the range: a range with no breakdown rows still says `true` and simply returns empty row arrays and `coverage.<kind>.rows: 0`. Neither Sheet configured (or an older cache) gives 200 with `false` / `false`, empty arrays and `spend_share: null`.
- `coverage.<kind>.rows`, `first_date` and `last_date` describe the breakdown rows inside the requested range (`null` dates when there are none). `spend_share` compares that range with Sheet 1 spend in the **same** range, summed over ads, for the Meta ad sets that appear anywhere in that breakdown Sheet. So a missing day or a stalled export lowers it, and an ad set that never appears in the Sheet is not part of the comparison (`/api/meta` has `all_meta_spend_share_last_28d` for that). It is `null` when Sheet 1 has no spend for those ad sets in the range. The route needs no second dataset for this: the Sheet 1 spend per ad set and day is stored with the breakdowns in the same cache version.
- `/api/breakdowns` sends `X-Data-Version` like `/api/rows`. The same value on `/api/rows`, `/api/meta` and `/api/breakdowns` means the three answers come from one refresh.
- Gender `unknown` and age `Unknown` are kept. The age order is fixed: 13-17, 18-24, 25-34, 35-44, 45-54, 55-64, 65+, Unknown.
- `spend_share` = breakdown spend ÷ Sheet 1 spend for the same ad sets and dates. It shows how complete the breakdown is. It sits close to 1 and can land slightly on either side:
  - **Under 1:** zero-spend rows are filtered out at export.
  - **Over 1:** the Sheets were exported at different moments while Meta was still revising the latest days (seen in the sample: 1.0005).

  Report the true ratio; the frontend caps what it displays.
- Money is rounded to 4 decimals, as in §2.2. Rows are de-duplicated on the upsert key.
- **Never** sum results across different ad-set objectives. The frontend picks the result metric from the ad set's campaign objective (messages, leads, video views, link clicks or impressions). Purchase value isn't in these Sheets, so Meta Conversions ad sets show spend and impression splits only.

## 3. Static files shipped with the dashboard (generated at build)
- `public/data/registry.js` sets `window.GROOV_REGISTRY`. It's a copy of `Ads/accounts/registry.json` and maps clients to vertical and account IDs. An optional per-client `budget` (THB/month per platform) enables pacing.
- `public/data/learnings.js` sets `window.GROOV_LEARNINGS`. It's parsed from `Ads/learnings/PLAYBOOK.md`, `LOG.md` and `rules.json`; see §4.
- `public/data/sample.js` sets `window.GROOV_SAMPLE` = `{ meta, rows, monthly, breakdowns }` in the shapes above. `breakdowns` is the full-range §2.5 payload built from `sample/sheets/meta_placements.csv` and `meta_audience.csv`; without those files it is the same payload with `available` false / false and empty arrays. `meta.breakdowns` is the §2.4 health block. Used for local preview only; never deployed.

## 4. Learnings JSON (`window.GROOV_LEARNINGS`)
```jsonc
{ "generated_at": "...",
  "log": [{ "id": "L-005", "date": "2026-10-12", "title": "…", "scope": "…", "evidence": "markdown", "sample": "…",
            "confidence": "Observation" | "Tested" | "Proven", "status": "Active" | "Superseded by L-NNN" | "Rejected",
            "applies_to": ["clinic","messages"], "next": "…",
            "clients": ["AT EASE Clinic"],          // registry client names found in scope/evidence
            "verticals": ["Clinic"] }],             // registry verticals found in scope/applies_to
  "playbook": { "sections": [{ "vertical": "Clinic", "note": null,
                               "rules": [{ "rule": "…", "confidence": "Observation", "evidence": ["L-005"] }] }],
                "open_questions": ["…"] },
  "rules": { ...contents of Ads/learnings/rules.json... } }
```

## 5. VPS storage (Hermes package, `server/`), added 2026-10-13
> This section covers only the VPS build. §1–§4 are unchanged and apply to it as written.

The VPS server reads the five datasets of §1 straight from the Windsor REST API (no Google Sheets, no Netlify) and serves the payloads of §2 unchanged. It runs the same `lib/normalize.mjs` and `lib/breakdowns.mjs`, and the tests compare its answers byte for byte with the normalisers run on `sample/sheets`.

| Dataset | Windsor connector | Fields | Rows kept |
|---|---|---|---|
| `meta` | `facebook` | §1 Sheet 1 | all |
| `tiktok` | `tiktok` | §1 Sheet 2 | all |
| `google` | `google_ads` | §1 Sheet 3 | all |
| `meta_placements` | `facebook` | §1 Sheet 4 | spend > 0 (the export filter, applied locally) |
| `meta_audience` | `facebook` | §1 Sheet 5 | spend > 0 (the export filter, applied locally) |

The field lists exist once: `lib/datasets.mjs` takes them from `SHEET_COLUMNS` (`lib/normalize.mjs`) and `BREAKDOWN_SHEET_COLUMNS` (`lib/breakdowns.mjs`).

Storage under `DATA_DIR`:

| Path | Content |
|---|---|
| `raw/<dataset>/<YYYY>/<YYYY-MM-DD>.json.gz` | One day, rows exactly as Windsor returned them: `{schema, dataset, date, connector, fetched_at, fields, rows_count, dropped_zero_spend, rows}`. A day with no rows still has a file. Files are written atomically, and a re-pull replaces exactly the days of a complete request. |
| `snapshots/<version>/` | `manifest.json`, `meta.json` (= `/api/meta`), `dataset.json.gz` (the `normalize()` output that `/api/rows` slices), `monthly.json.gz` (= `/api/monthly`), and `breakdowns.json.gz` (the `normaliseBreakdowns()` output, only when a breakdown has rows). The last 3 versions are kept. |
| `current.json` | `{version, previous, updated_at, reason}`: the version being served, replaced atomically. |
| `creatives/<meta\|tiktok>/<ad_id>.<jpg\|png\|webp\|gif\|avif>`, `creatives/index.json` | Saved creatives, original bytes, extension = real image type. In §2.1, `image: true` means a file exists here. |
| `static/registry.js`, `learnings.js`, `modules.js` | The §3 files, generated from `CONFIG_DIR`. |
| `refresh-status.json`, `refresh.lock` | The last run (`GET /api/refresh`), and the lock while a job runs. |

Deliberate differences from the Sheets build:
- **Upsert keys:** §1's upsert keys become "one file per day". A pull replaces whole days, so duplicates can only come from inside one Windsor answer, and they are reported as in §2.4.
- **`/api/meta` `sheets.<platform>`** describes the stored datasets. The key names stay as in §2.4; `columns_missing` lists fields Windsor did not return.
- **`breakdowns.<kind>`:** `configured` is the `ENABLE_BREAKDOWNS` setting. `error` reports a failed pull; the days stored before it stay available.
- **`/api/session`** answers `{email, name, expires: null, owner, mode: "tailscale" | "none"}`. Identity comes from Tailscale, and there is no cookie.
- **`/data/modules.js`** sets `window.GROOV_MODULES = {modules: [{id, label, enabled, route}]}` from `config/modules.json` (shipped default: `public/data/modules.js`, only `ads` enabled). The sidebar shows a module switcher when more than one module is enabled.
