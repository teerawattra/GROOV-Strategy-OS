# GROOV Ads Command Center: product spec

What the dashboard does and how every part operates. Read with `DATA_CONTRACT.md`, which covers the data. This file is the reference for building, changing or reviewing the dashboard. If behaviour changes, update this file in the same edit.

## 1. Purpose and principles
- **One place to run the morning check across every client:** what needs action, what can scale, what we've learned, and whether the data can be trusted.
- **Read-only.** The dashboard never changes ads. Changes happen in Claude Code, behind the confirm-first rules in `Ads/CLAUDE.md`.
- **Honest numbers:**
  - Different result types (messages, leads, clicks, conversions) are never added together.
  - Missing denominators show "—", never ฿0.
  - Comparisons use equal-length periods.
  - Platform-reported events are labelled as such and never called qualified leads.
  - Daily reach is never presented as unique reach.
- **Hermes design and decision logic are preserved:** the dark monitor look, the four decisions (Immediate Action, Watch Out, Ready to Scale, No Touching), and Evidence / Why / Action on every decision.
- **The learning log is data:** playbook rules show up as live checks, observed benchmark ranges, and "what we know" notes on each client.

## 2. Layout
```
┌────────────┬──────────────────────────────────────────────────────────┐
│  SIDEBAR   │ TOP BAR: breadcrumb · period vs compare · filter chips · ⟳ │
│  (264px,   ├──────────────────────────────────────────────────────────┤
│ collapsible│                                                          │
│  to 72px)  │                PAGE CONTENT (max 1500px)                 │
│            │                                                          │
└────────────┴──────────────────────────────────────────────────────────┘
```
- **Desktop:** the sidebar is fixed on the left. A collapse button shrinks it to a 72px icon rail; the choice is remembered.
- **Under 900px:** the sidebar becomes an off-canvas drawer opened from a ☰ button in the top bar. The page never scrolls horizontally; wide tables scroll inside their own container.
- **Top bar (sticky):** breadcrumb (e.g. Overview › Rena Yakiniku), then "14–20 Sep 2026 vs 7–13 Sep 2026", then removable chips for active filters, a filter count, and Refresh, which re-fetches data.
- **Sample mode:** a full-width amber banner above the top bar reads "SAMPLE DATA: Hermes snapshot 7–20 Sep 2026 · not live".

## 3. Sidebar menu (everything the user can adjust)
1. **Brand.** GROOV logo, "Ads Command Center", and a data pill: "Data through 20 Sep" (green when fresh, amber when 2+ days old, red when 4+ days old) plus Live or Sample.
2. **Navigate:**
   - Overview
   - Action queue, with a badge counting unreviewed Immediate Action and Watch Out items
   - Clients: expandable list with a search box. Pinned clients come first (☆ to pin). Each shows a decision colour dot and current spend.
   - Creatives
   - Playbook
   - Data health
3. **Period:**
   - Preset chips: 7D · 14D · 30D · 60D · 90D · MTD · Last month · QTD · Last quarter · Custom.
   - Custom shows two date inputs, limited to the history start and the "data through" date.
   - Presets count back from the **data-through date** (the latest complete day present in every Sheet), not from today. "Last 7 days" therefore never includes empty or partial days.
4. **Compare:**
   - Previous period (the default): the equal-length window just before. For MTD and QTD it's the same number of days at the start of the previous month or quarter.
   - Same period last month.
   - Same period last year.
   - Off.
   - If the comparison falls before the history start, changes show "no baseline" and the top bar says why.
5. **Filters:**
   - Platforms: Meta / TikTok / Google
   - Verticals: from the registry, plus "Unmapped"
   - Objectives: Messages / Lead generation / Awareness / Traffic / Engagement / Conversions
   - Decisions: Immediate / Watch / Scale / Hold
   - Delivery: All, or Active only
   - Min spend: ฿, hides small rows
   - Reset filters

   Platform, vertical and objective filters change every total and table. Decision, active-only and min-spend filters hide rows and cards but **do not change totals**. Totals cards say "Totals ignore row filters" whenever one of those is active.
6. **Decision rules** (collapsed by default), editable with the Hermes defaults shown:

   | Rule | Default |
   |---|---|
   | Immediate Action: spend with zero results ≥ | ฿100 |
   | Ready to Scale: results ≥ | 3 |
   | Ready to Scale: cost per result improves ≥ | 10% |
   | Ready to Scale: results drop at most | 10% |
   | Watch Out: cost per result worsens ≥ | 30% |
   | Watch Out: results fall ≥, on spend ≥ 80% of prior | 30% |
   | Watch Out: response rate falls ≥ | 25% |
   | Awareness frequency cap | 3.5× |

   "Reset to Hermes defaults" restores these. Every view recomputes instantly. A dot on the section header shows when any rule differs from the default.
7. **Footer.** Signed-in email and Sign out (live only), the "Read-only · no ad changes" pill, and the build date.

All sidebar state is kept per browser (localStorage key `groov.cc.v1`). Pages use hash routes: `#/overview`, `#/actions`, `#/client/<slug>`, `#/creatives`, `#/playbook`, `#/data`.

## 4. Pages

### 4.1 Overview: all clients at a glance
1. **KPI cards.** Each shows the value, the change vs comparison (green or red by direction of good), and a daily sparkline. Cards: Spend · Impressions · Link clicks · Messages* · Leads* · Conversions*. (*Platform-reported.) Only cards with non-zero values in either period are shown.
2. **Decision summary.** Four counters (clients by worst decision). Clicking one sets the Decisions filter.
3. **Daily spend chart.** Bars per day stacked by platform; a dashed line shows the comparison period aligned by day number. Hover shows exact values.
4. **Mix.** Spend share by platform and by vertical, as horizontal bars with ฿ and %.
5. **Clients table (main element).** One row per client (registry client; unmapped accounts get their own row).

   | Column | Content |
   |---|---|
   | Decision | coloured dot |
   | Client | client name, vertical tag, platform chips |
   | Spend | spend, Δ%, and share of total |
   | Primary result | the objective with the most spend in the period: count, Δ |
   | Cost/result | cost per primary result, Δ (red/green), plus a benchmark tick (inside, above or below the observed range) when a benchmark exists |
   | CTR | link CTR |
   | Flags | number of playbook checks hit (L-chips) |
   | Trend | daily spend sparkline |
   | Pacing | only when the registry has a monthly budget for the client |

   Columns are sortable; the default sort is decision severity, then spend. Clicking a row opens the client. ▸ expands the row into its platform accounts.
6. **Top movers.** The biggest spend increases and decreases, and the biggest cost-per-result improvements and declines. Only clients with spend ≥ max(min-spend filter, ฿300) in both periods are included.

### 4.2 Action queue: everything that needs a human, ranked
- **Item sources:**
  1. Campaign decisions: Immediate Action, Watch Out, Ready to Scale (the last is shown as an opportunity).
  2. Playbook checks from `rules.json`, citing their L-number.
  3. Delivery issues: campaigns whose status is ACTIVE but had no spend in the last 3 days of the period ("delivery stopped").
- **Order:**
  1. Immediate Action
  2. Playbook Watch Out
  3. Watch Out
  4. Delivery issue
  5. Opportunity (Ready to Scale and playbook Opportunity)

  Within each level, items sort by spend, highest first.
- **Each item shows:**
  - severity badge and a one-line title, e.g. "฿1,205 spent with zero messages"
  - path: Client › Platform › Campaign › Ad
  - Evidence: KPIs current vs comparison
  - Why and Action
  - source chip ("Decision engine" or "L-005")
  - Open client button
  - "Mark reviewed" tick, remembered per item and period end. Reviewed items collapse into a "Reviewed (n)" group, and the sidebar badge counts unreviewed items only.
- **Tabs:** All · Fix now · Watch · Opportunities · Playbook.

### 4.3 Client view: one client, the KPIs that matter
1. **Header.**
   - Client name, vertical, and account chips (platform, account name, account id).
   - Worst decision badge and the period.
   - A platform switch (All / Meta / TikTok / Google) that changes only this view.
2. **KPI strip (objective-aware).**
   - Spend comes first (Δ, share by platform).
   - Then one group per objective present, ordered by spend share, each showing its "KPIs that matter":

     | Objective | KPIs |
     |---|---|
     | Messages | Conversations · Cost per conversation · Click-to-conversation rate (conversations ÷ link clicks) · CTR · CPM |
     | Lead generation | Leads · CPL · Lead rate (leads ÷ link clicks) · CTR · CPM |
     | Awareness | Impressions · CPM · Avg daily frequency (impressions ÷ Σ daily reach) · Reach/day |
     | Traffic | Link clicks · CPC · CTR · CPM |
     | Engagement | Video views (3s) · Cost per view · View rate · CTR |
     | Conversions | Conversions · CPA · Conversion value · ROAS |

   - Every KPI shows Δ vs comparison.
   - Cost per conversation shows the **observed range** for the client's vertical from `rules.json` benchmarks: a small range bar with the client's position, labelled e.g. "Observed ฿16–115 · L-003 · Observation".
3. **What we know (learning log).**
   - Log entries that name this client, then entries for its vertical. Each shows its L-number, date, title, confidence badge and "Next".
   - Superseded entries are hidden behind a toggle.
   - Also shows `rules.context` notes that match the client's vertical or objectives, and open questions for the vertical under "To test next".
4. **Playbook checks.** Live hits of `rules.json` checks for this client, each with message, action and L-number. When there are none: "No playbook rule triggered."
5. **Decisions.** Counts plus the top items per decision with Evidence / Why / Action. Opportunities are listed separately.
6. **Trends.** Two small charts over the current period:
   - daily spend (bars) with daily primary results (line);
   - daily cost per primary result (line, with gaps on days without results).

   A switch toggles by platform or by top 5 campaigns.
7. **Campaigns table (hierarchical):** Campaign ▸ Ad set / ad group ▸ Ad.
   - Columns: status badge (ACTIVE green; any other red, with the raw status in a tooltip) · objective · spend · Δ · results · cost/result · Δ · CTR · CPM · avg daily frequency · decision badge (hover or tap for Why and Action) · flag chips.
   - Sortable, with expand all and collapse all. Paused items with spend in the period are shown, dimmed. The Active-only filter hides them.
8. **Creative wall** (see 4.4) limited to this client.
9. **Monthly history:**
   - The last 6 months (or since the history start) from `/api/monthly`: month · spend · Δ m/m · primary results · cost/result · Δ.
   - Plus quarter totals and a monthly spend bar chart. The current month is marked "MTD".
   - Reach and frequency are not shown monthly, because daily reach can't be added up into unique monthly reach.
10. **Notes:** the honesty footnotes (§1) that apply to what's on screen.

### 4.4 Creatives: what's working, with real images
- **Card contents:**
  - Image: center-cropped 4:5, `object-fit: cover`.
  - Platform chip, status, ad name, client › campaign › ad set.
  - Spend, primary result count and cost, CTR, frequency.
  - Decision badge, Preview link.
- **When there's no image,** the card shows a blank tile stating the reason:
  - `no_url`: "No image: the platform supplied no thumbnail for this ad."
  - `not_saved`: "Creative not saved yet: its image link expired before the daily image job stored it."
  - Google: "Text-only search ad."
- **Ranking tabs:**

  | Tab | Rule |
  |---|---|
  | Winners | lowest cost per primary result, ranked within objective. Gate: ≥ 2,000 impressions and ≥ 5 results; also spend ≥ 3× the client's target cost per result when a target exists. Labelled *directional* (5–24 results) or *confident* (25+). |
  | Spending, no results | spend ≥ the Immediate threshold and 0 results |
  | Fatigue risk | see below |
  | All | sortable by spend, cost/result, CTR, newest |

- **Fatigue risk:**
  - **Rule.** The ad had ≥ 2,000 impressions in both periods, and **at least 2 of 3** worsened vs its own comparison period: link CTR down ≥ 20%, CPM up ≥ 18%, cost per primary result up ≥ 30%.
  - **Frequency.** Avg daily frequency ≥ 2.5 (Meta) is shown as supporting evidence. It never triggers the flag on its own.
  - **Why this rule:** the research (`research/features-research.md` §3) found practitioners confirm fatigue only when 2+ metrics move together.
  - **New ads are exempt.** An ad launched (`first_date`) less than 7 days before the period end gets a **New** badge instead. Fatigue and loser flags are suppressed during learning.
- Every card shows "Live N days" from `first_date`.
- Honours all sidebar filters, and Client when opened from a client view.

### 4.5 Playbook: what we've learned, checked against live data
- **Rules by vertical,** from PLAYBOOK.md: each rule shows its confidence badge (Observation, Tested, Proven) and evidence L-numbers, which link to the log entry.
- **Live checks:** each `rules.json` check shows its current hit count and the matching items. Clicking one opens the filtered action queue.
- **Benchmarks:** each observed range with the current values of every client in that vertical, drawn as a dot plot over the range bar.
- **Log timeline:** LOG.md entries, newest first, expandable to full evidence.
- **Open questions** list.
- **Header line:** "Maintained by Claude in Ads/learnings/ · updated after each analysis · Observation = seen once, not a promise."

### 4.6 Data health: can I trust today's numbers?
- **One card per Sheet:**
  - first date, last date and row count;
  - accounts present;
  - missing dates in the last 60 days, shown as a calendar strip;
  - duplicates and missing columns;
  - a freshness verdict. Fresh means the last date is yesterday or the day before (Bangkok); sample mode never counts as fresh.
- **Registry match:**
  - accounts in data but not in `registry.json` ("Unmapped"; fix in the registry);
  - registry accounts with no data in the last 30 days.
- **Creative coverage** per platform: saved, no image link, not saved, with a list of active ads missing images.
- **Definitions:**
  - Reach: daily, not unique.
  - Results: platform-reported.
  - Late conversions: the last 7 days are re-pulled daily, so the last few days can still change.

### 4.7 KPI trend lines: every KPI has its own line chart
- **Every KPI tile gets a line chart** of its own daily values for the current period. This covers the overview cards, every client KPI tile (all objective groups) and every ad set panel KPI. Each chart shows:
  - the current-period line, with a marker on the last point;
  - the comparison period as a dashed line, aligned by day number;
  - the last 3 days shaded as "provisional";
  - a hover or tap tooltip with date, value and comparison value;
  - a direction colour on the end marker (green when the KPI moved the good way, red when bad; lower is better for cost KPIs).
- **Daily values are computed from daily sums,** not by averaging ratios:
  - Cost per conversation = day spend ÷ day conversations.
  - CTR = day clicks ÷ day impressions.
  - A day without a denominator (no conversations, no impressions) is a **gap** in the line, never ฿0 and never ∞.
- **Granularity:** daily up to 45 days, weekly (Mon–Sun) beyond that.
  - A weekly point sums the numerators and denominators over the week, then divides.
  - Partial first and last weeks are labelled "partial".
  - A Daily / Weekly toggle overrides the automatic choice.
- **Expanded view.** Clicking a KPI tile opens a large chart under the strip with:
  - axes and gridlines;
  - the Daily / Weekly toggle;
  - a split switch (Total · By platform · Top 5 campaigns · Top 5 ad sets);
  - the observed benchmark range from `rules.json`, drawn as a shaded band on cost-per-result charts;
  - the client target, drawn as a line when the registry has one;
  - a "Table view" listing the exact values.

  Only one tile is expanded at a time, and Esc closes it.
- **Behaviour as built:**
  - A stored Weekly choice falls back to daily when the period has fewer than 2 Mon–Sun weeks; the chart says so.
  - Weekly comparison points use the same day offsets as the current weeks.
  - Only the Total view draws the dashed comparison line. Split views show each series' comparison in the tooltip.
  - The y-axis follows the data. A benchmark band wider than 1.5× the data is clipped at the top edge ("continues above") so the line stays readable.
  - Ad set panels have no split switch.

### 4.8 Where results happen: placement and audience inside each ad set (Meta)
Data comes from the optional breakdown Sheets 4–5 (`DATA_CONTRACT.md` §1, §2.5). When they're missing, these panels show "Placement and audience splits appear once the two Meta breakdown exports run (see sheets-export.md)" and nothing else.
1. **Ad set panel.** Clicking an ad set row in the campaigns table (or its name anywhere) opens a panel. It includes:
   - **KPI trend lines** for the ad set, as in 4.7.
   - **By placement.** One row per placement (Facebook Feed, Facebook Reels, Instagram Stories, …) with: spend · **% of spend** · results · **% of results** · cost per result · link CTR · CPM, plus a paired bar showing % of spend next to % of results. A tag per row:

     | Tag | When |
     |---|---|
     | **Works** | share of results ≥ 1.2 × share of spend, with ≥ 3 results |
     | **Weak** | share of results ≤ 0.8 × share of spend |
     | **Spending, no results** | ≥ 10% of the ad set's spend and 0 results |
     | **Directional** | when the ad set has fewer than 10 results in total, no tag is stronger than "directional" |

   - **By audience.** An age × gender heatmap (rows 13-17 … 65+, Unknown; columns Female, Male, Unknown). Each cell shows **% of results**, shaded by its share. Hover shows spend, % of spend, results and cost per result. Beside it, age bars and gender bars give the same % of spend vs % of results comparison, with the same tags.
   - **Generated sentence,** from the numbers only. Example: "Facebook Feed took 62% of spend and brought 80% of conversations (฿96 each). Instagram Stories took 9% of spend with no conversations. Women 25–34 brought 46% of conversations at ฿96; men brought 12% at ฿104."
   - **Compare.** Each % has a small Δ vs the comparison period when the comparison has breakdown data.
2. **Client view, new "Where results happen" section** (after Decisions). The same placement table, audience heatmap and bars, aggregated over the client's ad sets.
   - **Objective selector.** It only offers objectives present, defaults to the one with the most spend, and **results are never mixed across objectives**.
   - **Campaign filter.** Narrows the section to one campaign.
   - **By ad set (targeting audience).** % of spend vs % of results for each ad set in that objective, so the team sees which targeted audiences carry the results.
3. **Campaigns table.** Ad set rows get a "% of results" column: the share of the client's results for that objective that came from the ad set.
4. **Coverage note.** Each breakdown block states the share of spend it covers ("covers 99.8% of this ad set's spend") and the low-n warning when the total is below 10 results.
   - Coverage shows capped at 100%. Above 100.5% it adds "breakdown data is newer than the main data for the last days".
   - An account with spend but no breakdown rows shows "No placement/audience data for this account — it isn't reachable in Windsor; reconnect it there".
6. **Readability rules (as built):**
   - Placements under 2% of the ad set's spend **and** with 0 results fold into an expandable "Other placements" row; rows inside it carry no tag.
   - The 13-17 age row is hidden when empty.
   - Unknown age or gender is hidden when under 1% of spend, with a footnote.
   - The ad set panel is in the URL (`as=meta:<adset_id>`), so it can be shared, and Back closes it.
   - "By ad set (targeting audience)" works without the breakdown Sheets, since it uses Sheet 1.
5. **Result metric by objective:**

   | Objective | Result metric |
   |---|---|
   | Messages | conversations |
   | Lead generation | leads |
   | Engagement | 3-second video views |
   | Traffic | link clicks |
   | Awareness | impressions (cost = CPM) |
   | Conversions (Meta ROAS) | not available by placement or audience; spend and impression shares only |

## 5. Calculations (shared engine)
- **Objective classification** (one classifier, used everywhere):
  - **Meta**, checked in this order:
    1. `OUTCOME_LEADS` or a lead-gen name (LEADGEN, LEAD_GEN, LEAD_GENERATION) → Lead generation
    2. `OUTCOME_SALES`, `CONVERSIONS` or `PRODUCT_CATALOG_SALES` → Conversions
    3. `OUTCOME_AWARENESS`, `REACH` or `BRAND_AWARENESS` → Awareness
    4. messages > 0 or a message name (MSG, MESSAGE(S), INBOX, MESSENGER) → Messages
    5. `LINK_CLICKS` or TRAFFIC → Traffic
    6. purchase ROAS present → Conversions
    7. otherwise → Engagement

    Message campaigns that pick up an attributed purchase stay **Messages**. An earlier draft put "ROAS present" second, which turned clinic message campaigns into conversion campaigns whenever a sale was attributed.
  - **TikTok:**
    - REACH → Awareness
    - VIDEO_VIEWS or ENGAGEMENT → Engagement
    - TRAFFIC → Traffic
    - LEAD_GENERATION → Lead generation
    - messages > 0 or a message name → Messages
    - otherwise → Conversions
  - **Google:** always Conversions. Clicks, CTR and CPC are shown alongside.
- **Primary result and cost by objective:**

  | Objective | Primary result | Cost |
  |---|---|---|
  | Messages | messages | spend ÷ messages |
  | Lead generation | leads | spend ÷ leads |
  | Awareness | impressions | CPM |
  | Traffic | link clicks | CPC |
  | Engagement | video views | cost per view |
  | Conversions | conversions | CPA |

  Response rate is: messages ÷ impressions, leads ÷ impressions, link CTR, views ÷ impressions, or conversions ÷ clicks, by objective.
- **Decisions judge exactly the KPIs on screen.**
  - Engagement is judged on cost per 3-second view; its response rate is views ÷ impressions.
  - Traffic is judged on link CPC; its response rate is link CTR.
  - So Evidence / Why always cite the numbers in the tables.
  - This is a deliberate change from Hermes's command center, which judged Engagement on CPC and Traffic on all-click CTR. On the Sep sample it changes 3 accounts, all listed in the parity test.
- **Decisions** use the Hermes rules with the sidebar thresholds:
  - Campaigns, from equal-period aggregates.
  - Ad sets and ads use the single-account variant: status-aware, so a PAUSED item with prior spend ≥ ฿100 and none now becomes "Immediate Action: confirm the pause was intended".
  - A client takes the most severe decision among its delivering campaigns.
- **Playbook checks:** each check's `scope` (verticals, platforms, objectives) and `level` (ad, campaign, client) select the entities. `when` predicates:
  - `spend_gte`, `cpr_gt`, `frequency_gt`;
  - `ctr_all_lt` / `ctr_all_gt`: CTR on **all** clicks (clicks ÷ impressions × 100);
  - `link_ctr_lt` / `link_ctr_gt`: link clicks ÷ impressions × 100. Never fires when link clicks aren't reported.
  - The definitions live in `rules.json` → `predicates`.
  - `name_not_contains_any` (true when no campaign name in scope contains any of the strings, case-insensitive);
  - `min_spend` (scope total).

  Every predicate must hold. A hit is labelled with the check's severity, message, action and source.
- **Benchmarks:** `rules.benchmarks` are matched on metric plus vertical, or objective plus platform. Position is "below / inside / above observed range". They're never called targets unless confidence is Tested or Proven.
- **Pacing** (only when the registry client has `budget`, THB per month per platform): MTD spend ÷ (budget × elapsed days ÷ days in month), with a projected month-end of MTD ÷ elapsed × days in month.

## 5b. Refinements adopted from research (`research/features-research.md`)
These are part of v1. None needs new Sheet columns.
1. **Sample-size honesty.**
   - Every cost-per-result and rate shows its count, e.g. "฿87 · n=33".
   - A Δ% is greyed and marked "low n" when either period has fewer than 10 results.
   - Rankings show *directional* (5–24) or *confident* (25+).
2. **Cost-per-result bridge** (client view, under the KPI strip, per objective). It splits a change in cost per result into its drivers using only existing columns:
   - **Messages:** cost per conversation = CPM ÷ 1000 × 1 ÷ link CTR × 1 ÷ chat-start rate (conversations ÷ link clicks).
   - **Leads:** the same, with lead rate.
   - Display: "Cost per conversation +42%, driven by: CPM +18% · CTR −12% · chat-start rate −9%". The contributions are logarithmic shares, so they add up to the total change.
3. **Delivery integrity items** (Action queue, *Delivery* level):
   - **Disapproved ad:** status DISAPPROVED.
   - **Delivery stopped:** status ACTIVE, zero spend in the last 3 days of the period, spend before that.
   - **Spend dropped sharply:** ACTIVE, last-3-day average < 40% of the prior 7-day average, with that average ≥ ฿100/day.
   - **Spend spike:** last-3-day average > 175% of the prior 7-day average and ≥ ฿500/day.

   Each uses two windows, so one odd day doesn't alert.
4. **Provisional days.** Late conversions can still arrive, and Windsor re-pulls 28 days. So the last 3 days up to `data_through` are shaded "provisional" on every daily chart, and noted under the KPI strip when the period includes them.
5. **Optional registry fields** (any client in `Ads/accounts/registry.json`). The UI hides each feature until a value exists:
   - `owner`: adds an **Owner** filter to the sidebar.
   - `budget`: `{ "meta": 30000, "tiktok": 5000, "google": 0 }` THB/month. Turns on **pacing**:
     - projected month-end = MTD + trailing 7-day average × days left, excluding today;
     - green within ±10% of budget, amber 10–20%, red beyond 20%;
     - no status for the first 3 days of a month.
   - `targets`: `{ "Messages": 120, "Lead generation": 350 }`, target cost per result by objective. Adds a "vs target" marker next to cost per result and feeds the winner gate (spend ≥ 3× target).
6. **Portfolio medians.** For each vertical × objective × platform, the median cost per result this period across clients with ≥ 5 results. It's shown next to the client's own value and in the Playbook benchmarks, labelled "portfolio median, this period" (live). The `rules.json` observed ranges are shown separately.
7. **Creative pipeline** (client view, small panel), using `first_date` / `last_date`:
   - active ads;
   - ads launched in the last 14 days;
   - share of spend on ads launched more than 28 days ago.

   "Refresh due" appears when that share is ≥ 70% and no ad launched in 14 days.
8. **Starred filter.** "Starred only" toggles to the pinned clients.
9. **Shareable URLs.** Route and key state are mirrored in the hash, so a copied link opens the same view: `#/client/rena-yakiniku?p=30d&c=prev&pl=meta,tiktok`. localStorage holds the defaults.
10. **Export CSV.** Buttons on the clients table, campaigns table, action queue and creatives list. Exports are client-side, of exactly what's shown, with the period in the filename.
11. **Snooze.** Besides "Mark reviewed", action items can be snoozed for 7 days, stored per browser.
12. **Display-only "New" badge.** Campaigns launched less than 7 days before the period end get a "New" badge. Decisions still follow Hermes exactly, so parity holds.

**Later** (need extra fields or storage):
- learning-stage protection (`adset_learning_stage_info`)
- account billing status (`account_status`)
- hook and hold rates (2s/6s or ThruPlay)
- optimisation goal and destination classification
- a windowed reach pull for true frequency
- Google impression share
- an outcome ledger (qualified leads and bookings)
- changelog annotations on charts
- shared alert state (Netlify Blobs)

## 6. Data loading
- **Boot:**
  1. Read `window.GROOV_REGISTRY` and `window.GROOV_LEARNINGS`.
  2. Use **sample mode** when `window.GROOV_SAMPLE` exists *and* the page is `file:` or localhost. Otherwise **live**: `GET /api/meta`.
  3. Compute periods from `data_through`.
  4. Fetch `/api/rows?from=<earliest needed>&to=<data_through>` once. Re-fetch only when a period falls outside the loaded range.
- **Monthly:** `/api/monthly` loads lazily on the first client view or monthly section.
- **Breakdowns:** `/api/breakdowns?from&to` (current and comparison ranges) loads lazily the first time an ad set panel or the "Where results happen" section opens. In sample mode it comes from `window.GROOV_SAMPLE.breakdowns`.
- **Images:** live `/img/<platform>/<ad_id>`; sample `../../command-center/creatives/<platform>/<ad_id>.jpg`.
- **Errors:** an API error shows a section-level error with Retry; the last good data stays visible with a "stale" note. A 401 in live mode redirects to `/login.html`.

## 7. Code layout (no build step; works from `file://` and on Netlify)
```
public/index.html            shell: sidebar + top bar + #view; loads scripts in order (classic scripts, no ES modules)
public/assets/app.css        Hermes tokens + components
public/assets/js/util.js     formatting (฿, %, ×, —), dates (Bangkok), slugify, esc
public/assets/js/data.js     data source (sample/live), periods, indexing, aggregation, filters
public/assets/js/engine.js   objective classifier, KPIs, decisions, playbook checks, benchmarks, fatigue, pacing
public/assets/js/model.js    turns data + engine into one cached snapshot per state (all views read from it)
public/assets/js/ui.js       shared UI pieces: badges, KPI tiles, sortable/expandable table with CSV export, tooltips
public/assets/js/charts.js   inline-SVG charts: sparkline, KPI trend line (daily/weekly, compare, provisional, band, target), stacked daily bars + compare line, range bar, monthly bars
public/assets/js/views/trends.js  KPI trend tiles + the expanded chart panel (SPEC §4.7)
public/assets/js/views/adset.js   ad set panel: KPI trends, placement table, age × gender heatmap, generated sentence (SPEC §4.8)
public/assets/js/sidebar.js  sidebar render + state (localStorage), filter chips
public/assets/js/views/*.js  overview, actions, client, creatives, playbook, health
public/assets/js/app.js      router, state store, boot, re-render
public/data/registry.js      generated: window.GROOV_REGISTRY
public/data/learnings.js     generated: window.GROOV_LEARNINGS
public/data/sample.js        generated: window.GROOV_SAMPLE (local only, git-ignored)
```
All code lives under one `window.GROOV` namespace. There are no external scripts or fonts except the system font stack.

## 8. Acceptance checks
- **Parity with Hermes:** on the sample, 14–20 Sep vs 7–13 Sep, there are 21 delivering accounts and total spend is ฿91,303.10 (±0.01; money is kept to 4 decimals). Account decisions match Hermes except for the documented, deliberate KPI-consistency changes (§5), which the test lists by name.
- **Totals reconcile:** client totals equal the sum of their campaigns; overview totals equal the sum of clients, under the same filters.
- **No bad values:** no `NaN`, `Infinity`, `undefined` or `null` on screen. Missing denominators show "—".
- **Layout:** works at 1440px, 1024px and 390px wide, with no page-level horizontal scroll.
- **Images:** every ad card shows its image or a blank tile with the reason. No broken-image icons.
- **Navigation:** sidebar settings persist across reloads, and Back/Forward follow the hash routes.
