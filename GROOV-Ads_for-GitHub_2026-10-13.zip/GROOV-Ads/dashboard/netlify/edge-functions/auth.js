// Edge function "auth" (Deno runtime): nothing on this site is served without a valid groov_session cookie,
// except the login page and what it needs. The cookie format and its verification live in
// lib/session-token.mjs (Web Crypto, constant-time HMAC verify), shared with the Node functions; the tests
// prove a cookie minted by lib/session.mjs passes this function and a tampered or expired one does not.
//
// Signed in -> the request continues untouched (static file or function). Otherwise:
//   page navigation (address bar, link, reload) -> 302 to /login.html
//   anything else (fetch, script, image)        -> 401 {"error": "Not signed in."}
// The functions check the session again themselves, so a routing mistake here cannot expose data on its own.
//
// Public: /login.html, /assets/login.css, /assets/login.js, /assets/groov-logo.png, /favicon.ico, /api/config,
// /api/session (it handles POST / GET / DELETE itself) and Netlify's internal /.netlify/* paths (the background
// data job is started there with its own HMAC token; scheduled functions cannot be called by URL at all).
// /data/sample.js (the local preview bundle) is answered 404 even when signed in, in case it is ever uploaded.

import {
  MIN_SECRET_LENGTH,
  SESSION_COOKIE,
  isDocumentRequest,
  isEmailAllowed,
  parseList,
  readCookie,
  verifySessionWeb,
} from '../../lib/session-token.mjs';

/** Served without a session. config.excludedPath below must list the same paths plus "/.netlify/*" (tested). */
export const PUBLIC_PATHS = Object.freeze([
  '/login.html',
  '/assets/login.css',
  '/assets/login.js',
  '/assets/groov-logo.png',
  '/favicon.ico',
  '/api/config',
  '/api/session',
]);
const NEVER_SERVED = new Set(['/data/sample.js']);

const BASE_HEADERS = Object.freeze({
  'Cache-Control': 'no-store',
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'strict-origin-when-cross-origin',
  'X-Robots-Tag': 'noindex, nofollow',
});
const CLEAR_COOKIE = `${SESSION_COOKIE}=; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=0; Expires=Thu, 01 Jan 1970 00:00:00 GMT`;

/** Netlify.env on the edge; Deno.env / process.env as fallbacks (local tools, tests). */
function env(name) {
  try {
    const v = globalThis.Netlify?.env?.get(name);
    if (v !== undefined) return v;
  } catch {
    // not on Netlify
  }
  try {
    const v = globalThis.Deno?.env?.get(name);
    if (v !== undefined) return v;
  } catch {
    // no env permission
  }
  return globalThis.process?.env?.[name];
}

/** Same matching as Netlify's generated exclusion patterns: exact path, optional trailing slash. */
export function isPublicPath(pathname) {
  const path = pathname.length > 1 && pathname.endsWith('/') ? pathname.slice(0, -1) : pathname;
  return PUBLIC_PATHS.includes(path) || path === '/.netlify' || path.startsWith('/.netlify/');
}

function misconfigured(request) {
  const message = 'The dashboard is not configured: SESSION_SECRET is not available to Edge Functions. In Netlify, give SESSION_SECRET the scope "All scopes" (or one that includes Functions), then deploy again.';
  if (isDocumentRequest(request)) {
    return new Response(`<!doctype html><meta charset="utf-8"><title>Not configured</title><p style="font:16px system-ui;max-width:40em;margin:3em auto">${message}</p>`, {
      status: 500, headers: { ...BASE_HEADERS, 'Content-Type': 'text/html; charset=utf-8', 'Content-Security-Policy': "default-src 'none'; style-src 'unsafe-inline'" },
    });
  }
  return new Response(JSON.stringify({ error: message }), { status: 500, headers: { ...BASE_HEADERS, 'Content-Type': 'application/json; charset=utf-8' } });
}

export default async function auth(request) {
  const { pathname } = new URL(request.url);
  if (isPublicPath(pathname)) return undefined; // excluded in config too; this is the second line of defence
  if (NEVER_SERVED.has(pathname)) {
    return new Response('Not found', { status: 404, headers: { ...BASE_HEADERS, 'Content-Type': 'text/plain; charset=utf-8' } });
  }

  const secret = String(env('SESSION_SECRET') ?? '').trim();
  if (secret.length < MIN_SECRET_LENGTH) return misconfigured(request);

  const token = readCookie(request.headers.get('cookie'), SESSION_COOKIE);
  if (token) {
    const result = await verifySessionWeb(token, secret, Math.floor(Date.now() / 1000));
    const allowList = { allowedDomains: parseList(env('ALLOWED_DOMAINS')), allowedEmails: parseList(env('ALLOWED_EMAILS')) };
    if (result.ok && isEmailAllowed(result.session.email, allowList)) return undefined; // continue the request chain
  }

  const headers = { ...BASE_HEADERS, ...(token ? { 'Set-Cookie': CLEAR_COOKIE } : {}) };
  if (isDocumentRequest(request)) return new Response(null, { status: 302, headers: { ...headers, Location: '/login.html' } });
  return new Response(JSON.stringify({ error: 'Not signed in.' }), { status: 401, headers: { ...headers, 'Content-Type': 'application/json; charset=utf-8' } });
}

export const config = {
  path: '/*',
  excludedPath: [
    '/login.html',
    '/assets/login.css',
    '/assets/login.js',
    '/assets/groov-logo.png',
    '/favicon.ico',
    '/api/config',
    '/api/session',
    '/.netlify/*',
  ],
};
