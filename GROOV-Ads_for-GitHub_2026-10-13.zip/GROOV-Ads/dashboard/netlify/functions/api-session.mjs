// /api/session (public route; the function does its own checks)
//   POST   {credential}  Google Identity Services ID token -> verify, allow-list, set the groov_session cookie -> {email, expires, owner}
//   GET                  -> {email, expires, owner} for a valid cookie, 401 otherwise
//   DELETE               -> clears the cookie, 204
// Error bodies are {error: "<human-readable reason>"}; the token is never echoed or logged.

import { AuthError, authorizeGoogleAccount, createJwksCache, verifyGoogleIdToken } from '../../lib/google-id-token.mjs';
import { errorJson, guarded, json, methodNotAllowed, noContent, sameOrigin } from '../../lib/http.mjs';
import { MIN_SECRET_LENGTH, authConfig, clearedSessionCookie, mintSession, requireSession, sessionCookie } from '../../lib/session.mjs';
import { SESSION_COOKIE, emailDomain, readCookie } from '../../lib/session-token.mjs';

const MAX_BODY_CHARS = 16 * 1024;

/** Handler factory so tests can inject a JWKS cache, env and clock. The default export uses the real ones. */
export function createSessionHandler({ jwks = createJwksCache(), getEnv = () => process.env, clock = Date.now } = {}) {
  async function signIn(request) {
    if (!sameOrigin(request)) return errorJson(403, 'Cross-site sign-in requests are not allowed.');
    const cfg = authConfig(getEnv());
    if (cfg.secret.length < MIN_SECRET_LENGTH) return errorJson(500, "Sign-in isn't configured on the server yet (SESSION_SECRET is missing or too short).");
    if (!cfg.clientId) return errorJson(500, "Sign-in isn't configured on the server yet (GOOGLE_CLIENT_ID is missing).");
    if (!cfg.allowedDomains.length && !cfg.allowedEmails.length) {
      return errorJson(500, "Sign-in isn't configured on the server yet (ALLOWED_DOMAINS and ALLOWED_EMAILS are both empty).");
    }
    if (!(request.headers.get('content-type') || '').toLowerCase().includes('application/json')) {
      return errorJson(415, 'Send the Google credential as JSON: {"credential": "..."}.');
    }
    const text = await request.text();
    if (text.length > MAX_BODY_CHARS) return errorJson(413, 'Request too large.');
    let credential = null;
    try {
      credential = JSON.parse(text)?.credential ?? null;
    } catch {
      // handled below
    }
    if (typeof credential !== 'string' || credential === '') return errorJson(400, 'Missing Google credential. Please try signing in again.');

    try {
      const user = await verifyGoogleIdToken(credential, { clientId: cfg.clientId, jwks, now: clock() });
      const { email, via } = authorizeGoogleAccount(user, cfg);
      const { token, exp } = mintSession(email, { secret: cfg.secret, now: clock() });
      console.log(`api-session: signed in (${emailDomain(email)}, via ${via})`);
      return json(
        { email, expires: new Date(exp * 1000).toISOString(), owner: cfg.ownerEmails.includes(email) },
        { request, headers: { 'Set-Cookie': sessionCookie(token) } },
      );
    } catch (err) {
      if (err instanceof AuthError) {
        console.warn(`api-session: sign-in rejected (${err.code}${err.reason ? `/${err.reason}` : ''})`);
        return errorJson(err.status, err.message);
      }
      throw err;
    }
  }

  function whoAmI(request) {
    const auth = requireSession(request, { env: getEnv(), now: clock() });
    if (!auth.ok) {
      // A cookie that is present but no longer valid is cleared, so the browser stops sending it.
      const stale = readCookie(request.headers.get('cookie'), SESSION_COOKIE) !== null && auth.status === 401;
      return errorJson(auth.status, auth.error, stale ? { 'Set-Cookie': clearedSessionCookie() } : {});
    }
    return json({ email: auth.email, expires: new Date(auth.exp * 1000).toISOString(), owner: auth.owner }, { request });
  }

  function signOut(request) {
    if (!sameOrigin(request)) return errorJson(403, 'Cross-site sign-out requests are not allowed.');
    return noContent({ 'Set-Cookie': clearedSessionCookie() });
  }

  return guarded('api-session', async (request) => {
    switch (request.method) {
      case 'POST': return signIn(request);
      case 'GET':
      case 'HEAD': return whoAmI(request);
      case 'DELETE': return signOut(request);
      default: return methodNotAllowed(['POST', 'GET', 'DELETE']);
    }
  });
}

export default createSessionHandler();

export const config = { path: '/api/session' };
