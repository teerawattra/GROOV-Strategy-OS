// GET /api/rows?from=YYYY-MM-DD&to=YYYY-MM-DD (signed-in): fact rows for an inclusive date range, with only the
// entities those rows reference (DATA_CONTRACT.md §2.2). At most 800 days per request.
//
// The normalised dataset is loaded from Blobs once per function instance and version (lib/blobs-store.mjs) and
// cut with lib/normalize.mjs sliceRows. Compressed bodies are kept in a small per-instance LRU, so a reload of the
// same range costs one manifest check.

import { openDataRequest } from '../../lib/api-data.mjs';
import { loadDataset } from '../../lib/blobs-store.mjs';
import { bodyResponse, createLru, errorJson, guarded, negotiateEncoding, prepareJsonBody, validateRange } from '../../lib/http.mjs';
import { sliceRows } from '../../lib/normalize.mjs';

const bodies = createLru(8);

/** For tests: forget prepared bodies. */
export function resetRowsCache() {
  bodies.clear();
}

export default guarded('api-rows', async (request) => {
  const ctx = await openDataRequest(request);
  if (ctx.response) return ctx.response;

  const params = new URL(request.url).searchParams;
  const range = validateRange(params.get('from'), params.get('to'));
  if (!range.ok) return errorJson(400, range.error);

  const encoding = negotiateEncoding(request.headers.get('accept-encoding'));
  const key = `${ctx.manifest.version}|${range.from}|${range.to}|${encoding ?? 'identity'}`;
  let prepared = bodies.get(key);
  if (!prepared) {
    const dataset = await loadDataset(ctx.store, ctx.manifest);
    prepared = prepareJsonBody(JSON.stringify(sliceRows(dataset, range.from, range.to)), encoding);
    bodies.set(key, prepared);
  }
  return bodyResponse(prepared, { headers: { 'X-Data-Version': ctx.manifest.version } });
});

export const config = { path: '/api/rows' };
