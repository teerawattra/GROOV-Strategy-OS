// /api/refresh
//   GET   (signed-in)  -> {status, can_refresh}: the last data-job run (state, counts, warnings, error)
//   POST  (owner only: OWNER_EMAILS) -> starts the data job now, 202. ?force=1 bypasses the shrink safety valve.
// The job itself runs in the background function refresh-background (15-minute limit).

import { DATASET_STORE, openStore, readStatus } from '../../lib/blobs-store.mjs';
import { errorJson, guarded, json, methodNotAllowed, sameOrigin } from '../../lib/http.mjs';
import { RUN_LOCK_MS, triggerBackgroundRefresh } from '../../lib/refresh.mjs';
import { requireSession } from '../../lib/session.mjs';

export function createRefreshHandler({ getEnv = () => process.env, fetchImpl = (...args) => globalThis.fetch(...args), clock = Date.now } = {}) {
  return guarded('api-refresh', async (request) => {
    if (!['GET', 'HEAD', 'POST'].includes(request.method)) return methodNotAllowed(['GET', 'POST']);
    if (request.method === 'POST' && !sameOrigin(request)) return errorJson(403, 'Cross-site refresh requests are not allowed.');
    const env = getEnv();
    const auth = requireSession(request, { env, now: clock() });
    if (!auth.ok) return errorJson(auth.status, auth.error);
    const store = await openStore(DATASET_STORE);
    const status = await readStatus(store);

    if (request.method !== 'POST') return json({ status, can_refresh: auth.owner }, { request });

    if (!auth.owner) return errorJson(403, 'Only the dashboard owner can start a data refresh. It runs by itself every day at 07:15 Bangkok.');
    const age = status?.started_at ? clock() - Date.parse(status.started_at) : Infinity;
    if (status?.state === 'running' && age >= 0 && age < RUN_LOCK_MS) {
      return errorJson(409, `A refresh is already running (started ${Math.max(1, Math.round(age / 60_000))} min ago). Check back in a few minutes.`);
    }
    const force = new URL(request.url).searchParams.get('force') === '1';
    const result = await triggerBackgroundRefresh({
      baseUrl: new URL(request.url).origin, trigger: 'manual', force, requestedBy: auth.email, env, fetchImpl, now: clock(),
    });
    if (!result.ok) {
      console.error(`api-refresh: could not start the background job: ${result.error}`);
      return errorJson(502, `The refresh could not be started: ${result.error}`);
    }
    console.log(`api-refresh: manual refresh started${force ? ' (forced)' : ''}`);
    return json({ started: true, force, message: 'Refresh started. It usually takes 1 to 3 minutes; reload GET /api/refresh to follow it.' }, { request, status: 202 });
  });
}

export default createRefreshHandler();

export const config = { path: '/api/refresh' };
