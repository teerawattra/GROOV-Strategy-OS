// GET /api/meta (signed-in): per-sheet health, data_through, history_from, creatives coverage
// (DATA_CONTRACT.md §2.4). Served from the manifest written by the data job, so it never loads the dataset.

import { openDataRequest } from '../../lib/api-data.mjs';
import { guarded, json } from '../../lib/http.mjs';

export default guarded('api-meta', async (request) => {
  const ctx = await openDataRequest(request);
  if (ctx.response) return ctx.response;
  return json(ctx.manifest.meta, { request, headers: { 'X-Data-Version': ctx.manifest.version } });
});

export const config = { path: '/api/meta' };
