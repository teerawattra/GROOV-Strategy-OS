// Background function (15-minute limit) that runs the data job: Sheets -> normalise -> Blobs caches -> images.
// Started only by the scheduled function refresh-data or by POST /api/refresh (owner), which sign the request
// with a 5-minute HMAC token derived from SESSION_SECRET. Netlify answers the caller 202 before this code runs,
// so a request without a valid token is simply logged and ignored.

import { CREATIVES_STORE, DATASET_STORE, openStore } from '../../lib/blobs-store.mjs';
import { runRefresh } from '../../lib/refresh.mjs';
import { INTERNAL_TOKEN_HEADER, authConfig, verifyInternalToken } from '../../lib/session.mjs';

export default async (request) => {
  let body = {};
  try {
    body = await request.json();
  } catch {
    // no body: treated as an invalid request below
  }
  const trigger = body?.trigger === 'manual' ? 'manual' : 'schedule';
  const force = body?.force === true;
  const { secret } = authConfig(process.env);
  if (!verifyInternalToken(request.headers.get(INTERNAL_TOKEN_HEADER), { secret, trigger, force })) {
    console.warn('refresh-background: ignored a request without a valid trigger token');
    return;
  }
  const requestedBy = typeof body?.requested_by === 'string' ? body.requested_by.slice(0, 320) : null;
  const [datasetStore, creativesStore] = await Promise.all([openStore(DATASET_STORE), openStore(CREATIVES_STORE)]);
  const status = await runRefresh({ datasetStore, creativesStore, trigger, force, requestedBy });
  console.log(`refresh-background: finished with state ${status.state}`);
};

export const config = { background: true };
