// Scheduled function: every day at 00:15 UTC = 07:15 Bangkok, after Windsor's 06:00 export.
// Scheduled functions may run for only 30 seconds, so this one just starts the background function
// refresh-background (15 minutes), which does the work and records the outcome in status.json.
// Run it on demand from the Netlify UI: Logs & metrics > Functions > refresh-data > Run now.

import { DATASET_STORE, openStore, writeStatus } from '../../lib/blobs-store.mjs';
import { triggerBackgroundRefresh } from '../../lib/refresh.mjs';

export default async (request, context) => {
  let nextRun = null;
  try {
    ({ next_run: nextRun } = await request.json());
  } catch {
    // "Run now" and local invocations may send no body
  }
  // Production: the site's main address. Under `netlify dev` that would be the live site, so use the local URL.
  const baseUrl = (process.env.NETLIFY_DEV === 'true' && process.env.URL) || context?.site?.url || process.env.URL;
  const result = await triggerBackgroundRefresh({ baseUrl, trigger: 'schedule' });
  if (result.ok) {
    console.log(`refresh-data: background refresh started (HTTP ${result.status}); next scheduled run ${nextRun ?? 'unknown'}`);
    return;
  }
  console.error(`refresh-data: could not start the background refresh: ${result.error}`);
  try {
    const store = await openStore(DATASET_STORE);
    const at = new Date().toISOString();
    await writeStatus(store, { state: 'error', trigger: 'schedule', started_at: at, finished_at: at, error: `The scheduled run could not start the background job: ${result.error}` });
  } catch (err) {
    console.error(`refresh-data: could not record the failure: ${err?.message ?? err}`);
  }
};

export const config = { schedule: '15 0 * * *' };
