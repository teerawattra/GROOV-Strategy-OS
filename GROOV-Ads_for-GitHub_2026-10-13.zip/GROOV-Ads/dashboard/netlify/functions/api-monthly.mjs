// GET /api/monthly (signed-in): full history at campaign x month (DATA_CONTRACT.md §2.3), precomputed by the
// data job and cached per function instance and version.

import { openDataRequest } from '../../lib/api-data.mjs';
import { loadMonthlyText } from '../../lib/blobs-store.mjs';
import { bodyResponse, createLru, guarded, negotiateEncoding, prepareJsonBody } from '../../lib/http.mjs';

const bodies = createLru(4);

export function resetMonthlyCache() {
  bodies.clear();
}

export default guarded('api-monthly', async (request) => {
  const ctx = await openDataRequest(request);
  if (ctx.response) return ctx.response;
  const encoding = negotiateEncoding(request.headers.get('accept-encoding'));
  const key = `${ctx.manifest.version}|${encoding ?? 'identity'}`;
  let prepared = bodies.get(key);
  if (!prepared) {
    prepared = prepareJsonBody(await loadMonthlyText(ctx.store, ctx.manifest), encoding);
    bodies.set(key, prepared);
  }
  return bodyResponse(prepared, { headers: { 'X-Data-Version': ctx.manifest.version } });
});

export const config = { path: '/api/monthly' };
