// GET /api/breakdowns?from=YYYY-MM-DD&to=YYYY-MM-DD (signed-in): placement and age x gender splits per ad set for an
// inclusive date range (DATA_CONTRACT.md §2.5), from the OPTIONAL Meta breakdown Sheets. At most 800 days per request.
//
// Same shape as /api/rows: the breakdown dataset is loaded from Blobs once per function instance and version
// (lib/blobs-store.mjs loadBreakdowns) and cut with lib/breakdowns.mjs sliceBreakdowns; compressed bodies are kept in a
// small per-instance LRU. spend_share comes from the main spend per ad set and day stored inside the breakdown blob, so
// this route never loads the main dataset, and both always come from the same manifest version.
//
// Neither Sheet configured (the manifest has no breakdown blob): 200 with available false / false and empty arrays,
// never an error.

import { openDataRequest } from '../../lib/api-data.mjs';
import { emptyBreakdowns, sliceBreakdowns } from '../../lib/breakdowns.mjs';
import { loadBreakdowns } from '../../lib/blobs-store.mjs';
import { bodyResponse, createLru, errorJson, guarded, negotiateEncoding, prepareJsonBody, validateRange } from '../../lib/http.mjs';

const bodies = createLru(8);

/** For tests: forget prepared bodies. */
export function resetBreakdownsCache() {
  bodies.clear();
}

export default guarded('api-breakdowns', async (request) => {
  const ctx = await openDataRequest(request);
  if (ctx.response) return ctx.response;

  const params = new URL(request.url).searchParams;
  const range = validateRange(params.get('from'), params.get('to'));
  if (!range.ok) return errorJson(400, range.error);

  const encoding = negotiateEncoding(request.headers.get('accept-encoding'));
  const key = `${ctx.manifest.version}|${range.from}|${range.to}|${encoding ?? 'identity'}`;
  let prepared = bodies.get(key);
  if (!prepared) {
    const bds = (await loadBreakdowns(ctx.store, ctx.manifest)) ?? emptyBreakdowns({ mode: ctx.manifest.mode === 'sample' ? 'sample' : 'live' });
    prepared = prepareJsonBody(JSON.stringify(sliceBreakdowns(bds, range.from, range.to)), encoding);
    bodies.set(key, prepared);
  }
  return bodyResponse(prepared, { headers: { 'X-Data-Version': ctx.manifest.version } });
});

export const config = { path: '/api/breakdowns' };
