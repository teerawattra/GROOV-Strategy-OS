// GET /api/config (public): what the login page needs before anyone is signed in.
// The OAuth client id is not a secret (Google shows it to every browser that renders the button).

import { guarded, json, methodNotAllowed } from '../../lib/http.mjs';

export default guarded('api-config', async (request) => {
  if (request.method !== 'GET' && request.method !== 'HEAD') return methodNotAllowed(['GET']);
  const clientId = String(process.env.GOOGLE_CLIENT_ID ?? '').trim();
  return json({ google_client_id: clientId || null }, { request, cache: 'no-store' });
});

export const config = { path: '/api/config' };
