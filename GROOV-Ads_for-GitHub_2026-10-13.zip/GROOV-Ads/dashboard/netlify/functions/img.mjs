// GET /img/:platform/:id (signed-in): a saved ad creative from the Blobs store "creatives".
// platform must be meta or tiktok and id digits only (no other keys of the store are reachable).
// Images are private to the signed-in browser for a day (Cache-Control: private, max-age=86400) and revalidate
// with ETag. Only raster types are ever served as images; anything else goes out as an inert download.

import { CREATIVES_STORE, creativeKey, openStore } from '../../lib/blobs-store.mjs';
import { SECURITY_HEADERS, errorJson, guarded, methodNotAllowed } from '../../lib/http.mjs';
import { requireSession } from '../../lib/session.mjs';

const RASTER_TYPES = new Set(['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/avif']);
const PLATFORMS = new Set(['meta', 'tiktok']);

export default guarded('img', async (request, context) => {
  if (request.method !== 'GET' && request.method !== 'HEAD') return methodNotAllowed(['GET']);
  const auth = requireSession(request);
  if (!auth.ok) return errorJson(auth.status, auth.error);

  let { platform, id } = context?.params ?? {};
  if (!platform || !id) {
    const m = /^\/img\/([^/]+)\/([^/]+)\/?$/.exec(new URL(request.url).pathname);
    if (m) [platform, id] = [decodeURIComponent(m[1]), decodeURIComponent(m[2])];
  }
  if (!PLATFORMS.has(platform)) return errorJson(400, 'Unknown platform: use meta or tiktok.');
  if (typeof id !== 'string' || !/^\d{1,30}$/.test(id)) return errorJson(400, 'The ad id must contain digits only.');

  const store = await openStore(CREATIVES_STORE);
  const ifNoneMatch = (request.headers.get('if-none-match') || '').trim();
  const etag = ifNoneMatch && !ifNoneMatch.includes(',') ? ifNoneMatch : undefined;
  const entry = await store.getWithMetadata(creativeKey(platform, id), { type: 'stream', ...(etag ? { etag } : {}) });
  if (!entry) return errorJson(404, 'No saved creative for this ad.', { 'Cache-Control': 'private, no-store' });

  const headers = {
    ...SECURITY_HEADERS,
    'Content-Security-Policy': "default-src 'none'; sandbox",
    'Cache-Control': 'private, max-age=86400',
    ...(entry.etag ? { ETag: entry.etag } : {}),
  };
  if (entry.data === null) return new Response(null, { status: 304, headers });
  const contentType = RASTER_TYPES.has(entry.metadata?.contentType) ? entry.metadata.contentType : 'application/octet-stream';
  if (request.method === 'HEAD') {
    try {
      await entry.data.cancel();
    } catch {
      // nothing to release
    }
    return new Response(null, { status: 200, headers: { ...headers, 'Content-Type': contentType } });
  }
  return new Response(entry.data, { status: 200, headers: { ...headers, 'Content-Type': contentType } });
});

export const config = { path: '/img/:platform/:id' };
