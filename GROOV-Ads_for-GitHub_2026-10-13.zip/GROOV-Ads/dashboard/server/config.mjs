// Settings for the VPS server and CLI, from environment variables (DEPLOY: config/groov.env.example documents each).
//
// Where the values come from, in order of precedence:
//   1. the process environment (systemd EnvironmentFile= lines, or `set -a; . /opt/data/.env; . ../groov.env; set +a`)
//   2. GROOV_ENV_FILE, an optional KEY=VALUE file; it never overrides a variable that is already set
// Relative DATA_DIR / CONFIG_DIR paths are resolved against the current working directory (systemd:
// WorkingDirectory=/opt/data/groov-cc/app, so the install layout sets both to absolute paths outside app/).
//
// The Windsor key is kept off every enumerable property, so printing or JSON-encoding a config object can never
// show it; read it with `config.windsorKey`.

import { existsSync, readFileSync } from 'node:fs';
import { dirname, isAbsolute, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { checkTimeZone, isIsoDay } from './util.mjs';

/** The package root: the folder that holds server/, public/, lib/, tools/. */
export const APP_ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');

export const DEFAULT_WINDSOR_URL = 'https://connectors.windsor.ai';

export class ConfigError extends Error {
  constructor(message) {
    super(message);
    this.name = 'ConfigError';
  }
}

// ---------------------------------------------------------------------------------------------------------
// Env files
// ---------------------------------------------------------------------------------------------------------

/**
 * Value cleanup shared by env files and the process environment. systemd's EnvironmentFile= has no inline comments,
 * so `ALLOWED_USERS=   # anyone` arrives as "# anyone": a value that starts with "#" is empty, and an unquoted
 * " # comment" tail is cut off.
 */
export function cleanValue(raw) {
  if (raw === undefined || raw === null) return '';
  let v = String(raw).trim();
  if (v.length >= 2 && ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'")))) return v.slice(1, -1);
  if (v.startsWith('#')) return '';
  const hash = v.search(/\s#/);
  if (hash !== -1) v = v.slice(0, hash).trim();
  return v;
}

/** Parse KEY=VALUE lines (blank lines, `# comments` and an optional `export ` prefix are allowed). */
export function parseEnvFile(text) {
  const out = {};
  for (const line of String(text).split(/\r?\n/)) {
    const t = line.trim();
    if (!t || t.startsWith('#') || t.startsWith(';')) continue;
    const m = /^(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=(.*)$/.exec(t);
    if (!m) continue;
    out[m[1]] = cleanValue(m[2]);
  }
  return out;
}

/**
 * Load an env file into `env` without overriding variables that are already set. Returns the NAMES it set (never
 * values). A missing file is a ConfigError: GROOV_ENV_FILE names a file on purpose.
 */
export function loadEnvFile(path, env = process.env) {
  if (!existsSync(path)) throw new ConfigError(`GROOV_ENV_FILE points at ${path}, which does not exist.`);
  const values = parseEnvFile(readFileSync(path, 'utf8'));
  const set = [];
  for (const [k, v] of Object.entries(values)) {
    if (env[k] === undefined) {
      env[k] = v;
      set.push(k);
    }
  }
  return set;
}

// ---------------------------------------------------------------------------------------------------------
// Parsing helpers
// ---------------------------------------------------------------------------------------------------------

/** "a@x.co, B@Y.co ,," -> ["a@x.co", "b@y.co"] (trimmed, lower-case, de-duplicated). */
export function parseUserList(value) {
  const out = [];
  for (const item of cleanValue(value).split(/[,\s;]+/)) {
    const v = item.trim().toLowerCase();
    if (v && !out.includes(v)) out.push(v);
  }
  return out;
}

function intVar(env, name, fallback, min, max) {
  const raw = cleanValue(env[name]);
  if (raw === '') return fallback;
  if (!/^\d+$/.test(raw)) throw new ConfigError(`${name} must be a whole number (got "${raw.slice(0, 40)}").`);
  const n = Number(raw);
  if (n < min || n > max) throw new ConfigError(`${name} must be between ${min} and ${max} (got ${n}).`);
  return n;
}

function boolVar(env, name, fallback) {
  const raw = cleanValue(env[name]).toLowerCase();
  if (raw === '') return fallback;
  if (['1', 'true', 'yes', 'on'].includes(raw)) return true;
  if (['0', 'false', 'no', 'off'].includes(raw)) return false;
  throw new ConfigError(`${name} must be 1 or 0 (got "${raw.slice(0, 40)}").`);
}

const LOOPBACK_NAMES = new Set(['localhost', 'ip6-localhost', 'ip6-loopback']);

/** True for 127.0.0.0/8, ::1 and "localhost" (with or without IPv6 brackets). */
export function isLoopbackHost(host) {
  const h = String(host ?? '').trim().toLowerCase().replace(/^\[|\]$/g, '');
  if (LOOPBACK_NAMES.has(h)) return true;
  if (h === '::1' || h === '0:0:0:0:0:0:0:1') return true;
  if (/^::ffff:127\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(h)) return true;
  return /^127\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(h);
}

/** The Windsor base URL: https anywhere, plain http only on this machine (the test double). */
function windsorUrl(raw) {
  const value = cleanValue(raw) || DEFAULT_WINDSOR_URL;
  let u;
  try {
    u = new URL(value);
  } catch {
    throw new ConfigError('WINDSOR_BASE_URL is not a valid URL.');
  }
  if (u.username || u.password || u.search || u.hash) throw new ConfigError('WINDSOR_BASE_URL must be a plain address, e.g. https://connectors.windsor.ai');
  if (u.protocol !== 'https:' && !(u.protocol === 'http:' && isLoopbackHost(u.hostname))) {
    throw new ConfigError('WINDSOR_BASE_URL must use https (plain http is allowed only for 127.0.0.1, for tests).');
  }
  return u.href.replace(/\/+$/, '');
}

// ---------------------------------------------------------------------------------------------------------
// Config
// ---------------------------------------------------------------------------------------------------------

/**
 * Build the config object. Throws ConfigError with a fix-it message for invalid values. Never reads or throws the
 * key's value; a missing key is allowed here (serve does not need it) and reported by the commands that pull.
 * @param {{ env?: object, cwd?: string, appRoot?: string }} [options]
 */
export function loadConfig({ env = process.env, cwd = process.cwd(), appRoot = APP_ROOT } = {}) {
  const pathVar = (name, fallback) => {
    const v = cleanValue(env[name]) || fallback;
    return isAbsolute(v) ? v : resolve(cwd, v);
  };
  const authMode = (cleanValue(env.AUTH_MODE) || 'tailscale').toLowerCase();
  if (!['tailscale', 'none'].includes(authMode)) throw new ConfigError(`AUTH_MODE must be "tailscale" or "none" (got "${authMode.slice(0, 40)}").`);
  const tz = cleanValue(env.TZ_REPORT) || 'Asia/Bangkok';
  try {
    checkTimeZone(tz);
  } catch {
    throw new ConfigError(`TZ_REPORT must be an IANA timezone such as Asia/Bangkok (got "${tz.slice(0, 60)}").`);
  }
  const backfillFrom = cleanValue(env.BACKFILL_FROM);
  if (backfillFrom && !isIsoDay(backfillFrom)) throw new ConfigError(`BACKFILL_FROM must be a date as YYYY-MM-DD (got "${backfillFrom.slice(0, 40)}").`);

  // The key: WINDSOR_API_KEY wins; MCP_WINDSOR_API_KEY is the name Hermes already uses in /opt/data/.env.
  let keySource = null;
  let key = '';
  for (const name of ['WINDSOR_API_KEY', 'MCP_WINDSOR_API_KEY']) {
    const v = cleanValue(env[name]);
    if (v && !/^replace_with/i.test(v)) {
      key = v;
      keySource = name;
      break;
    }
  }

  const config = {
    appRoot,
    publicDir: resolve(appRoot, 'public'),
    toolsDir: resolve(appRoot, 'tools'),
    dataDir: pathVar('DATA_DIR', './data'),
    configDir: pathVar('CONFIG_DIR', './config'),
    host: cleanValue(env.HOST) || '127.0.0.1',
    port: intVar(env, 'PORT', 8787, 0, 65535),
    authMode,
    allowedUsers: parseUserList(env.ALLOWED_USERS),
    ownerUsers: parseUserList(env.OWNER_USERS),
    tzReport: tz,
    refreshDays: intVar(env, 'REFRESH_DAYS', 28, 1, 400),
    enableBreakdowns: boolVar(env, 'ENABLE_BREAKDOWNS', true),
    backfillFrom: backfillFrom || null,
    python: cleanValue(env.PYTHON) || 'python3',
    windsor: {
      baseUrl: windsorUrl(env.WINDSOR_BASE_URL),
      chunkDays: intVar(env, 'WINDSOR_CHUNK_DAYS', 7, 1, 31),
      maxRows: intVar(env, 'WINDSOR_MAX_ROWS', 100_000, 10, 10_000_000),
      timeoutMs: intVar(env, 'WINDSOR_TIMEOUT_MS', 180_000, 1_000, 3_600_000),
      concurrency: intVar(env, 'WINDSOR_CONCURRENCY', 2, 1, 8),
    },
    keySource, // the variable NAME the key came from, never its value
    hasWindsorKey: Boolean(key),
  };
  Object.defineProperty(config, 'windsorKey', { value: key, enumerable: false, writable: false });
  return config;
}

/** Refuse settings that would expose the dashboard. Throws ConfigError. */
export function checkServeSafety(config) {
  if (!isLoopbackHost(config.host)) {
    throw new ConfigError(
      `HOST=${config.host} is not a loopback address. The server must listen on 127.0.0.1 only: `
      + (config.authMode === 'none'
        ? 'AUTH_MODE=none has no sign-in at all and is for local testing.'
        : 'tailscale serve proxies to 127.0.0.1, and on any other address anyone who can reach the port could forge the Tailscale identity headers.')
      + ' Set HOST=127.0.0.1.',
    );
  }
}

/** A one-screen description of the settings for logs and `status` (no secrets). */
export function describeConfig(config) {
  return {
    data_dir: config.dataDir,
    config_dir: config.configDir,
    listen: `${config.host}:${config.port}`,
    auth: config.authMode,
    allowed_users: config.allowedUsers.length,
    owner_users: config.ownerUsers.length,
    tz_report: config.tzReport,
    refresh_days: config.refreshDays,
    breakdowns: config.enableBreakdowns,
    backfill_from: config.backfillFrom,
    windsor_key: config.hasWindsorKey ? `set (${config.keySource})` : 'missing',
    windsor_endpoint: config.windsor.baseUrl === DEFAULT_WINDSOR_URL ? 'windsor.ai' : 'custom (WINDSOR_BASE_URL)',
  };
}
