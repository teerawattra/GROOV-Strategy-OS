// Small shared helpers for the VPS server: report-timezone dates, atomic file writes, a bounded parallel map and a
// logger that can never print a secret it has been told about. Zero dependencies.

import { randomBytes } from 'node:crypto';
import { mkdir, open, readFile, rename, rm } from 'node:fs/promises';
import { basename, dirname, join } from 'node:path';

// ---------------------------------------------------------------------------------------------------------
// Dates (ISO "YYYY-MM-DD", calendar arithmetic in UTC so it never depends on the machine's timezone)
// ---------------------------------------------------------------------------------------------------------

const DAY_MS = 86_400_000;
const ISO_DAY = /^\d{4}-\d{2}-\d{2}$/;

/** "YYYY-MM-DD" that is a real calendar date -> true. */
export function isIsoDay(value) {
  if (typeof value !== 'string' || !ISO_DAY.test(value)) return false;
  const [y, m, d] = value.split('-').map(Number);
  const t = new Date(Date.UTC(y, m - 1, d));
  return t.getUTCFullYear() === y && t.getUTCMonth() === m - 1 && t.getUTCDate() === d;
}

export const dayNumber = (iso) => Date.UTC(+iso.slice(0, 4), +iso.slice(5, 7) - 1, +iso.slice(8, 10)) / DAY_MS;
export const isoFromDayNumber = (n) => new Date(n * DAY_MS).toISOString().slice(0, 10);
export const addDays = (iso, n) => isoFromDayNumber(dayNumber(iso) + n);
/** Days from a to b (b - a). */
export const daysBetween = (a, b) => dayNumber(b) - dayNumber(a);

/** Every date from `from` to `to`, inclusive. */
export function dateRange(from, to) {
  const out = [];
  for (let n = dayNumber(from), end = dayNumber(to); n <= end; n++) out.push(isoFromDayNumber(n));
  return out;
}

/** Split [from, to] into consecutive pieces of at most `size` days. */
export function splitDays(from, to, size) {
  const out = [];
  let start = dayNumber(from);
  const end = dayNumber(to);
  while (start <= end) {
    const stop = Math.min(start + size - 1, end);
    out.push({ from: isoFromDayNumber(start), to: isoFromDayNumber(stop) });
    start = stop + 1;
  }
  return out;
}

/** Contiguous runs of a sorted list of ISO dates: ["01","02","05"] -> [{01..02}, {05..05}]. */
export function dateRuns(sortedDates) {
  const runs = [];
  for (const d of sortedDates) {
    const last = runs[runs.length - 1];
    if (last && dayNumber(d) === dayNumber(last.to) + 1) last.to = d;
    else runs.push({ from: d, to: d });
  }
  return runs;
}

/** The calendar date in `timeZone` at instant `now` (default: Asia/Bangkok, the accounts' timezone). */
export function todayIn(timeZone = 'Asia/Bangkok', now = new Date()) {
  const parts = new Intl.DateTimeFormat('en-US', { timeZone, year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(now);
  const get = (type) => parts.find((p) => p.type === type).value;
  return `${get('year')}-${get('month')}-${get('day')}`;
}

/** Local wall-clock time in `timeZone`, e.g. "2026-10-13 07:02" (for status lines). */
export function localStamp(timeZone, date) {
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23',
  }).formatToParts(date);
  const get = (type) => parts.find((p) => p.type === type).value;
  return `${get('year')}-${get('month')}-${get('day')} ${get('hour')}:${get('minute')}`;
}

/** Throws a RangeError for an unknown IANA timezone name. */
export function checkTimeZone(timeZone) {
  // eslint-disable-next-line no-new
  new Intl.DateTimeFormat('en-US', { timeZone });
  return timeZone;
}

// ---------------------------------------------------------------------------------------------------------
// Files
// ---------------------------------------------------------------------------------------------------------

/** Temp-file name next to `path` (same directory, so the final rename is atomic on one filesystem). */
export function tempPathFor(path) {
  return join(dirname(path), `.${basename(path)}.tmp-${process.pid}-${randomBytes(4).toString('hex')}`);
}

/**
 * Write `data` to `path` atomically: write a temp file in the same folder, flush it to disk, then rename it over
 * `path`. A reader sees either the old file or the new one, never half of one; a crash leaves only a temp file.
 */
export async function atomicWrite(path, data, { mode = 0o644 } = {}) {
  await mkdir(dirname(path), { recursive: true });
  const tmp = tempPathFor(path);
  let handle;
  try {
    handle = await open(tmp, 'w', mode);
    await handle.writeFile(data);
    await handle.sync();
    await handle.close();
    handle = null;
    await rename(tmp, path);
  } catch (err) {
    if (handle) await handle.close().catch(() => {});
    await rm(tmp, { force: true }).catch(() => {});
    throw err;
  }
}

/** Parsed JSON file, or null when it does not exist. Malformed JSON throws (with the path in the message). */
export async function readJsonFile(path) {
  let text;
  try {
    text = await readFile(path, 'utf8');
  } catch (err) {
    if (err.code === 'ENOENT') return null;
    throw err;
  }
  try {
    return JSON.parse(text);
  } catch {
    throw new Error(`${path} is not valid JSON`);
  }
}

export async function writeJsonFile(path, value) {
  await atomicWrite(path, `${JSON.stringify(value, null, 1)}\n`);
}

// ---------------------------------------------------------------------------------------------------------
// Concurrency
// ---------------------------------------------------------------------------------------------------------

/** Run fn over items with at most `limit` in flight; results in input order. Rejects on the first failure. */
export async function mapLimit(items, limit, fn) {
  const results = new Array(items.length);
  let next = 0;
  async function worker() {
    while (next < items.length) {
      const i = next++;
      results[i] = await fn(items[i], i);
    }
  }
  await Promise.all(Array.from({ length: Math.min(Math.max(1, limit), items.length) }, worker));
  return results;
}

export const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

// ---------------------------------------------------------------------------------------------------------
// Logging
// ---------------------------------------------------------------------------------------------------------

/** A secret as it can appear in text: raw, URL-encoded and form-encoded (for redact()). Empty input -> []. */
export function secretForms(secret) {
  if (typeof secret !== 'string' || secret === '') return [];
  return [...new Set([secret, encodeURIComponent(secret), new URLSearchParams({ k: secret }).toString().slice(2)])];
}

/**
 * Replace every occurrence of the given secrets, any `api_key=...` / `key=...` query value and any URL query string
 * in `text`. Used on everything that could reach a log line or an error message.
 */
export function redact(text, secrets = []) {
  let s = String(text ?? '');
  for (const secret of secrets) {
    if (typeof secret === 'string' && secret.length >= 4) s = s.split(secret).join('[redacted]');
  }
  s = s.replace(/(api[_-]?key|access[_-]?token|token|key|signature)=([^&\s"'<>]+)/gi, '$1=[redacted]');
  s = s.replace(/(https?:\/\/[^\s"'<>?]+)\?[^\s"'<>]*/gi, '$1?[query removed]');
  s = s.replace(/((?:^|[\s"'(])\/[\w.\-/%]*)\?[^\s"'<>)]*/g, '$1?[query removed]'); // "/facebook?api_key=…" echoed back
  return s;
}

/**
 * Logger with info / warn / error. Every line goes through redact(), so even a mistake elsewhere cannot print the
 * Windsor key. `sink` receives (level, line); the default writes to stdout / stderr.
 */
export function createLogger({ secrets = [], sink = null, quiet = false } = {}) {
  const lines = [];
  const write = (level, args) => {
    const line = redact(args.map((a) => (typeof a === 'string' ? a : a instanceof Error ? `${a.name}: ${a.message}` : JSON.stringify(a))).join(' '), secrets);
    lines.push({ level, line });
    if (sink) sink(level, line);
    else if (!quiet) (level === 'info' ? process.stdout : process.stderr).write(`${line}\n`);
  };
  return {
    lines,
    info: (...args) => write('info', args),
    log: (...args) => write('info', args),
    warn: (...args) => write('warn', args),
    error: (...args) => write('error', args),
    addSecret(secret) {
      if (typeof secret === 'string' && secret.length >= 4 && !secrets.includes(secret)) secrets.push(secret);
    },
  };
}

/** Thousands separators for counts in CLI output. */
export const int = (n) => Number(n || 0).toLocaleString('en-US');
/** "฿1,234.56". */
export const baht = (n) => `฿${Number(n || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
