// The three small data scripts the dashboard loads with <script> tags, generated from CONFIG_DIR:
//
//   /data/registry.js   window.GROOV_REGISTRY   <- config/accounts/registry.json            (tools/build_static.py)
//   /data/learnings.js  window.GROOV_LEARNINGS  <- config/learnings/{LOG,PLAYBOOK}.md, rules.json (tools/build_static.py)
//   /data/modules.js    window.GROOV_MODULES    <- config/modules.json                       (modulesJs below)
//
// Registry and learnings come from the one existing implementation, tools/build_static.py (run with python3 and
// --registry / --learnings-dir / --out-dir), into DATA_DIR/static/. Without python3 the learnings fall back to the
// pre-built public/data/learnings.js shipped in the package (with a warning), and the registry is written from the
// JSON as is. The server serves DATA_DIR/static/<name> when it exists, else the shipped public/data/<name>.

import { execFile } from 'node:child_process';
import { copyFile, mkdir, mkdtemp, readFile, rm, stat } from 'node:fs/promises';
import { join } from 'node:path';
import { atomicWrite } from './util.mjs';

export const STATIC_NAMES = Object.freeze(['registry.js', 'learnings.js', 'modules.js']);
export const staticDir = (dataDir) => join(dataDir, 'static');

/** The default module list: only the Ads Command Center (the switcher stays hidden). */
export const DEFAULT_MODULES = Object.freeze({ modules: Object.freeze([Object.freeze({ id: 'ads', label: 'Ads', enabled: true, route: '#/overview' })]) });

const MODULE_ID = /^[a-z][a-z0-9_-]{0,31}$/;
const MODULE_ROUTE = /^#\/[A-Za-z0-9_\-/]*$/;

/**
 * Clean a modules.json object: { modules: [{ id, label, enabled, route }] }. Entries without a valid id are dropped,
 * ids are unique, `enabled` must be exactly true to count, and a route must be an in-app hash ("#/kol/overview");
 * anything else falls back to "#/<id>" so no configuration can put a javascript: link in the sidebar.
 */
export function normaliseModules(raw) {
  const list = Array.isArray(raw) ? raw : Array.isArray(raw?.modules) ? raw.modules : [];
  const out = [];
  const seen = new Set();
  for (const m of list) {
    if (!m || typeof m !== 'object') continue;
    const id = typeof m.id === 'string' ? m.id.trim() : '';
    if (!MODULE_ID.test(id) || seen.has(id)) continue;
    seen.add(id);
    const label = typeof m.label === 'string' && m.label.trim() ? m.label.trim().slice(0, 40) : id;
    const route = typeof m.route === 'string' && MODULE_ROUTE.test(m.route.trim()) ? m.route.trim() : `#/${id}`;
    out.push({ id, label, enabled: m.enabled === true, route });
  }
  return { modules: out };
}

// U+2028 / U+2029 are legal inside JSON strings but were syntax errors in JS string literals before ES2019, so they are
// written as escapes. The pattern is built from char codes to keep this source free of those characters.
const LINE_SEPARATORS = new RegExp('[' + String.fromCharCode(0x2028, 0x2029) + ']', 'g');

/** JSON as a JavaScript literal (U+2028 / U+2029 escaped, like build_static.py's to_js). */
function toJs(value) {
  return JSON.stringify(value).replace(LINE_SEPARATORS, (c) => `\\u${c.charCodeAt(0).toString(16)}`);
}

export function modulesJs(raw) {
  return `window.GROOV_MODULES = ${toJs(normaliseModules(raw))};\n`;
}

/** Registry script straight from the JSON: used only when python3 is not available. */
export function registryJs(registry) {
  return `window.GROOV_REGISTRY = ${toJs(registry)};\n`;
}

export function configSources(config) {
  return {
    registry: join(config.configDir, 'accounts', 'registry.json'),
    learningsDir: join(config.configDir, 'learnings'),
    learnings: ['LOG.md', 'PLAYBOOK.md', 'rules.json'].map((f) => join(config.configDir, 'learnings', f)),
    modules: join(config.configDir, 'modules.json'),
  };
}

async function exists(path) {
  try {
    await stat(path);
    return true;
  } catch {
    return false;
  }
}

async function mtime(path) {
  try {
    return (await stat(path)).mtimeMs;
  } catch {
    return null;
  }
}

function runPython(python, args, { timeoutMs = 60_000 } = {}) {
  // A minimal environment: the script needs no settings, and the Windsor key has no business in a child process.
  // UTF-8 output whatever the service's locale (client names are Thai).
  const env = { PATH: process.env.PATH ?? '/usr/local/bin:/usr/bin:/bin', HOME: process.env.HOME ?? '/', PYTHONUTF8: '1', PYTHONIOENCODING: 'utf-8', LANG: 'C.UTF-8' };
  return new Promise((resolve) => {
    execFile(python, args, { timeout: timeoutMs, maxBuffer: 4 * 1024 * 1024, env }, (error, stdout, stderr) => {
      resolve({ error, stdout: String(stdout ?? ''), stderr: String(stderr ?? '') });
    });
  });
}

/**
 * Regenerate DATA_DIR/static/{registry,learnings,modules}.js. Never throws for content problems: the result says what
 * was used, and the previous files stay in place when a rebuild fails.
 * @returns {Promise<{ ok: boolean, registry: string, learnings: string, modules: string, warnings: string[], output: string }>}
 *   registry: python | json | shipped | kept · learnings: python | shipped | kept · modules: config | default
 */
export async function buildStatic(config, { log = console, python = config.python } = {}) {
  const out = staticDir(config.dataDir);
  await mkdir(out, { recursive: true });
  const src = configSources(config);
  const result = { ok: true, registry: 'kept', learnings: 'kept', modules: 'default', warnings: [], output: '' };
  const warn = (msg) => {
    result.warnings.push(msg);
    log.warn(`build-static: ${msg}`);
  };
  const shipped = (name) => join(config.publicDir, 'data', name);

  // modules.js (no python needed)
  let modules = DEFAULT_MODULES;
  if (await exists(src.modules)) {
    try {
      modules = JSON.parse(await readFile(src.modules, 'utf8'));
      result.modules = 'config';
    } catch {
      warn(`${src.modules} is not valid JSON; only the Ads module is shown.`);
    }
  }
  await atomicWrite(join(out, 'modules.js'), modulesJs(modules));

  // registry.js + learnings.js
  const haveConfig = (await exists(src.registry)) && (await Promise.all(src.learnings.map(exists))).every(Boolean);
  /** Keep the last good generated file; without one, copy the file shipped in public/data. */
  const keepOrShipped = async () => {
    for (const name of ['registry.js', 'learnings.js']) {
      if (await exists(join(out, name))) continue;
      if (await exists(shipped(name))) {
        await copyFile(shipped(name), join(out, name));
        result[name.replace('.js', '')] = 'shipped';
      }
    }
  };
  if (!haveConfig) {
    warn(`${src.registry} or a file in ${src.learningsDir} is missing; serving the registry and learnings shipped in public/data.`);
    await keepOrShipped();
    return result;
  }

  const tmp = await mkdtemp(join(out, '.build-'));
  try {
    const script = join(config.toolsDir, 'build_static.py');
    const run = await runPython(python, [script, '--registry', src.registry, '--learnings-dir', src.learningsDir, '--out-dir', tmp]);
    result.output = (run.stdout + run.stderr).trim();
    if (run.error && run.error.code === 'ENOENT') {
      // No python3: learnings from the shipped file, registry straight from the JSON.
      warn(`${python} was not found, so the learning log could not be rebuilt: serving the learnings shipped in public/data/learnings.js. Install Python 3 and run "node server/cli.mjs build-static".`);
      result.degraded = true;
      try {
        await atomicWrite(join(out, 'registry.js'), registryJs(JSON.parse(await readFile(src.registry, 'utf8'))));
        result.registry = 'json';
      } catch {
        warn(`${src.registry} is not valid JSON; the previous registry stays in place.`);
        if (!(await exists(join(out, 'registry.js'))) && (await exists(shipped('registry.js')))) {
          await copyFile(shipped('registry.js'), join(out, 'registry.js'));
          result.registry = 'shipped';
        }
      }
      if (await exists(shipped('learnings.js'))) {
        await atomicWrite(join(out, 'learnings.js'), await readFile(shipped('learnings.js')));
        result.learnings = 'shipped';
      }
      return result;
    }
    if (run.error) {
      const last = result.output.split('\n').filter(Boolean).pop() ?? run.error.message;
      warn(`tools/build_static.py failed (${last.slice(0, 300)}); the previous registry and learnings stay in place.`);
      await keepOrShipped();
      result.ok = false;
      return result;
    }
    for (const name of ['registry.js', 'learnings.js']) {
      await atomicWrite(join(out, name), await readFile(join(tmp, name)));
      result[name.replace('.js', '')] = 'python';
    }
    log.info(`build-static: registry.js and learnings.js rebuilt from ${config.configDir} (python), modules.js from ${result.modules === 'config' ? src.modules : 'the default'}`);
    return result;
  } finally {
    await rm(tmp, { recursive: true, force: true }).catch(() => {});
  }
}

/**
 * True when DATA_DIR/static is missing a file or older than one of its sources (registry, learnings, modules), so the
 * server can rebuild after Hermes edits config/ without a restart.
 */
export async function staticIsStale(config) {
  const out = staticDir(config.dataDir);
  const outs = await Promise.all(STATIC_NAMES.map((n) => mtime(join(out, n))));
  if (outs.some((t) => t === null)) return true;
  const src = configSources(config);
  const sources = await Promise.all([src.registry, ...src.learnings, src.modules].map(mtime));
  const newestSource = Math.max(...sources.filter((t) => t !== null), 0);
  return newestSource > Math.min(...outs);
}

/** A fingerprint of the config sources (paths + modification times), to avoid retrying a failed build unchanged. */
export async function sourcesSignature(config) {
  const src = configSources(config);
  const paths = [src.registry, ...src.learnings, src.modules];
  return (await Promise.all(paths.map(async (p) => `${p}:${(await mtime(p)) ?? '-'}`))).join('|');
}

/** Path to serve for /data/<name>: the generated file, else the one shipped in public/data. */
export async function staticFilePath(config, name) {
  if (!STATIC_NAMES.includes(name)) return null;
  const generated = join(staticDir(config.dataDir), name);
  if (await exists(generated)) return generated;
  const shipped = join(config.publicDir, 'data', name);
  return (await exists(shipped)) ? shipped : null;
}
