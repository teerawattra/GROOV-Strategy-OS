// The dashboard server: node:http on 127.0.0.1 (never another address), routes from server/routes.mjs, the current
// snapshot held in memory and swapped when data/current.json changes (hot reload, no restart), and the owner's
// "Refresh data now" button running server/refresh.mjs in the background.

import http from 'node:http';
import { stat, unwatchFile, watchFile } from 'node:fs';
import { promisify } from 'node:util';
import { checkServeSafety, describeConfig } from './config.mjs';
import { createHandler, sendError } from './routes.mjs';
import { lockIsLive, readLock, refresh } from './refresh.mjs';
import { currentFile, loadSnapshot, readCurrent } from './snapshot.mjs';
import { buildStatic, sourcesSignature, staticIsStale } from './static-data.mjs';

const statAsync = promisify(stat);
const RETRY_FAILED_LOAD_MS = 60_000;

/**
 * Holds the snapshot the API serves. `get()` re-reads data/current.json at most every `checkEveryMs`; when it names a
 * new version, that version is loaded completely and only then swapped in, so requests keep getting the previous
 * snapshot while the new one loads, and a version that fails to load never replaces a good one.
 */
export class SnapshotHolder {
  constructor(dataDir, { log = console, checkEveryMs = 1000 } = {}) {
    this.dataDir = dataDir;
    this.log = log;
    this.checkEveryMs = checkEveryMs;
    this.current = null;
    this.lastCheck = 0;
    this.signature = null;
    this.failed = null; // { signature, at }
    this.loading = null;
  }

  get version() {
    return this.current?.version ?? null;
  }

  async get() {
    if (Date.now() - this.lastCheck >= this.checkEveryMs) {
      const pending = this.check();
      if (!this.current) await pending; // nothing to serve yet: wait for the first load
    }
    return this.current;
  }

  /** Load the version data/current.json names, if it changed. Never throws. */
  check() {
    if (this.loading) return this.loading;
    this.lastCheck = Date.now();
    this.loading = (async () => {
      let signature = null;
      try {
        let st;
        try {
          st = await statAsync(currentFile(this.dataDir));
        } catch {
          return; // no snapshot yet
        }
        signature = `${st.mtimeMs}|${st.size}|${st.ino}`;
        if (signature === this.signature && this.current) return;
        if (this.failed && this.failed.signature === signature && Date.now() - this.failed.at < RETRY_FAILED_LOAD_MS) return;
        const cur = await readCurrent(this.dataDir);
        if (!cur) return;
        if (this.current && cur.version === this.current.version) {
          this.signature = signature;
          return;
        }
        const snap = await loadSnapshot(this.dataDir, cur.version);
        this.current = snap;
        this.signature = signature;
        this.failed = null;
        this.log.info(`server: serving snapshot ${snap.version} (data through ${snap.manifest.data_through ?? 'none'})`);
      } catch (err) {
        this.failed = { signature, at: Date.now() };
        this.log.error(`server: could not load the snapshot data/current.json points at (${err?.message ?? err}); ${this.current ? `still serving ${this.current.version}` : 'nothing to serve yet'}`);
      } finally {
        this.loading = null;
      }
    })();
    return this.loading;
  }

  watch(intervalMs = 1000) {
    watchFile(currentFile(this.dataDir), { interval: intervalMs, persistent: false }, () => this.check());
  }

  close() {
    unwatchFile(currentFile(this.dataDir));
  }
}

/**
 * Create (not start) the server. Options are for tests: fetchImpl / imageFetchImpl / sleep reach the background refresh.
 * @returns {{ server: http.Server, holder: SnapshotHolder, listen(): Promise<{host: string, port: number}>, close(): Promise<void>,
 *   startRefresh: Function, readonly lastRefresh: Promise<object>|null }}
 */
export function createDashboardServer(config, { log = console, fetchImpl, imageFetchImpl, sleep, checkEveryMs = 1000, watchIntervalMs = 1000 } = {}) {
  checkServeSafety(config);
  const holder = new SnapshotHolder(config.dataDir, { log, checkEveryMs });
  let running = null;
  let lastRefresh = null;

  async function startRefresh({ force = false, requestedBy = null, trigger = 'manual' } = {}) {
    const lock = await readLock(config.dataDir);
    if (running) return { running: true, started_at: running.startedAt };
    if (lockIsLive(lock)) return { running: true, started_at: lock.started_at };
    if (!config.hasWindsorKey) return { started: false, error: 'no Windsor API key is set for the server (WINDSOR_API_KEY or MCP_WINDSOR_API_KEY in its EnvironmentFile).' };
    const startedAt = new Date().toISOString();
    const promise = refresh(config, { force, trigger, requestedBy, log, fetchImpl, imageFetchImpl, sleep })
      .catch((err) => ({ state: 'error', error: String(err?.message ?? err) }))
      .then((status) => {
        running = null;
        holder.check();
        return status;
      });
    running = { promise, startedAt };
    lastRefresh = promise;
    return { started: true };
  }

  // /data/*.js: rebuild after config/ changed (checked at most every 5 s; a failed build waits for the next edit).
  let staticCheckedAt = 0;
  let staticBusy = null;
  let failedSignature = null;
  async function ensureStatic({ force = false } = {}) {
    if (staticBusy) return staticBusy;
    if (!force && Date.now() - staticCheckedAt < 5000) return undefined;
    staticCheckedAt = Date.now();
    staticBusy = (async () => {
      if (!force && !(await staticIsStale(config))) return;
      const signature = await sourcesSignature(config);
      if (!force && signature === failedSignature) return;
      const result = await buildStatic(config, { log });
      failedSignature = result.ok ? null : signature;
    })().finally(() => {
      staticBusy = null;
    });
    return staticBusy;
  }

  const handler = createHandler({ config, snapshots: holder, startRefresh, ensureStatic, log });
  const server = http.createServer((req, res) => {
    handler(req, res).catch((err) => {
      log.error(`server: unexpected error on ${req.method} ${String(req.url ?? '').split('?')[0].slice(0, 200)}: ${err?.name ?? 'Error'}: ${String(err?.message ?? err).slice(0, 300)}`);
      if (!res.headersSent) sendError(req, res, 500, 'Something went wrong on the server. Try again; if it keeps happening, check the server log.');
      else res.destroy();
    });
  });
  server.headersTimeout = 30_000;
  server.requestTimeout = 120_000;
  server.keepAliveTimeout = 5_000;

  return {
    server,
    holder,
    startRefresh,
    ensureStatic,
    get lastRefresh() {
      return lastRefresh;
    },
    async listen() {
      await ensureStatic({ force: false }).catch((err) => log.error(`build-static: ${err?.message ?? err}`));
      await holder.check();
      holder.watch(watchIntervalMs);
      await new Promise((resolve, reject) => {
        server.once('error', reject);
        server.listen(config.port, config.host, () => {
          server.off('error', reject);
          resolve();
        });
      });
      const addr = server.address();
      return { host: addr.address, port: addr.port };
    },
    async close() {
      holder.close();
      await new Promise((resolve) => {
        server.close(() => resolve());
        server.closeAllConnections?.();
      });
    },
  };
}

/** `node server/cli.mjs serve`: start, log one line, stop cleanly on SIGTERM / SIGINT. */
export async function startServer(config, { log = console } = {}) {
  const app = createDashboardServer(config, { log });
  const { host, port } = await app.listen();
  const d = describeConfig(config);
  const auth = config.authMode === 'tailscale'
    ? `tailscale (allow-list: ${d.allowed_users ? `${d.allowed_users} users` : 'any tailnet user'}, owners: ${d.owner_users})`
    : 'NONE (local testing only)';
  const cur = await readCurrent(config.dataDir).catch(() => null);
  log.info(`groov-cc: listening on http://${host.includes(':') ? `[${host}]` : host}:${port} · auth ${auth} · data ${config.dataDir} · config ${config.configDir} · snapshot ${cur ? cur.version : 'none yet'} · windsor key ${config.hasWindsorKey ? 'set' : 'missing (refresh button disabled)'}`);
  let stopping = false;
  const stop = (signal) => {
    if (stopping) return;
    stopping = true;
    log.info(`groov-cc: ${signal} received, stopping`);
    const timer = setTimeout(() => process.exit(0), 5000);
    timer.unref();
    app.close().then(() => process.exit(0));
  };
  process.on('SIGTERM', () => stop('SIGTERM'));
  process.on('SIGINT', () => stop('SIGINT'));
  return app;
}
