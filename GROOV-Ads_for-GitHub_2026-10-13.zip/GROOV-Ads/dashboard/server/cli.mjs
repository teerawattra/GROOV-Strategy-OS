#!/usr/bin/env node
// GROOV Command Center on a VPS: one command line for the server and the data jobs. Run from the package folder:
//
//   node server/cli.mjs serve                     start the dashboard on HOST:PORT (default 127.0.0.1:8787)
//   node server/cli.mjs refresh [--days N] [--force]
//   node server/cli.mjs backfill --from YYYY-MM-DD [--to YYYY-MM-DD] [--datasets a,b] [--force] [--no-snapshot]
//   node server/cli.mjs snapshot                  rebuild the snapshot from stored data (no Windsor calls)
//   node server/cli.mjs images                    save new ad creatives now
//   node server/cli.mjs status [--json]
//   node server/cli.mjs rollback [--to VERSION]   serve the previous snapshot (or VERSION)
//   node server/cli.mjs seed-creatives <dir>      copy a saved-creatives library into DATA_DIR/creatives
//   node server/cli.mjs build-static              regenerate /data/registry.js, learnings.js, modules.js from CONFIG_DIR
//
// Settings come from the environment (config/groov.env.example lists them); GROOV_ENV_FILE may name one more KEY=VALUE
// file, which never overrides variables already set. Exit codes: 0 ok · 1 failed · 2 usage or settings error ·
// 75 skipped because another job holds the lock (systemd: SuccessExitStatus=75).

import { realpathSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { DATASET_IDS } from '../lib/datasets.mjs';
import { ConfigError, cleanValue, loadConfig, loadEnvFile } from './config.mjs';
import { seedCreatives } from './images.mjs';
import { EXIT_SKIPPED, backfill, describeError, imagesOnly, rebuildSnapshot, refresh, withLock } from './refresh.mjs';
import { buildSnapshot, readCurrent, rollback } from './snapshot.mjs';
import { startServer } from './server.mjs';
import { buildStatic } from './static-data.mjs';
import { collectStatus, formatStatus } from './status.mjs';
import { createLogger, secretForms } from './util.mjs';

export const USAGE = `Usage: node server/cli.mjs <command> [options]

  serve                          start the dashboard (HOST:PORT, default 127.0.0.1:8787)
  refresh [--days N] [--force]   pull the last N complete days (default REFRESH_DAYS=28), rebuild the
                                 snapshot, save new creatives (the daily timer runs this)
  backfill --from YYYY-MM-DD [--to YYYY-MM-DD] [--datasets ${DATASET_IDS.join(',')}] [--force] [--no-snapshot]
                                 pull history in 7-day chunks; days already stored are skipped unless --force
                                 (--from defaults to BACKFILL_FROM, --to to yesterday)
  snapshot                       rebuild the snapshot from the stored raw data (no Windsor calls)
  images                         save creatives of ads that ran in the last 7 days
  status [--json]                stored data, snapshot versions, creatives, last run (no secrets)
  rollback [--to VERSION]        serve the previous snapshot version (or VERSION from status)
  seed-creatives <dir>           copy <dir>/meta/<ad_id>.jpg and <dir>/tiktok/<ad_id>.jpg into DATA_DIR/creatives
  build-static                   regenerate /data/registry.js, learnings.js and modules.js from CONFIG_DIR

Settings: environment variables (config/groov.env.example); GROOV_ENV_FILE may name an extra KEY=VALUE file.`;

const FLAGS = new Set(['force', 'json', 'no-snapshot', 'help']);
const ALLOWED = {
  serve: [], refresh: ['days', 'force'], backfill: ['from', 'to', 'datasets', 'force', 'no-snapshot'], snapshot: [], images: [],
  status: ['json'], rollback: ['to'], 'seed-creatives': [], 'build-static': [],
};

class UsageError extends Error {}

export function parseArgs(argv) {
  const [command, ...rest] = argv;
  const opts = { _: [] };
  for (let i = 0; i < rest.length; i++) {
    const arg = rest[i];
    if (arg === '-h') {
      opts.help = true;
      continue;
    }
    if (!arg.startsWith('--')) {
      opts._.push(arg);
      continue;
    }
    const eq = arg.indexOf('=');
    const name = eq === -1 ? arg.slice(2) : arg.slice(2, eq);
    if (FLAGS.has(name)) {
      opts[name] = true;
      continue;
    }
    const value = eq === -1 ? rest[++i] : arg.slice(eq + 1);
    if (value === undefined || value === '') throw new UsageError(`--${name} needs a value`);
    opts[name] = value;
  }
  return { command, opts };
}

function checkOptions(command, opts) {
  const allowed = ALLOWED[command];
  if (!allowed) throw new UsageError(`Unknown command "${command}".`);
  for (const key of Object.keys(opts)) {
    if (key === '_' || key === 'help') continue;
    if (!allowed.includes(key)) throw new UsageError(`${command} does not take --${key}.`);
  }
  const positional = command === 'seed-creatives' ? 1 : 0;
  if (opts._.length !== positional) {
    throw new UsageError(command === 'seed-creatives' ? 'seed-creatives needs exactly one folder, e.g. seed/creatives' : `${command} takes no arguments other than options.`);
  }
}

const exitFor = (state) => (state === 'ok' ? 0 : state === 'skipped' ? EXIT_SKIPPED : 1);

/**
 * Run one command. Returns the exit code (the caller sets process.exitCode), except `serve`, which keeps running.
 * @param {string[]} argv
 * @param {{ env?: object, cwd?: string, log?: object, out?: (s: string) => void, now?: Date, fetchImpl?: typeof fetch,
 *   imageFetchImpl?: typeof fetch, sleep?: Function }} [io]  (tests: a mock Windsor, no image downloads, no waiting)
 */
export async function main(argv, io = {}) {
  const env = io.env ?? process.env;
  const out = io.out ?? ((s) => process.stdout.write(`${s}\n`));
  let parsed;
  try {
    parsed = parseArgs(argv);
    if (!parsed.command || parsed.command === 'help' || parsed.command === '--help' || parsed.command === '-h') {
      out(USAGE);
      return parsed.command ? 0 : 2;
    }
    checkOptions(parsed.command, parsed.opts);
    if (parsed.opts.help) {
      out(USAGE);
      return 0;
    }
  } catch (err) {
    (io.log?.error ?? console.error)(`${err.message}\n\n${USAGE}`);
    return 2;
  }
  const { command, opts } = parsed;

  let config;
  try {
    const envFile = cleanValue(env.GROOV_ENV_FILE);
    if (envFile) loadEnvFile(resolve(io.cwd ?? process.cwd(), envFile), env);
    config = loadConfig({ env, cwd: io.cwd ?? process.cwd() });
  } catch (err) {
    (io.log?.error ?? console.error)(`groov-cc: ${err instanceof ConfigError ? err.message : describeError(err)}`);
    return 2;
  }
  const log = io.log ?? createLogger({ secrets: secretForms(config.windsorKey) });
  const now = io.now ?? new Date();
  const jobOptions = {
    now, log, ...(io.fetchImpl ? { fetchImpl: io.fetchImpl } : {}), ...(io.imageFetchImpl ? { imageFetchImpl: io.imageFetchImpl } : {}), ...(io.sleep ? { sleep: io.sleep } : {}),
  };

  try {
    switch (command) {
      case 'serve': {
        await startServer(config, { log });
        return null; // keeps running
      }
      case 'refresh': {
        let days;
        if (opts.days !== undefined) {
          if (!/^\d+$/.test(opts.days) || +opts.days < 1 || +opts.days > 400) throw new UsageError('--days must be a whole number from 1 to 400');
          days = +opts.days;
        }
        const status = await refresh(config, { ...jobOptions, days, force: Boolean(opts.force), trigger: env.GROOV_TRIGGER === 'schedule' ? 'schedule' : 'cli' });
        return exitFor(status.state);
      }
      case 'backfill': {
        const datasets = opts.datasets ? opts.datasets.split(',').map((s) => s.trim()).filter(Boolean) : null;
        const status = await backfill(config, { ...jobOptions, from: opts.from, to: opts.to, datasets, force: Boolean(opts.force), snapshot: !opts['no-snapshot'] });
        return status.usage ? 2 : exitFor(status.state);
      }
      case 'snapshot': {
        const r = await rebuildSnapshot(config, { now, log });
        if (r.skipped) {
          log.info('snapshot: skipped, a refresh or backfill is running (it builds a snapshot when it finishes).');
          return EXIT_SKIPPED;
        }
        return 0;
      }
      case 'images': {
        const r = await imagesOnly(config, { now, log, ...(io.imageFetchImpl ? { fetchImpl: io.imageFetchImpl } : {}) });
        if (r.skipped) {
          log.info('images: skipped, a refresh or backfill is running (it saves images when it finishes).');
          return EXIT_SKIPPED;
        }
        return 0;
      }
      case 'status': {
        const s = await collectStatus(config, { now });
        out(opts.json ? JSON.stringify(s, null, 1) : formatStatus(s));
        return 0;
      }
      case 'rollback': {
        const r = await withLock(config, 'rollback', () => rollback(config.dataDir, { to: opts.to ?? null, now }));
        if (r.skipped) {
          log.info('rollback: a refresh or backfill is running; try again when it has finished.');
          return EXIT_SKIPPED;
        }
        log.info(`rollback: now serving ${r.value.to} (was ${r.value.from}). The server picks it up within seconds; the next refresh builds a new version again.`);
        return 0;
      }
      case 'seed-creatives': {
        const dir = resolve(io.cwd ?? process.cwd(), opts._[0]);
        const r = await withLock(config, 'seed-creatives', async () => {
          const counts = await seedCreatives(config, dir, { log, now });
          if (counts.copied && (await readCurrent(config.dataDir))) await buildSnapshot(config, { now, log, reason: 'seed-creatives' });
          return counts;
        });
        if (r.skipped) {
          log.info('seed-creatives: a refresh or backfill is running; try again when it has finished.');
          return EXIT_SKIPPED;
        }
        if (r.value.found === 0) {
          log.error(`seed-creatives: no images found under ${dir} (expected ${dir}/meta/<ad_id>.jpg and ${dir}/tiktok/<ad_id>.jpg).`);
          return 1;
        }
        return r.value.failed ? 1 : 0;
      }
      case 'build-static': {
        const r = await buildStatic(config, { log });
        if (r.output) out(r.output);
        log.info(`build-static: registry ${r.registry}, learnings ${r.learnings}, modules ${r.modules}${r.warnings.length ? ` · ${r.warnings.length} warning(s)` : ''}`);
        return r.ok ? 0 : 1;
      }
      default:
        throw new UsageError(`Unknown command "${command}".`);
    }
  } catch (err) {
    if (err instanceof UsageError) {
      log.error(`${err.message}\n\n${USAGE}`);
      return 2;
    }
    log.error(`${command}: ${describeError(err, secretForms(config.windsorKey))}`);
    return 1;
  }
}

// Run only when executed directly (not when imported by the tests).
if (process.argv[1] && realpathSync(resolve(process.argv[1])) === realpathSync(fileURLToPath(import.meta.url))) {
  main(process.argv.slice(2)).then((code) => {
    if (code !== null && code !== undefined) process.exitCode = code;
  }, (err) => {
    console.error(`groov-cc: ${describeError(err)}`);
    process.exitCode = 1;
  });
}
