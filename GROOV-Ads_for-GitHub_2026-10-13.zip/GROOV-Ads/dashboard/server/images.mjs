// Saved ad creatives on disk, the daily image job and the one-time seed.
//
//   data/creatives/<meta|tiktok>/<ad_id>.<jpg|png|webp|gif|avif>   one file per ad, the original bytes
//   data/creatives/index.json                                       content type, size, when and from what day
//
// Meta `image_url` / TikTok `video_thumbnail_url` links expire within days, so after each refresh the job saves the
// image of every Meta / TikTok ad that has a link in the last 7 days and no saved file yet. Downloading reuses
// lib/creatives-job.mjs unchanged (https only, public hosts, 15 s timeout, 5 MB cap, the bytes must really be a
// JPEG / PNG / WebP / GIF / AVIF). Images are stored as downloaded: converting them to JPEG would need an image library,
// and the package has no dependencies, so the file keeps its real extension and the index records its type.
//
// The folder (not the index) is the truth about what is saved: listSavedCreatives() scans it, so an interrupted run
// or a hand-copied file is picked up as is. Logs carry counts only; image links hold signed tokens and are never logged.

import { mkdir, readdir, readFile, rm, stat } from 'node:fs/promises';
import { join } from 'node:path';
import { IMAGE_CONCURRENCY, LOOKBACK_DAYS, pickImageCandidates, runImageJob, sniffImageType } from '../lib/creatives-job.mjs';
import { readRows } from './store.mjs';
import { addDays, atomicWrite, readJsonFile, todayIn, writeJsonFile } from './util.mjs';

export const CREATIVE_PLATFORMS = Object.freeze(['meta', 'tiktok']);
/** Raster types we keep, and the file extension each gets. */
export const IMAGE_TYPES = Object.freeze({ 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp', 'image/gif': 'gif', 'image/avif': 'avif' });
const EXTENSIONS = Object.freeze(['jpg', 'png', 'webp', 'gif', 'avif', 'jpeg']);
const EXT_TYPE = Object.freeze({ jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', webp: 'image/webp', gif: 'image/gif', avif: 'image/avif' });
const FILE_RE = /^(\d{1,30})\.(jpg|jpeg|png|webp|gif|avif)$/;
const SEED_RE = /^(\d{1,30})\.(jpe?g|png|webp|gif|avif)$/i;
/** Files of 100 bytes or less are stubs, not images (the same rule as the library's own loader). */
const MIN_BYTES = 101;
const JOB_BUDGET_MS = 15 * 60_000;

export const creativesRoot = (dataDir) => join(dataDir, 'creatives');
const indexFile = (dataDir) => join(creativesRoot(dataDir), 'index.json');

/** Content type implied by a stored file's extension. */
export const typeOfExtension = (ext) => EXT_TYPE[String(ext).toLowerCase()] ?? null;

/**
 * Every saved creative: `saved` in normalize()'s format ("meta:<ad_id>"), per-platform counts, and the files.
 * @returns {Promise<{saved: Set<string>, counts: {meta: number, tiktok: number}, entries: Map<string, {platform, id, file, bytes}>}>}
 */
export async function listSavedCreatives(dataDir) {
  const saved = new Set();
  const counts = { meta: 0, tiktok: 0 };
  const entries = new Map();
  for (const platform of CREATIVE_PLATFORMS) {
    const folder = join(creativesRoot(dataDir), platform);
    let names;
    try {
      names = await readdir(folder);
    } catch (err) {
      if (err.code === 'ENOENT') continue;
      throw err;
    }
    for (const name of names.sort()) {
      const m = FILE_RE.exec(name);
      if (!m) continue;
      const key = `${platform}:${m[1]}`;
      if (saved.has(key)) continue;
      let size = 0;
      try {
        size = (await stat(join(folder, name))).size;
      } catch {
        continue;
      }
      if (size < MIN_BYTES) continue;
      saved.add(key);
      counts[platform]++;
      entries.set(key, { platform, id: m[1], file: join(folder, name), bytes: size });
    }
  }
  return { saved, counts, entries };
}

/** The saved file of one ad, or null. `platform` must be meta / tiktok and `id` digits (checked by the caller too). */
export async function findCreative(dataDir, platform, id) {
  if (!CREATIVE_PLATFORMS.includes(platform) || !/^\d{1,30}$/.test(String(id))) return null;
  for (const ext of EXTENSIONS) {
    const path = join(creativesRoot(dataDir), platform, `${id}.${ext}`);
    try {
      const st = await stat(path);
      if (st.isFile() && st.size >= MIN_BYTES) return { path, ext, size: st.size, mtimeMs: st.mtimeMs };
    } catch {
      // try the next extension
    }
  }
  return null;
}

export async function readCreativesIndex(dataDir) {
  const index = await readJsonFile(indexFile(dataDir)).catch(() => null);
  return index && typeof index === 'object' && index.files && typeof index.files === 'object' ? index : { schema: 1, files: {} };
}

/** A store for lib/creatives-job.mjs runImageJob: set("meta/<id>", bytes, { metadata }) writes the file atomically. */
export function folderStore(dataDir, index) {
  return {
    async set(key, value, { metadata = {} } = {}) {
      const m = /^(meta|tiktok)\/(\d{1,30})$/.exec(String(key));
      if (!m) throw new Error('invalid creative key');
      const ext = IMAGE_TYPES[metadata.contentType];
      if (!ext) throw new Error('not a raster image type');
      const bytes = Buffer.from(value instanceof ArrayBuffer ? new Uint8Array(value) : value);
      const folder = join(creativesRoot(dataDir), m[1]);
      await mkdir(folder, { recursive: true });
      for (const other of EXTENSIONS) if (other !== ext) await rm(join(folder, `${m[2]}.${other}`), { force: true });
      await atomicWrite(join(folder, `${m[2]}.${ext}`), bytes);
      index.files[key] = {
        file: `${m[1]}/${m[2]}.${ext}`, content_type: metadata.contentType, bytes: bytes.length,
        saved_at: metadata.savedAt ?? new Date().toISOString(), source_date: metadata.sourceDate ?? null, source: metadata.source ?? 'refresh',
      };
      return { modified: true };
    },
  };
}

/**
 * Save the creatives of ads that delivered in the last 7 days (report timezone) and have none yet. Never throws for
 * a single image; returns lib/creatives-job.mjs counts ({ candidates, attempted, saved, failed, deferred, bytes,
 * failures: { reason: n } }) and the newly saved keys ("meta:<id>").
 */
export async function runImages(config, { now = new Date(), clock = Date.now, fetchImpl = globalThis.fetch, log = console, budgetMs = JOB_BUDGET_MS, concurrency = IMAGE_CONCURRENCY } = {}) {
  const since = addDays(todayIn(config.tzReport, now), -LOOKBACK_DAYS);
  const sheets = {};
  for (const platform of CREATIVE_PLATFORMS) sheets[platform] = await readRows(config.dataDir, platform, { from: since });
  const { saved } = await listSavedCreatives(config.dataDir);
  const candidates = pickImageCandidates(sheets, { saved, since });
  const index = await readCreativesIndex(config.dataDir);
  const store = folderStore(config.dataDir, index);
  const started = clock();
  const { counts, savedKeys } = await runImageJob({ candidates, store, fetchImpl, clock, deadline: started + budgetMs, concurrency });
  if (savedKeys.length) {
    index.updated_at = new Date(clock()).toISOString();
    await writeJsonFile(indexFile(config.dataDir), index);
  }
  log.info(`images: since ${since}: ${counts.candidates} to fetch, ${counts.saved} saved, ${counts.failed} failed${counts.failed ? ` ${JSON.stringify(counts.failures)}` : ''}, ${counts.deferred} left for the next run`);
  return { counts, savedKeys, since };
}

/**
 * Copy a creative library (<srcDir>/meta/<ad_id>.jpg, <srcDir>/tiktok/<ad_id>.jpg, …) into data/creatives. Files that
 * are 100 bytes or less or are not really images are skipped; ads that already have a file are left alone. The
 * extension follows the real image type.
 */
export async function seedCreatives(config, srcDir, { log = console, now = new Date() } = {}) {
  const counts = { found: 0, copied: 0, already: 0, invalid: 0, failed: 0, byPlatform: { meta: 0, tiktok: 0 }, copiedByPlatform: { meta: 0, tiktok: 0 } };
  const { saved } = await listSavedCreatives(config.dataDir);
  const index = await readCreativesIndex(config.dataDir);
  let any = false;
  for (const platform of CREATIVE_PLATFORMS) {
    const folder = join(srcDir, platform);
    let names;
    try {
      names = (await readdir(folder)).sort();
    } catch (err) {
      if (err.code === 'ENOENT') continue;
      throw err;
    }
    for (const name of names) {
      const m = SEED_RE.exec(name);
      if (!m) continue;
      counts.found++;
      counts.byPlatform[platform]++;
      const key = `${platform}:${m[1]}`;
      try {
        const bytes = await readFile(join(folder, name));
        const type = bytes.length >= MIN_BYTES ? sniffImageType(bytes) : null;
        if (!type || !IMAGE_TYPES[type]) {
          counts.invalid++;
          continue;
        }
        if (saved.has(key)) {
          counts.already++;
          continue;
        }
        const ext = IMAGE_TYPES[type];
        await atomicWrite(join(creativesRoot(config.dataDir), platform, `${m[1]}.${ext}`), bytes);
        index.files[`${platform}/${m[1]}`] = { file: `${platform}/${m[1]}.${ext}`, content_type: type, bytes: bytes.length, saved_at: now.toISOString(), source_date: null, source: 'seed' };
        saved.add(key);
        counts.copied++;
        counts.copiedByPlatform[platform]++;
        any = true;
      } catch {
        counts.failed++;
      }
    }
  }
  if (any) {
    index.updated_at = now.toISOString();
    await writeJsonFile(indexFile(config.dataDir), index);
  }
  log.info(`seed-creatives: ${counts.found} files in the library (meta ${counts.byPlatform.meta}, tiktok ${counts.byPlatform.tiktok}) · ${counts.copied} copied · ${counts.already} already saved · ${counts.invalid} skipped (not an image) · ${counts.failed} failed`);
  return counts;
}

/** Content type of a stored file from its bytes (only the raster types are trusted). */
export function sniffStored(bytes) {
  const type = sniffImageType(bytes);
  return type && IMAGE_TYPES[type] ? type : null;
}
