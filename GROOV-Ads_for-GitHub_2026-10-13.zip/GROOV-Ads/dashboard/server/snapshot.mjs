// Normalised snapshots: raw partitions -> lib/normalize.mjs + lib/breakdowns.mjs -> one immutable folder per version,
// and data/current.json, the pointer the server follows.
//
//   data/snapshots/<version>/manifest.json        what is inside (counts, dates, warnings, sources, files)
//   data/snapshots/<version>/meta.json            the /api/meta payload, served as stored
//   data/snapshots/<version>/dataset.json.gz      the whole normalize() dataset (/api/rows slices it)
//   data/snapshots/<version>/monthly.json.gz      the /api/monthly payload, served as stored
//   data/snapshots/<version>/breakdowns.json.gz   the normaliseBreakdowns() dataset (only when a breakdown has rows)
//   data/current.json                             { version, previous, updated_at, reason }
//
// A version folder is written under a temp name and renamed into place when complete; current.json is replaced
// atomically (temp file + rename) only after that, so the server never sees half a version and a failed build leaves
// the previous snapshot serving. The last 3 versions are kept (plus whatever current.json points at).
//
// The payloads are exactly what the Netlify functions serve: /api/meta = { ...meta(dataset), breakdowns: health },
// /api/monthly = monthly(dataset); /api/rows and /api/breakdowns slice the stored datasets with sliceRows /
// sliceBreakdowns. The tests compare them byte for byte with the normalisers run directly on the sample CSVs.

import { mkdir, readdir, readFile, rename, rm, stat } from 'node:fs/promises';
import { open } from 'node:fs/promises';
import { randomBytes } from 'node:crypto';
import { join } from 'node:path';
import { gunzipSync, gzipSync } from 'node:zlib';
import { BREAKDOWN_KINDS, breakdownsHealth, normaliseBreakdowns } from '../lib/breakdowns.mjs';
import { BREAKDOWN_DATASETS, DATASETS, MAIN_DATASETS, normaliserInputs } from '../lib/datasets.mjs';
import { meta as metaPayloadOf, monthly as monthlyPayloadOf, normalize, PLATFORMS } from '../lib/normalize.mjs';
import { listSavedCreatives } from './images.mjs';
import { listDates, readRows } from './store.mjs';
import { atomicWrite, readJsonFile } from './util.mjs';

export const KEEP_VERSIONS = 3;
const VERSION_RE = /^(\d{8}T\d{6}Z)-[0-9a-f]{6}$/;
const TEMP_DIR_RE = /^\.tmp-/;
const LOW_COVERAGE = 0.9;

export class SnapshotError extends Error {
  constructor(message) {
    super(message);
    this.name = 'SnapshotError';
  }
}

export const snapshotsRoot = (dataDir) => join(dataDir, 'snapshots');
export const currentFile = (dataDir) => join(dataDir, 'current.json');
export const isVersionId = (v) => typeof v === 'string' && VERSION_RE.test(v);

/** "20261013T000512Z-a1b2c3": sortable, carries its creation time, unique per build. */
export function newVersionId(now = new Date()) {
  const stamp = now.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}Z$/, 'Z');
  return `${stamp}-${randomBytes(3).toString('hex')}`;
}

/** Creation time (ms) encoded in a version id, or null. */
export function versionTime(version) {
  const m = VERSION_RE.exec(version ?? '');
  if (!m) return null;
  const s = m[1];
  return Date.UTC(+s.slice(0, 4), +s.slice(4, 6) - 1, +s.slice(6, 8), +s.slice(9, 11), +s.slice(11, 13), +s.slice(13, 15));
}

/**
 * A version id that sorts after every version already on disk, so "newest" by name is always "built last" (two builds
 * in the same second, e.g. the refresh and its image pass, would otherwise tie and sort by their random suffix).
 */
async function nextVersionId(root, now) {
  let names = [];
  try {
    names = (await readdir(root)).filter(isVersionId).sort();
  } catch {
    // no snapshots yet
  }
  const latest = names.length ? versionTime(names[names.length - 1]) : null;
  const t = Math.floor(now.getTime() / 1000) * 1000;
  return newVersionId(new Date(latest !== null && latest >= t ? latest + 1000 : t));
}

async function writeSynced(path, data) {
  const handle = await open(path, 'w', 0o644);
  try {
    await handle.writeFile(data);
    await handle.sync();
  } finally {
    await handle.close();
  }
}

// ---------------------------------------------------------------------------------------------------------
// Warnings (plain language, for the refresh status and `status`)
// ---------------------------------------------------------------------------------------------------------

function mainWarnings(dataset) {
  const out = [];
  for (const p of PLATFORMS) {
    const d = dataset.diagnostics?.[p];
    const h = dataset.health?.sheets?.[p];
    if (!d || !h) continue;
    if (h.columns_missing.length) out.push(`${p}: Windsor did not return these fields: ${h.columns_missing.join(', ')}. Check them against docs/DATA_CONTRACT.md §1.`);
    const skipped = d.skipped.bad_date + d.skipped.no_account + d.skipped.no_campaign;
    if (skipped) out.push(`${p}: ${skipped} rows had no usable date, account or campaign id and were skipped.`);
    if (d.duplicates_conflicting) out.push(`${p}: ${d.duplicates_conflicting} rows were sent twice for the same day and ${p === 'google' ? 'ad group' : 'ad'} with different numbers; the later one is used.`);
  }
  return out;
}

function breakdownWarningsVps(bds, health) {
  const out = [];
  for (const [i, kind] of BREAKDOWN_KINDS.entries()) {
    const id = BREAKDOWN_DATASETS[i];
    const h = bds.health[kind];
    const d = bds.diagnostics[kind];
    const s = health[kind];
    if (h.columns_missing.length) out.push(`${id}: Windsor did not return these fields: ${h.columns_missing.join(', ')}.${h.ignored ? ' The dataset was ignored.' : ''}`);
    if (d.skipped.no_adset) out.push(`${id}: ${d.skipped.no_adset} rows have no adset_id and were skipped.`);
    if (d.duplicates_conflicting) out.push(`${id}: ${d.duplicates_conflicting} rows were sent twice for the same day and segment with different numbers; the later one is used.`);
    if (s.available && s.all_meta_spend_share_last_28d !== null && s.all_meta_spend_share_last_28d < LOW_COVERAGE) {
      out.push(`${id}: covers only ${Math.round(s.all_meta_spend_share_last_28d * 1000) / 10}% of the Meta spend of the last 28 days (some accounts or days are missing from the breakdown pull).`);
    }
  }
  return out;
}

// ---------------------------------------------------------------------------------------------------------
// Build
// ---------------------------------------------------------------------------------------------------------

/** First / last stored day, number of stored days and rows of each dataset (from rows already read). */
async function describeSources(dataDir, rowsByDataset) {
  const out = {};
  for (const id of Object.keys(rowsByDataset)) {
    const dates = await listDates(dataDir, id);
    out[id] = { partitions: dates.length, first_date: dates[0] ?? null, last_date: dates[dates.length - 1] ?? null, rows: rowsByDataset[id].length };
  }
  return out;
}

/** Usable fact rows per platform (after de-duplication and skipped rows). */
function factRowsByPlatform(dataset) {
  const out = Object.fromEntries(PLATFORMS.map((p) => [p, 0]));
  for (const r of dataset.rows) {
    const key = dataset.campaigns[r[1]]?.key ?? '';
    const platform = key.slice(0, key.indexOf(':'));
    if (platform in out) out[platform]++;
  }
  return out;
}

/**
 * Compute everything a snapshot holds from the raw partitions, without writing anything.
 * @param {object} config
 * @param {{ now?: Date, breakdownErrors?: Record<string,string>, extraWarnings?: string[] }} [options]
 *   breakdownErrors: keyed by dataset id (meta_placements / meta_audience), shown as `error` in /api/meta health
 */
export async function computeSnapshot(config, { now = new Date(), breakdownErrors = {}, extraWarnings = [] } = {}) {
  const ids = config.enableBreakdowns ? [...MAIN_DATASETS, ...BREAKDOWN_DATASETS] : [...MAIN_DATASETS];
  const rowsByDataset = {};
  for (const id of ids) rowsByDataset[id] = await readRows(config.dataDir, id);
  const inputs = normaliserInputs(rowsByDataset);
  const creatives = await listSavedCreatives(config.dataDir);

  const dataset = normalize(inputs.main, { savedCreatives: creatives.saved, mode: 'live', now });

  // The optional breakdowns: `configured` is the ENABLE_BREAKDOWNS switch, `error` a failed pull (keyed by the
  // normaliser's input names, as breakdownsHealth expects).
  const configured = {};
  const errors = {};
  for (const id of BREAKDOWN_DATASETS) {
    configured[DATASETS[id].input] = config.enableBreakdowns;
    if (config.enableBreakdowns && breakdownErrors[id]) errors[DATASETS[id].input] = breakdownErrors[id];
  }
  let bds;
  try {
    bds = normaliseBreakdowns(config.enableBreakdowns ? inputs.breakdowns : {}, { mode: 'live', now, main: dataset });
  } catch (err) {
    const why = `The breakdown data could not be processed (${err?.name ?? 'Error'}: ${String(err?.message ?? err).slice(0, 200)}).`;
    for (const id of BREAKDOWN_DATASETS) if (config.enableBreakdowns && !errors[DATASETS[id].input]) errors[DATASETS[id].input] = why;
    bds = normaliseBreakdowns({}, { mode: 'live', now, main: dataset });
  }
  const health = breakdownsHealth(bds, dataset, { configured, errors });
  const storeBreakdowns = BREAKDOWN_KINDS.some((k) => bds.available[k]);

  const warnings = [...mainWarnings(dataset), ...(config.enableBreakdowns ? breakdownWarningsVps(bds, health) : []), ...extraWarnings];
  const metaPayload = { ...metaPayloadOf(dataset), breakdowns: health };
  const monthlyPayload = monthlyPayloadOf(dataset);
  return {
    dataset, bds: storeBreakdowns ? bds : null, metaPayload, monthlyPayload, warnings,
    sources: await describeSources(config.dataDir, rowsByDataset),
    creatives: creatives.counts,
    factRows: factRowsByPlatform(dataset),
  };
}

/**
 * Build a new snapshot version from the raw partitions and (by default) point data/current.json at it.
 * Throws on failure; the previous snapshot keeps serving.
 * @returns {Promise<object>} the version's manifest
 */
export async function buildSnapshot(config, { now = new Date(), log = console, breakdownErrors = {}, extraWarnings = [], reason = 'refresh', flip = true } = {}) {
  const started = Date.now();
  const snap = await computeSnapshot(config, { now, breakdownErrors, extraWarnings });
  const root = snapshotsRoot(config.dataDir);
  await mkdir(root, { recursive: true });
  const version = await nextVersionId(root, now);
  const tmp = join(root, `.tmp-${version}`);
  await rm(tmp, { recursive: true, force: true });
  await mkdir(tmp, { recursive: true });

  try {
    const datasetJson = JSON.stringify(snap.dataset);
    const datasetGz = gzipSync(datasetJson, { level: 6 });
    const monthlyJson = JSON.stringify(snap.monthlyPayload);
    const monthlyGz = gzipSync(monthlyJson, { level: 6 });
    const metaJson = JSON.stringify(snap.metaPayload);
    const files = { meta: 'meta.json', dataset: 'dataset.json.gz', monthly: 'monthly.json.gz', breakdowns: null };
    const sizes = { dataset_json: Buffer.byteLength(datasetJson), dataset_gz: datasetGz.length, monthly_json: Buffer.byteLength(monthlyJson), meta_json: Buffer.byteLength(metaJson) };
    await writeSynced(join(tmp, files.dataset), datasetGz);
    await writeSynced(join(tmp, files.monthly), monthlyGz);
    await writeSynced(join(tmp, files.meta), metaJson);
    let breakdownRows = null;
    if (snap.bds) {
      const bdJson = JSON.stringify(snap.bds);
      const bdGz = gzipSync(bdJson, { level: 6 });
      files.breakdowns = 'breakdowns.json.gz';
      sizes.breakdowns_json = Buffer.byteLength(bdJson);
      sizes.breakdowns_gz = bdGz.length;
      breakdownRows = { placement: snap.bds.placement_rows.length, audience: snap.bds.audience_rows.length };
      await writeSynced(join(tmp, files.breakdowns), bdGz);
    }
    const manifest = {
      schema: 1,
      version,
      created_at: now.toISOString(),
      built_in_ms: 0,
      generated_at: snap.dataset.generated_at,
      mode: snap.dataset.mode,
      reason,
      data_through: snap.metaPayload.data_through,
      history_from: snap.metaPayload.history_from,
      rows: snap.dataset.rows.length,
      fact_rows: snap.factRows,
      breakdown_rows: breakdownRows,
      breakdowns_enabled: config.enableBreakdowns,
      sources: snap.sources,
      creatives: snap.creatives,
      warnings: snap.warnings,
      files,
      sizes,
    };
    manifest.built_in_ms = Date.now() - started;
    await writeSynced(join(tmp, 'manifest.json'), `${JSON.stringify(manifest, null, 1)}\n`);
    await rename(tmp, join(root, version));
    if (flip) {
      await setCurrent(config.dataDir, version, { reason });
      await pruneSnapshots(config.dataDir, { now });
    }
    log.info(`snapshot: ${version} built in ${(manifest.built_in_ms / 1000).toFixed(1)} s · data through ${manifest.data_through ?? 'none'} · ${manifest.rows} fact rows${breakdownRows ? ` · breakdowns ${breakdownRows.placement} + ${breakdownRows.audience} rows` : ''} · ${manifest.warnings.length} warnings`);
    return manifest;
  } catch (err) {
    await rm(tmp, { recursive: true, force: true }).catch(() => {});
    throw err;
  }
}

// ---------------------------------------------------------------------------------------------------------
// current.json, versions, pruning, rollback
// ---------------------------------------------------------------------------------------------------------

/** { version, previous, updated_at, reason } or null before the first snapshot. */
export async function readCurrent(dataDir) {
  const cur = await readJsonFile(currentFile(dataDir));
  return cur && isVersionId(cur.version) ? cur : null;
}

/** Point data/current.json at `version` (atomic replace). The server picks the change up by itself. */
export async function setCurrent(dataDir, version, { reason = 'refresh', now = new Date() } = {}) {
  if (!isVersionId(version)) throw new SnapshotError(`Not a snapshot version: "${String(version).slice(0, 60)}".`);
  const manifest = await readManifest(dataDir, version);
  if (!manifest) throw new SnapshotError(`Snapshot ${version} does not exist or is incomplete.`);
  const prev = await readCurrent(dataDir).catch(() => null);
  const value = { schema: 1, version, previous: prev && prev.version !== version ? prev.version : (prev?.previous ?? null), updated_at: now.toISOString(), reason };
  await atomicWrite(currentFile(dataDir), `${JSON.stringify(value, null, 1)}\n`);
  return value;
}

export async function readManifest(dataDir, version) {
  if (!isVersionId(version)) return null;
  try {
    return await readJsonFile(join(snapshotsRoot(dataDir), version, 'manifest.json'));
  } catch {
    return null;
  }
}

/** Complete versions (with a manifest), newest first. */
export async function listVersions(dataDir) {
  let names;
  try {
    names = await readdir(snapshotsRoot(dataDir));
  } catch (err) {
    if (err.code === 'ENOENT') return [];
    throw err;
  }
  const out = [];
  for (const name of names.filter(isVersionId).sort().reverse()) {
    const manifest = await readManifest(dataDir, name);
    if (manifest) out.push({ version: name, manifest });
  }
  return out;
}

/**
 * Delete versions beyond the newest `keep` (never the one current.json points at, nor its `previous`), plus temp
 * folders a crashed build left behind (older than an hour).
 */
export async function pruneSnapshots(dataDir, { keep = KEEP_VERSIONS, now = new Date() } = {}) {
  const root = snapshotsRoot(dataDir);
  let names;
  try {
    names = await readdir(root);
  } catch {
    return 0;
  }
  const cur = await readCurrent(dataDir).catch(() => null);
  const protect = new Set([cur?.version, cur?.previous].filter(Boolean));
  const versions = names.filter(isVersionId).sort().reverse();
  let removed = 0;
  for (const v of versions.slice(keep)) {
    if (protect.has(v)) continue;
    await rm(join(root, v), { recursive: true, force: true });
    removed++;
  }
  for (const name of names.filter((n) => TEMP_DIR_RE.test(n))) {
    try {
      if (now.getTime() - (await stat(join(root, name))).mtimeMs > 3_600_000) {
        await rm(join(root, name), { recursive: true, force: true });
        removed++;
      }
    } catch {
      // gone meanwhile
    }
  }
  return removed;
}

/**
 * Serve an older snapshot: `to` (a version id) or, by default, the newest version older than the current one.
 * @returns {Promise<{from: string, to: string}>}
 */
export async function rollback(dataDir, { to = null, now = new Date() } = {}) {
  const cur = await readCurrent(dataDir);
  if (!cur) throw new SnapshotError('No snapshot is being served yet, so there is nothing to roll back.');
  const versions = await listVersions(dataDir);
  let target;
  if (to) {
    target = versions.find((v) => v.version === to);
    if (!target) throw new SnapshotError(`Snapshot ${to} is not on disk. Run "node server/cli.mjs status" to see the versions kept.`);
  } else {
    target = versions.find((v) => v.version < cur.version);
    if (!target) throw new SnapshotError('There is no older snapshot to roll back to.');
  }
  if (target.version === cur.version) throw new SnapshotError(`Snapshot ${target.version} is already being served.`);
  await setCurrent(dataDir, target.version, { reason: 'rollback', now });
  return { from: cur.version, to: target.version };
}

// ---------------------------------------------------------------------------------------------------------
// Loading (server)
// ---------------------------------------------------------------------------------------------------------

/** Everything the API serves for one version. Throws a SnapshotError when a file is missing or damaged. */
export async function loadSnapshot(dataDir, version) {
  const dir = join(snapshotsRoot(dataDir), version);
  const manifest = await readManifest(dataDir, version);
  if (!manifest) throw new SnapshotError(`Snapshot ${version} has no manifest.`);
  const read = async (name) => {
    try {
      return await readFile(join(dir, name));
    } catch {
      throw new SnapshotError(`Snapshot ${version} is missing ${name}.`);
    }
  };
  const gunzipJsonText = (buf, name) => {
    try {
      return gunzipSync(buf).toString('utf8');
    } catch {
      throw new SnapshotError(`Snapshot ${version}: ${name} is damaged.`);
    }
  };
  const files = manifest.files ?? {};
  const metaText = (await read(files.meta ?? 'meta.json')).toString('utf8');
  const monthlyText = gunzipJsonText(await read(files.monthly ?? 'monthly.json.gz'), 'monthly');
  const dataset = JSON.parse(gunzipJsonText(await read(files.dataset ?? 'dataset.json.gz'), 'dataset'));
  const bds = files.breakdowns ? JSON.parse(gunzipJsonText(await read(files.breakdowns), 'breakdowns')) : null;
  return { version, manifest, metaText, meta: JSON.parse(metaText), monthlyText, dataset, bds };
}
