// Raw Windsor data on disk: one gzip file per dataset and day.
//
//   data/raw/<dataset>/<YYYY>/<YYYY-MM-DD>.json.gz
//   { "schema": 1, "dataset": "meta", "date": "2026-09-14", "connector": "facebook", "fetched_at": "…",
//     "fields": [...], "rows_count": 183, "dropped_zero_spend": 0, "rows": [ …exactly as Windsor returned them… ] }
//
// - A day's file holds every row Windsor returned for that day (only the breakdown datasets drop rows with spend <= 0,
//   the contract's export filter). A day with no rows still gets a file, so "pulled, nothing there" and "never
//   pulled" stay distinguishable (status, backfill resume).
// - Files are written to a temp name and renamed into place, so a reader never sees half a file and a crash leaves
//   the previous file untouched.
// - Nothing here edits rows: fixing data means pulling the day again (backfill --force).

import { mkdir, readdir, readFile, rm, stat } from 'node:fs/promises';
import { join } from 'node:path';
import { gunzipSync, gzipSync } from 'node:zlib';
import { DATASETS, DATE_FIELD, SPEND_FIELD } from '../lib/datasets.mjs';
import { sheetHelpers } from '../lib/normalize.mjs';
import { atomicWrite, isIsoDay, mapLimit } from './util.mjs';

const { parseDate, num } = sheetHelpers;
const FILE_RE = /^(\d{4}-\d{2}-\d{2})\.json\.gz$/;
const YEAR_RE = /^\d{4}$/;
const READ_CONCURRENCY = 8;

export class StoreError extends Error {
  constructor(message) {
    super(message);
    this.name = 'StoreError';
  }
}

function checkDataset(dataset) {
  if (!Object.prototype.hasOwnProperty.call(DATASETS, dataset)) throw new StoreError(`Unknown dataset "${dataset}".`);
}
function checkDate(date) {
  if (!isIsoDay(date)) throw new StoreError(`Not a date: "${String(date).slice(0, 40)}" (expected YYYY-MM-DD).`);
}

export const rawRoot = (dataDir) => join(dataDir, 'raw');
export const datasetDir = (dataDir, dataset) => join(rawRoot(dataDir), dataset);

/** data/raw/<dataset>/<YYYY>/<YYYY-MM-DD>.json.gz */
export function partitionPath(dataDir, dataset, date) {
  checkDataset(dataset);
  checkDate(date);
  return join(datasetDir(dataDir, dataset), date.slice(0, 4), `${date}.json.gz`);
}

/**
 * Write one day's rows (atomic: temp file + rename).
 * @param {object} info  { connector, fields, fetched_at, dropped_zero_spend }
 */
export async function writePartition(dataDir, dataset, date, rows, info = {}) {
  const path = partitionPath(dataDir, dataset, date);
  const envelope = {
    schema: 1,
    dataset,
    date,
    connector: info.connector ?? DATASETS[dataset].connector,
    fetched_at: info.fetched_at ?? new Date().toISOString(),
    fields: info.fields ?? DATASETS[dataset].fields,
    rows_count: rows.length,
    dropped_zero_spend: info.dropped_zero_spend ?? 0,
    rows,
  };
  await atomicWrite(path, gzipSync(JSON.stringify(envelope), { level: 6 }));
  return path;
}

/** One day's file as stored, or null when that day was never pulled. A damaged file throws a StoreError naming it. */
export async function readPartition(dataDir, dataset, date) {
  const path = partitionPath(dataDir, dataset, date);
  let buf;
  try {
    buf = await readFile(path);
  } catch (err) {
    if (err.code === 'ENOENT') return null;
    throw err;
  }
  try {
    const envelope = JSON.parse(gunzipSync(buf).toString('utf8'));
    if (!envelope || !Array.isArray(envelope.rows)) throw new Error('no rows list');
    return envelope;
  } catch {
    throw new StoreError(`${path} is damaged. Pull that day again: node server/cli.mjs backfill --from ${date} --to ${date} --datasets ${dataset} --force`);
  }
}

/** Sorted dates that have a file for `dataset`. */
export async function listDates(dataDir, dataset) {
  checkDataset(dataset);
  const root = datasetDir(dataDir, dataset);
  let years;
  try {
    years = (await readdir(root, { withFileTypes: true })).filter((e) => e.isDirectory() && YEAR_RE.test(e.name)).map((e) => e.name);
  } catch (err) {
    if (err.code === 'ENOENT') return [];
    throw err;
  }
  const dates = [];
  for (const year of years) {
    for (const name of await readdir(join(root, year))) {
      const m = FILE_RE.exec(name);
      if (m && m[1].startsWith(year) && isIsoDay(m[1])) dates.push(m[1]);
    }
  }
  return dates.sort();
}

/** Envelopes for every stored day in [from, to] (both optional), in date order. */
export async function readPartitions(dataDir, dataset, { from = null, to = null } = {}) {
  const dates = (await listDates(dataDir, dataset)).filter((d) => (!from || d >= from) && (!to || d <= to));
  return mapLimit(dates, READ_CONCURRENCY, (date) => readPartition(dataDir, dataset, date));
}

/** Every stored row of `dataset` in [from, to], in date order and, within a day, in Windsor's order. */
export async function readRows(dataDir, dataset, range = {}) {
  const envelopes = await readPartitions(dataDir, dataset, range);
  const rows = [];
  for (const e of envelopes) for (const r of e.rows) rows.push(r);
  return rows;
}

/** Spend of a list of rows, read with the normaliser's number rules (blank = 0), in 1/10000 units to avoid drift. */
export function spendOf(rows) {
  let units = 0;
  for (const r of rows) units += Math.round((num(r?.[SPEND_FIELD]) ?? 0) * 10_000);
  return units / 10_000;
}

/**
 * Group a Windsor answer for [from, to] by day. Rows whose date is unreadable or outside the range cannot be placed
 * and are counted, not stored. For the breakdown datasets rows with spend <= 0 are dropped (counted).
 * @returns {{ byDate: Map<string, object[]>, unplaced: number, droppedBy: Map<string, number> }}
 */
export function groupByDate(dataset, rows, from, to, keep) {
  const byDate = new Map();
  const droppedBy = new Map();
  let unplaced = 0;
  for (const row of rows) {
    const date = parseDate(row?.[DATE_FIELD]);
    if (!date || date < from || date > to) {
      unplaced++;
      continue;
    }
    if (keep && !keep(dataset, row)) {
      droppedBy.set(date, (droppedBy.get(date) ?? 0) + 1);
      continue;
    }
    if (!byDate.has(date)) byDate.set(date, []);
    byDate.get(date).push(row);
  }
  return { byDate, unplaced, droppedBy };
}

/** Sizes on disk (bytes) and file count of data/raw/<dataset>. */
export async function datasetDiskUsage(dataDir, dataset) {
  const root = datasetDir(dataDir, dataset);
  let bytes = 0;
  let files = 0;
  for (const date of await listDates(dataDir, dataset)) {
    try {
      bytes += (await stat(join(root, date.slice(0, 4), `${date}.json.gz`))).size;
      files++;
    } catch {
      // removed meanwhile
    }
  }
  return { bytes, files };
}

/** Remove temp files a crashed writer may have left (older than an hour). */
export async function cleanTempFiles(dataDir, { olderThanMs = 3_600_000, now = Date.now() } = {}) {
  let removed = 0;
  for (const dataset of Object.keys(DATASETS)) {
    const root = datasetDir(dataDir, dataset);
    let years = [];
    try {
      years = await readdir(root);
    } catch {
      continue;
    }
    for (const year of years) {
      let names = [];
      try {
        names = await readdir(join(root, year));
      } catch {
        continue;
      }
      for (const name of names) {
        if (!name.startsWith('.') || !name.includes('.tmp-')) continue;
        const p = join(root, year, name);
        try {
          if (now - (await stat(p)).mtimeMs > olderThanMs) {
            await rm(p, { force: true });
            removed++;
          }
        } catch {
          // ignore
        }
      }
    }
  }
  return removed;
}

export async function ensureDataDir(dataDir) {
  await mkdir(rawRoot(dataDir), { recursive: true });
}
