// Who is asking: Tailscale identity headers (AUTH_MODE=tailscale) or nobody at all (AUTH_MODE=none, local tests).
//
// `tailscale serve` proxies the tailnet HTTPS address to 127.0.0.1:<PORT>. It first deletes any Tailscale-* headers the
// client sent, then adds Tailscale-User-Login / Tailscale-User-Name for the tailnet user who opened the page (none for
// tagged devices; non-ASCII values are RFC 2047 Q-encoded). Because only processes on this machine can reach
// 127.0.0.1, those headers can be trusted, which is why the server refuses to listen on any other address
// (config.checkServeSafety). Requests from Tailscale Funnel (the public internet) carry Tailscale-Funnel-Request and are
// refused.
//
// Browser-side protections that depend on the request, not the user:
//   - fetch metadata: a cross-site or same-site request that is not a top-level page load is refused, so another site
//     cannot embed /data/*.js, /img/* or the API with the visitor's tailnet identity
//   - state-changing requests (POST /api/refresh) must come from the dashboard's own origin

export const IDENTITY_HEADERS = Object.freeze({ login: 'tailscale-user-login', name: 'tailscale-user-name', funnel: 'tailscale-funnel-request' });

/** Decode RFC 2047 encoded words (=?utf-8?q?…?= / =?utf-8?b?…?=), as Tailscale sends non-ASCII names. */
export function decodeHeaderValue(value) {
  const s = String(value ?? '').trim();
  if (!s.includes('=?')) return s;
  const joined = s.replace(/\?=\s+=\?/g, '?==?'); // whitespace between adjacent encoded words is not part of the text
  return joined.replace(/=\?([^?]+)\?([qQbB])\?([^?]*)\?=/g, (whole, charset, enc, text) => {
    if (!/^utf-?8$/i.test(charset)) return whole;
    const bytes = enc.toLowerCase() === 'b'
      ? Buffer.from(text, 'base64')
      : Buffer.from(text.replace(/_/g, ' ').replace(/=([0-9A-Fa-f]{2})/g, (m, h) => String.fromCharCode(parseInt(h, 16))), 'latin1');
    return bytes.toString('utf8');
  });
}

function header(req, name) {
  const v = req.headers?.[name];
  return Array.isArray(v) ? v.join(', ') : typeof v === 'string' ? v : '';
}

/**
 * @returns {{ ok: true, mode: 'tailscale'|'none', user: { email: string|null, name: string|null, owner: boolean } }
 *   | { ok: false, status: number, reason: string, error: string, login?: string }}
 */
export function identify(req, config) {
  if (config.authMode === 'none') return { ok: true, mode: 'none', user: { email: null, name: null, owner: true } };
  if (header(req, IDENTITY_HEADERS.funnel)) {
    return { ok: false, status: 403, reason: 'funnel', error: 'This dashboard is not available over Tailscale Funnel. Open it from a device in the tailnet.' };
  }
  const login = decodeHeaderValue(header(req, IDENTITY_HEADERS.login));
  if (!login || login.length > 320 || /[\s,\u0000-\u001f\u007f]/.test(login)) {
    return {
      ok: false, status: 401, reason: 'no_identity',
      error: 'Open this dashboard through its Tailscale address (https://<machine>.<tailnet>.ts.net) from a device logged into the tailnet. Requests without a Tailscale identity are refused.',
    };
  }
  const key = login.toLowerCase();
  const owner = config.ownerUsers.includes(key);
  if (config.allowedUsers.length && !config.allowedUsers.includes(key) && !owner) {
    return { ok: false, status: 403, reason: 'not_allowed', login, error: `Your Tailscale account (${login}) is not on this dashboard's allow-list. Ask Finn to add it.` };
  }
  const name = decodeHeaderValue(header(req, IDENTITY_HEADERS.name)).replace(/[\u0000-\u001f\u007f]/g, '').slice(0, 200) || null;
  return { ok: true, mode: 'tailscale', user: { email: login, name, owner } };
}

/** The /api/session answer. `expires` is always null: there is no session to expire, Tailscale vouches per request. */
export function sessionPayload(auth) {
  return { email: auth.user.email, name: auth.user.name, expires: null, owner: auth.user.owner, mode: auth.mode };
}

/** A top-level page load (address bar, link, reload), as opposed to fetch / script / image requests. */
export function isPageLoad(req) {
  if (req.method !== 'GET' && req.method !== 'HEAD') return false;
  const dest = header(req, 'sec-fetch-dest');
  if (dest) return dest === 'document';
  const mode = header(req, 'sec-fetch-mode');
  if (mode) return mode === 'navigate';
  return header(req, 'accept').includes('text/html');
}

/**
 * Fetch-metadata policy: refuse requests another site makes with the visitor's browser (scripts, images, fetches),
 * except plain page loads (a link to the dashboard). Requests without Sec-Fetch-Site (curl, old browsers) pass.
 */
export function isCrossSiteSubresource(req) {
  const site = header(req, 'sec-fetch-site');
  if (!site || site === 'same-origin' || site === 'none') return false;
  return !(req.method === 'GET' && header(req, 'sec-fetch-mode') === 'navigate');
}

/** For POST / DELETE: the request must come from this dashboard's own pages (or from a non-browser client). */
export function isSameOriginWrite(req) {
  const site = header(req, 'sec-fetch-site');
  if (site) return site === 'same-origin';
  const origin = header(req, 'origin');
  if (!origin) return true; // curl / scripts on the server: no browser, no cross-site risk
  let host;
  try {
    host = new URL(origin).host.toLowerCase();
  } catch {
    return false;
  }
  const hosts = new Set();
  for (const value of [header(req, 'host'), header(req, 'x-forwarded-host').split(',')[0]]) if (value) hosts.add(value.trim().toLowerCase());
  return hosts.has(host);
}
