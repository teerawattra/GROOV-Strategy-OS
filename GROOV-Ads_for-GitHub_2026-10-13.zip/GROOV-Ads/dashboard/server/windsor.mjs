// Read-only Windsor.ai REST client (reporting endpoint only; nothing here can change an ad account or Windsor).
//
//   GET https://connectors.windsor.ai/<connector>?api_key=…&date_from=…&date_to=…&fields=…&_max_rows=…
//
// - Answers: {"data": [...]} or a bare [...] (both seen in the wild); {"status": "pending"} is polled with backoff in
//   case Windsor ever answers asynchronously.
// - Each request has a timeout; network errors, timeouts, 429 and 5xx are retried twice with backoff (2 s, 8 s).
// - A request that returns _max_rows rows (or more) may be truncated, so its date range is split in halves and pulled
//   again, down to single days (a single day at the limit is an error: raise WINDSOR_MAX_ROWS).
// - Errors and log lines NEVER contain the request URL or the key: messages are built from the connector, dataset
//   and dates only, and anything taken from a response body goes through redact().
//
// Field lists come from lib/datasets.mjs (which takes them from the normalisers), never from here.

import { DATASETS } from '../lib/datasets.mjs';
import { addDays, daysBetween, redact, secretForms, sleep as realSleep } from './util.mjs';

export class WindsorError extends Error {
  /**
   * @param {string} message  plain language, safe to log and show (no URL, no key)
   * @param {{status?: number|null, code?: string|null, fatal?: boolean, retryable?: boolean}} [info]
   *   fatal: every further request would fail the same way (missing or refused key), so the run stops
   */
  constructor(message, { status = null, code = null, fatal = false, retryable = false } = {}) {
    super(message);
    this.name = 'WindsorError';
    this.status = status;
    this.code = code;
    this.fatal = fatal;
    this.retryable = retryable;
  }
}

const PENDING_STATES = new Set(['pending', 'processing', 'queued', 'running', 'in_progress', 'in progress', 'accepted', 'started']);
const USER_AGENT = 'GROOV-Command-Center/1.0 (read-only reporting)';
const MAX_ERROR_BODY = 64 * 1024;

function isPendingAnswer(body) {
  const state = typeof body.status === 'string' ? body.status : typeof body.state === 'string' ? body.state : '';
  if (!PENDING_STATES.has(state.trim().toLowerCase())) return false;
  return !Array.isArray(body.data) || body.data.length === 0;
}

/** The useful words of an error body (JSON error / message / detail, or the text), single line, at most 200 chars. */
function bodyExcerpt(text) {
  let s = String(text ?? '');
  try {
    const j = JSON.parse(s);
    if (j && typeof j === 'object') {
      const pick = j.error?.message ?? j.error ?? j.message ?? j.detail ?? j.errors ?? null;
      if (pick !== null && pick !== undefined) s = typeof pick === 'string' ? pick : JSON.stringify(pick);
    }
  } catch {
    // plain text
  }
  return s.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 200);
}

/**
 * @param {object} o
 * @param {string} o.apiKey
 * @param {string} [o.baseUrl]        https://connectors.windsor.ai (tests: a local double)
 * @param {typeof fetch} [o.fetchImpl]
 * @param {number} [o.timeoutMs]      per attempt (default 180 s)
 * @param {number} [o.retries]        extra attempts on network errors / timeouts / 429 / 5xx (default 2)
 * @param {number[]} [o.retryDelaysMs]
 * @param {number} [o.pendingPolls]   how many "pending" answers to wait through (default 8)
 * @param {number} [o.pendingDelayMs] first wait; doubles each time up to 30 s
 * @param {number} [o.maxRows]        _max_rows per request (default 100,000)
 * @param {(ms: number) => Promise<void>} [o.sleep]
 * @param {{info: Function}} [o.log]
 */
export function createWindsorClient({
  apiKey, baseUrl = 'https://connectors.windsor.ai', fetchImpl = globalThis.fetch, timeoutMs = 180_000, retries = 2,
  retryDelaysMs = [2_000, 8_000], pendingPolls = 8, pendingDelayMs = 3_000, maxPendingDelayMs = 30_000, maxRows = 100_000,
  sleep = realSleep, log = null,
} = {}) {
  if (typeof apiKey !== 'string' || apiKey.trim() === '') {
    throw new WindsorError('No Windsor API key: set WINDSOR_API_KEY or MCP_WINDSOR_API_KEY (for example in /opt/data/.env).', { fatal: true, code: 'no_key' });
  }
  const secrets = secretForms(apiKey);
  const clean = (s) => redact(s, secrets);
  const base = String(baseUrl).replace(/\/+$/, '');

  const delayFor = (attempt, retryAfterMs) => {
    if (retryAfterMs !== null) return Math.min(retryAfterMs, 30_000);
    const d = retryDelaysMs[Math.min(attempt, retryDelaysMs.length - 1)] ?? 2_000;
    return Math.round(d * (0.8 + Math.random() * 0.4));
  };

  function urlFor(connector, fields, from, to, limit) {
    const params = new URLSearchParams({ api_key: apiKey, date_from: from, date_to: to, fields: fields.join(','), _max_rows: String(limit) });
    return `${base}/${encodeURIComponent(connector)}?${params}`;
  }

  function networkReason(err) {
    if (err?.name === 'TimeoutError' || err?.name === 'AbortError') return `timed out after ${timeoutMs >= 1000 ? `${Math.round(timeoutMs / 1000)} s` : `${timeoutMs} ms`}`;
    const code = err?.cause?.code ?? err?.code;
    return typeof code === 'string' && /^[A-Z0-9_]+$/.test(code) ? `network error (${code})` : 'network error';
  }

  /** One HTTP exchange: { rows, dropped } | { pending: true }; throws a classified WindsorError. */
  async function once(label, url) {
    let res;
    try {
      res = await fetchImpl(url, { headers: { accept: 'application/json', 'user-agent': USER_AGENT }, signal: AbortSignal.timeout(timeoutMs) });
    } catch (err) {
      throw new WindsorError(`${label}: ${networkReason(err)}`, { code: 'network', retryable: true });
    }
    let text;
    try {
      text = await res.text();
    } catch (err) {
      throw new WindsorError(`${label}: the answer could not be read (${networkReason(err)})`, { status: res.status, code: 'network', retryable: true });
    }
    if (res.status === 429 || res.status >= 500) {
      const raw = (res.headers.get('retry-after') ?? '').trim();
      const e = new WindsorError(`${label}: HTTP ${res.status}${res.statusText ? ` ${clean(res.statusText)}` : ''}`, { status: res.status, code: 'http', retryable: true });
      e.retryAfterMs = /^\d+$/.test(raw) ? Number(raw) * 1000 : null;
      throw e;
    }
    if (res.status >= 400) {
      const why = clean(bodyExcerpt(text.slice(0, MAX_ERROR_BODY)));
      const refused = res.status === 401 || res.status === 403;
      const hint = refused
        ? ' The API key was refused: check WINDSOR_API_KEY / MCP_WINDSOR_API_KEY (the value is never printed).'
        : res.status === 400 ? ' Windsor rejected the request (a field name or date may be wrong).' : '';
      throw new WindsorError(`${label}: HTTP ${res.status}.${hint}${why ? ` Windsor says: ${why}` : ''}`, { status: res.status, code: 'http', fatal: refused });
    }
    let body;
    try {
      body = JSON.parse(text);
    } catch {
      throw new WindsorError(`${label}: the answer was not JSON (HTTP ${res.status})`, { status: res.status, code: 'bad_json', retryable: true });
    }
    let rows;
    if (Array.isArray(body)) rows = body;
    else if (body && typeof body === 'object') {
      if (isPendingAnswer(body)) return { pending: true };
      if (Array.isArray(body.data)) rows = body.data;
      else if (body.error !== undefined || body.errors !== undefined || body.message !== undefined || body.detail !== undefined) {
        throw new WindsorError(`${label}: Windsor answered with an error: ${clean(bodyExcerpt(text.slice(0, MAX_ERROR_BODY)))}`, { status: res.status, code: 'api_error' });
      } else {
        throw new WindsorError(`${label}: unexpected answer (no "data" list)`, { status: res.status, code: 'bad_shape' });
      }
    } else {
      throw new WindsorError(`${label}: unexpected answer (not a list)`, { status: res.status, code: 'bad_shape' });
    }
    const objects = rows.filter((r) => r !== null && typeof r === 'object' && !Array.isArray(r));
    return { rows: objects, dropped: rows.length - objects.length };
  }

  /**
   * One request with retries and pending polls.
   * @returns {Promise<{rows: object[], truncated: boolean, dropped: number, attempts: number}>}
   */
  async function fetchRows({ connector, fields, from, to, label = `Windsor ${connector} ${from}..${to}`, limit = maxRows }) {
    const url = urlFor(connector, fields, from, to, limit);
    let attempt = 0;
    let polls = 0;
    for (;;) {
      let outcome;
      try {
        outcome = await once(label, url);
      } catch (err) {
        if (err instanceof WindsorError && err.retryable && attempt < retries) {
          const wait = delayFor(attempt, err.retryAfterMs ?? null);
          log?.info?.(`windsor: ${err.message}; retrying in ${Math.round(wait / 100) / 10} s`);
          await sleep(wait);
          attempt++;
          continue;
        }
        if (err instanceof WindsorError && err.retryable) err.message = `${err.message} (gave up after ${attempt + 1} attempts)`;
        throw err;
      }
      if (outcome.pending) {
        if (polls >= pendingPolls) {
          throw new WindsorError(`${label}: Windsor still answered "pending" after ${polls + 1} checks. Try again later.`, { code: 'pending' });
        }
        const wait = Math.min(pendingDelayMs * 2 ** polls, maxPendingDelayMs);
        log?.info?.(`windsor: ${label}: report not ready yet ("pending"); checking again in ${Math.round(wait / 100) / 10} s`);
        await sleep(wait);
        polls++;
        continue;
      }
      return { rows: outcome.rows, truncated: outcome.rows.length >= limit, dropped: outcome.dropped, attempts: attempt + 1 };
    }
  }

  /**
   * Pull one dataset for [range.from, range.to]. A piece that comes back at the row limit is split in halves until
   * every piece is complete; `onPiece({ from, to, rows })` is awaited once per complete piece (a piece is only ever
   * handed over whole). `stats` ({ requests, rows, splits }) is updated in place. Throws WindsorError on failure;
   * pieces handed over before the failure stay handed over.
   */
  async function pullRange(datasetId, range, onPiece, stats = { requests: 0, rows: 0, splits: 0 }) {
    const d = DATASETS[datasetId];
    if (!d) throw new WindsorError(`Unknown dataset "${datasetId}".`, { code: 'usage' });
    const label = `Windsor ${d.connector} (${d.id} ${range.from}..${range.to})`;
    stats.requests++;
    const { rows, truncated } = await fetchRows({ connector: d.connector, fields: d.fields, from: range.from, to: range.to, label });
    if (truncated) {
      if (range.from === range.to) {
        throw new WindsorError(`${label}: ${rows.length} rows for a single day reached the row limit (WINDSOR_MAX_ROWS=${maxRows}), so the day may be incomplete. Raise WINDSOR_MAX_ROWS and pull it again.`, { code: 'max_rows' });
      }
      const days = daysBetween(range.from, range.to) + 1;
      const mid = addDays(range.from, Math.floor(days / 2) - 1);
      stats.splits++;
      log?.info?.(`windsor: ${d.id} ${range.from}..${range.to} reached the row limit (${rows.length} rows); pulling it in two halves`);
      await pullRange(datasetId, { from: range.from, to: mid }, onPiece, stats);
      await pullRange(datasetId, { from: addDays(mid, 1), to: range.to }, onPiece, stats);
      return stats;
    }
    stats.rows += rows.length;
    await onPiece({ from: range.from, to: range.to, rows });
    return stats;
  }

  return { fetchRows, pullRange, maxRows };
}
