// The data jobs: refresh (daily: the last N complete days), backfill (history, resumable) and the image step.
//
// refresh({ days: 28 })
//   1. lock (data/refresh.lock): a second refresh / backfill / snapshot while one runs is skipped, not doubled
//   2. pull the last N complete days (report timezone, default Asia/Bangkok; today is never pulled) of every enabled
//      dataset from Windsor in 7-day chunks; each complete chunk overwrites exactly its days (data/raw, atomic)
//   3. if a MAIN dataset (meta / tiktok / google) failed: stop. The previous snapshot keeps serving; the days that did
//      arrive are stored and the next run fills the rest. A failed BREAKDOWN dataset only adds a warning and an
//      `error` in /api/meta health (its stored days still show).
//   4. build a new snapshot (server/snapshot.mjs) and flip data/current.json atomically; the server hot-reloads it
//   5. save new ad creatives (server/images.mjs); if any were saved, build once more so their ads say image: true
//   6. data/refresh-status.json records the run (GET /api/refresh shows it)
//
// backfill({ from, to }) pulls history the same way, but by default only the days that are not stored yet, so it can
// be stopped and simply run again. --force pulls (and overwrites) every day in the range.
//
// Shrink guard: if Windsor suddenly returns less than half the rows stored for a chunk (>= 50 rows stored), the stored
// days are kept and a warning says so; a real drop is accepted with --force (refresh --force / backfill --force).
//
// Logs carry counts, dates and plain-language errors only: never the key, never a URL.

import { hostname } from 'node:os';
import { join } from 'node:path';
import { mkdir, open, rm } from 'node:fs/promises';
import { BREAKDOWN_DATASETS, DATASET_IDS, DATASETS, MAIN_DATASETS, enabledDatasets, keepRow } from '../lib/datasets.mjs';
import { buildSnapshot, readCurrent, SnapshotError } from './snapshot.mjs';
import { groupByDate, listDates, readPartition, StoreError, writePartition } from './store.mjs';
import { runImages } from './images.mjs';
import { createWindsorClient, WindsorError } from './windsor.mjs';
import { ConfigError } from './config.mjs';
import { LOOKBACK_DAYS } from '../lib/creatives-job.mjs';
import { addDays, dateRange, dateRuns, isIsoDay, mapLimit, readJsonFile, redact, secretForms, splitDays, todayIn, writeJsonFile } from './util.mjs';

export const STATUS_FILE = 'refresh-status.json';
export const LOCK_FILE = 'refresh.lock';
export const EXIT_SKIPPED = 75; // EX_TEMPFAIL: another job holds the lock (systemd: SuccessExitStatus=75)
const LOCK_STALE_MS = 6 * 3600_000;
const SHRINK_MIN_ROWS = 50;
const SHRINK_RATIO = 0.5;

export class JobError extends Error {
  constructor(message) {
    super(message);
    this.name = 'JobError';
  }
}

const iso = (ms) => new Date(ms).toISOString();

/** Plain-language error text, safe for logs and the status file. */
export function describeError(err, secrets = []) {
  if (err instanceof WindsorError || err instanceof StoreError || err instanceof SnapshotError || err instanceof ConfigError || err instanceof JobError) {
    return redact(err.message, secrets);
  }
  return redact(`Unexpected error (${err?.name ?? 'Error'}): ${String(err?.message ?? err).slice(0, 300)}`, secrets);
}

// ---------------------------------------------------------------------------------------------------------
// Lock
// ---------------------------------------------------------------------------------------------------------

const lockPath = (dataDir) => join(dataDir, LOCK_FILE);

export async function readLock(dataDir) {
  return readJsonFile(lockPath(dataDir)).catch(() => null);
}

/** True while the process that wrote the lock is alive (and the lock is younger than 6 h). */
export function lockIsLive(holder, { now = Date.now(), staleMs = LOCK_STALE_MS } = {}) {
  if (!holder || typeof holder !== 'object') return false;
  const age = now - Date.parse(holder.started_at);
  if (!(age >= -60_000) || age > staleMs) return false;
  if (holder.host && holder.host !== hostname()) return true; // cannot check a process on another machine
  if (!Number.isInteger(holder.pid) || holder.pid <= 0) return false;
  try {
    process.kill(holder.pid, 0);
    return true;
  } catch (err) {
    return err.code === 'EPERM';
  }
}

/**
 * Take data/refresh.lock (created exclusively). Returns { release() } or null when another live job holds it.
 * A lock left by a process that no longer exists (or older than 6 h) is taken over.
 */
export async function acquireLock(dataDir, info = {}, { now = Date.now() } = {}) {
  await mkdir(dataDir, { recursive: true });
  const path = lockPath(dataDir);
  const mine = { pid: process.pid, host: hostname(), started_at: iso(now), ...info };
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const handle = await open(path, 'wx', 0o644);
      await handle.writeFile(JSON.stringify(mine));
      await handle.close();
      return {
        holder: mine,
        async release() {
          const current = await readLock(dataDir);
          if (current && current.pid === mine.pid && current.started_at === mine.started_at) await rm(path, { force: true });
        },
      };
    } catch (err) {
      if (err.code !== 'EEXIST') throw err;
      const holder = await readLock(dataDir);
      if (lockIsLive(holder, { now })) return null;
      await rm(path, { force: true });
    }
  }
  return null;
}

// ---------------------------------------------------------------------------------------------------------
// Status file
// ---------------------------------------------------------------------------------------------------------

export async function readStatus(dataDir) {
  return readJsonFile(join(dataDir, STATUS_FILE)).catch(() => null);
}

/** The last run as the API shows it: a "running" run whose process is gone is reported as interrupted. */
export async function currentStatus(dataDir, { now = Date.now() } = {}) {
  const status = await readStatus(dataDir);
  if (status?.state === 'running' && !lockIsLive(await readLock(dataDir), { now })) {
    return { ...status, state: 'interrupted', error: 'The run stopped before it finished (the process ended). The previous snapshot keeps serving; run it again.' };
  }
  return status;
}

async function writeStatus(dataDir, status) {
  await writeJsonFile(join(dataDir, STATUS_FILE), status);
  return status;
}

// ---------------------------------------------------------------------------------------------------------
// Pulling
// ---------------------------------------------------------------------------------------------------------

function newResult() {
  return {
    requests: 0, splits: 0, rows_received: 0, rows_stored: 0, chunks: 0, chunks_failed: 0,
    days_written: 0, days_kept: 0, dropped_zero_spend: 0, unplaced_rows: 0, errors: [], warnings: [],
  };
}

/** Store one complete piece of a pull: one file per day, unless the shrink guard keeps what is stored. */
async function storePiece(config, dataset, piece, { force, result, log, fetchedAt }) {
  const { byDate, unplaced, droppedBy } = groupByDate(dataset, piece.rows, piece.from, piece.to, keepRow);
  const days = dateRange(piece.from, piece.to);
  let incoming = 0;
  for (const rows of byDate.values()) incoming += rows.length;
  result.rows_received += piece.rows.length;
  result.unplaced_rows += unplaced;
  if (!force) {
    let stored = 0;
    for (const day of days) {
      const e = await readPartition(config.dataDir, dataset, day).catch(() => null);
      if (e) stored += e.rows.length;
    }
    if (stored >= SHRINK_MIN_ROWS && incoming < stored * SHRINK_RATIO) {
      result.days_kept += days.length;
      const w = `${dataset} ${piece.from}..${piece.to}: Windsor returned ${incoming} rows where ${stored} are stored, so the stored days were kept. If the drop is real, pull again with --force.`;
      result.warnings.push(w);
      log.warn(`pull: ${w}`);
      return;
    }
  }
  const info = { fetched_at: fetchedAt, connector: DATASETS[dataset].connector, fields: DATASETS[dataset].fields };
  let dropped = 0;
  for (const day of days) {
    const d = droppedBy.get(day) ?? 0;
    dropped += d;
    await writePartition(config.dataDir, dataset, day, byDate.get(day) ?? [], { ...info, dropped_zero_spend: d });
    result.days_written++;
  }
  result.rows_stored += incoming;
  result.dropped_zero_spend += dropped;
  log.info(`pull: ${dataset} ${piece.from}..${piece.to}: ${piece.rows.length} rows, ${days.length} days stored${dropped ? ` (${dropped} zero-spend rows left out)` : ''}${unplaced ? ` (${unplaced} rows outside these days not stored)` : ''}`);
}

/**
 * Pull `chunks` ({ dataset: [{from, to}, …] }) with at most config.windsor.concurrency requests in flight.
 * Never throws for a chunk: failures are collected per dataset. A fatal error (missing or refused key) stops the
 * remaining chunks.
 */
async function pullChunks(config, client, chunks, { force, log, now }) {
  const results = Object.fromEntries(Object.keys(chunks).map((d) => [d, newResult()]));
  const tasks = [];
  for (const [dataset, list] of Object.entries(chunks)) {
    results[dataset].chunks = list.length;
    for (const range of list) tasks.push({ dataset, range });
  }
  const fetchedAt = now.toISOString();
  let fatal = null;
  await mapLimit(tasks, config.windsor.concurrency, async ({ dataset, range }) => {
    const result = results[dataset];
    if (fatal) {
      result.chunks_failed++;
      return;
    }
    const stats = { requests: 0, rows: 0, splits: 0 };
    try {
      await client.pullRange(dataset, range, (piece) => storePiece(config, dataset, piece, { force, result, log, fetchedAt }), stats);
    } catch (err) {
      result.chunks_failed++;
      const msg = err instanceof WindsorError ? err.message : `${dataset} ${range.from}..${range.to}: ${describeError(err, secretForms(config.windsorKey))}`;
      result.errors.push(msg);
      log.error(`pull: ${msg}`);
      if (err?.fatal) fatal = err;
    } finally {
      result.requests += stats.requests;
      result.splits += stats.splits;
    }
  });
  for (const [dataset, r] of Object.entries(results)) {
    if (r.unplaced_rows) r.warnings.push(`${dataset}: ${r.unplaced_rows} rows had no date, or a date outside the requested days, and were not stored.`);
  }
  return { results, fatal };
}

function windsorClient(config, { fetchImpl, sleep, log }) {
  return createWindsorClient({
    apiKey: config.windsorKey,
    baseUrl: config.windsor.baseUrl,
    timeoutMs: config.windsor.timeoutMs,
    maxRows: config.windsor.maxRows,
    fetchImpl: fetchImpl ?? globalThis.fetch,
    ...(sleep ? { sleep } : {}),
    log,
  });
}

/** Compact per-dataset summary for the status file. */
function pullSummary(results) {
  const out = {};
  for (const [d, r] of Object.entries(results)) {
    out[d] = {
      requests: r.requests, chunks: r.chunks, chunks_failed: r.chunks_failed, rows: r.rows_stored, days_written: r.days_written,
      days_kept: r.days_kept, ...(r.dropped_zero_spend ? { dropped_zero_spend: r.dropped_zero_spend } : {}), ...(r.errors.length ? { errors: r.errors.slice(0, 5) } : {}),
    };
  }
  return out;
}

function snapshotSummary(manifest) {
  return manifest ? {
    version: manifest.version, data_through: manifest.data_through, history_from: manifest.history_from, rows: manifest.rows,
    fact_rows: manifest.fact_rows, breakdown_rows: manifest.breakdown_rows,
  } : null;
}

/** After the main pulls: stop on a failed main dataset; turn failed breakdown pulls into health errors + warnings. */
function assessPulls(results, fatal) {
  const failedMain = MAIN_DATASETS.filter((d) => results[d]?.errors.length);
  if (fatal || failedMain.length) {
    const first = fatal ? fatal.message : results[failedMain[0]].errors[0];
    const which = failedMain.length ? failedMain.map((d) => `${d} (${results[d].chunks_failed} of ${results[d].chunks} chunks)`).join(', ') : 'every dataset';
    throw new JobError(`Windsor pull failed for ${which}: ${first} The previous snapshot keeps serving. Days that did arrive are stored; run it again to fill the rest.`);
  }
  const breakdownErrors = {};
  const warnings = [];
  for (const d of BREAKDOWN_DATASETS) {
    const r = results[d];
    if (!r) continue;
    if (r.errors.length) {
      breakdownErrors[d] = `The latest pull failed (${r.errors[0]}). The splits show the days stored before it.`;
      warnings.push(`${d}: ${breakdownErrors[d]}`);
    }
  }
  for (const r of Object.values(results)) warnings.push(...r.warnings);
  return { breakdownErrors, warnings };
}

/** Run the image step; it never fails the job (the snapshot is already live). */
async function imageStep(config, { now, clock, imageFetchImpl, log, breakdownErrors, warnings }) {
  try {
    const images = await runImages(config, { now, clock, fetchImpl: imageFetchImpl ?? globalThis.fetch, log });
    let manifest = null;
    if (images.savedKeys.length) manifest = await buildSnapshot(config, { now, log, breakdownErrors, extraWarnings: warnings, reason: 'images' });
    return { counts: images.counts, manifest };
  } catch (err) {
    const msg = `images: ${describeError(err, secretForms(config.windsorKey))}`;
    log.error(msg);
    return { counts: { error: msg }, manifest: null };
  }
}

// ---------------------------------------------------------------------------------------------------------
// refresh / backfill / images / snapshot
// ---------------------------------------------------------------------------------------------------------

function commonOptions(o) {
  return {
    now: o.now ?? new Date(), log: o.log ?? console, clock: o.clock ?? Date.now, fetchImpl: o.fetchImpl, sleep: o.sleep, imageFetchImpl: o.imageFetchImpl,
  };
}

/**
 * Daily refresh. Never throws; returns the status it stored ({ state: 'ok' | 'error' | 'skipped', … }).
 * @param {object} config
 * @param {{ days?: number, force?: boolean, trigger?: string, requestedBy?: string|null, datasets?: string[],
 *   now?: Date, clock?: () => number, log?: object, fetchImpl?: typeof fetch, imageFetchImpl?: typeof fetch, sleep?: Function }} [options]
 */
export async function refresh(config, options = {}) {
  const { now, log, clock, fetchImpl, sleep, imageFetchImpl } = commonOptions(options);
  const { days = config.refreshDays, force = false, trigger = 'manual', requestedBy = null } = options;
  const ids = options.datasets ?? enabledDatasets(config);
  const lock = await acquireLock(config.dataDir, { command: 'refresh', trigger }, { now: clock() });
  if (!lock) {
    log.info('refresh: skipped, another refresh, backfill or snapshot build is running');
    return { state: 'skipped', reason: 'already_running', holder: await readLock(config.dataDir) };
  }
  const started = clock();
  const to = addDays(todayIn(config.tzReport, now), -1);
  const from = addDays(to, -(days - 1));
  let status = { state: 'running', command: 'refresh', trigger, force: Boolean(force), requested_by: requestedBy, started_at: iso(started), range: { from, to }, datasets: ids };
  try {
    await writeStatus(config.dataDir, status);
    log.info(`refresh: pulling ${from}..${to} (${days} days, ${config.tzReport}) for ${ids.join(', ')}${force ? ' (forced)' : ''}`);
    const client = windsorClient(config, { fetchImpl, sleep, log });
    const chunks = Object.fromEntries(ids.map((d) => [d, splitDays(from, to, config.windsor.chunkDays)]));
    const { results, fatal } = await pullChunks(config, client, chunks, { force, log, now });
    status.pulls = pullSummary(results);
    const { breakdownErrors, warnings } = assessPulls(results, fatal);
    let manifest = await buildSnapshot(config, { now, log, breakdownErrors, extraWarnings: warnings, reason: 'refresh' });
    status = { ...status, snapshot: snapshotSummary(manifest) };
    await writeStatus(config.dataDir, status);
    const images = await imageStep(config, { now, clock, imageFetchImpl, log, breakdownErrors, warnings });
    if (images.manifest) manifest = images.manifest;
    const finished = clock();
    status = { ...status, state: 'ok', finished_at: iso(finished), duration_s: Math.round((finished - started) / 100) / 10, snapshot: snapshotSummary(manifest), images: images.counts, warnings: manifest.warnings };
    log.info(`refresh: ok in ${status.duration_s} s · snapshot ${manifest.version} · data through ${manifest.data_through} · ${manifest.warnings.length} warnings`);
  } catch (err) {
    const finished = clock();
    status = { ...status, state: 'error', finished_at: iso(finished), duration_s: Math.round((finished - started) / 100) / 10, error: describeError(err, secretForms(config.windsorKey)) };
    log.error(`refresh: failed: ${status.error}`);
  } finally {
    await writeStatus(config.dataDir, status).catch((e) => log.error(`refresh: could not write the status file: ${e.message}`));
    await lock.release().catch(() => {});
  }
  return status;
}

/** Validate backfill arguments; returns { from, to, ids, notes }. Throws JobError with a usage message. */
export function backfillPlan(config, { from = config.backfillFrom, to = null, datasets = null, now = new Date() } = {}) {
  const yesterday = addDays(todayIn(config.tzReport, now), -1);
  const notes = [];
  if (!from) throw new JobError('backfill needs --from YYYY-MM-DD (or BACKFILL_FROM in the settings).');
  if (!isIsoDay(from)) throw new JobError(`--from must be a date as YYYY-MM-DD (got "${String(from).slice(0, 40)}").`);
  let end = to ?? yesterday;
  if (!isIsoDay(end)) throw new JobError(`--to must be a date as YYYY-MM-DD (got "${String(end).slice(0, 40)}").`);
  if (end > yesterday) {
    notes.push(`--to ${end} is not a complete day yet in ${config.tzReport}; using ${yesterday}.`);
    end = yesterday;
  }
  if (from > end) throw new JobError(`--from ${from} is after --to ${end}.`);
  let ids = enabledDatasets(config);
  if (datasets && datasets.length) {
    const unknown = datasets.filter((d) => !DATASET_IDS.includes(d));
    if (unknown.length) throw new JobError(`Unknown dataset(s): ${unknown.join(', ')}. Use: ${DATASET_IDS.join(', ')}.`);
    ids = [...new Set(datasets)];
  }
  return { from, to: end, ids, notes };
}

/**
 * Pull history. Days already stored are skipped unless `force`. Builds a snapshot at the end (unless snapshot:false)
 * when anything new was stored or no snapshot exists yet, and saves creatives when the range reaches the last 7 days.
 * Never throws; returns the stored status.
 */
export async function backfill(config, options = {}) {
  const { now, log, clock, fetchImpl, sleep, imageFetchImpl } = commonOptions(options);
  const { force = false, snapshot = true } = options;
  let plan;
  try {
    plan = backfillPlan(config, { from: options.from ?? config.backfillFrom, to: options.to ?? null, datasets: options.datasets ?? null, now });
  } catch (err) {
    log.error(`backfill: ${describeError(err)}`);
    return { state: 'error', command: 'backfill', error: describeError(err), usage: true };
  }
  const lock = await acquireLock(config.dataDir, { command: 'backfill' }, { now: clock() });
  if (!lock) {
    log.info('backfill: skipped, another refresh, backfill or snapshot build is running. Try again when it has finished.');
    return { state: 'skipped', reason: 'already_running', holder: await readLock(config.dataDir) };
  }
  const started = clock();
  let status = { state: 'running', command: 'backfill', trigger: 'cli', force: Boolean(force), started_at: iso(started), range: { from: plan.from, to: plan.to }, datasets: plan.ids };
  try {
    for (const note of plan.notes) log.info(`backfill: ${note}`);
    await writeStatus(config.dataDir, status);
    const wanted = dateRange(plan.from, plan.to);
    const chunks = {};
    const todo = {};
    for (const d of plan.ids) {
      const stored = force ? new Set() : new Set(await listDates(config.dataDir, d));
      const missing = wanted.filter((day) => !stored.has(day));
      todo[d] = { missing: missing.length, stored: wanted.length - missing.length };
      chunks[d] = [];
      for (const run of dateRuns(missing)) chunks[d].push(...splitDays(run.from, run.to, config.windsor.chunkDays));
    }
    log.info(`backfill: ${plan.from}..${plan.to}: ${plan.ids.map((d) => `${d} ${todo[d].missing} days to pull${todo[d].stored ? ` (${todo[d].stored} already stored)` : ''}`).join(' · ')}${force ? ' (forced: every day is pulled again)' : ''}`);
    const totalChunks = Object.values(chunks).reduce((n, l) => n + l.length, 0);
    let results = Object.fromEntries(plan.ids.map((d) => [d, newResult()]));
    let fatal = null;
    if (totalChunks) {
      const client = windsorClient(config, { fetchImpl, sleep, log });
      ({ results, fatal } = await pullChunks(config, client, chunks, { force, log, now }));
    }
    status.pulls = pullSummary(results);
    status.todo = todo;
    const { breakdownErrors, warnings } = assessPulls(results, fatal);
    const written = Object.values(results).reduce((n, r) => n + r.days_written, 0);
    let manifest = null;
    if (snapshot && (written > 0 || !(await readCurrent(config.dataDir)))) {
      manifest = await buildSnapshot(config, { now, log, breakdownErrors, extraWarnings: warnings, reason: 'backfill' });
      const recent = addDays(todayIn(config.tzReport, now), -LOOKBACK_DAYS);
      if (plan.to >= recent && plan.ids.some((d) => d === 'meta' || d === 'tiktok')) {
        const images = await imageStep(config, { now, clock, imageFetchImpl, log, breakdownErrors, warnings });
        if (images.manifest) manifest = images.manifest;
        status.images = images.counts;
      }
    } else if (!totalChunks) {
      log.info('backfill: every day in the range is already stored; nothing to pull (use --force to pull again).');
    }
    const finished = clock();
    status = { ...status, state: 'ok', finished_at: iso(finished), duration_s: Math.round((finished - started) / 100) / 10, snapshot: snapshotSummary(manifest), warnings: manifest ? manifest.warnings : warnings };
    log.info(`backfill: ok in ${status.duration_s} s · ${written} days stored${manifest ? ` · snapshot ${manifest.version} · data through ${manifest.data_through}` : ''}`);
  } catch (err) {
    const finished = clock();
    status = { ...status, state: 'error', finished_at: iso(finished), duration_s: Math.round((finished - started) / 100) / 10, error: describeError(err, secretForms(config.windsorKey)) };
    log.error(`backfill: failed: ${status.error}`);
  } finally {
    await writeStatus(config.dataDir, status).catch((e) => log.error(`backfill: could not write the status file: ${e.message}`));
    await lock.release().catch(() => {});
  }
  return status;
}

/** Run `fn` under the lock (snapshot / images / seed commands). Returns { skipped: true } when the lock is held. */
export async function withLock(config, command, fn, { now = Date.now() } = {}) {
  const lock = await acquireLock(config.dataDir, { command }, { now });
  if (!lock) return { skipped: true, holder: await readLock(config.dataDir) };
  try {
    return { skipped: false, value: await fn() };
  } finally {
    await lock.release().catch(() => {});
  }
}

/** Rebuild the snapshot from the stored raw data (no Windsor calls). */
export async function rebuildSnapshot(config, { now = new Date(), log = console, reason = 'manual' } = {}) {
  return withLock(config, 'snapshot', () => buildSnapshot(config, { now, log, reason }));
}

/** The image step alone (CLI `images`), plus a rebuild when something was saved. */
export async function imagesOnly(config, { now = new Date(), clock = Date.now, fetchImpl = globalThis.fetch, log = console } = {}) {
  return withLock(config, 'images', async () => {
    const images = await runImages(config, { now, clock, fetchImpl, log });
    let manifest = null;
    if (images.savedKeys.length && (await readCurrent(config.dataDir))) manifest = await buildSnapshot(config, { now, log, reason: 'images' });
    return { ...images, manifest };
  });
}
