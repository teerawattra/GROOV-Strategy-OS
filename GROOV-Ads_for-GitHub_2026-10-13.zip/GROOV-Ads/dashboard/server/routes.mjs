// Request handling for the VPS server (node:http). The API answers exactly what the Netlify functions answer
// (DATA_CONTRACT.md §2): same payloads, same validation and range cap (lib/http.mjs validateRange), same compression
// (brotli / gzip via lib/http.mjs), same X-Data-Version header and error shape {"error": "..."}.
//
//   public   GET /login.html (built in), /assets/groov-logo.png, /favicon.ico, /healthz
//   signed   GET /  and every file of public/ except the Google sign-in files and data/sample.*
//            GET /data/registry.js, /data/learnings.js, /data/modules.js   (generated from CONFIG_DIR)
//            GET /api/meta, /api/rows?from&to, /api/monthly, /api/breakdowns?from&to, /img/<meta|tiktok>/<ad_id>
//            GET /api/session · DELETE /api/session · GET /api/refresh · POST /api/refresh[?force=1] (owners)
//   never    /data/sample.js (the local preview bundle with real client numbers): 404 even when the file exists
//
// "Signed" = a Tailscale identity on the request (AUTH_MODE=tailscale) or anything (AUTH_MODE=none, loopback only).
// A page load without one gets the built-in login page with status 401 (403 when the user is not on the allow-list).

import { readFile, stat } from 'node:fs/promises';
import { extname, join, normalize as normalizePath, sep } from 'node:path';
import { emptyBreakdowns, sliceBreakdowns } from '../lib/breakdowns.mjs';
import { SECURITY_HEADERS, createLru, encodeBytes, negotiateEncoding, prepareJsonBody, validateRange } from '../lib/http.mjs';
import { sliceRows } from '../lib/normalize.mjs';
import { identify, isCrossSiteSubresource, isPageLoad, isSameOriginWrite, sessionPayload } from './auth.mjs';
import { findCreative, sniffStored } from './images.mjs';
import { loginPage } from './login-page.mjs';
import { currentStatus } from './refresh.mjs';
import { STATIC_NAMES, staticFilePath } from './static-data.mjs';

/** Security headers for pages and files (netlify.toml's, without the Google sign-in sources). */
export const PAGE_HEADERS = Object.freeze({
  'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'",
  'X-Frame-Options': 'DENY',
  'X-Content-Type-Options': 'nosniff',
  'Referrer-Policy': 'strict-origin-when-cross-origin',
  'Permissions-Policy': 'camera=(), microphone=(), geolocation=(), payment=(), usb=(), serial=(), bluetooth=(), hid=()',
  'Cross-Origin-Opener-Policy': 'same-origin',
  'Cross-Origin-Resource-Policy': 'same-origin',
  'Strict-Transport-Security': 'max-age=31536000',
  'X-Robots-Tag': 'noindex, nofollow',
});
/** API and image responses: lib/http.mjs's (CSP default-src 'none') plus same-origin resource policy. */
export const API_HEADERS = Object.freeze({ ...SECURITY_HEADERS, 'Cross-Origin-Resource-Policy': 'same-origin' });

export const NO_DATA_MESSAGE = "No data yet: the first data pull hasn't finished. On the server run \"node server/cli.mjs backfill --from YYYY-MM-DD\" (or \"refresh\"), then reload.";

const TYPES = Object.freeze({
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.txt': 'text/plain; charset=utf-8', '.map': 'application/json; charset=utf-8', '.svg': 'image/svg+xml',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif', '.webp': 'image/webp', '.avif': 'image/avif', '.ico': 'image/x-icon',
  '.woff2': 'font/woff2', '.woff': 'font/woff',
});
const COMPRESSIBLE = /^(text\/|application\/json|image\/svg\+xml)/;
const COMPRESS_MIN_BYTES = 1024;
/** Files of public/ that belong to the Netlify build only (Google sign-in) or must never leave the machine. */
const NOT_SERVED = [/^\/login\.html$/, /^\/assets\/login\.(js|css)$/, /^\/data\/sample\./i, /(^|\/)\./];
const PUBLIC_ASSETS = new Set(['/assets/groov-logo.png', '/favicon.ico']);
const DATA_ROUTES = new Set(['/api/meta', '/api/rows', '/api/monthly', '/api/breakdowns']);

function contentTypeOf(path) {
  return TYPES[extname(path).toLowerCase()] ?? 'application/octet-stream';
}

// ---------------------------------------------------------------------------------------------------------
// Response helpers (node:http)
// ---------------------------------------------------------------------------------------------------------

function send(req, res, status, headers, body) {
  if (body !== undefined && body !== null) headers['Content-Length'] = Buffer.byteLength(body);
  res.writeHead(status, headers);
  res.end(req.method === 'HEAD' ? undefined : body);
}

function sendPrepared(req, res, prepared, { status = 200, headers = {}, cache = 'private, no-store' } = {}) {
  const h = { ...API_HEADERS, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': cache, Vary: 'Accept-Encoding', ...headers };
  if (prepared.encoding) h['Content-Encoding'] = prepared.encoding;
  send(req, res, status, h, prepared.bytes);
}

function sendJson(req, res, value, options = {}) {
  sendPrepared(req, res, prepareJsonBody(typeof value === 'string' ? value : JSON.stringify(value), negotiateEncoding(req.headers['accept-encoding'])), options);
}

/** Small uncompressed JSON error, {"error": message} (lib/http.mjs errorJson's shape). */
export function sendError(req, res, status, message, headers = {}) {
  send(req, res, status, { ...API_HEADERS, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...headers }, JSON.stringify({ error: message }));
}

function methodNotAllowed(req, res, allowed) {
  sendError(req, res, 405, `Method not allowed. Use ${allowed.join(' or ')}.`, { Allow: allowed.join(', ') });
}

function sendHtml(req, res, status, html) {
  send(req, res, status, { ...PAGE_HEADERS, 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' }, html);
}

// ---------------------------------------------------------------------------------------------------------
// Handler
// ---------------------------------------------------------------------------------------------------------

/**
 * @param {object} deps
 * @param {object} deps.config
 * @param {{ get(): Promise<object|null> }} deps.snapshots   current snapshot (server.mjs SnapshotHolder)
 * @param {(opts: object) => Promise<object>} deps.startRefresh
 * @param {() => Promise<void>} [deps.ensureStatic]           rebuild /data/*.js when config/ changed
 * @param {object} [deps.log]
 */
export function createHandler({ config, snapshots, startRefresh, ensureStatic = async () => {}, log = console }) {
  const files = createLru(64); // path -> { etag, bytes, encoded: {} }
  const bodies = createLru(16); // version|route|from|to|encoding -> prepared body

  async function sendFile(req, res, path, { type = contentTypeOf(path), headers = PAGE_HEADERS, cache = 'private, no-cache' } = {}) {
    let st;
    try {
      st = await stat(path);
    } catch {
      return sendError(req, res, 404, 'Not found.');
    }
    if (!st.isFile()) return sendError(req, res, 404, 'Not found.');
    const etag = `W/"${st.size.toString(16)}-${Math.floor(st.mtimeMs).toString(16)}"`;
    const base = { ...headers, 'Content-Type': type, 'Cache-Control': cache, ETag: etag };
    const compressible = COMPRESSIBLE.test(type);
    if (compressible) base.Vary = 'Accept-Encoding';
    if ((req.headers['if-none-match'] || '').split(',').map((s) => s.trim()).includes(etag)) {
      res.writeHead(304, base);
      return res.end();
    }
    let entry = files.get(path);
    if (!entry || entry.etag !== etag) {
      entry = { etag, bytes: await readFile(path), encoded: {} };
      if (entry.bytes.length <= 2 * 1024 * 1024) files.set(path, entry);
    }
    let body = entry.bytes;
    const encoding = compressible && body.length >= COMPRESS_MIN_BYTES ? negotiateEncoding(req.headers['accept-encoding']) : null;
    if (encoding) {
      entry.encoded[encoding] ??= encodeBytes(entry.bytes, encoding);
      body = entry.encoded[encoding];
      base['Content-Encoding'] = encoding;
    }
    return send(req, res, 200, base, body);
  }

  async function dataRoute(req, res, url) {
    if (req.method !== 'GET' && req.method !== 'HEAD') return methodNotAllowed(req, res, ['GET']);
    const snap = await snapshots.get();
    if (!snap) return sendError(req, res, 503, NO_DATA_MESSAGE);
    const version = { 'X-Data-Version': snap.version };
    const encoding = negotiateEncoding(req.headers['accept-encoding']);
    const route = url.pathname;
    if (route === '/api/meta' || route === '/api/monthly') {
      const key = `${snap.version}|${route}|${encoding ?? 'identity'}`;
      let prepared = bodies.get(key);
      if (!prepared) {
        prepared = prepareJsonBody(route === '/api/meta' ? snap.metaText : snap.monthlyText, encoding);
        bodies.set(key, prepared);
      }
      return sendPrepared(req, res, prepared, { headers: version });
    }
    const range = validateRange(url.searchParams.get('from'), url.searchParams.get('to'));
    if (!range.ok) return sendError(req, res, 400, range.error);
    const key = `${snap.version}|${route}|${range.from}|${range.to}|${encoding ?? 'identity'}`;
    let prepared = bodies.get(key);
    if (!prepared) {
      const payload = route === '/api/rows'
        ? sliceRows(snap.dataset, range.from, range.to)
        : sliceBreakdowns(snap.bds ?? emptyBreakdowns({ mode: snap.dataset.mode === 'sample' ? 'sample' : 'live' }), range.from, range.to);
      prepared = prepareJsonBody(JSON.stringify(payload), encoding);
      bodies.set(key, prepared);
    }
    return sendPrepared(req, res, prepared, { headers: version });
  }

  async function sessionRoute(req, res, auth) {
    if (req.method === 'GET' || req.method === 'HEAD') return sendJson(req, res, sessionPayload(auth));
    if (req.method === 'DELETE') {
      if (!isSameOriginWrite(req)) return sendError(req, res, 403, 'Cross-site sign-out requests are not allowed.');
      res.writeHead(204, { ...API_HEADERS, 'Cache-Control': 'no-store' });
      return res.end();
    }
    return methodNotAllowed(req, res, ['GET', 'DELETE']);
  }

  async function refreshRoute(req, res, url, auth) {
    if (req.method === 'GET' || req.method === 'HEAD') {
      return sendJson(req, res, { status: await currentStatus(config.dataDir), can_refresh: auth.user.owner });
    }
    if (req.method !== 'POST') return methodNotAllowed(req, res, ['GET', 'POST']);
    if (!isSameOriginWrite(req)) return sendError(req, res, 403, 'Cross-site refresh requests are not allowed.');
    if (!auth.user.owner) return sendError(req, res, 403, 'Only the dashboard owner can start a data refresh. It runs by itself every morning at 07:00 Bangkok.');
    const force = url.searchParams.get('force') === '1';
    const started = await startRefresh({ force, requestedBy: auth.user.email, trigger: 'manual' });
    if (started.running) {
      const age = started.started_at ? Date.now() - Date.parse(started.started_at) : NaN;
      return sendError(req, res, 409, `A refresh is already running${Number.isFinite(age) ? ` (started ${Math.max(1, Math.round(age / 60_000))} min ago)` : ''}. Check back in a few minutes.`);
    }
    if (!started.started) return sendError(req, res, 503, `The refresh could not be started: ${started.error ?? 'unknown reason'}`);
    log.info(`api: manual refresh started${force ? ' (forced)' : ''}`);
    return sendJson(req, res, { started: true, force, message: 'Refresh started. It usually takes 1 to 3 minutes; reload GET /api/refresh to follow it.' }, { status: 202 });
  }

  async function imageRoute(req, res, path) {
    if (req.method !== 'GET' && req.method !== 'HEAD') return methodNotAllowed(req, res, ['GET']);
    const m = /^\/img\/([^/]+)\/([^/]+)\/?$/.exec(path);
    const platform = m ? m[1] : '';
    const id = m ? m[2] : '';
    if (platform !== 'meta' && platform !== 'tiktok') return sendError(req, res, 400, 'Unknown platform: use meta or tiktok.');
    if (!/^\d{1,30}$/.test(id)) return sendError(req, res, 400, 'The ad id must contain digits only.');
    const found = await findCreative(config.dataDir, platform, id);
    if (!found) return sendError(req, res, 404, 'No saved creative for this ad.', { 'Cache-Control': 'private, no-store' });
    const etag = `"${found.size.toString(16)}-${Math.floor(found.mtimeMs).toString(16)}"`;
    const headers = { ...API_HEADERS, 'Content-Security-Policy': "default-src 'none'; sandbox", 'Cache-Control': 'private, max-age=86400', ETag: etag };
    if ((req.headers['if-none-match'] || '').trim() === etag) {
      res.writeHead(304, headers);
      return res.end();
    }
    const bytes = await readFile(found.path);
    return send(req, res, 200, { ...headers, 'Content-Type': sniffStored(bytes) ?? 'application/octet-stream' }, bytes);
  }

  async function staticRoute(req, res, path) {
    if (req.method !== 'GET' && req.method !== 'HEAD') return methodNotAllowed(req, res, ['GET']);
    if (path.startsWith('/data/')) {
      const name = path.slice('/data/'.length);
      if (!STATIC_NAMES.includes(name)) return sendError(req, res, 404, 'Not found.');
      await ensureStatic().catch((err) => log.error(`build-static: ${err?.message ?? err}`));
      const file = await staticFilePath(config, name);
      return file ? sendFile(req, res, file, { type: TYPES['.js'] }) : sendError(req, res, 404, 'Not found.');
    }
    const rel = path === '/' ? 'index.html' : path.slice(1);
    const full = normalizePath(join(config.publicDir, rel));
    if (!full.startsWith(config.publicDir + sep)) return sendError(req, res, 404, 'Not found.');
    return sendFile(req, res, full);
  }

  return async function handle(req, res) {
    let url;
    try {
      if (!req.url || req.url.length > 4096 || !req.url.startsWith('/')) throw new Error('bad url');
      url = new URL(req.url, 'http://dashboard.invalid');
    } catch {
      return sendError(req, res, 400, 'Bad request.');
    }
    let path;
    try {
      path = decodeURIComponent(url.pathname);
    } catch {
      return sendError(req, res, 400, 'Bad request.');
    }
    if (path.includes('\0') || path.includes('\\') || path.split('/').includes('..')) return sendError(req, res, 400, 'Bad request.');
    if (!['GET', 'HEAD', 'POST', 'DELETE'].includes(req.method)) return methodNotAllowed(req, res, ['GET', 'POST', 'DELETE']);
    if (isCrossSiteSubresource(req)) return sendError(req, res, 403, 'Cross-site requests are not allowed.');

    // ----- public -----
    if (path === '/healthz') {
      const snap = await snapshots.get().catch(() => null);
      return sendJson(req, res, { ok: true, snapshot: snap ? snap.version : null });
    }
    if (path === '/login.html') {
      if (req.method !== 'GET' && req.method !== 'HEAD') return methodNotAllowed(req, res, ['GET']);
      const who = identify(req, config);
      return sendHtml(req, res, 200, loginPage(who.ok ? { reason: who.mode === 'tailscale' ? 'signed_in' : 'local', login: who.user.email } : { reason: who.reason, login: who.login }));
    }
    if (PUBLIC_ASSETS.has(path)) {
      if (req.method !== 'GET' && req.method !== 'HEAD') return methodNotAllowed(req, res, ['GET']);
      return sendFile(req, res, join(config.publicDir, 'assets', 'groov-logo.png'), { type: 'image/png' });
    }

    // ----- everything else needs an identity -----
    const auth = identify(req, config);
    if (!auth.ok) {
      if (isPageLoad(req) && !path.startsWith('/api/') && !path.startsWith('/img/')) return sendHtml(req, res, auth.status, loginPage({ reason: auth.reason, login: auth.login }));
      return sendError(req, res, auth.status, auth.error);
    }

    if (path.startsWith('/api/')) {
      if (DATA_ROUTES.has(path)) return dataRoute(req, res, url);
      if (path === '/api/session') return sessionRoute(req, res, auth);
      if (path === '/api/refresh') return refreshRoute(req, res, url, auth);
      return sendError(req, res, 404, 'Not found.');
    }
    if (path.startsWith('/img/')) return imageRoute(req, res, path);
    if (NOT_SERVED.some((re) => re.test(path))) return sendError(req, res, 404, 'Not found.');
    return staticRoute(req, res, path);
  };
}
