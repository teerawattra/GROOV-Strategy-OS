// The VPS server's own /login.html (the Google sign-in page of the Netlify build is not used here). There is nothing
// to sign in to: Tailscale tells the server who is asking. The page explains how to get in. No scripts at all; the
// inline <style> is allowed by the CSP's style-src 'unsafe-inline' (the dashboard sets style="" on charts too).

const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

const STYLE = `
:root{--bg:#050708;--card:#11161a;--line:#1f272d;--copper:#ca743e;--ink:#faf9f6;--muted:#959a9c;--warn-bg:#2a1512;--warn-line:#6b2c22;--warn-ink:#ffb4a6;
--font:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,"Noto Sans Thai",sans-serif}
*,*::before,*::after{box-sizing:border-box}html,body{margin:0;min-height:100%}
body{background:var(--bg);background-image:radial-gradient(1200px 600px at 50% -10%,rgba(202,116,62,.14),transparent 60%);color:var(--ink);font:16px/1.5 var(--font);-webkit-font-smoothing:antialiased}
.page{min-height:100vh;min-height:100dvh;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:20px;padding:32px 16px}
.card{width:100%;max-width:440px;background:var(--card);border:1px solid var(--line);border-top:3px solid var(--copper);border-radius:18px;padding:36px 28px 28px;text-align:center;box-shadow:0 24px 60px rgba(0,0,0,.45)}
.logo{display:block;width:156px;max-width:60%;height:auto;margin:0 auto 22px}
h1{margin:0;font-size:1.5rem;line-height:1.25}
.lead{margin:10px 0 0;color:var(--muted)}
.msg{margin:22px 0 0;padding:12px 14px;border-radius:12px;text-align:left;font-size:.95rem}
.msg.warn{background:var(--warn-bg);border:1px solid var(--warn-line);color:var(--warn-ink)}
.msg.ok{background:#0f2a35;border:1px solid #173e50;color:#d8f4ff}
ol{margin:18px 0 0;padding-left:1.3em;text-align:left;color:var(--ink);font-size:.95rem}li{margin:6px 0}
code{background:#0b0f12;border:1px solid var(--line);border-radius:6px;padding:1px 6px;font-size:.88em}
a.btn{display:inline-block;margin-top:22px;background:var(--copper);color:#160b04;font-weight:700;text-decoration:none;padding:10px 18px;border-radius:10px}
.pill{display:inline-block;border:1px solid #72a8b9;background:#173e50;color:#d8f4ff;border-radius:999px;padding:4px 10px;font-weight:700;font-size:12px}
`;

/**
 * @param {{ reason?: 'no_identity'|'not_allowed'|'funnel'|'signed_in'|'local'|null, login?: string|null }} [state]
 */
export function loginPage({ reason = null, login = null } = {}) {
  let message;
  if (reason === 'signed_in') {
    message = `<p class="msg ok" role="status">Signed in via Tailscale as <b>${esc(login)}</b>.</p><a class="btn" href="/">Open the dashboard</a>`;
  } else if (reason === 'local') {
    message = '<p class="msg ok" role="status">Local test mode (AUTH_MODE=none): no sign-in on this machine.</p><a class="btn" href="/">Open the dashboard</a>';
  } else if (reason === 'not_allowed') {
    message = `<p class="msg warn" role="alert">Your Tailscale account <b>${esc(login)}</b> is not on this dashboard's allow-list. Ask Finn to add it.</p>`;
  } else if (reason === 'funnel') {
    message = '<p class="msg warn" role="alert">This dashboard is private to the GROOV tailnet and is not available on the public internet.</p>';
  } else {
    message = `<p class="msg warn" role="alert">Open this dashboard through your Tailscale address; your Tailscale account must be on the allow-list.</p>
<ol>
<li>Install Tailscale on this device (<code>tailscale.com/download</code>) and log in with the GROOV tailnet account.</li>
<li>Open the dashboard's Tailscale address, e.g. <code>https://groov-vps.&lt;tailnet&gt;.ts.net</code> (Finn has it).</li>
<li>If it still says this, ask Finn to add your Tailscale login to the allow-list.</li>
</ol>`;
  }
  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<meta name="color-scheme" content="dark">
<meta name="theme-color" content="#050708">
<title>Sign in · GROOV Ads Command Center</title>
<link rel="icon" type="image/png" href="/assets/groov-logo.png">
<style>${STYLE}</style>
</head>
<body>
<main class="page">
<section class="card" aria-labelledby="title">
<img class="logo" src="/assets/groov-logo.png" alt="GROOV Strategy" width="514" height="180">
<h1 id="title">Ads Command Center</h1>
<p class="lead">Private to the GROOV tailnet. There is no password: Tailscale tells the dashboard who you are.</p>
${message}
</section>
<p><span class="pill">Read-only · no ad changes</span></p>
</main>
</body>
</html>
`;
}
