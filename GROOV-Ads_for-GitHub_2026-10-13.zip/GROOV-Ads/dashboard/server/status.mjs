// `node server/cli.mjs status`: what is stored, what is served, what ran last. Counts, dates and paths only:
// no key, no URLs, no client numbers beyond the daily spend total used for the Windsor cross-check.

import { DATASETS, DATASET_IDS, enabledDatasets } from '../lib/datasets.mjs';
import { describeConfig } from './config.mjs';
import { listSavedCreatives } from './images.mjs';
import { currentStatus, lockIsLive, readLock } from './refresh.mjs';
import { listVersions, readCurrent, versionTime } from './snapshot.mjs';
import { datasetDiskUsage, listDates, readPartition, spendOf } from './store.mjs';
import { addDays, baht, int, localStamp, mapLimit, todayIn } from './util.mjs';

const WINDOW_DAYS = 60;

/** Status as data (status --json prints it as is). */
export async function collectStatus(config, { now = new Date() } = {}) {
  const today = todayIn(config.tzReport, now);
  const yesterday = addDays(today, -1);
  const enabled = new Set(enabledDatasets(config));
  const datasets = {};
  for (const id of DATASET_IDS) {
    const dates = await listDates(config.dataDir, id);
    const envelopes = await mapLimit(dates, 8, (d) => readPartition(config.dataDir, id, d).catch(() => null));
    const rowsOf = new Map();
    let rows = 0;
    let damaged = 0;
    dates.forEach((d, i) => {
      const e = envelopes[i];
      if (!e) {
        damaged++;
        return;
      }
      rowsOf.set(d, e.rows.length);
      rows += e.rows.length;
    });
    const first = dates[0] ?? null;
    const last = dates[dates.length - 1] ?? null;
    const withRows = dates.filter((d) => rowsOf.get(d) > 0);
    const lastEnvelope = envelopes[envelopes.length - 1] ?? null;
    const notPulled = [];
    const empty = [];
    // Gaps are counted from the first day Windsor had rows (days pulled before the history starts are not gaps).
    const from = withRows[0] ?? first;
    if (from) {
      const start = addDays(yesterday, -(WINDOW_DAYS - 1));
      const stored = new Set(dates);
      for (let d = start > from ? start : from; d <= yesterday; d = addDays(d, 1)) {
        if (!stored.has(d)) notPulled.push(d);
        else if (rowsOf.get(d) === 0) empty.push(d);
      }
    }
    datasets[id] = {
      label: DATASETS[id].label,
      enabled: enabled.has(id),
      first_date: first,
      last_date: last,
      first_date_with_rows: withRows[0] ?? null,
      last_date_with_rows: withRows[withRows.length - 1] ?? null,
      partitions: dates.length,
      rows,
      damaged_partitions: damaged,
      last_day: lastEnvelope ? { date: lastEnvelope.date, rows: lastEnvelope.rows.length, spend: spendOf(lastEnvelope.rows), fetched_at: lastEnvelope.fetched_at ?? null } : null,
      missing_last_60_days: { not_pulled: notPulled, no_rows: empty },
      disk_bytes: (await datasetDiskUsage(config.dataDir, id)).bytes,
    };
  }
  const cur = await readCurrent(config.dataDir).catch(() => null);
  const versions = await listVersions(config.dataDir).catch(() => []);
  const describe = (v) => {
    if (!v) return null;
    const m = v.manifest;
    const created = Date.parse(m.created_at) || versionTime(v.version);
    return {
      version: v.version, created_at: m.created_at, age_hours: Math.round(((now.getTime() - created) / 3_600_000) * 10) / 10,
      reason: m.reason ?? null, data_through: m.data_through, history_from: m.history_from, rows: m.rows,
      breakdown_rows: m.breakdown_rows ?? null, warnings: m.warnings ?? [],
    };
  };
  const currentV = cur ? versions.find((v) => v.version === cur.version) ?? null : null;
  const previousV = cur?.previous ? versions.find((v) => v.version === cur.previous) ?? null : versions.find((v) => cur && v.version < cur.version) ?? null;
  const creatives = await listSavedCreatives(config.dataDir);
  const lock = await readLock(config.dataDir);
  return {
    generated_at: now.toISOString(),
    local_time: `${localStamp(config.tzReport, now)} (${config.tzReport})`,
    complete_through: yesterday,
    config: describeConfig(config),
    datasets,
    snapshot: {
      current: describe(currentV),
      previous: describe(previousV),
      kept: versions.map((v) => v.version),
      current_missing: Boolean(cur && !currentV),
    },
    creatives: { ...creatives.counts, total: creatives.saved.size },
    last_run: await currentStatus(config.dataDir, { now: now.getTime() }),
    lock: lock && lockIsLive(lock) ? { command: lock.command ?? null, pid: lock.pid, started_at: lock.started_at } : null,
  };
}

function listDatesShort(list) {
  if (!list.length) return '';
  return list.length <= 5 ? list.join(', ') : `${list.slice(0, 5).join(', ')} … (+${list.length - 5})`;
}

const pad = (s, n) => String(s).padEnd(n);
const lpad = (s, n) => String(s).padStart(n);
const mb = (bytes) => `${(bytes / 1024 / 1024).toFixed(1)} MB`;

/** Status as text for people (and Hermes's reports to Finn). */
export function formatStatus(s) {
  const out = [];
  out.push(`GROOV Command Center · status · ${s.local_time}`);
  const c = s.config;
  out.push(`Settings     data ${c.data_dir} · config ${c.config_dir} · listen ${c.listen} · auth ${c.auth}${c.auth === 'tailscale' ? ` (${c.allowed_users ? `${c.allowed_users} allowed users` : 'any tailnet user'}, ${c.owner_users} owner${c.owner_users === 1 ? '' : 's'})` : ' (LOCAL TESTING ONLY)'}`);
  out.push(`             Windsor key ${c.windsor_key} · refresh ${c.refresh_days} days · breakdowns ${c.breakdowns ? 'on' : 'off'} · complete days through ${s.complete_through}`);
  out.push('');
  out.push(`Raw data (data/raw)   ${pad('first', 11)} ${pad('last', 11)} ${lpad('days', 5)} ${lpad('rows', 9)}  ${pad('last day: rows / spend', 30)} last 60 days (to ${s.complete_through})`);
  for (const [id, d] of Object.entries(s.datasets)) {
    if (!d.enabled && !d.partitions) {
      out.push(`  ${pad(id, 19)} switched off (ENABLE_BREAKDOWNS=0)`);
      continue;
    }
    if (!d.partitions) {
      out.push(`  ${pad(id, 19)} nothing stored yet`);
      continue;
    }
    const lastDay = d.last_day ? `${int(d.last_day.rows)} / ${baht(d.last_day.spend)}` : '';
    const miss = d.missing_last_60_days;
    const gaps = [];
    if (miss.not_pulled.length) gaps.push(`${miss.not_pulled.length} not pulled: ${listDatesShort(miss.not_pulled)}`);
    if (miss.no_rows.length) gaps.push(`${miss.no_rows.length} with no rows: ${listDatesShort(miss.no_rows)}`);
    if (d.damaged_partitions) gaps.push(`${d.damaged_partitions} damaged files`);
    // "first" is the first day Windsor had rows for (days pulled before that are empty); "last" is the last day pulled.
    const pulledFrom = d.first_date_with_rows && d.first_date_with_rows !== d.first_date ? ` (pulled from ${d.first_date}; earlier days had no rows)` : '';
    out.push(`  ${pad(id, 19)} ${pad(d.first_date_with_rows ?? '—', 11)} ${pad(d.last_date, 11)} ${lpad(int(d.partitions), 5)} ${lpad(int(d.rows), 9)}  ${pad(lastDay, 30)} ${gaps.length ? gaps.join(' · ') : 'complete'}${d.enabled ? '' : ' (switched off)'}${pulledFrom}`);
  }
  const disk = Object.values(s.datasets).reduce((n, d) => n + d.disk_bytes, 0);
  out.push(`  on disk ${mb(disk)}`);
  out.push('');
  const snap = s.snapshot;
  out.push('Snapshot');
  if (!snap.current) {
    out.push(snap.current_missing ? '  current      data/current.json names a version that is not on disk; run: node server/cli.mjs snapshot' : '  current      none yet (run backfill or refresh)');
  } else {
    const v = snap.current;
    out.push(`  current      ${v.version} · built ${v.created_at} (${v.age_hours} h ago, ${v.reason ?? 'refresh'}) · data through ${v.data_through ?? 'none'} · ${int(v.rows)} fact rows${v.breakdown_rows ? ` · breakdowns ${int(v.breakdown_rows.placement)} + ${int(v.breakdown_rows.audience)} rows` : ''} · ${v.warnings.length} warnings`);
    for (const w of v.warnings.slice(0, 8)) out.push(`               ! ${w}`);
  }
  if (snap.previous) out.push(`  previous     ${snap.previous.version} · built ${snap.previous.created_at} · data through ${snap.previous.data_through ?? 'none'}`);
  out.push(`  kept         ${snap.kept.length} version${snap.kept.length === 1 ? '' : 's'}${snap.kept.length ? `: ${snap.kept.join(', ')}` : ''}`);
  if (snap.previous) out.push('  roll back    node server/cli.mjs rollback   (serves the previous version; --to <version> for another)');
  out.push('');
  out.push(`Creatives    ${int(s.creatives.total)} saved (meta ${int(s.creatives.meta)}, tiktok ${int(s.creatives.tiktok)})`);
  const r = s.last_run;
  if (!r) out.push('Last run     none recorded');
  else {
    const span = `${r.started_at ?? '?'}${r.finished_at ? ` → ${r.finished_at} (${r.duration_s} s)` : ''}`;
    out.push(`Last run     ${r.command ?? 'refresh'} ${r.state} · ${span}${r.range ? ` · days ${r.range.from}..${r.range.to}` : ''}${Array.isArray(r.warnings) ? ` · ${r.warnings.length} warnings` : ''}`);
    if (r.error) out.push(`               ! ${r.error}`);
  }
  out.push(`Lock         ${s.lock ? `held by ${s.lock.command ?? 'a job'} (pid ${s.lock.pid}) since ${s.lock.started_at}` : 'free'}`);
  return out.join('\n');
}
