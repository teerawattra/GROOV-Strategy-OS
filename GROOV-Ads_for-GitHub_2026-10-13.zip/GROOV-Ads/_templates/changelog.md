# <Client> — Ads changelog

Newest first. One line per live change.

| Date (ICT) | Platform | Entity (ID) | Change (before → after) | Why | Approved by |
|---|---|---|---|---|---|
