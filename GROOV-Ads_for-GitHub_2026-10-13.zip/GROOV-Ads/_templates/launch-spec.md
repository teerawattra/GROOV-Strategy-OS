# Launch: <campaign name>

- **Client / account:**                 · **Platform:** Meta / Google / TikTok
- **Objective:**                        · **Optimisation event:**
- **Flight:** start → end               · **Budget:** daily / lifetime ฿
- **Status:** draft → approved → created (PAUSED) → live

## Ad sets
| Ad set | Audience / targeting | Placements | Budget |
|---|---|---|---|

## Ads
| Ad | Format | Creative file | Primary text | Headline | CTA / destination |
|---|---|---|---|---|---|

## Approval
- [ ] Finn approved spec (date)
- [ ] Created PAUSED — IDs:
- [ ] Activated (date) — logged in changelog
