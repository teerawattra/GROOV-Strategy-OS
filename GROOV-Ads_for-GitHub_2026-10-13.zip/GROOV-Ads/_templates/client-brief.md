# <Client> — Ads brief

- **Accounts:** see `accounts/registry.json`
- **Package / tier:**
- **Monthly ad budget (THB):**   · **Ad-spend fee/rate:**
- **Contract period:**

## Goals & KPIs
| Objective | KPI | Target | Current |
|---|---|---|---|
| | | | |

## Audience
- Core:
- Exclusions:
- Custom / lookalike audiences:

## Always-on structure
| Campaign | Objective | Daily budget | Notes |
|---|---|---|---|

## Do / don't
-
