#!/usr/bin/env python3
"""Build read-only, self-contained TikTok account dashboards from the local daily export."""
from __future__ import annotations

import base64
import hashlib
import html
import json
import mimetypes
import re
import urllib.request
from collections import defaultdict
from datetime import datetime
from pathlib import Path

import creatives
from period import (CURRENT_DATES, PREVIOUS_DATES, CURRENT as CUR_WIN, COMPARISON as PREV_WIN, CUR_LABEL, CUR_SHORT,
                    CUR_UPPER, PREV_LABEL, PREV_SHORT, WINDOW_LABEL, LOGO as GROOV_LOGO, back_link)

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "source" / "tiktok-ad-daily.json"
OUT = ROOT / "html" / "tiktok"
MANIFEST = ROOT / "tiktok-manifest.json"
LOGO = GROOV_LOGO
CURRENT_START, CURRENT_END = CUR_WIN["start"], CUR_WIN["end"]
PREVIOUS_START, PREVIOUS_END = PREV_WIN["start"], PREV_WIN["end"]
ALL_DATES = set(CURRENT_DATES + PREVIOUS_DATES)
COLORS = ["#25f4ee", "#fe2c55", "#ca743e", "#72a8b9", "#e0a17a", "#7fd1bd", "#b991d4"]


def num(v):
    try:
        return float(v or 0)
    except (TypeError, ValueError):
        return 0.0


def esc(v):
    return html.escape(str(v if v is not None else ""), quote=True)


def slugify(s):
    s = re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")
    return s or "account"


def data_uri(path):
    mime = mimetypes.guess_type(str(path))[0] or "application/octet-stream"
    return f"data:{mime};base64," + base64.b64encode(path.read_bytes()).decode("ascii")


def download_image(url):
    if not url:
        return None
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=20) as response:
            content_type = response.headers.get_content_type()
            blob = response.read(5_000_000)
        if len(blob) < 100 or not content_type.startswith("image/"):
            return None
        return f"data:{content_type};base64," + base64.b64encode(blob).decode("ascii")
    except Exception:
        return None


def period_rows(rows, dates):
    date_set = set(dates)
    return [r for r in rows if r.get("date") in date_set]


def aggregate(rows):
    spend = sum(num(r.get("spend")) for r in rows)
    impressions = sum(num(r.get("impressions")) for r in rows)
    reach = sum(num(r.get("reach")) for r in rows)
    clicks = sum(num(r.get("clicks")) for r in rows)
    views = sum(num(r.get("total_play")) for r in rows)
    six_second_views = sum(num(r.get("play_duration_6s")) for r in rows)
    completions = sum(num(r.get("play_over")) for r in rows)
    leads = sum(num(r.get("total_sales_lead")) for r in rows)
    messages = sum(num(r.get("messaging_total_conversation_tiktok_direct_message")) for r in rows)
    conversions = sum(num(r.get("conversions")) for r in rows)
    payment_roas_num = sum(num(r.get("complete_payment_roas")) * num(r.get("spend")) for r in rows)
    onsite_roas_num = sum(num(r.get("onsite_purchases_roas")) * num(r.get("spend")) for r in rows)
    return {
        "spend": spend,
        "impressions": impressions,
        "reach": reach,
        "frequency": impressions / reach if reach else 0,
        "clicks": clicks,
        "ctr": clicks / impressions * 100 if impressions else 0,
        "cpc": spend / clicks if clicks else 0,
        "cpm": spend / impressions * 1000 if impressions else 0,
        "video_views": views,
        "six_second_views": six_second_views,
        "video_completions": completions,
        "leads": leads,
        "cpl": spend / leads if leads else 0,
        "messages": messages,
        "cpr": spend / messages if messages else 0,
        "conversions": conversions,
        "cpa": spend / conversions if conversions else 0,
        "roas": max(payment_roas_num, onsite_roas_num) / spend if spend else 0,
    }


def result_spec(rows):
    first = rows[0] if rows else {}
    objective_type = str(first.get("objective_type") or "").upper()
    objective_name = str(first.get("objective") or "").upper()
    text = objective_type + " " + objective_name + " " + str(first.get("campaign") or "").upper()
    if "MESSAGE" in text or sum(num(r.get("messaging_total_conversation_tiktok_direct_message")) for r in rows) > 0:
        return {"kind": "messaging", "result": "messages", "result_label": "Messages", "metrics": [("messages", "Messages", "integer"), ("ctr", "CTR", "pct"), ("cpm", "CPM", "money"), ("cpr", "CPR", "money")], "cost": "cpr", "cost_label": "CPR"}
    if objective_type == "REACH" or "AWARENESS" in objective_type:
        return {"kind": "awareness", "result": "impressions", "result_label": "Impressions", "metrics": [("impressions", "Impressions", "integer"), ("cpm", "CPM", "money"), ("frequency", "Frequency*", "decimal")], "cost": "cpm", "cost_label": "CPM"}
    if objective_type in {"VIDEO_VIEWS", "ENGAGEMENT"} or "VIDEO" in objective_type or "ENGAGEMENT" in objective_type:
        return {"kind": "engagement", "result": "video_views", "result_label": "Video views", "metrics": [("video_views", "Video views", "integer"), ("ctr", "CTR", "pct"), ("cpc", "CPC", "money")], "cost": "cpc", "cost_label": "CPC"}
    if objective_type == "TRAFFIC" or "TRAFFIC" in objective_type:
        return {"kind": "traffic", "result": "clicks", "result_label": "Clicks", "metrics": [("clicks", "Clicks", "integer"), ("ctr", "CTR", "pct"), ("cpc", "CPC", "money")], "cost": "cpc", "cost_label": "CPC"}
    if objective_type == "LEAD_GENERATION" or "LEAD" in objective_type:
        return {"kind": "lead", "result": "leads", "result_label": "Leads", "metrics": [("leads", "Leads", "integer"), ("ctr", "CTR", "pct"), ("cpm", "CPM", "money"), ("cpl", "CPL", "money")], "cost": "cpl", "cost_label": "CPL"}
    return {"kind": "conversion", "result": "conversions", "result_label": "Conversions", "metrics": [("conversions", "Conversions", "integer"), ("cpa", "CPA", "money"), ("roas", "ROAS", "roas")], "cost": "cpa", "cost_label": "CPA"}


def fmt(value, kind):
    if kind == "money":
        return f"฿{value:,.2f}" if value else "—"
    if kind == "pct":
        return f"{value:.2f}%"
    if kind == "integer":
        return f"{value:,.0f}"
    if kind == "decimal":
        return f"{value:.2f}×" if value else "—"
    if kind == "roas":
        return f"{value:.2f}×" if value else "—"
    return f"{value:,.2f}"


def change(cur, prev):
    return None if prev == 0 else (cur / prev - 1) * 100


def delta_html(cur, prev, lower=False):
    d = change(cur, prev)
    if d is None:
        return '<span class="delta neutral">new / no prior</span>' if cur else '<span class="delta neutral">—</span>'
    good = d < 0 if lower else d > 0
    cls = "neutral" if abs(d) < 0.5 else ("good" if good else "bad")
    return f'<span class="delta {cls}">{d:+.1f}%</span>'


def status_info(rows):
    raw_campaign = next((r.get("campaign_status") for r in reversed(rows) if r.get("campaign_status")), "NOT_PROVIDED")
    raw_operation = next((r.get("campaign_operation_status") for r in reversed(rows) if r.get("campaign_operation_status")), "NOT_PROVIDED")
    enabled = raw_campaign == "CAMPAIGN_STATUS_ENABLE" and raw_operation == "ENABLE"
    delivery_dates = sorted({r.get("date") for r in rows if num(r.get("spend")) > 0 or num(r.get("impressions")) > 0})
    return {
        "enabled": enabled,
        "label": "ACTIVE" if enabled else "PAUSED",
        "campaign_status": raw_campaign,
        "operation_status": raw_operation,
        "opt_status": next((str(r.get("opt_status")) for r in reversed(rows) if r.get("opt_status") is not None), "NOT_PROVIDED"),
        "first_observed": delivery_dates[0] if delivery_dates else None,
        "last_active": delivery_dates[-1] if delivery_dates else None,
    }


def objective_label(rows):
    first = rows[0]
    return f'{first.get("objective_type") or "UNKNOWN"} · {first.get("objective") or "UNKNOWN"}'


def decision(cur, prev, spec, status, level):
    result = cur[spec["result"]]
    prior_result = prev[spec["result"]]
    cost = cur[spec["cost"]]
    prior_cost = prev[spec["cost"]]
    rd, cd = change(result, prior_result), change(cost, prior_cost)
    evidence = f'{spec["result_label"]} {fmt(result, "integer")} ({"no baseline" if rd is None else f"{rd:+.0f}%"}); {spec["cost_label"]} {fmt(cost, "money")} ({"no baseline" if cd is None else f"{cd:+.0f}%"}); spend {fmt(cur["spend"], "money")}.'
    if not status["enabled"]:
        return ("HOLD", "hold", f"Campaign status is paused/disabled. {evidence}", "Confirm the pause is intentional; do not change delivery from this report.")
    if cur["spend"] == 0:
        return ("CHECK DELIVERY", "watch", f"Enabled campaign status but no current delivery. {evidence}", "Check schedule, budget, audience, approval, and parent delivery state in TikTok Ads Manager.")
    if result == 0 and cur["spend"] >= 100:
        return ("INVESTIGATE", "alert", f"Meaningful spend produced zero {spec['result_label'].lower()}. {evidence}", "Validate tracking and creative-to-objective fit before any budget decision.")
    if cd is not None and cd <= -15 and (rd is None or rd >= -10):
        return ("SCALE TEST", "scale", evidence, "Consider a controlled 10% scale test; monitor the same objective KPI daily.")
    if (cd is not None and cd >= 25) or (rd is not None and rd <= -25 and cur["spend"] >= prev["spend"] * 0.8):
        return ("WATCH", "watch", evidence, f"Hold budget and inspect this {level}'s audience/creative inputs before scaling.")
    return ("KEEP STABLE", "stable", evidence, "Maintain the setup and collect another equal comparison window.")


def status_html(status, inherited=False):
    cls = "active" if status["enabled"] else "paused"
    timing = f'Last active {status["last_active"]}' if status["last_active"] else "No delivery in source window"
    qualifier = "Inherited campaign state" if inherited else "Returned campaign state"
    return f'<span class="status {cls}"><b>{status["label"]}</b><small>{esc(timing)} · {qualifier}</small></span>'


def metric_cells(cur, prev, spec):
    cells = []
    for key, label, kind in spec["metrics"]:
        lower = key in {"cpm", "cpc", "cpl", "cpr", "cpa"}
        cells.append(f'<td data-label="{esc(label)}"><strong>{fmt(cur[key], kind)}</strong>{delta_html(cur[key], prev[key], lower)}</td>')
    return "".join(cells)


def decision_html(d):
    label, cls, why, action = d
    return f'<div class="decision"><span class="decision-tag {cls}">{esc(label)}</span><p><b>Why:</b> {esc(why)}<br><b>Decision:</b> {esc(action)}</p></div>'


def source_provides(rows, field):
    """True only when the frozen connector export contains a non-null value."""
    return any(r.get(field) is not None for r in rows)


def daily_trend_groups(rows):
    """Shared trend specification used by every TikTok account dashboard."""
    return [
        {
            "slug": "delivery-audience",
            "title": "Delivery / Audience",
            "metrics": [
                {"key": "spend", "label": "Spend", "kind": "money", "available": True},
                {"key": "impressions", "label": "Impressions", "kind": "integer", "available": True},
                {"key": "reach", "label": "Reach", "kind": "integer", "available": True},
                {"key": "frequency", "label": "Frequency", "kind": "decimal", "available": True},
            ],
        },
        {
            "slug": "click-efficiency",
            "title": "Click Efficiency",
            "metrics": [
                {"key": "clicks", "label": "Total Clicks", "kind": "integer", "available": True},
                {"key": "ctr", "label": "CTR", "kind": "pct", "available": True},
                {"key": "cpc", "label": "CPC", "kind": "money", "available": True},
                {"key": "cpm", "label": "CPM", "kind": "money", "available": True},
            ],
        },
        {
            "slug": "objective-result-performance",
            "title": "Objective / Result Performance",
            "metrics": [
                {"key": "objective_results", "label": "Objective results", "kind": "integer", "available": True},
                {"key": "video_views", "label": "Video views", "kind": "integer", "available": source_provides(rows, "total_play")},
                {"key": "video_completions", "label": "Video completions", "kind": "integer", "available": source_provides(rows, "play_over")},
                {"key": "messages", "label": "Messaging conversations", "kind": "integer", "available": source_provides(rows, "messaging_total_conversation_tiktok_direct_message")},
                {"key": "cost_message", "label": "Cost / message", "kind": "money", "available": source_provides(rows, "messaging_cost_per_conversation_tiktok_direct_message")},
            ],
        },
    ]


def daily_metric_value(rows, metric):
    if metric["key"] == "objective_results":
        spec = result_spec(rows)
        return aggregate(rows)[spec["result"]]
    if metric["key"] == "cost_message":
        messages = sum(num(r.get("messaging_total_conversation_tiktok_direct_message")) for r in rows)
        return sum(num(r.get("spend")) for r in rows) / messages if messages else 0
    return aggregate(rows)[metric["key"]]


def metric_axis_label(value, kind):
    if kind == "money":
        return f"฿{value:,.0f}"
    if kind == "pct":
        return f"{value:.1f}%"
    if kind == "decimal":
        return f"{value:.2f}×"
    return f"{value:,.0f}"


def daily_metric_chart(campaign_groups, metric):
    if not metric["available"]:
        return '<div class="trend-na"><b>N/A</b><span>Not supplied by Windsor/source</span></div>'
    dates = PREVIOUS_DATES + CURRENT_DATES
    values, series = [], []
    for _, group in campaign_groups:
        by_date = defaultdict(list)
        for row in group:
            by_date[row["date"]].append(row)
        vals = [daily_metric_value(by_date.get(date, []), metric) for date in dates]
        values.extend(vals)
        series.append(vals)
    vmax = max(values + [1])
    W, H, L, R, T, B = 620, 220, 56, 15, 18, 34
    iw, ih = W - L - R, H - T - B
    x = lambda i: L + i * iw / (len(dates) - 1)
    y = lambda value: T + ih - value / vmax * ih
    out = [f'<svg viewBox="0 0 {W} {H}" role="img" aria-label="Daily {esc(metric["label"])} by campaign, comparison then current period">']
    current_x = (x(6) + x(7)) / 2
    out.append(f'<rect class="current-window" x="{current_x:.1f}" y="{T}" width="{W-R-current_x:.1f}" height="{ih}"/>')
    for j in range(3):
        yy = T + ih * j / 2
        val = vmax * (1 - j / 2)
        out.append(f'<line x1="{L}" y1="{yy:.1f}" x2="{W-R}" y2="{yy:.1f}"/><text x="{L-7}" y="{yy+4:.1f}" text-anchor="end">{metric_axis_label(val, metric["kind"])}</text>')
    out.append(f'<line class="period-divider" x1="{current_x:.1f}" y1="{T}" x2="{current_x:.1f}" y2="{T+ih}"/>')
    for idx, vals in enumerate(series):
        points = " ".join(f"{x(i):.1f},{y(value):.1f}" for i, value in enumerate(vals))
        out.append(f'<polyline points="{points}" style="stroke:{COLORS[idx % len(COLORS)]}"/>')
    for i, date in enumerate(dates):
        if i in {0, 3, 6, 7, 10, 13}:
            out.append(f'<text x="{x(i):.1f}" y="{H-8}" text-anchor="middle">{date[5:]}</text>')
    return "".join(out) + "</svg>"


def daily_trends_html(campaign_groups, rows):
    legends = "".join(
        f'<span><i style="background:{COLORS[i % len(COLORS)]}"></i>{esc(group[0].get("campaign") or campaign_id)}</span>'
        for i, (campaign_id, group) in enumerate(campaign_groups)
    )
    sections = []
    for group in daily_trend_groups(rows):
        cards = []
        for metric in group["metrics"]:
            cards.append(
                f'<article class="trend-card" data-metric="{esc(metric["key"])}"><h3>{esc(metric["label"])}</h3>'
                f'{daily_metric_chart(campaign_groups, metric)}</article>'
            )
        sections.append(
            f'<section class="trend-group" data-trend-group="{group["slug"]}"><div class="trend-heading"><h3>{esc(group["title"])}</h3>'
            f'<p>Campaign-level daily series · {PREV_SHORT} comparison / {CUR_SHORT} current</p></div>'
            f'<div class="trend-grid">{"".join(cards)}</div></section>'
        )
    return f'<div class="trend-period-key"><span>Comparison · {PREV_SHORT}</span><span class="current-key">Current · {CUR_SHORT}</span></div><div class="legend">{legends}</div>{"".join(sections)}'


def build_account(account_id, account_name, rows, logo_uri):
    current = period_rows(rows, CURRENT_DATES)
    previous = period_rows(rows, PREVIOUS_DATES)
    cur_all, prev_all = aggregate(current), aggregate(previous)

    def groups(key):
        bucket = defaultdict(list)
        for row in rows:
            bucket[str(row.get(key) or "")].append(row)
        return sorted(bucket.items(), key=lambda pair: sum(num(r.get("spend")) for r in pair[1] if r.get("date") in CURRENT_DATES), reverse=True)

    campaign_groups = groups("campaign_id")
    adgroup_groups = groups("adgroup_id")
    ad_groups = groups("ad_id")
    campaign_status = {cid: status_info(group) for cid, group in campaign_groups}

    def entity_data(level, entity_groups):
        out = []
        for entity_id, group in entity_groups:
            first = group[0]
            spec = result_spec(group)
            cur, prev = aggregate(period_rows(group, CURRENT_DATES)), aggregate(period_rows(group, PREVIOUS_DATES))
            cid = str(first.get("campaign_id") or "")
            status = campaign_status[cid]
            name_field = {"campaign": "campaign", "ad group": "adgroup_name", "ad": "ad_name"}[level]
            out.append({"id": entity_id, "name": first.get(name_field) or "Unnamed", "campaign": first.get("campaign") or "Unnamed", "adgroup": first.get("adgroup_name") or "Unnamed", "objective": objective_label(group), "spec": spec, "cur": cur, "prev": prev, "status": status, "decision": decision(cur, prev, spec, status, level), "rows": group, "thumb_url": next((r.get("video_thumbnail_url") for r in reversed(group) if r.get("video_thumbnail_url")), None), "video_url": next((r.get("video_url") for r in reversed(group) if r.get("video_url")), None)})
        return out

    campaigns = entity_data("campaign", campaign_groups)
    adgroups = entity_data("ad group", adgroup_groups)
    ads = entity_data("ad", ad_groups)
    for ad in ads:
        ad["thumb_data"] = creatives.data_uri("tiktok", ad["id"]) or download_image(ad["thumb_url"])

    # Account KPI strip: universal delivery metrics plus total objective results across campaigns.
    objective_results_cur = sum(c["cur"][c["spec"]["result"]] for c in campaigns)
    objective_results_prev = sum(c["prev"][c["spec"]["result"]] for c in campaigns)
    cost_result_cur = cur_all["spend"] / objective_results_cur if objective_results_cur else 0
    cost_result_prev = prev_all["spend"] / objective_results_prev if objective_results_prev else 0
    kpis = [
        ("Spend", cur_all["spend"], prev_all["spend"], "money", False),
        ("Impressions", cur_all["impressions"], prev_all["impressions"], "integer", False),
        ("Clicks", cur_all["clicks"], prev_all["clicks"], "integer", False),
        ("CTR", cur_all["ctr"], prev_all["ctr"], "pct", False),
        ("CPM", cur_all["cpm"], prev_all["cpm"], "money", True),
        ("Objective results†", objective_results_cur, objective_results_prev, "integer", False),
        ("Cost / result†", cost_result_cur, cost_result_prev, "money", True),
    ]
    kpi_html = "".join(f'<article class="kpi"><span>{esc(label)}</span><b>{fmt(cur, kind)}</b>{delta_html(cur, prev, lower)}<small>vs {PREV_SHORT}</small></article>' for label, cur, prev, kind, lower in kpis)

    def table(entity_list, level):
        blocks = []
        for item in entity_list:
            spec = item["spec"]
            parent = "" if level == "Campaign" else (f'<small>{esc(item["campaign"])}' + (f' · {esc(item["adgroup"])}' if level == "Ad" else "") + "</small>")
            headers = "".join(f"<th>{esc(label)}</th>" for _, label, _ in spec["metrics"])
            row = f'''<tr><td data-label="{level}"><strong>{esc(item['name'])}</strong>{parent}<small>{esc(item['objective'])}</small></td><td data-label="Status">{status_html(item['status'], level != 'Campaign')}<small class="raw">{esc(item['status']['campaign_status'])} · {esc(item['status']['operation_status'])} · opt {esc(item['status']['opt_status'])}</small></td><td data-label="Spend"><strong>{fmt(item['cur']['spend'],'money')}</strong>{delta_html(item['cur']['spend'],item['prev']['spend'])}</td>{metric_cells(item['cur'], item['prev'], spec)}<td data-label="Decision">{decision_html(item['decision'])}</td></tr>'''
            blocks.append(f'<div class="table-block"><div class="basis">Objective KPI basis: <b>{esc(spec["kind"])}</b></div><div class="table-scroll"><table><thead><tr><th>{level}</th><th>Status / observed timing</th><th>Spend</th>{headers}<th>Decision</th></tr></thead><tbody>{row}</tbody></table></div></div>')
        return "".join(blocks)

    cards = []
    for ad in ads:
        media = '<div class="media-missing">Thumbnail unavailable</div>'
        if ad["thumb_data"]:
            media = f'<img src="{ad["thumb_data"]}" alt="Video thumbnail for {esc(ad["name"])}">'
        elif ad["thumb_url"]:
            media = '<div class="media-missing">Thumbnail URL supplied but could not be embedded</div>'
        preview = f'<a class="preview" href="{esc(ad["video_url"])}" target="_blank" rel="noreferrer">Open supplied video URL ↗</a>' if ad["video_url"] else '<span class="no-preview">No video URL supplied</span>'
        metrics = "".join(f'<span><b>{fmt(ad["cur"][key], kind)}</b>{esc(label)}</span>' for key, label, kind in ad["spec"]["metrics"])
        cards.append(f'''<article class="ad-card"><div class="media">{media}<span class="platform-mark">TIKTOK</span></div><div class="ad-body"><p class="lineage">{esc(ad['campaign'])} / {esc(ad['adgroup'])}</p><h3>{esc(ad['name'])}</h3>{status_html(ad['status'], True)}<p class="objective">{esc(ad['objective'])} · {esc(ad['spec']['kind'])} basis</p><div class="ad-kpis"><span><b>{fmt(ad['cur']['spend'],'money')}</b>Spend</span>{metrics}</div>{decision_html(ad['decision'])}{preview}</div></article>''')

    objective_notes = []
    for c in campaigns:
        s = c["spec"]
        labels = ", ".join(label for _, label, _ in s["metrics"])
        objective_notes.append(f'<li><b>{esc(c["name"])}</b> — {esc(c["objective"])} → {esc(labels)}</li>')

    html_doc = f'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>GROOV · {esc(account_name)} · TikTok</title>
<style>
:root{{--bg:#050708;--surface:#11161a;--surface2:#171d21;--ink:#faf9f6;--muted:#959a9c;--line:#2a3135;--copper:#ca743e;--copper-soft:#e0a17a;--blue:#72a8b9;--blue-deep:#173e50;--cyan:#25f4ee;--pink:#fe2c55;--good:#7fd1bd;--bad:#f18c9f}}
*{{box-sizing:border-box}}html{{background:var(--bg);scroll-behavior:smooth;overflow-x:hidden}}body{{margin:0;overflow-x:hidden;background:var(--bg);color:var(--ink);font-family:-apple-system,BlinkMacSystemFont,"SF Pro Display","SF Pro Text","Helvetica Neue",Arial,sans-serif;line-height:1.45}}a{{color:var(--cyan)}}.page{{width:min(1640px,100%);margin:auto;min-width:0}}header{{min-height:260px;padding:42px 58px;display:grid;grid-template-columns:190px 1fr 350px;gap:38px;align-items:center;border-bottom:1px solid var(--line);position:relative}}header:after{{content:"";position:absolute;bottom:-1px;left:58px;width:180px;height:3px;background:linear-gradient(90deg,var(--cyan) 0 49%,var(--pink) 51% 100%)}}header img{{width:175px;max-height:90px;object-fit:contain}}.eyebrow{{font-size:11px;letter-spacing:1.7px;color:var(--copper-soft);font-weight:700}}h1{{font-size:clamp(34px,4vw,54px);letter-spacing:-1.8px;line-height:1.02;margin:8px 0 12px}}header p{{color:var(--muted);margin:0;max-width:720px}}.period{{text-align:right;color:var(--muted);font-size:13px;line-height:1.7}}.period b{{color:var(--ink);display:block;font-size:20px}}.readonly{{display:inline-block;border:1px solid var(--line);border-radius:4px;padding:4px 8px;margin-top:10px;font-size:10px;letter-spacing:1.2px}}nav{{position:sticky;top:0;z-index:10;background:#050708f2;border-bottom:1px solid var(--line);padding:0 58px;display:flex;gap:26px;overflow:auto;backdrop-filter:blur(12px)}}nav a{{color:var(--muted);text-decoration:none;padding:14px 0;font-size:12px;white-space:nowrap}}nav a:hover,nav a:focus{{color:var(--ink)}}main{{padding:30px 46px 70px}}.kpis{{display:grid;grid-template-columns:repeat(7,1fr);gap:10px}}.kpi,.panel{{background:var(--surface);border:1px solid #1b2227;box-shadow:0 12px 30px #0005}}.kpi{{padding:18px;min-height:126px}}.kpi span,.kpi small{{display:block;color:var(--muted);font-size:10px;text-transform:uppercase;letter-spacing:.6px}}.kpi b{{font-size:clamp(19px,2vw,28px);display:block;margin:7px 0 2px;letter-spacing:-.5px}}.delta{{font-size:11px!important;text-transform:none!important;font-weight:700;letter-spacing:0!important}}.good{{color:var(--good)!important}}.bad{{color:var(--bad)!important}}.neutral{{color:var(--blue)!important}}.panel{{padding:26px;margin-top:18px}}.panel-head{{display:flex;justify-content:space-between;gap:30px;align-items:end;margin-bottom:19px}}h2{{font-size:27px;letter-spacing:-.6px;margin:0}}.panel-head p{{color:var(--muted);font-size:11px;margin:0;text-align:right}}.chart-grid{{display:grid;grid-template-columns:2fr 1fr;gap:14px}}.chart,.method{{background:var(--surface2);padding:18px;border:1px solid var(--line)}}.trend-period-key{{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:8px}}.trend-period-key span{{padding:5px 8px;border:1px solid var(--line);font-size:9px;color:var(--muted)}}.trend-period-key .current-key{{background:#25f4ee10;border-color:#25f4ee55;color:var(--cyan)}}.trend-group{{margin-top:22px;padding-top:18px;border-top:1px solid var(--line)}}.trend-heading{{display:flex;align-items:end;justify-content:space-between;gap:18px;margin-bottom:10px}}.trend-heading h3{{font-size:18px;margin:0}}.trend-heading p{{font-size:10px;color:var(--muted);margin:0;text-align:right}}.trend-grid{{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}}.trend-card{{min-width:0;background:var(--surface2);border:1px solid var(--line);padding:13px}}.trend-card h3{{font-size:12px;margin:0 0 6px;color:var(--copper-soft)}}.trend-na{{min-height:220px;display:grid;place-content:center;text-align:center;border:1px dashed var(--line);color:var(--muted)}}.trend-na b{{font-size:28px;color:var(--ink)}}.trend-na span{{font-size:10px}}svg{{width:100%;display:block}}svg line{{stroke:var(--line)}}svg .period-divider{{stroke:var(--cyan);stroke-dasharray:4 4}}svg .current-window{{fill:#25f4ee08}}svg polyline{{fill:none;stroke-width:2.5;vector-effect:non-scaling-stroke}}svg text{{fill:var(--muted);font-size:10px}}.legend{{display:flex;gap:8px 16px;flex-wrap:wrap;margin-top:10px}}.legend span{{font-size:10px;color:var(--muted)}}.legend i{{width:8px;height:8px;border-radius:50%;display:inline-block;margin-right:5px}}.method h3{{margin:0 0 10px;font-size:15px}}.method ul{{padding-left:18px;color:var(--muted);font-size:12px}}.method li{{margin:8px 0}}.table-block{{margin-top:12px;border:1px solid var(--line)}}.basis{{padding:9px 12px;background:var(--surface2);font-size:10px;color:var(--muted);text-transform:uppercase;letter-spacing:.6px}}.table-scroll{{overflow:auto}}table{{width:100%;border-collapse:collapse;min-width:1050px}}th{{font-size:9px;color:var(--muted);text-transform:uppercase;letter-spacing:.7px;text-align:left;padding:10px 12px;background:#0c1013}}td{{vertical-align:top;padding:13px 12px;border-top:1px solid var(--line);font-size:12px}}td strong{{display:block}}td small{{display:block;color:var(--muted);font-size:9px;margin-top:4px}}.raw{{max-width:220px;word-break:break-word}}.status{{display:inline-flex;flex-direction:column;border:1px solid var(--line);padding:6px 8px;min-width:130px}}.status b{{font-size:10px;letter-spacing:.8px}}.status small{{font-size:8px;margin:2px 0 0;color:var(--muted)}}.status.active{{border-color:#3e8275}}.status.active b{{color:var(--cyan)}}.status.paused{{border-color:#7e3948}}.status.paused b{{color:var(--pink)}}.decision{{min-width:250px}}.decision-tag{{font-size:9px;padding:4px 7px;border:1px solid;letter-spacing:.8px;font-weight:800}}.decision-tag.scale{{color:var(--cyan)}}.decision-tag.watch,.decision-tag.alert{{color:var(--pink)}}.decision-tag.stable{{color:var(--blue)}}.decision-tag.hold{{color:var(--muted)}}.decision p{{font-size:10px;color:var(--muted);margin:8px 0 0}}.ad-grid{{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px}}.ad-card{{background:var(--surface2);border:1px solid var(--line);display:grid;grid-template-columns:minmax(140px,180px) 1fr;align-items:start;min-width:0}}.media{{position:relative;background:#090c0e;aspect-ratio:4/5;width:100%;overflow:hidden}}.media img{{width:100%;height:100%;object-fit:cover;display:block}}.media-missing{{height:100%;display:grid;place-items:center;padding:18px;color:var(--muted);font-size:10px;text-align:center}}.platform-mark{{position:absolute;left:8px;top:8px;background:#050708d9;padding:4px 6px;font-size:8px;letter-spacing:1px;border-bottom:1px solid var(--cyan);box-shadow:2px 2px 0 var(--pink)}}.ad-body{{padding:16px;min-width:0}}.lineage,.objective{{color:var(--muted);font-size:9px;margin:0 0 6px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}}.ad-body h3{{font-size:16px;margin:0 0 11px;word-break:break-word}}.ad-kpis{{display:grid;grid-template-columns:repeat(2,1fr);gap:7px;margin:12px 0}}.ad-kpis span{{font-size:8px;color:var(--muted);text-transform:uppercase}}.ad-kpis b{{font-size:13px;color:var(--ink);display:block}}.preview,.no-preview{{display:inline-block;margin-top:12px;font-size:10px}}footer{{margin-top:20px;padding:24px;color:var(--muted);font-size:11px;border-top:1px solid var(--line)}}footer p{{max-width:1200px}}code{{color:var(--copper-soft)}}
@media(max-width:1200px){{.kpis{{grid-template-columns:repeat(4,1fr)}}.ad-grid{{grid-template-columns:repeat(2,1fr)}}header{{grid-template-columns:150px 1fr 250px;padding:34px}}nav{{padding:0 34px}}}}
@media(max-width:760px){{header{{display:block;padding:28px 20px}}header img{{width:120px;margin-bottom:28px}}.period{{text-align:left;margin-top:20px}}nav{{padding:0 20px}}main{{padding:20px 12px 50px}}.kpis{{grid-template-columns:repeat(2,1fr)}}.panel{{padding:16px}}.panel-head,.trend-heading{{display:block}}.panel-head p,.trend-heading p{{text-align:left;margin-top:7px}}.chart-grid,.trend-grid,.ad-grid{{grid-template-columns:1fr}}.ad-card{{grid-template-columns:120px 1fr}}h2{{font-size:23px}}}}
@media(max-width:440px){{.kpis{{grid-template-columns:1fr 1fr}}.ad-card{{grid-template-columns:1fr}}}}
</style></head><body>{back_link()}<div class="page">
<header><img src="{logo_uri}" alt="GROOV logo"><div><div class="eyebrow">CLIENT PERFORMANCE · TIKTOK ADS</div><h1>{esc(account_name)}</h1><p>Objective-aware delivery review across campaign, ad group, and ad levels. Exact source names, returned campaign status, and supplied video previews only.</p></div><div class="period"><b>{CUR_UPPER}</b>vs {PREV_LABEL}<br>Currency shown as THB<div class="readonly">READ ONLY · LOCAL EXPORT</div></div></header>
<nav><a href="#overview">Overview</a><a href="#trends">Daily trends</a><a href="#campaigns">Campaigns</a><a href="#adgroups">Ad groups</a><a href="#ads">Ads</a><a href="#notes">Data notes</a></nav>
<main><section id="overview" class="kpis">{kpi_html}</section>
<section id="trends" class="panel"><div class="panel-head"><h2>Expanded daily trends</h2><p>Both exact seven-day periods · one line per campaign</p></div>{daily_trends_html(campaign_groups, rows)}<aside class="method" style="margin-top:18px"><h3>Objective hierarchy used</h3><ul>{''.join(objective_notes)}</ul><p>† Objective results use each campaign’s objective-appropriate result (impressions for reach, clicks for traffic, video views for engagement, leads or conversions where applicable). Cross-objective totals are directional, not interchangeable outcomes.</p></aside></section>
<section id="campaigns" class="panel"><div class="panel-head"><h2>Campaign decisions</h2><p>{len(campaigns)} campaign{'s' if len(campaigns)!=1 else ''} · exact source names · current vs prior</p></div>{table(campaigns,'Campaign')}</section>
<section id="adgroups" class="panel"><div class="panel-head"><h2>Ad group decisions</h2><p>{len(adgroups)} ad group{'s' if len(adgroups)!=1 else ''} · campaign status inherited because ad-group status was not supplied</p></div>{table(adgroups,'Ad group')}</section>
<section id="ads" class="panel"><div class="panel-head"><h2>Ad decisions & video previews</h2><p>{len(ads)} ads · thumbnails embedded where source URLs remained available</p></div>{table(ads,'Ad')}<div class="ad-grid" style="margin-top:18px">{''.join(cards)}</div></section>
<footer id="notes"><p><b>Period integrity:</b> All displayed performance uses {CUR_LABEL} and compares with the equal seven-day window {PREV_LABEL}. Source: <code>source/tiktok-ad-daily.json</code>. No ad platform was queried or modified.</p><p><b>Status and timing limitations:</b> The export supplies campaign-level <code>campaign_status</code>, <code>campaign_operation_status</code>, and <code>opt_status</code>, but no distinct ad-group/ad status or scheduled start/end timestamps. Campaign state is shown verbatim and inherited by child rows; it does not prove child-level eligibility. “Last active” is the latest date with spend or impressions inside the available {WINDOW_LABEL} source window—not a platform lifecycle timestamp. A “Started” date is intentionally not shown because the source does not support it.</p><p><b>Metric limitations:</b> *Frequency is calculated as summed daily impressions ÷ summed daily reach. Because cross-day audience overlap is unavailable, this is a reported-day frequency proxy, not deduplicated seven-day frequency. Windsor/source supplied messaging-conversation counts (all zero in this frozen snapshot) but did not supply cost per message; cost per message is therefore shown as N/A, never as zero. ROAS uses the larger spend-weighted value from the two supplied TikTok ROAS fields. Zero-denominator cost metrics are shown as em dashes. Decisions are diagnostic prompts, not changes or automated recommendations.</p></footer></main></div></body></html>'''

    slug = slugify(account_name)
    out_path = OUT / f"{slug}.html"
    out_path.write_text(html_doc, encoding="utf-8")
    return {
        "account_id": account_id,
        "account_name": account_name,
        "slug": slug,
        "html": str(out_path.relative_to(ROOT)),
        "source_rows": len(rows),
        "current_rows": len(current),
        "previous_rows": len(previous),
        "current_spend": round(cur_all["spend"], 2),
        "current_impressions": int(cur_all["impressions"]),
        "campaigns": len(campaigns),
        "adgroups": len(adgroups),
        "ads": len(ads),
        "daily_trend_groups": 3,
        "daily_trend_metrics": sum(len(group["metrics"]) for group in daily_trend_groups(rows)),
        "unavailable_connector_kpis": [metric["label"] for group in daily_trend_groups(rows) for metric in group["metrics"] if not metric["available"]],
        "creative_thumbnail_urls": sum(bool(ad["thumb_url"]) for ad in ads),
        "embedded_thumbnails": sum(bool(ad["thumb_data"]) for ad in ads),
        "creative_embed_failures": sum(bool(ad["thumb_url"]) and not bool(ad["thumb_data"]) for ad in ads),
        "embedded_assets": sum(bool(ad["thumb_data"]) for ad in ads) + bool(logo_uri),
        "video_urls": sum(bool(ad["video_url"]) for ad in ads),
        "sha256": hashlib.sha256(out_path.read_bytes()).hexdigest(),
        "bytes": out_path.stat().st_size,
    }


def main():
    if not SOURCE.exists():
        raise SystemExit(f"Missing source: {SOURCE}")
    raw = json.loads(SOURCE.read_text(encoding="utf-8"))
    if not isinstance(raw, list):
        raise SystemExit("Expected the source JSON to be a list")
    window = [r for r in raw if r.get("date") in ALL_DATES]
    grouped = defaultdict(list)
    for row in window:
        grouped[(str(row.get("account_id")), str(row.get("account_name")))].append(row)
    selected = []
    for key, rows in grouped.items():
        current = period_rows(rows, CURRENT_DATES)
        if sum(num(r.get("spend")) for r in current) > 0 or sum(num(r.get("impressions")) for r in current) > 0:
            selected.append((key, rows))
    selected.sort(key=lambda item: item[0][1].lower())
    OUT.mkdir(parents=True, exist_ok=True)
    for old in OUT.glob("*.html"):
        old.unlink()
    logo_uri = data_uri(LOGO) if LOGO.exists() else ""
    dashboards = [build_account(account_id, name, rows, logo_uri) for (account_id, name), rows in selected]
    manifest = {
        "generated_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "read_only": True,
        "source": str(SOURCE.relative_to(ROOT)),
        "source_total_rows": len(raw),
        "period": {"current": [CURRENT_START, CURRENT_END], "comparison": [PREVIOUS_START, PREVIOUS_END]},
        "selection_rule": "current spend > 0 or current impressions > 0",
        "daily_trend_standard": ["Delivery / Audience", "Click Efficiency", "Objective / Result Performance"],
        "unavailable_connector_kpis": ["Cost / message"],
        "accounts": len(dashboards),
        "dashboards": dashboards,
    }
    MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(manifest, ensure_ascii=False))


if __name__ == "__main__":
    main()
