"""Shared reporting windows and paths for every GROOV dashboard builder.

Current period = the latest seven completed Bangkok days; comparison = the seven before that.
Override the last completed day with GROOV_PERIOD_END=YYYY-MM-DD (e.g. to rebuild a frozen snapshot).
"""
from __future__ import annotations

import os
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

BKK = timezone(timedelta(hours=7))
ROOT = Path(__file__).resolve().parent            # Ads/command-center
ADS_ROOT = ROOT.parent                            # Ads/
SOURCE = ROOT / "source"
HTML_DIR = ROOT / "html"
LOGO = ADS_ROOT / "assets" / "groov-logo.png"
DAYS = 7


def today_bkk() -> date:
    return datetime.now(BKK).date()


def _end() -> date:
    override = os.environ.get("GROOV_PERIOD_END")
    if override:
        return date.fromisoformat(override)
    return today_bkk() - timedelta(days=1)


def _range(start: date, end: date) -> list[str]:
    return [(start + timedelta(days=i)).isoformat() for i in range((end - start).days + 1)]


END = _end()
START = END - timedelta(days=DAYS - 1)
PREV_END = START - timedelta(days=1)
PREV_START = PREV_END - timedelta(days=DAYS - 1)

CURRENT_DATES = _range(START, END)
PREVIOUS_DATES = _range(PREV_START, PREV_END)
CURRENT = {"start": START.isoformat(), "end": END.isoformat()}
COMPARISON = {"start": PREV_START.isoformat(), "end": PREV_END.isoformat()}
FETCH_FROM, FETCH_TO = PREV_START, END


def label(start: date, end: date, year: bool = True, upper: bool = False) -> str:
    """'14–20 Sep 2026' or '26 Sep–2 Oct 2026'."""
    if start.month == end.month and start.year == end.year:
        text = f"{start.day}–{end.day} {end:%b}"
    else:
        text = f"{start.day} {start:%b}–{end.day} {end:%b}"
    if year:
        text += f" {end.year}"
    return text.upper() if upper else text


CUR_LABEL = label(START, END)                  # 14–20 Sep 2026
CUR_SHORT = label(START, END, year=False)      # 14–20 Sep
CUR_UPPER = label(START, END, upper=True)      # 14–20 SEP 2026
PREV_LABEL = label(PREV_START, PREV_END)       # 7–13 Sep 2026
PREV_SHORT = label(PREV_START, PREV_END, year=False)
WINDOW_LABEL = label(PREV_START, END, year=False)  # 7–20 Sep
GENERATED = datetime.now(BKK).strftime("%-d %b %Y, %H:%M")


def back_link(depth: int = 1) -> str:
    """'Back to Command Center' bar for account pages (html/<platform>/<slug>.html)."""
    href = "../" * depth + "index.html"
    return (f'<nav class="groov-back-bar"><a class="groov-back" href="{href}">← Command Center</a></nav>'
            '<style>.groov-back-bar{background:#050708;padding:12px clamp(12px,3vw,42px) 0}.groov-back{display:inline-block;color:#faf9f6;'
            'border:1px solid #ca743e;border-radius:999px;padding:7px 13px;font:600 12px -apple-system,BlinkMacSystemFont,sans-serif;'
            'text-decoration:none}.groov-back:hover{background:#ca743e}</style>')
