#!/usr/bin/env python3
"""Stage the live artifact: live/index.html + logo + the creative library (+ index.json of saved ad IDs)."""
import json, shutil
from period import ROOT, LOGO

LIVE = ROOT / "live"
(LIVE / "assets").mkdir(parents=True, exist_ok=True)
shutil.copy(LOGO, LIVE / "assets" / "groov-logo.png")
index = {}
for platform in ("meta", "tiktok"):
    src, dst = ROOT / "creatives" / platform, LIVE / "creatives" / platform
    shutil.rmtree(dst, ignore_errors=True); dst.mkdir(parents=True)
    ids = []
    for f in sorted(src.glob("*.jpg")):
        shutil.copy(f, dst / f.name); ids.append(f.stem)
    index[platform] = ids
(LIVE / "creatives" / "index.json").write_text(json.dumps(index))
print({k: len(v) for k, v in index.items()}, "creatives staged")
