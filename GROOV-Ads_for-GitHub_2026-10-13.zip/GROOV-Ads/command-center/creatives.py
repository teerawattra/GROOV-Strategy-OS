#!/usr/bin/env python3
"""Permanent creative library for the dashboards: creatives/<platform>/<ad_id>.jpg.

Meta/TikTok image URLs expire within days, so every creative the builders can see is saved here
once (resized to <= 720 px, JPEG) and embedded from here on later builds.

Run directly to fill gaps for every ad in source/*.json:
  1. images already downloaded by Output/Ad Creatives ("…__<ad_id>.jpg")
  2. fresh URLs in Output/Ad Creatives/creatives.csv and creatives/fresh-urls.json ({"platform:ad_id": url})
  3. the source snapshot's own URLs (works only while they have not expired)
"""
from __future__ import annotations

import base64
import csv
import io
import json
import re
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from period import ADS_ROOT, ROOT, SOURCE

LIB = ROOT / "creatives"
CREATIVE_LIBRARY = ADS_ROOT.parent / "Output" / "Ad Creatives"
MAX_PX = 720


def path_for(platform: str, ad_id: str) -> Path:
    return LIB / platform.lower() / f"{ad_id}.jpg"


def data_uri(platform: str, ad_id: str) -> str | None:
    """Saved creative for this ad as a data URI, or None (caller shows a declared placeholder)."""
    p = path_for(platform, str(ad_id))
    return "data:image/jpeg;base64," + base64.b64encode(p.read_bytes()).decode() if p.exists() and p.stat().st_size > 100 else None


def save(platform: str, ad_id: str, raw: bytes) -> bool:
    """Normalise any image bytes to a <= MAX_PX JPEG in the library. Returns False if not an image."""
    try:
        from PIL import Image
        img = Image.open(io.BytesIO(raw))
        img = img.convert("RGB")
        img.thumbnail((MAX_PX, MAX_PX * 2))
        out = io.BytesIO(); img.save(out, "JPEG", quality=78, optimize=True, progressive=True)
    except Exception:
        return False
    p = path_for(platform, ad_id); p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(out.getvalue())
    return True


def download(url: str) -> bytes | None:
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=25) as r:
            raw = r.read()
            return raw if len(raw) > 100 and r.headers.get_content_type().startswith("image/") else None
    except Exception:
        return None


def wanted() -> dict[tuple[str, str], list[str]]:
    """(platform, ad_id) -> candidate URLs from the current source snapshots."""
    out: dict[tuple[str, str], list[str]] = {}
    for platform, name, keys in (("meta", "meta-ad-daily.json", ("image_url", "thumbnail_url")), ("tiktok", "tiktok-ad-daily.json", ("video_thumbnail_url",))):
        f = SOURCE / name
        if not f.exists(): continue
        for row in json.loads(f.read_text(encoding="utf-8")):
            urls = out.setdefault((platform, str(row.get("ad_id"))), [])
            urls += [row[k] for k in keys if isinstance(row.get(k), str) and row[k].startswith("http") and row[k] not in urls]
    return out


def main() -> None:
    need = {k: v for k, v in wanted().items() if not path_for(*k).exists()}
    print(f"{len(need)} ads without a saved creative")
    # 1. Output/Ad Creatives downloads
    local = {m.group(1): f for f in CREATIVE_LIBRARY.glob("Images/**/*") if (m := re.search(r"__(\d+)\.\w+$", f.name))}
    for (platform, ad_id) in list(need):
        if ad_id in local and save(platform, ad_id, local[ad_id].read_bytes()):
            need.pop((platform, ad_id))
    print(f"  after local library: {len(need)} missing")
    # 2. fresh URLs (creative-library CSV + any fresh-urls.json written from a Meta/Windsor lookup)
    fresh: dict[tuple[str, str], str] = {}
    csv_path = CREATIVE_LIBRARY / "creatives.csv"
    if csv_path.exists():
        for r in csv.DictReader(open(csv_path, encoding="utf-8-sig")):
            if r.get("image_url"): fresh[(r["platform"].lower(), r["ad_id"])] = r["image_url"]
    extra = LIB / "fresh-urls.json"
    if extra.exists():
        for key, url in json.loads(extra.read_text()).items():
            platform, ad_id = key.split(":", 1); fresh[(platform, ad_id)] = url
    # 3. snapshot URLs as a last resort
    jobs = [(k, ([fresh[k]] if k in fresh else []) + need[k]) for k in need]

    def fetch(job):
        key, urls = job
        for u in urls:
            raw = download(u)
            if raw and save(*key, raw): return key
        return None
    with ThreadPoolExecutor(max_workers=12) as pool:
        for key in pool.map(fetch, jobs):
            if key: need.pop(key)
    print(f"  after fresh URLs: {len(need)} missing")
    (LIB / "missing.json").write_text(json.dumps(sorted(f"{p}:{a}" for p, a in need), indent=1))


if __name__ == "__main__":
    main()
