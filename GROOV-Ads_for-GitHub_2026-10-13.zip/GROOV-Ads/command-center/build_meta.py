#!/usr/bin/env python3
"""Build standalone, read-only Meta account dashboards from local snapshots.

Ported from the Hermes single-client reference (_reference/hermes-package/single-client/build_meta.py);
periods come from period.py and every delivering account gets its own page."""
from __future__ import annotations

import base64
import hashlib
import html
import json
import mimetypes
import re
import unicodedata
import urllib.request
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, date, timedelta
from pathlib import Path
from typing import Any

import creatives
from period import (CURRENT_DATES, PREVIOUS_DATES, CURRENT as CUR_WIN, COMPARISON as PREV_WIN, CUR_UPPER, CUR_SHORT,
                    PREV_LABEL, PREV_SHORT, CUR_LABEL, WINDOW_LABEL, GENERATED, LOGO, back_link)

ROOT = Path(__file__).resolve().parent
DAILY_PATH = ROOT / "source/meta-ad-daily.json"
STATUS_PATH = ROOT / "source/meta-status.json"
CAMPAIGN_DAILY_PATH = ROOT / "source/meta-campaign-daily.json"
LOGO_PATH = LOGO
OUT_DIR = ROOT / "html/meta"
ASSET_CACHE = ROOT / ".meta-image-cache"
MANIFEST_PATH = ROOT / "meta-manifest.json"
def date_range(start: date, end: date) -> list[str]:
    return [(start + timedelta(days=offset)).isoformat() for offset in range((end - start).days + 1)]

CURRENT = set(CURRENT_DATES)
PREVIOUS = set(PREVIOUS_DATES)
WINDOW = CURRENT | PREVIOUS
COLORS = ["#ca743e", "#72a8b9", "#e0a17a", "#7fba9b", "#c589a7", "#9f91d3", "#d6be78", "#6f9fc7"]
ACTIVE = {"ACTIVE", "ENABLED"}


def num(value: Any) -> float:
    try:
        return float(value or 0)
    except (TypeError, ValueError):
        return 0.0


def esc(value: Any) -> str:
    return html.escape(str(value if value is not None else ""), quote=True)


def safe_slug(name: str, account_id: str) -> str:
    text = unicodedata.normalize("NFKD", name).encode("ascii", "ignore").decode().lower()
    text = re.sub(r"[^a-z0-9]+", "-", text).strip("-")
    return text or f"meta-{account_id}"


def money(value: float) -> str:
    return f"฿{value:,.2f}"


def integer(value: float) -> str:
    return f"{value:,.0f}"


def percent(value: float) -> str:
    return f"{value:.2f}%"


def ratio(value: float) -> str:
    return f"{value:.2f}×"


def fmt_date(value: Any) -> str:
    if not value:
        return "Not provided"
    text = str(value)[:10]
    try:
        return datetime.strptime(text, "%Y-%m-%d").strftime("%d %b %Y")
    except ValueError:
        return text


def change(current: float, previous: float) -> float | None:
    if previous == 0:
        return None
    return (current / previous - 1) * 100


def change_text(current: float, previous: float) -> str:
    delta = change(current, previous)
    if delta is None:
        return "new / no baseline" if current else "—"
    return f"{delta:+.0f}%"


def delta_badge(current: float, previous: float, lower_is_better: bool = False) -> str:
    delta = change(current, previous)
    if delta is None:
        return '<span class="delta neutral">new / no prior value</span>' if current else '<span class="delta neutral">—</span>'
    good = delta < 0 if lower_is_better else delta > 0
    cls = "neutral" if abs(delta) < 0.5 else ("good" if good else "bad")
    return f'<span class="delta {cls}">{delta:+.0f}% vs {PREV_SHORT}</span>'


def row_roas(row: dict[str, Any]) -> float:
    omni = row.get("purchase_roas_omni_purchase")
    web = row.get("website_purchase_roas_offsite_conversion_fb_pixel_purchase")
    if omni is not None:
        return num(omni)
    return num(web)


def aggregate(rows: list[dict[str, Any]]) -> dict[str, float]:
    spend = sum(num(r.get("spend")) for r in rows)
    impressions = sum(num(r.get("impressions")) for r in rows)
    reach = sum(num(r.get("reach")) for r in rows)
    clicks = sum(num(r.get("clicks")) for r in rows)
    links = sum(num(r.get("link_clicks")) for r in rows)
    video = sum(num(r.get("actions_video_view")) for r in rows)
    complete = sum(num(r.get("video_p100_watched_actions_video_view")) for r in rows)
    messages = sum(num(r.get("actions_onsite_conversion_messaging_conversation_started_7d")) for r in rows)
    leads = sum(num(r.get("actions_lead")) for r in rows)
    revenue = sum(num(r.get("spend")) * row_roas(r) for r in rows)
    return {
        "spend": spend, "impressions": impressions, "reach": reach, "clicks": clicks,
        "link_clicks": links, "video_views": video, "video_complete": complete,
        "messages": messages, "leads": leads,
        "ctr": clicks / impressions * 100 if impressions else 0,
        "cpc": spend / clicks if clicks else 0,
        "cpc_link": spend / links if links else 0,
        "cpm": spend / impressions * 1000 if impressions else 0,
        "frequency": impressions / reach if reach else 0,
        "cpv": spend / video if video else 0,
        "cpr": spend / messages if messages else 0,
        "cpl": spend / leads if leads else 0,
        "roas": revenue / spend if spend else 0,
    }


def campaign_daily_metrics(row: dict[str, Any] | None) -> dict[str, float | None]:
    """Use campaign-level daily data so Reach/Frequency are not duplicated across ads."""
    row = row or {}
    spend = num(row.get("spend"))
    impressions = num(row.get("impressions"))
    reach = num(row.get("reach"))
    clicks = num(row.get("clicks"))
    messages = num(row.get("actions_onsite_conversion_messaging_conversation_started_7d"))
    return {
        "spend": spend,
        "impressions": impressions,
        "reach": reach,
        "frequency": impressions / reach if reach else None,
        "clicks": clicks,
        "ctr": clicks / impressions * 100 if impressions else None,
        "cpc": spend / clicks if clicks else None,
        "cpm": spend / impressions * 1000 if impressions else None,
        "messages": messages,
        "cost_per_message": spend / messages if messages else None,
    }


def objective_kind(group: list[dict[str, Any]]) -> str:
    """Classify with the required Lead-before-Messages hierarchy."""
    first = group[0]
    objective = str(first.get("objective") or "").upper()
    name = str(first.get("campaign") or "").upper()
    leads = sum(num(r.get("actions_lead")) for r in group)
    messages = sum(num(r.get("actions_onsite_conversion_messaging_conversation_started_7d")) for r in group)
    if "LEAD" in objective or "LEAD" in name or leads > 0:
        return "leads"
    if messages > 0 or any(token in name for token in ("MSG", "MESSAGE", "MESSAGING", "INBOX")):
        return "messages"
    if any(token in objective for token in ("SALES", "CONVERSION", "PURCHASE")) or any(row_roas(r) > 0 for r in group):
        return "conversion"
    if "AWARENESS" in objective or "REACH" in objective:
        return "awareness"
    if "TRAFFIC" in objective or "LINK_CLICK" in objective:
        return "traffic"
    return "engagement"


KIND_LABEL = {
    "awareness": "Awareness", "engagement": "Engagement", "traffic": "Traffic",
    "messages": "Messages", "leads": "Lead generation", "conversion": "Conversion",
}


def kpi_items(kind: str, values: dict[str, float]) -> list[tuple[str, str]]:
    if kind == "awareness":
        return [("CPM", money(values["cpm"])), ("Frequency", f'{values["frequency"]:.2f}×')]
    if kind == "engagement":
        return [("Video views", integer(values["video_views"])), ("CTR", percent(values["ctr"])), ("CPC", money(values["cpc"]))]
    if kind == "traffic":
        return [("Link clicks", integer(values["link_clicks"])), ("CTR", percent(values["ctr"])), ("CPC", money(values["cpc_link"]))]
    if kind == "messages":
        return [("Conversations", integer(values["messages"])), ("CTR", percent(values["ctr"])), ("CPM", money(values["cpm"])), ("CPR", money(values["cpr"]) if values["messages"] else "—")]
    if kind == "leads":
        return [("Leads", integer(values["leads"])), ("CTR", percent(values["ctr"])), ("CPM", money(values["cpm"])), ("CPL", money(values["cpl"]) if values["leads"] else "—")]
    return [("ROAS", ratio(values["roas"]) if values["roas"] else "Not tracked"), ("CTR", percent(values["ctr"])), ("CPM", money(values["cpm"]))]


def result_and_cost(kind: str, values: dict[str, float]) -> tuple[float, float, str, str, bool]:
    if kind == "awareness":
        return values["impressions"], values["cpm"], "Impressions", "CPM", True
    if kind == "engagement":
        return values["video_views"], values["cpv"], "Video views", "Cost / view", True
    if kind == "traffic":
        return values["link_clicks"], values["cpc_link"], "Link clicks", "CPC", True
    if kind == "messages":
        return values["messages"], values["cpr"], "Conversations", "CPR", True
    if kind == "leads":
        return values["leads"], values["cpl"], "Leads", "CPL", True
    return values["roas"], values["roas"], "ROAS", "ROAS", False


def decision_for(kind: str, current: dict[str, float], previous: dict[str, float], operation: dict[str, str]) -> dict[str, str]:
    result, cost, result_label, cost_label, lower_cost = result_and_cost(kind, current)
    prev_result, prev_cost, _, _, _ = result_and_cost(kind, previous)
    result_delta = change(result, prev_result)
    cost_delta = change(cost, prev_cost)
    ctr_delta = change(current["ctr"], previous["ctr"])
    if kind == "conversion":
        evidence = f'ROAS: {ratio(result) if result else "Not tracked"} ({change_text(result, prev_result)}); CTR: {percent(current["ctr"])} ({change_text(current["ctr"], previous["ctr"])}); Spend: {money(current["spend"])}.'
    else:
        cost_text = "—" if kind in ("messages", "leads") and result == 0 else money(cost)
        evidence = f'{result_label}: {integer(result)} ({change_text(result, prev_result)}); {cost_label}: {cost_text} ({change_text(cost, prev_cost)}); CTR: {percent(current["ctr"])} ({change_text(current["ctr"], previous["ctr"])}).'
    is_active = operation["status"] in ACTIVE
    if not is_active and previous["spend"] >= 100 and current["spend"] == 0:
        return {"label": "Immediate Action", "class": "immediate", "why": f'{operation["status"]}; delivery stopped after {money(previous["spend"])} prior spend. {evidence}', "action": "Confirm that the pause or parent-level stop is intentional before making any change."}
    if not is_active:
        return {"label": "No Touching", "class": "hold", "why": f'{operation["status"]}. {evidence}', "action": "Leave unchanged; reactivate only if the campaign plan requires it."}
    if current["spend"] == 0 and current["impressions"] == 0:
        return {"label": "Immediate Action", "class": "immediate", "why": f'Active but no current delivery. {evidence}', "action": "Check schedule, budget, approval, audience and parent delivery status."}
    if kind != "awareness" and kind != "conversion" and result == 0 and current["spend"] >= 100:
        return {"label": "Immediate Action", "class": "immediate", "why": f'{money(current["spend"])} spent with zero {result_label.lower()}. {evidence}', "action": "Validate tracking, then inspect the setup and weakest creative before changing delivery."}
    if kind == "conversion" and current["spend"] >= 100 and result == 0:
        return {"label": "Immediate Action", "class": "immediate", "why": f'No tracked ROAS after {money(current["spend"])} spend. {evidence}', "action": "Validate purchase-value tracking before judging or changing performance."}
    scale = False
    if kind == "conversion":
        scale = result > 0 and result_delta is not None and result_delta >= 10
    elif kind == "awareness":
        scale = cost_delta is not None and cost_delta <= -10 and (result_delta is None or result_delta >= -10) and current["frequency"] <= 3.5
    else:
        scale = result >= 3 and cost_delta is not None and cost_delta <= -10 and (result_delta is None or result_delta >= -10)
    if scale:
        return {"label": "Ready to Scale", "class": "scale", "why": evidence, "action": "Consider a controlled +10% budget test after confirming downstream quality."}
    adverse_cost = (cost_delta is not None and ((cost_delta >= 30) if lower_cost else (cost_delta <= -30)))
    adverse_result = result_delta is not None and result_delta <= -30 and current["spend"] >= previous["spend"] * 0.8
    adverse_ctr = ctr_delta is not None and ctr_delta <= -25
    high_frequency = kind == "awareness" and current["frequency"] > 3.5
    if adverse_cost or adverse_result or adverse_ctr or high_frequency:
        return {"label": "Watch Out", "class": "watch", "why": evidence + (" Frequency is above 3.5×." if high_frequency else ""), "action": "Hold budget; inspect creative, audience, placement and tracking before scaling."}
    return {"label": "No Touching", "class": "hold", "why": evidence, "action": "Keep stable and continue collecting comparable data."}


def media_urls(group: list[dict[str, Any]]) -> list[str]:
    urls: list[str] = []
    for row in group:
        for key in ("image_url", "thumbnail_url"):
            value = row.get(key)
            if isinstance(value, str) and value:
                urls.append(value)
        carousel = row.get("carousel_card_media_urls")
        if isinstance(carousel, list):
            urls.extend(x for x in carousel if isinstance(x, str) and x)
        elif isinstance(carousel, str) and carousel:
            try:
                parsed = json.loads(carousel)
                if isinstance(parsed, list):
                    urls.extend(x for x in parsed if isinstance(x, str) and x)
            except json.JSONDecodeError:
                pass
    return list(dict.fromkeys(urls))


def fetch_media(url: str) -> dict[str, str] | None:
    digest = hashlib.sha256(url.encode()).hexdigest()
    data_path = ASSET_CACHE / f"{digest}.bin"
    type_path = ASSET_CACHE / f"{digest}.type"
    try:
        if data_path.exists() and data_path.stat().st_size > 100 and type_path.exists():
            raw = data_path.read_bytes()
            mime = type_path.read_text().strip()
        else:
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=25) as response:
                raw = response.read()
                mime = response.headers.get_content_type()
            if len(raw) <= 100 or not mime.startswith("image/"):
                return None
            data_path.write_bytes(raw)
            type_path.write_text(mime)
        return {"uri": f'data:{mime};base64,{base64.b64encode(raw).decode()}', "mime": mime, "bytes": str(len(raw))}
    except Exception:
        return None


def data_uri(path: Path) -> str:
    mime = mimetypes.guess_type(str(path))[0] or "application/octet-stream"
    return f"data:{mime};base64,{base64.b64encode(path.read_bytes()).decode()}"


def index_status(status_rows: list[dict[str, Any]], level: str) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    for row in status_rows:
        entity_id = str(row.get(f"{level}_id") or "")
        if entity_id and entity_id not in result:
            result[entity_id] = row
    return result


def operation(level: str, entity_id: str, group: list[dict[str, Any]], status_map: dict[str, dict[str, Any]]) -> dict[str, str]:
    status = status_map.get(entity_id, {})
    if level == "campaign":
        state = status.get("campaign_effective_status") or "UNKNOWN"
        start = status.get("campaign_start_time") or status.get("campaign_start_date") or status.get("campaign_created_time")
        end = status.get("campaign_stop_time")
    elif level == "adset":
        state = status.get("adset_effective_status") or "UNKNOWN"
        start = status.get("adset_start_time") or status.get("adset_created_time")
        end = status.get("adset_end_time")
    else:
        state = status.get("effective_status") or "UNKNOWN"
        start = status.get("ad_created_time")
        end = None
    delivered = [str(r.get("date")) for r in group if num(r.get("spend")) > 0 or num(r.get("impressions")) > 0]
    return {"status": str(state), "start": fmt_date(start), "end": fmt_date(end), "last": fmt_date(max(delivered)) if delivered else "No delivery in available window"}


def delivery_badge(op: dict[str, str]) -> str:
    active = op["status"] in ACTIVE
    timing = f'Started {op["start"]}' if active else f'Last active {op["last"]}'
    return f'<span class="delivery {"active" if active else "inactive"}"><b>{esc(op["status"])}</b><small>{esc(timing)}</small></span>'


def decision_html(decision: dict[str, str]) -> str:
    return f'<div class="decision-wrap"><span class="decision {decision["class"]}">{esc(decision["label"])}</span><small><b>Why:</b> {esc(decision["why"])}<br><b>Action:</b> {esc(decision["action"])}</small></div>'


def kpis_html(kind: str, current: dict[str, float], previous: dict[str, float]) -> str:
    current_items = kpi_items(kind, current)
    previous_items = dict(kpi_items(kind, previous))
    chunks = []
    for label, value in current_items:
        chunks.append(f'<span><b>{esc(value)}</b>{esc(label)}<small>Prior: {esc(previous_items.get(label, "—"))}</small></span>')
    return '<div class="mini-kpis">' + "".join(chunks) + "</div>"


def entity_row(entity: dict[str, Any], show_end: bool) -> str:
    lineage = f'<small>{esc(entity.get("parent", ""))}</small>' if entity.get("parent") else ""
    end = f'<td>{esc(entity["operation"]["end"])}</td>' if show_end else ""
    return f'<tr><td><b>{esc(entity["name"])}</b>{lineage}<span class="objective">{esc(KIND_LABEL[entity["kind"]])} · {esc(entity["objective"])}</span></td><td>{delivery_badge(entity["operation"])}</td>{end}<td>{money(entity["current"]["spend"])}</td><td>{integer(entity["current"]["impressions"])}</td><td>{kpis_html(entity["kind"], entity["current"], entity["previous"])}</td><td>{decision_html(entity["decision"])}</td></tr>'


def chart_tick(value: float, value_format: str) -> str:
    if value_format == "money":
        return f"฿{value:,.0f}"
    if value_format == "percent":
        return f"{value:.1f}%"
    if value_format == "ratio":
        return f"{value:.1f}×"
    return f"{value:,.0f}"


def svg_chart(campaigns: list[dict[str, Any]], key: str, label: str, dates: list[str], value_format: str = "number") -> str:
    width, height, left, top, bottom = 760, 220, 66, 18, 34
    inner_w, inner_h = width - left - 14, height - top - bottom
    values = [c["daily"][date].get(key) for c in campaigns for date in dates]
    numeric = [float(value) for value in values if value is not None]
    vmax = max(numeric + [1.0])
    out = [f'<svg viewBox="0 0 {width} {height}" role="img" aria-label="Daily {esc(label)}">']
    for step in range(4):
        y = top + inner_h * step / 3
        val = vmax * (1 - step / 3)
        out.append(f'<line x1="{left}" y1="{y:.1f}" x2="{width-14}" y2="{y:.1f}" stroke="#2a3135"/><text x="{left-7}" y="{y+4:.1f}" text-anchor="end">{esc(chart_tick(val, value_format))}</text>')
    for index, campaign in enumerate(campaigns):
        segments: list[list[str]] = []
        segment: list[str] = []
        circles: list[str] = []
        for day_index, date in enumerate(dates):
            value = campaign["daily"][date].get(key)
            x = left + inner_w * day_index / max(len(dates) - 1, 1)
            if value is None:
                if segment:
                    segments.append(segment)
                    segment = []
                continue
            y = top + inner_h - float(value) / vmax * inner_h
            segment.append(f"{x:.1f},{y:.1f}")
            circles.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="2.6" fill="{COLORS[index % len(COLORS)]}"/>')
        if segment:
            segments.append(segment)
        color = COLORS[index % len(COLORS)]
        for points in segments:
            if len(points) > 1:
                out.append(f'<polyline points="{" ".join(points)}" fill="none" stroke="{color}" stroke-width="2.3"/>')
        out.extend(circles)
    for day_index, date in enumerate(dates):
        if len(dates) > 10 and day_index % 3 and day_index != len(dates) - 1:
            continue
        x = left + inner_w * day_index / max(len(dates) - 1, 1)
        out.append(f'<text x="{x:.1f}" y="{height-9}" text-anchor="middle">{date[8:]}</text>')
    return "".join(out) + "</svg>"


def build_dashboard(account_name: str, account_id: str, rows: list[dict[str, Any]], campaign_daily_rows: list[dict[str, Any]], status_rows: list[dict[str, Any]], logo_uri: str, media: dict[str, dict[str, str] | None], slug: str) -> dict[str, Any]:
    status_maps = {level: index_status([r for r in status_rows if str(r.get("account_id")) == account_id], level) for level in ("campaign", "adset", "ad")}
    grouped: dict[str, dict[str, list[dict[str, Any]]]] = {}
    for level, key in (("campaign", "campaign_id"), ("adset", "adset_id"), ("ad", "ad_id")):
        groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for row in rows:
            groups[str(row.get(key))].append(row)
        grouped[level] = groups

    entities: dict[str, list[dict[str, Any]]] = {"campaign": [], "adset": [], "ad": []}
    for level in ("campaign", "adset", "ad"):
        name_key = {"campaign": "campaign", "adset": "adset_name", "ad": "ad_name"}[level]
        for entity_id, group in grouped[level].items():
            first = group[0]
            campaign_group = grouped["campaign"][str(first.get("campaign_id"))]
            kind = objective_kind(campaign_group)
            current = aggregate([r for r in group if r.get("date") in CURRENT])
            previous = aggregate([r for r in group if r.get("date") in PREVIOUS])
            op = operation(level, entity_id, group, status_maps[level])
            entity = {
                "id": entity_id, "name": first.get(name_key) or f"Unnamed {level}",
                "objective": first.get("objective") or "Not provided", "kind": kind,
                "current": current, "previous": previous, "operation": op,
                "decision": decision_for(kind, current, previous, op),
                "campaign_id": str(first.get("campaign_id")),
            }
            if level == "adset":
                entity["parent"] = first.get("campaign") or ""
            if level == "ad":
                entity["parent"] = f'{first.get("campaign") or ""} › {first.get("adset_name") or ""}'
                entity["preview"] = first.get("ad_preview_shareable_link") or ""
                entity["copy"] = first.get("title") or first.get("body") or "No copy supplied"
                entity["urls"] = media_urls(group)
            entities[level].append(entity)
        entities[level].sort(key=lambda item: (-item["current"]["spend"], item["name"]))

    campaigns = entities["campaign"]
    trend_index = {
        (str(row.get("campaign_id")), str(row.get("date"))): row
        for row in campaign_daily_rows
        if str(row.get("account_id")) == account_id
    }
    for campaign in campaigns:
        campaign["daily"] = {}
        for date in CURRENT_DATES:
            campaign["daily"][date] = campaign_daily_metrics(trend_index.get((campaign["id"], date)))

    current_account = aggregate([r for r in rows if r.get("date") in CURRENT])
    previous_account = aggregate([r for r in rows if r.get("date") in PREVIOUS])
    campaign_rows = "".join(entity_row(item, True) for item in entities["campaign"])
    adset_rows = "".join(entity_row(item, True) for item in entities["adset"])

    creative_sections = []
    embedded_count = failed_count = 0
    for campaign in campaigns:
        cards = []
        for ad in [a for a in entities["ad"] if a["campaign_id"] == campaign["id"]]:
            visuals = []
            saved = creatives.data_uri("meta", ad["id"])
            if saved:
                embedded_count += 1
                visuals.append(f'<img src="{saved}" alt="Creative for {esc(ad["name"])}">')
            elif not ad["urls"]:
                visuals.append('<div class="placeholder">No creative image URL supplied</div>')
            else:
                for position, url in enumerate(ad["urls"], 1):
                    fetched = media.get(url)
                    if fetched:
                        embedded_count += 1
                        visuals.append(f'<img src="{fetched["uri"]}" alt="Creative {position} for {esc(ad["name"])}">')
                    else:
                        failed_count += 1
                        visuals.append(f'<div class="placeholder">Creative image {position} unavailable from supplied URL</div>')
            preview = f'<a href="{esc(ad["preview"])}" target="_blank" rel="noopener">Official ad preview ↗</a>' if ad["preview"] else ""
            cards.append(f'<article class="creative"><div class="creative-media">{"".join(visuals)}</div><div class="creative-body"><h4>{esc(ad["name"])}</h4><p class="lineage">{esc(ad["parent"])}</p>{delivery_badge(ad["operation"])}{kpis_html(ad["kind"], ad["current"], ad["previous"])}{decision_html(ad["decision"])}<p class="copy">{esc(str(ad["copy"])[:420])}</p>{preview}</div></article>')
        creative_sections.append(f'<section class="creative-group"><div class="group-head"><h3>{esc(campaign["name"])}</h3><span>{len(cards)} ads · {esc(KIND_LABEL[campaign["kind"]])}</span></div><div class="creative-grid">{"".join(cards)}</div></section>')

    legend = "".join(f'<span><i style="background:{COLORS[i % len(COLORS)]}"></i>{esc(c["name"])}</span>' for i, c in enumerate(campaigns))
    trend_groups = []
    chart_groups = [
        ("Delivery and audience", [
            ("spend", "Spend (THB)", "money"),
            ("impressions", "Impressions", "number"),
            ("reach", "Reach", "number"),
            ("frequency", "Frequency", "ratio"),
        ]),
        ("Click efficiency", [
            ("clicks", "Total clicks", "number"),
            ("ctr", "CTR", "percent"),
            ("cpc", "CPC", "money"),
            ("cpm", "CPM", "money"),
        ]),
        ("Messaging performance", [
            ("messages", "Messaging conversations started", "number"),
            ("cost_per_message", "Cost per message", "money"),
        ]),
    ]
    for group_title, definitions in chart_groups:
        cards = "".join(
            f'<div class="chart"><h4>{esc(title)}</h4>{svg_chart(campaigns, key, title, CURRENT_DATES, value_format)}</div>'
            for key, title, value_format in definitions
        )
        trend_groups.append(f'<section class="trend-group"><h3>{esc(group_title)}</h3><div class="charts">{cards}</div></section>')
    trend_html = "".join(trend_groups)
    css = """
:root{--bg:#050708;--card:#11161a;--nested:#171d21;--ink:#faf9f6;--muted:#959a9c;--line:#2a3135;--copper:#ca743e;--soft:#e0a17a;--blue:#72a8b9;--deep:#173e50;--green:#80c79a;--red:#ec8e88}*{box-sizing:border-box}html,body{margin:0;max-width:100%;overflow-x:hidden;background:var(--bg);color:var(--ink);font-family:-apple-system,BlinkMacSystemFont,"SF Pro Display","Segoe UI",sans-serif}.page{width:min(1600px,100%);margin:auto}header{min-height:250px;padding:38px 54px;display:grid;grid-template-columns:210px 1fr 320px;gap:35px;align-items:center;border-bottom:4px solid var(--copper)}header img{width:190px;max-width:100%;height:auto}h1{font-size:clamp(32px,4vw,52px);line-height:1.05;letter-spacing:-1.5px;margin:8px 0}.eyebrow{color:var(--soft);font-size:11px;letter-spacing:1.6px}.sub,.period{color:var(--muted)}.period{text-align:right;line-height:1.7}.period b{display:block;color:var(--ink);font-size:19px}.read-only{display:inline-block;border:1px solid var(--blue);color:var(--blue);padding:4px 8px;border-radius:99px;font-size:10px}main{padding:30px 42px 70px}.stats{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:12px}.stat,.panel{background:var(--card);border-radius:12px;box-shadow:0 8px 26px #0005}.stat{padding:20px;min-width:0}.stat>b{display:block;font-size:clamp(20px,2.2vw,29px);overflow-wrap:anywhere}.stat>span{color:var(--muted);font-size:10px}.delta{display:block!important;margin-top:8px;font-weight:700}.good{color:var(--green)!important}.bad{color:var(--red)!important}.neutral{color:var(--blue)!important}.panel{margin-top:20px;padding:25px;overflow:hidden}.panel-head,.group-head{display:flex;justify-content:space-between;align-items:flex-end;gap:16px;margin-bottom:16px}h2{font-size:28px;margin:0}h3,h4{margin:0}.panel-head p,.group-head span{color:var(--muted);font-size:11px;margin:0}.framework{display:grid;grid-template-columns:repeat(3,1fr);gap:9px}.framework div{background:var(--nested);border:1px solid var(--line);padding:13px;border-radius:9px}.framework b{display:block;color:var(--soft);font-size:12px;margin-bottom:4px}.framework span{color:var(--muted);font-size:11px}.trend-group{margin-top:20px}.trend-group:first-of-type{margin-top:0}.trend-group>h3{margin:0 0 10px;color:var(--soft);font-size:14px}.charts{display:grid;grid-template-columns:1fr 1fr;gap:12px}.chart{background:var(--nested);padding:14px;border-radius:9px}.chart h4{font-size:13px}svg{display:block;width:100%}svg text{fill:var(--muted);font-size:9px}.legend{display:flex;flex-wrap:wrap;gap:8px 14px;margin-top:16px}.legend span{font-size:9px;color:var(--muted)}.legend i{display:inline-block;width:7px;height:7px;border-radius:50%;margin-right:5px}.trend-note{margin:14px 0 0;color:var(--muted);font-size:10px}.table-wrap{overflow-x:auto;-webkit-overflow-scrolling:touch}table{width:100%;min-width:1250px;border-collapse:collapse}th{text-align:left;font-size:9px;color:var(--muted);text-transform:uppercase;letter-spacing:.7px;padding:10px;border-bottom:1px solid var(--line)}td{padding:13px 10px;border-bottom:1px solid var(--line);vertical-align:top;font-size:11px}td:first-child{width:240px}td small,.objective{display:block;color:var(--muted);margin-top:5px}.objective{color:var(--blue);font-size:9px}.delivery{display:inline-block;min-width:122px;padding:7px 9px;border-radius:6px;border:1px solid}.delivery b,.delivery small{display:block;margin:0}.delivery small{font-size:8px;margin-top:3px}.delivery.active{background:#153c2a;border-color:#35835a;color:#baf1cb}.delivery.inactive{background:#492424;border-color:#9b4747;color:#ffc3be}.mini-kpis{display:flex;flex-wrap:wrap;gap:7px}.mini-kpis>span{background:var(--nested);padding:7px 8px;border-radius:6px;color:var(--muted);font-size:8px;min-width:74px}.mini-kpis b{display:block;color:var(--ink);font-size:11px}.mini-kpis small{display:block;color:var(--muted);margin-top:3px}.decision-wrap{min-width:260px}.decision{display:inline-block;border-radius:99px;padding:5px 8px;font-size:9px;font-weight:800;margin-bottom:5px}.immediate{background:#702a27;color:#ffd1cc}.watch{background:#684716;color:#ffe5a4}.hold{background:var(--deep);color:#b9e0ee}.scale{background:#184a32;color:#c0f0cf}.decision-wrap small{display:block;line-height:1.45;color:var(--muted)}.creative-group{margin-top:24px}.group-head{padding-bottom:9px;border-bottom:1px solid var(--line)}.creative-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px}.creative{background:var(--nested);border:1px solid var(--line);border-radius:12px;overflow:hidden;min-width:0}.creative-media{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));align-items:start;background:#0b0e10}.creative-media img,.placeholder{display:block;width:100%;height:auto;aspect-ratio:4/5;object-fit:cover;background:#080a0b}.placeholder{display:grid;place-items:center;text-align:center;padding:20px;color:var(--muted);font-size:11px;background:linear-gradient(135deg,#151b1f,#20272b)}.creative-body{padding:15px}.lineage,.copy{color:var(--muted);font-size:10px;line-height:1.5}.creative .delivery,.creative .mini-kpis,.creative .decision-wrap{margin-top:11px}.creative a{color:var(--soft);font-size:10px}footer{margin-top:24px;padding:20px;border-top:1px solid var(--line);color:var(--muted);font-size:10px;line-height:1.6}@media(max-width:1000px){header{grid-template-columns:160px 1fr;padding:30px}.period{grid-column:1/-1;text-align:left}.stats{grid-template-columns:repeat(3,1fr)}.creative-grid{grid-template-columns:repeat(2,1fr)}.framework{grid-template-columns:repeat(2,1fr)}}@media(max-width:620px){header{display:block;padding:25px 18px}header img{width:145px;margin-bottom:24px}.period{margin-top:20px}main{padding:18px 12px 50px}.stats{grid-template-columns:repeat(2,minmax(0,1fr))}.stat{padding:14px}.panel{padding:16px}.charts,.creative-grid,.framework{grid-template-columns:1fr}.panel-head,.group-head{display:block}.panel-head p,.group-head span{display:block;margin-top:7px}}
"""
    production_note = " Production is included in account totals; its earlier ten conversations were identified separately as spam and are not qualified results." if account_id == "1329660951861233" else ""
    html_doc = f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>GROOV · {esc(account_name)} · Meta Ads</title><style>{css}</style></head><body>{back_link()}<div class="page"><header><img src="{logo_uri}" alt="GROOV Strategy official logo"><div><div class="eyebrow">SINGLE-ACCOUNT PERFORMANCE · META ADS</div><h1>{esc(account_name)}</h1><p class="sub">Objective-aware performance, delivery status and complete supplied creative library.</p><span class="read-only">READ ONLY · NO AD CHANGES MADE</span></div><div class="period"><b>{CUR_UPPER}</b>Compared with {PREV_LABEL}<br>Equal 7-day completed periods · THB<br>Built {GENERATED}, Bangkok time</div></header><main>
<section class="stats"><div class="stat"><b>{money(current_account["spend"])}</b><span>Spend</span>{delta_badge(current_account["spend"],previous_account["spend"])}</div><div class="stat"><b>{integer(current_account["impressions"])}</b><span>Impressions</span>{delta_badge(current_account["impressions"],previous_account["impressions"])}</div><div class="stat"><b>{percent(current_account["ctr"])}</b><span>CTR</span>{delta_badge(current_account["ctr"],previous_account["ctr"])}</div><div class="stat"><b>{money(current_account["cpm"])}</b><span>CPM</span>{delta_badge(current_account["cpm"],previous_account["cpm"],True)}</div><div class="stat"><b>{integer(current_account["leads"])}</b><span>Meta-reported lead actions</span>{delta_badge(current_account["leads"],previous_account["leads"])}</div><div class="stat"><b>{integer(current_account["messages"])}</b><span>Meta-reported conversations</span>{delta_badge(current_account["messages"],previous_account["messages"])}</div></section>
<section class="panel"><div class="panel-head"><h2>Objective KPI framework</h2><p>Lead generation is classified before Messages</p></div><div class="framework"><div><b>Lead generation</b><span>Leads · CTR · CPM · CPL</span></div><div><b>Messages</b><span>Conversations · CTR · CPM · CPR</span></div><div><b>Awareness</b><span>CPM · Frequency</span></div><div><b>Engagement</b><span>Video views · CTR · CPC</span></div><div><b>Traffic</b><span>Link clicks · CTR · CPC</span></div><div><b>Conversion</b><span>Purchase ROAS when tracked · CTR · CPM</span></div></div></section>
<section class="panel"><div class="panel-head"><h2>Daily current-period trends</h2><p>{CUR_SHORT} · campaign-level daily data · Reach is not summed from ads</p></div>{trend_html}<div class="legend">{legend}</div><p class="trend-note">Cost per message is intentionally blank when a campaign records zero messaging conversations; blank is not treated as ฿0. Both comparison windows contain completed Bangkok days.</p></section>
<section class="panel"><div class="panel-head"><h2>Campaign performance</h2><p>Every campaign in either period · objective-aware decisions</p></div><div class="table-wrap"><table><thead><tr><th>Campaign / objective</th><th>Delivery status</th><th>End</th><th>Spend</th><th>Impressions</th><th>Objective KPIs / prior</th><th>Decision · Why · Action</th></tr></thead><tbody>{campaign_rows}</tbody></table></div></section>
<section class="panel"><div class="panel-head"><h2>Ad set performance</h2><p>Every ad set in either period · exact names preserved</p></div><div class="table-wrap"><table><thead><tr><th>Ad set / campaign</th><th>Delivery status</th><th>End</th><th>Spend</th><th>Impressions</th><th>Objective KPIs / prior</th><th>Decision · Why · Action</th></tr></thead><tbody>{adset_rows}</tbody></table></div></section>
<section class="panel"><div class="panel-head"><h2>Complete creative library</h2><p>Every ad in either period · real creatives saved in Ads/command-center/creatives; any still missing are marked unavailable</p></div>{"".join(creative_sections)}</section>
<footer><b>Periods:</b> Current {CUR_LABEL}; comparison {PREV_LABEL}. Both are equal seven-day completed windows. <b>Metric meaning:</b> Messaging conversations and Meta-reported lead actions are platform-attributed events, not verified qualified leads or unique people.{production_note} <b>Delivery status:</b> Green means ACTIVE/ENABLED; every other effective status is red. Active campaign/ad-set dates use supplied start timestamps. Active ad “Started” dates use supplied creation timestamps because Meta did not provide separate ad activation dates. Inactive “Last active” dates are the latest dates with spend or impressions in the supplied {WINDOW_LABEL} data. End is retained for campaign/ad set whenever supplied; “Not provided” means no end date was present. <b>Read only:</b> Built from the read-only Windsor export; no ads were changed. Failed creative URLs are shown as placeholders and no creative was invented.</footer>
</main></div></body></html>'''
    output_path = OUT_DIR / f"{slug}.html"
    output_path.write_text(html_doc, encoding="utf-8")
    return {
        "account_id": account_id, "account_name": account_name, "slug": slug,
        "html": str(output_path.relative_to(ROOT)), "source_rows": len(rows),
        "campaigns": len(entities["campaign"]), "adsets": len(entities["adset"]), "ads": len(entities["ad"]),
        "creative_urls": embedded_count + failed_count, "images_embedded": embedded_count,
        "image_placeholders_for_failed_urls": failed_count,
        "current_spend": round(current_account["spend"], 2), "current_impressions": round(current_account["impressions"]),
    }


def main() -> None:
    daily = json.loads(DAILY_PATH.read_text(encoding="utf-8"))
    status = json.loads(STATUS_PATH.read_text(encoding="utf-8"))
    campaign_daily = json.loads(CAMPAIGN_DAILY_PATH.read_text(encoding="utf-8"))
    if not daily or not status or not campaign_daily:
        raise RuntimeError("Ad-daily, campaign-daily, and status source snapshots must all be non-empty")
    if not LOGO_PATH.exists():
        raise FileNotFoundError(f"Official GROOV logo not found: {LOGO_PATH}")
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    ASSET_CACHE.mkdir(parents=True, exist_ok=True)
    for old in OUT_DIR.glob("*.html"):
        old.unlink()

    current_by_account: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    for row in daily:
        if row.get("date") in CURRENT:
            current_by_account[(str(row.get("account_id")), str(row.get("account_name")))].append(row)
    qualifying = sorted((key for key, rows in current_by_account.items() if sum(num(r.get("spend")) for r in rows) > 0 or sum(num(r.get("impressions")) for r in rows) > 0), key=lambda item: item[1].lower())

    rows_by_account: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    qualifying_set = set(qualifying)
    for row in daily:
        key = (str(row.get("account_id")), str(row.get("account_name")))
        if key in qualifying_set and row.get("date") in WINDOW:
            rows_by_account[key].append(row)

    all_urls: set[str] = set()
    for rows in rows_by_account.values():
        ad_groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for row in rows:
            ad_groups[str(row.get("ad_id"))].append(row)
        for ad_id, group in ad_groups.items():
            if not creatives.path_for("meta", ad_id).exists():
                all_urls.update(media_urls(group))
    media: dict[str, dict[str, str] | None] = {}
    with ThreadPoolExecutor(max_workers=16) as pool:
        futures = {pool.submit(fetch_media, url): url for url in all_urls}
        for future in as_completed(futures):
            media[futures[future]] = future.result()

    logo_uri = data_uri(LOGO_PATH)
    used_slugs: set[str] = set()
    accounts = []
    for account_id, account_name in qualifying:
        slug = safe_slug(account_name, account_id)
        if slug in used_slugs:
            slug = f"{slug}-{account_id}"
        used_slugs.add(slug)
        accounts.append(build_dashboard(account_name, account_id, rows_by_account[(account_id, account_name)], campaign_daily, status, logo_uri, media, slug))

    manifest = {
        "platform": "Meta", "read_only": True,
        "current_period": {**CUR_WIN, "days": 7, "partial_end_day": False},
        "comparison_period": {**PREV_WIN, "days": 7},
        "source": {"daily": str(DAILY_PATH.relative_to(ROOT)), "daily_rows": len(daily), "campaign_daily": str(CAMPAIGN_DAILY_PATH.relative_to(ROOT)), "campaign_daily_rows": len(campaign_daily), "status": str(STATUS_PATH.relative_to(ROOT)), "status_rows": len(status)},
        "html_dir": str(OUT_DIR.relative_to(ROOT)), "account_count": len(accounts), "dashboard_count": len(accounts),
        "accounts": accounts,
        "totals": {
            "campaigns": sum(a["campaigns"] for a in accounts), "adsets": sum(a["adsets"] for a in accounts), "ads": sum(a["ads"] for a in accounts),
            "creative_urls": sum(a["creative_urls"] for a in accounts), "images_embedded": sum(a["images_embedded"] for a in accounts),
            "failed_creative_urls": sum(a["image_placeholders_for_failed_urls"] for a in accounts),
        },
    }
    MANIFEST_PATH.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(manifest, ensure_ascii=False))


if __name__ == "__main__":
    main()
