#!/usr/bin/env python3
"""Build the read-only GROOV Ads Command Center from local daily exports.

Ported from the Hermes reference (_reference/hermes-package/command-center). Every account card links to the
platform dashboard built by build_meta/build_tiktok/build_google, keyed by exact platform + account ID."""
from __future__ import annotations

import base64
import html
import json
import math
import mimetypes
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

from period import (CURRENT as PERIOD, COMPARISON, CUR_LABEL, PREV_LABEL, PREV_SHORT, GENERATED, LOGO, SOURCE, HTML_DIR)

ROOT = Path(__file__).resolve().parent
FILES = {"Meta": "meta-ad-daily.json", "TikTok": "tiktok-ad-daily.json", "Google": "google-ad-daily.json"}
MANIFESTS = {"Meta": ("meta-manifest.json", "accounts", "html"), "TikTok": ("tiktok-manifest.json", "dashboards", "html"), "Google": ("google-manifest.json", "accounts", "file")}
SEVERITY = {"Immediate Action": 4, "Watch Out": 3, "Ready to Scale": 2, "No Touching": 1}
ORDER = ["Immediate Action", "Watch Out", "Ready to Scale", "No Touching"]
ADDITIVE = {
    "spend", "impressions", "reach", "clicks", "link_clicks", "actions_video_view",
    "actions_onsite_conversion_messaging_conversation_started_7d", "actions_lead",
    "total_play", "messaging_total_conversation_tiktok_direct_message", "total_sales_lead",
    "conversions", "conversion_value", "all_conversion_value"
}


def num(value: Any) -> float:
    try:
        value = float(value or 0)
        return value if math.isfinite(value) else 0.0
    except (TypeError, ValueError):
        return 0.0


def ratio(a: float, b: float) -> float:
    return a / b if b else 0.0


def change(current: float, previous: float) -> float | None:
    return None if previous == 0 else (current / previous - 1) * 100


def delivered(row: dict[str, Any]) -> bool:
    return num(row.get("spend")) > 0 or num(row.get("impressions")) > 0


def lead_name(name: str) -> bool:
    normalized = re.sub(r"[^A-Z0-9]+", "_", name.upper())
    return any(token in normalized for token in ("LEADGEN", "LEAD_GEN", "LEAD_GENERATION"))


def message_name(name: str) -> bool:
    return bool(re.search(r"(^|[^A-Z])(MSG|MESSAGE|MESSAGES|INBOX|MESSENGER)([^A-Z]|$)", name.upper()))


def objective_for(platform: str, row: dict[str, Any]) -> str:
    name = str(row.get("campaign") or "")
    if platform == "Meta":
        raw = str(row.get("objective") or "").upper()
        # Required hierarchy: lead generation is resolved before message signals.
        if raw == "OUTCOME_LEADS" or lead_name(name):
            return "Lead generation"
        if raw == "OUTCOME_AWARENESS":
            return "Awareness"
        if num(row.get("actions_onsite_conversion_messaging_conversation_started_7d")) > 0 or message_name(name):
            return "Messages"
        if raw == "LINK_CLICKS" or "TRAFFIC" in raw:
            return "Traffic"
        return "Engagement"
    if platform == "TikTok":
        raw = str(row.get("objective_type") or row.get("objective") or "").upper()
        if raw == "REACH": return "Awareness"
        if raw in ("VIDEO_VIEWS", "ENGAGEMENT"): return "Engagement"
        if raw == "TRAFFIC": return "Traffic"
        if raw == "LEAD_GENERATION": return "Lead generation"
        if num(row.get("messaging_total_conversation_tiktok_direct_message")) > 0 or message_name(name): return "Messages"
        return "Conversions"
    return "Conversions"


def aggregate(rows: list[dict[str, Any]], start: str, end: str) -> dict[tuple[str, str], dict[str, Any]]:
    groups: dict[tuple[str, str], dict[str, Any]] = {}
    for row in rows:
        if not (start <= str(row.get("date", "")) <= end):
            continue
        key = (str(row.get("account_id") or row.get("account_name") or ""), str(row.get("campaign_id") or row.get("campaign") or ""))
        if key not in groups:
            groups[key] = {k: row.get(k) for k in ("account_id", "account_name", "campaign", "campaign_id", "objective", "objective_type", "advertising_channel_type")}
            groups[key].update({field: 0.0 for field in ADDITIVE})
        for field in ADDITIVE:
            groups[key][field] += num(row.get(field))
        # ROAS is reconstructed from spend-weighted daily/ad values where no value field exists.
        for field in ("purchase_roas_omni_purchase", "website_purchase_roas_offsite_conversion_fb_pixel_purchase", "complete_payment_roas", "onsite_purchases_roas"):
            groups[key][field + "_value"] = groups[key].get(field + "_value", 0.0) + num(row.get(field)) * num(row.get("spend"))
    return groups


def metrics(platform: str, row: dict[str, Any], objective: str) -> dict[str, Any]:
    spend, impressions, clicks = num(row.get("spend")), num(row.get("impressions")), num(row.get("clicks"))
    reach = num(row.get("reach")); ctr = ratio(clicks, impressions); cpc = ratio(spend, clicks); cpm = ratio(spend * 1000, impressions)
    frequency = ratio(impressions, reach)
    link_clicks = num(row.get("link_clicks")) if platform == "Meta" else clicks
    video_views = num(row.get("actions_video_view")) if platform == "Meta" else num(row.get("total_play"))
    messages = num(row.get("actions_onsite_conversion_messaging_conversation_started_7d")) if platform == "Meta" else num(row.get("messaging_total_conversation_tiktok_direct_message"))
    leads = num(row.get("actions_lead")) if platform == "Meta" else num(row.get("total_sales_lead"))
    conversions = num(row.get("conversions")); value = num(row.get("conversion_value")) or num(row.get("all_conversion_value"))
    if platform == "Meta":
        roas_value = max(num(row.get("purchase_roas_omni_purchase_value")), num(row.get("website_purchase_roas_offsite_conversion_fb_pixel_purchase_value")))
        roas = ratio(roas_value, spend)
    elif platform == "TikTok":
        roas_value = max(num(row.get("complete_payment_roas_value")), num(row.get("onsite_purchases_roas_value")))
        roas = ratio(roas_value, spend)
    else: roas = ratio(value, spend)
    if objective == "Awareness": results, result_label, cost, cost_label, response, response_label = impressions, "Impressions", cpm, "CPM", ratio(impressions, spend), "Impressions / spend"
    elif objective == "Traffic": results, result_label, cost, cost_label, response, response_label = link_clicks, "Link clicks" if platform == "Meta" else "Clicks", ratio(spend, link_clicks), "CPC", ctr, "CTR"
    elif objective == "Engagement": results, result_label, cost, cost_label, response, response_label = video_views, "Video views", cpc, "CPC", ratio(video_views, impressions), "View rate"
    elif objective == "Messages": results, result_label, cost, cost_label, response, response_label = messages, "Messages", ratio(spend, messages), "CPR", ratio(messages, impressions), "Message rate"
    elif objective == "Lead generation": results, result_label, cost, cost_label, response, response_label = leads, "Leads", ratio(spend, leads), "CPL", ratio(leads, impressions), "Lead rate"
    else: results, result_label, cost, cost_label, response, response_label = conversions, "Conversions", ratio(spend, conversions), "CPA", ratio(conversions, clicks), "Conversion rate"
    return {"spend": spend, "impressions": impressions, "frequency": frequency, "clicks": clicks, "ctr": ctr, "cpc": cpc, "cpm": cpm, "results": results, "result_label": result_label, "cost_per_result": cost, "cost_label": cost_label, "response_rate": response, "response_label": response_label, "conversion_value": value, "roas": roas}


def deltas(cur: dict[str, Any], prev: dict[str, Any]) -> dict[str, float | None]:
    return {key + "_pct": change(cur[key], prev[key]) for key in ("spend", "results", "cost_per_result", "response_rate", "ctr", "cpm", "frequency", "cpc", "conversion_value", "roas")}


def decide(cur: dict[str, Any], prev: dict[str, Any]) -> tuple[str, str, str, dict[str, Any]]:
    delta = deltas(cur, prev); word = cur["result_label"].lower()
    if cur["spend"] >= 100 and cur["results"] == 0:
        return "Immediate Action", f"฿{cur['spend']:,.2f} spent with zero {word} in the current equal-length period.", "Check tracking and delivery setup; replace or stop the weak setup after confirming data quality.", delta
    if cur["results"] >= 3 and delta["cost_per_result_pct"] is not None and delta["cost_per_result_pct"] <= -10 and (delta["results_pct"] is None or delta["results_pct"] >= -10):
        return "Ready to Scale", f"{cur['cost_label']} improved at least 10% while {word} did not decline more than 10%.", "Test a controlled +10% budget increase while protecting result quality.", delta
    stable_spend = prev["spend"] > 0 and cur["spend"] >= prev["spend"] * .8
    reasons = []
    if delta["cost_per_result_pct"] is not None and delta["cost_per_result_pct"] >= 30: reasons.append(f"{cur['cost_label']} worsened at least 30%")
    if delta["results_pct"] is not None and delta["results_pct"] <= -30 and stable_spend: reasons.append(f"{cur['result_label']} fell at least 30% on roughly stable spend")
    if delta["response_rate_pct"] is not None and delta["response_rate_pct"] <= -25: reasons.append(f"{cur['response_label']} fell at least 25%")
    if reasons: return "Watch Out", "; ".join(reasons) + ".", "Hold budget; inspect creative, audience, placement and tracking before scaling.", delta
    return "No Touching", "No campaign-level intervention threshold was crossed.", "Keep stable and continue collecting comparable data.", delta


def account_links() -> dict[tuple[str, str], str]:
    """(platform, account_id) -> page path relative to html/index.html, from each builder's manifest."""
    links: dict[tuple[str, str], str] = {}
    for platform, (filename, key, field) in MANIFESTS.items():
        path = ROOT / filename
        if not path.exists(): continue
        for item in json.loads(path.read_text(encoding="utf-8")).get(key, []):
            target = (ROOT / item[field]).resolve()
            links[(platform, str(item["account_id"]))] = str(target.relative_to(HTML_DIR.resolve()))
    return links


def fmt_delta(value: float | None) -> str:
    return "no baseline" if value is None else f"{value:+.0f}%"


def esc(value: Any) -> str:
    return html.escape(str(value if value is not None else ""))


def data_uri(path: Path) -> str:
    mime = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
    return f"data:{mime};base64," + base64.b64encode(path.read_bytes()).decode("ascii")


def build() -> tuple[dict[str, Any], str]:
    if not LOGO.is_file(): raise FileNotFoundError(f"Official logo not found: {LOGO}")
    accounts: dict[tuple[str, str], dict[str, Any]] = {}
    objective_counts: Counter[str] = Counter(); campaign_counts: Counter[str] = Counter()
    for platform, filename in FILES.items():
        rows = json.loads((SOURCE / filename).read_text(encoding="utf-8"))
        current, previous = aggregate(rows, **PERIOD), aggregate(rows, **COMPARISON)
        active_ids = {aid for (aid, _), row in current.items() if delivered(row)}
        for aid in active_ids:
            account_rows = [row for (account_id, _), row in current.items() if account_id == aid and delivered(row)]
            name = str(account_rows[0].get("account_name") or aid)
            item = {"platform": platform, "account_id": aid, "account": name, "decision": "No Touching", "campaigns_evaluated": len(account_rows), "account_totals": {"spend": 0.0, "prior_spend": 0.0, "impressions": 0.0, "clicks": 0.0}, "campaigns": []}
            for row in account_rows:
                key = (aid, str(row.get("campaign_id") or row.get("campaign") or "")); prior = previous.get(key, {})
                objective = objective_for(platform, row); cur = metrics(platform, row, objective); prev = metrics(platform, prior, objective)
                label, why, action, delta = decide(cur, prev)
                campaign = {"campaign_id": key[1], "campaign": row.get("campaign"), "objective": objective, "objective_raw": row.get("objective_type") or row.get("objective") or row.get("advertising_channel_type"), "decision": label, "current": cur, "previous": prev, "changes": delta, "why": why, "action": action}
                item["campaigns"].append(campaign); objective_counts[objective] += 1; campaign_counts[platform] += 1
                item["account_totals"]["spend"] += cur["spend"]; item["account_totals"]["prior_spend"] += prev["spend"]; item["account_totals"]["impressions"] += cur["impressions"]; item["account_totals"]["clicks"] += cur["clicks"]
            item["decision"] = max((c["decision"] for c in item["campaigns"]), key=lambda value: SEVERITY[value])
            item["drivers"] = sorted((c for c in item["campaigns"] if c["decision"] == item["decision"]), key=lambda c: (-c["current"]["spend"], str(c["campaign"])))[:2]
            accounts[(platform, aid)] = item
    account_list = sorted(accounts.values(), key=lambda a: (ORDER.index(a["decision"]), a["platform"], a["account"].casefold()))
    platform_counts = Counter(a["platform"] for a in account_list)
    keys = {(a["platform"], a["account_id"]) for a in account_list}
    if len(keys) != len(account_list): raise RuntimeError("Active account keys are not unique")
    links = account_links()
    for a in account_list:
        a["href"] = links.get((a["platform"], a["account_id"]))
    missing = [f'{a["platform"]}::{a["account_id"]} {a["account"]}' for a in account_list if not a["href"]]
    if missing: print("WARNING no account dashboard for: " + ", ".join(missing))
    lead = [c for a in account_list for c in a["campaigns"] if c["objective"] == "Lead generation" and c["current"]["cost_label"] != "CPL"]
    if lead: raise RuntimeError("Lead-generation campaign without CPL: hierarchy regression")
    decisions = Counter(a["decision"] for a in account_list)
    for label in ORDER: decisions.setdefault(label, 0)
    data = {
        "title": "GROOV Ads Command Center", "read_only": True,
        "statement": "Read-only analysis of Windsor exports. No ad changes were made.", "generated": GENERATED,
        "period": PERIOD, "comparison_period": COMPARISON,
        "overall": {"total_ad_spend": sum(a["account_totals"]["spend"] for a in account_list), "previous_ad_spend": sum(a["account_totals"]["prior_spend"] for a in account_list), "connected_active_accounts": len(account_list)},
        "account_count": len(account_list), "platform_counts": dict(platform_counts), "decision_counts": dict(decisions), "campaigns_evaluated": sum(campaign_counts.values()), "accounts": account_list,
        "methodology": {
            "rollup": "Highest severity current delivered campaign wins; up to two exact campaigns at that severity are shown.",
            "rules": {"Immediate Action": "Current spend >= 100 with zero objective results.", "Ready to Scale": "Results >= 3; cost/result improves >= 10%; results do not decline > 10%.", "Watch Out": "Cost/result worsens >= 30%, results fall >= 30% on roughly stable spend, or the objective-specific response rate falls >= 25%.", "No Touching": "No threshold crossed."},
            "objective_kpis": {"Awareness": ["CPM", "Frequency", "Impressions"], "Traffic": ["Link clicks/clicks", "CTR", "CPC"], "Engagement": ["Video views", "CTR", "CPC"], "Messages": ["Messages", "CTR", "CPM", "CPR"], "Lead generation": ["Leads", "CTR", "CPM", "CPL"], "Conversions": ["Conversions", "CPA", "Conversion value", "ROAS"]}
        },
        "consistency_audit": {"active_accounts": len(account_list), "unique_account_keys": len(keys), "accounts_by_platform": dict(platform_counts), "campaigns_evaluated_by_platform": dict(campaign_counts), "campaign_objective_counts": dict(sorted(objective_counts.items())), "accounts_without_dashboard": missing}
    }
    return data, render(data)


def render_driver(driver: dict[str, Any]) -> str:
    cur, delta = driver["current"], driver["changes"]
    return f'''<article class="driver"><div class="campaign-line"><strong>{esc(driver['campaign'])}</strong><span class="objective">{esc(driver['objective'])}</span></div><div class="kpis"><b>{esc(cur['result_label'])} {cur['results']:,.0f} <span>{fmt_delta(delta['results_pct'])}</span></b><b>{esc(cur['cost_label'])} ฿{cur['cost_per_result']:,.2f} <span>{fmt_delta(delta['cost_per_result_pct'])}</span></b></div><p><em>Why</em> {esc(driver['why'])}</p><p><em>Action</em> {esc(driver['action'])}</p></article>'''


def render(data: dict[str, Any]) -> str:
    colors = {"Immediate Action": "#ff5d68", "Watch Out": "#ffb258", "Ready to Scale": "#4dd68a", "No Touching": "#8c98a8"}
    sections = []
    for label in ORDER:
        rows = [a for a in data["accounts"] if a["decision"] == label]; cards = []
        for a in rows:
            tag, attr = ("a", f' href="{esc(a["href"])}"') if a.get("href") else ("article", "")
            cards.append(f'''<{tag}{attr} class="account-card {a['platform'].lower()}" data-account-key="{esc(a['platform'])}::{esc(a['account_id'])}"><header><div><span class="platform">{esc(a['platform'])}</span><h3>{esc(a['account'])}</h3></div><span class="spend">฿{a['account_totals']['spend']:,.0f}</span></header><div class="meta">{a['campaigns_evaluated']} delivered campaign{'s' if a['campaigns_evaluated'] != 1 else ''} · {a['account_totals']['impressions']:,.0f} impressions</div>{''.join(render_driver(d) for d in a['drivers'])}{'<div class="open">Open account dashboard →</div>' if a.get('href') else ''}</{tag}>''')
        sections.append(f'''<section class="decision-section" style="--decision:{colors[label]}"><div class="section-head"><h2>{label}</h2><span>{len(rows)} account{'s' if len(rows) != 1 else ''}</span></div><div class="account-grid">{''.join(cards)}</div></section>''')
    framework = "".join(f"<div><b>{esc(obj)}</b><span>{esc(' · '.join(kpis))}</span></div>" for obj, kpis in data["methodology"]["objective_kpis"].items())
    counts = "".join(f'<div class="count" style="--c:{colors[label]}"><b>{data["decision_counts"][label]}</b><span>{label}</span></div>' for label in ORDER)
    spend = data["overall"]["total_ad_spend"]; prior = data["overall"]["previous_ad_spend"]
    embedded = json.dumps(data, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")
    return f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>GROOV Ads Command Center</title><style>
:root{{--bg:#050708;--card:#11161a;--nested:#171d21;--text:#faf9f6;--muted:#959a9c;--border:#2a3135;--copper:#ca743e;--soft:#e0a17a;--blue:#72a8b9;--deep:#173e50;--meta:#1683f3;--tiktok:#25f4ee;--google:#fbbc04}}*{{box-sizing:border-box}}html,body{{overflow-x:hidden}}body{{margin:0;background:var(--bg);color:var(--text);font-family:-apple-system,BlinkMacSystemFont,"SF Pro Display","Segoe UI",sans-serif}}main{{width:min(1500px,calc(100% - 40px));margin:auto;padding:28px 0 60px}}.top{{display:flex;justify-content:space-between;gap:28px;align-items:flex-start;border-bottom:4px solid var(--copper);padding:12px 0 24px}}.brand{{display:flex;gap:20px;align-items:center}}.brand img{{width:165px;height:68px;object-fit:contain}}h1{{font-size:clamp(30px,4vw,54px);letter-spacing:-.045em;margin:0}}.eyebrow{{color:var(--soft);font-weight:750;letter-spacing:.13em;text-transform:uppercase;font-size:11px}}.period{{text-align:right;color:var(--muted);font-size:13px;line-height:1.6}}.readonly{{display:inline-flex;color:#d8f4ff;background:var(--deep);border:1px solid var(--blue);border-radius:999px;padding:5px 10px;font-weight:700}}.overall{{display:grid;grid-template-columns:2fr 1fr;gap:12px;margin:20px 0 12px}}.overall-card{{min-height:132px;padding:22px 24px;border-radius:12px;display:flex;flex-direction:column;justify-content:center;box-shadow:0 8px 26px #0005}}.overall-card span{{font-size:12px;text-transform:uppercase;letter-spacing:.12em;font-weight:750}}.overall-card b{{font-size:38px;letter-spacing:-.04em;margin:5px 0}}.overall-card small{{font-size:12px}}.spend-card{{background:linear-gradient(135deg,var(--copper),#8d4427)}}.account-total{{background:linear-gradient(135deg,var(--deep),#245f77)}}.summary{{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin:12px 0 20px}}.count{{background:linear-gradient(145deg,var(--nested),var(--card));border:1px solid var(--border);border-top:3px solid var(--c);padding:16px;border-radius:12px;display:flex;align-items:baseline;gap:10px}}.count b{{font-size:32px}}.count span{{color:var(--muted);font-size:13px;font-weight:650}}.framework{{background:var(--card);border:1px solid var(--border);border-radius:12px;padding:15px 17px;margin-bottom:24px}}.framework-head{{display:flex;justify-content:space-between;gap:20px;margin-bottom:10px}}.framework-head span{{color:var(--muted);font-size:12px}}.framework-grid{{display:grid;grid-template-columns:repeat(6,1fr);gap:8px}}.framework-grid div{{background:var(--nested);border-radius:10px;padding:9px}}.framework-grid b,.framework-grid span{{display:block;font-size:11px}}.framework-grid span{{color:var(--muted);margin-top:4px;line-height:1.35}}.decision-section{{margin:26px 0 34px}}.section-head{{display:flex;align-items:center;justify-content:space-between;border-left:4px solid var(--decision);padding-left:12px;margin-bottom:11px}}h2{{margin:0;font-size:25px}}.section-head span,.meta{{color:var(--muted);font-size:11px}}.account-grid{{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}}a.account-card{{display:block;color:inherit;text-decoration:none;transition:border-color .15s,transform .15s}}a.account-card:hover{{border-color:var(--copper);transform:translateY(-2px)}}.open{{margin-top:10px;font-size:11px;font-weight:700;color:var(--soft)}}.account-card{{min-width:0;background:linear-gradient(160deg,var(--nested),var(--card));border:1px solid var(--border);border-radius:12px;padding:15px;box-shadow:0 8px 26px #0005}}.account-card.meta{{border-top:2px solid var(--meta)}}.account-card.tiktok{{border-top:2px solid var(--tiktok)}}.account-card.google{{border-top:2px solid var(--google)}}.account-card>header{{display:flex;justify-content:space-between;gap:16px}}h3{{font-size:17px;margin:5px 0 0}}.platform{{font-size:10px;text-transform:uppercase;letter-spacing:.12em;color:var(--muted)}}.spend{{font-weight:750}}.meta{{margin:8px 0 10px}}.driver{{border-top:1px solid var(--border);padding-top:10px;margin-top:8px}}.campaign-line{{display:flex;gap:8px;justify-content:space-between}}.campaign-line strong{{font-size:13px;overflow-wrap:anywhere}}.objective{{flex:none;background:#222b36;padding:3px 7px;border-radius:999px;font-size:9px;font-weight:700}}.kpis{{display:flex;gap:6px;flex-wrap:wrap;margin-top:7px}}.kpis b{{font-size:10px;background:#0b0e12;border:1px solid var(--border);padding:5px 7px;border-radius:7px}}.kpis span{{color:var(--muted);font-weight:500;margin-left:4px}}p{{font-size:11px;color:#c3cad3;line-height:1.4;margin:6px 0}}p em{{color:var(--decision);font-style:normal;font-weight:800;margin-right:4px}}footer{{color:var(--muted);font-size:11px;border-top:1px solid var(--border);padding-top:17px;margin-top:26px;display:flex;justify-content:space-between;gap:20px}}
@media(max-width:950px){{.framework-grid{{grid-template-columns:repeat(3,1fr)}}}}@media(max-width:700px){{main{{width:min(100% - 24px,1500px)}}.top{{display:block}}.period{{text-align:left;margin-top:14px}}.overall{{grid-template-columns:1fr}}.summary{{grid-template-columns:repeat(2,1fr)}}.account-grid{{grid-template-columns:1fr}}.framework-grid{{grid-template-columns:repeat(2,1fr)}}footer{{display:block}}}}@media(max-width:390px){{.brand{{gap:12px}}.brand img{{width:105px}}.summary{{grid-template-columns:1fr}}.framework-grid{{grid-template-columns:1fr}}}}
</style></head><body><main><header class="top"><div class="brand"><img src="{data_uri(LOGO)}" alt="Official GROOV logo"><div><div class="eyebrow">All-account decision view</div><h1>Ads Command Center</h1></div></div><div class="period"><span class="readonly">Read-only · no changes made</span><br>Current <b>{CUR_LABEL}</b><br>Comparison {PREV_LABEL}<br>Built {GENERATED} ICT<br>{data["account_count"]} connected-active accounts · {data['campaigns_evaluated']} delivered campaigns</div></header><section class="overall"><div class="overall-card spend-card"><span>Total current ad spend</span><b>฿{spend:,.2f}</b><small>{fmt_delta(change(spend, prior))} vs {PREV_SHORT}</small></div><div class="overall-card account-total"><span>Connected-active accounts</span><b>{data["account_count"]}</b><small>{" · ".join(f"{n} {p}" for p, n in sorted(data["platform_counts"].items(), key=lambda x: -x[1]))}</small></div></section><div class="summary">{counts}</div><section class="framework"><div class="framework-head"><b>Objective KPI framework</b><span>Equal 7-day periods · campaign severity rolls up to account</span></div><div class="framework-grid">{framework}</div></section>{''.join(sections)}<footer><span>Decision order: Immediate Action › Watch Out › Ready to Scale › No Touching.</span><span>Read-only Windsor export · no ad settings changed · exact values are preserved in command-center-data.json.</span></footer><script id="command-center-data" type="application/json">{embedded}</script></main></body></html>'''


if __name__ == "__main__":
    output, page = build(); HTML_DIR.mkdir(parents=True, exist_ok=True)
    data_path = ROOT / "command-center-data.json"; html_path = HTML_DIR / "index.html"
    data_path.write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")
    html_path.write_text(page, encoding="utf-8")
    print(json.dumps({"script": str(Path(__file__)), "html": str(html_path), "data": str(data_path), "accounts": output["account_count"], "counts": output["decision_counts"], "platform_counts": output["platform_counts"], "campaigns_evaluated": output["campaigns_evaluated"], "spend": output["overall"]["total_ad_spend"], "accounts_without_dashboard": output["consistency_audit"]["accounts_without_dashboard"]}, ensure_ascii=False, indent=2))
