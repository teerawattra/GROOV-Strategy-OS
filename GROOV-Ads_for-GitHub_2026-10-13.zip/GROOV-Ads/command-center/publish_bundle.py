#!/usr/bin/env python3
"""Copy html/ into publish/ for the claude.ai artifact.

The artifact host wraps the main page in its own <!doctype>/<head>/<body> skeleton, so index.html
loses those tags here; account pages are published as separate files and keep theirs.
"""
import re
import shutil
from period import HTML_DIR, ROOT

OUT = ROOT / "publish"
shutil.rmtree(OUT, ignore_errors=True)
shutil.copytree(HTML_DIR, OUT)
page = (OUT / "index.html").read_text(encoding="utf-8")
page = re.sub(r'^<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">', "", page)
page = page.replace("</style></head><body>", ":root{{color-scheme:dark}}</style>".replace("{{", "{").replace("}}", "}"), 1)
page = page.replace("</body></html>", "")
assert "<html" not in page and "<body" not in page and page.lstrip().startswith("<title>")
(OUT / "index.html").write_text(page, encoding="utf-8")
for f in OUT.rglob("*.html"):  # broken characters in source ad copy: keep them, but as an entity
    t = f.read_text(encoding="utf-8")
    if "\ufffd" in t: f.write_text(t.replace("\ufffd", "&#xFFFD;"), encoding="utf-8")
pages = sorted(str(p.relative_to(OUT)) for p in OUT.rglob("*.html") if p.name != "index.html" or p.parent != OUT)
print(len(pages), "account pages;", round(sum(p.stat().st_size for p in OUT.rglob("*.html")) / 1e6, 1), "MB")
