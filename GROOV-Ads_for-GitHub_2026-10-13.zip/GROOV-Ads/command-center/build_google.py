#!/usr/bin/env python3
import base64
import hashlib
import html
import json
import re
from collections import defaultdict
from pathlib import Path

from period import (CURRENT_DATES, CURRENT as CUR_WIN, COMPARISON as PREV_WIN, CUR_LABEL, CUR_SHORT, CUR_UPPER,
                    PREV_LABEL, WINDOW_LABEL, LOGO as GROOV_LOGO, back_link)

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "source" / "google-ad-daily.json"
OUT_DIR = ROOT / "html" / "google"
MANIFEST = ROOT / "google-manifest.json"
LOGO = GROOV_LOGO
CURRENT = (CUR_WIN["start"], CUR_WIN["end"])
PREVIOUS = (PREV_WIN["start"], PREV_WIN["end"])
GOOGLE = ["#4285f4", "#ea4335", "#fbbc04", "#34a853"]


def num(v):
    try:
        return float(v or 0)
    except (TypeError, ValueError):
        return 0.0


def esc(v):
    return html.escape(str(v if v is not None else ""))


def slugify(v):
    return re.sub(r"-+", "-", re.sub(r"[^a-z0-9]+", "-", v.lower())).strip("-") or "account"


def within(row, window):
    return window[0] <= row.get("date", "") <= window[1]


def aggregate(rows):
    spend = sum(num(r.get("spend")) for r in rows)
    impressions = sum(num(r.get("impressions")) for r in rows)
    clicks = sum(num(r.get("clicks")) for r in rows)
    conversions = sum(num(r.get("conversions")) for r in rows)
    value = sum(num(r.get("conversion_value")) for r in rows)
    return {
        "spend": spend,
        "impressions": impressions,
        "clicks": clicks,
        "conversions": conversions,
        "value": value,
        "ctr": clicks / impressions * 100 if impressions else 0,
        "cpc": spend / clicks if clicks else 0,
        "cpm": spend / impressions * 1000 if impressions else 0,
        "cpa": spend / conversions if conversions else 0,
        "roas": value / spend if spend else 0,
    }


def daily_metrics(rows):
    """Aggregate exact campaign-day rows and retain undefined ratios as gaps."""
    values = aggregate(rows)
    if not rows:
        return {key: None for key in values}
    if not values["impressions"]:
        values["ctr"] = None
        values["cpm"] = None
    if not values["clicks"]:
        values["cpc"] = None
    if not values["conversions"]:
        values["cpa"] = None
    if not values["spend"]:
        values["roas"] = None
    return values


def change(cur, prev):
    return None if prev == 0 else (cur / prev - 1) * 100


def money(v):
    return f"฿{v:,.2f}"


def integer(v):
    return f"{v:,.0f}"


def decimal(v):
    return f"{v:,.1f}"


def percent(v):
    return f"{v:.2f}%"


def multiple(v):
    return f"{v:.2f}×"


def delta_text(cur, prev):
    d = change(cur, prev)
    if d is None:
        return "new" if cur else "—"
    return f"{d:+.1f}%"


def metric_pair(cur, prev, key, formatter):
    return f'<span class="now">{formatter(cur[key])}</span><span class="prior">Prev {formatter(prev[key])} · {delta_text(cur[key], prev[key])}</span>'


def objective_for(channel, name):
    name_lower = (name or "").lower()
    return "CONVERSION" if channel == "PERFORMANCE_MAX" or "conv" in name_lower else "TRAFFIC"


def status_info(status):
    status = status or "NOT PROVIDED"
    if status == "ENABLED":
        return "active", "Active / enabled"
    if status == "PAUSED":
        return "paused", "Paused"
    return "limited", status.replace("_", " ").title()


def evidence(cur, prev, objective):
    if objective == "CONVERSION":
        return (
            f"Conversions {decimal(cur['conversions'])} vs {decimal(prev['conversions'])}; "
            f"CPA {money(cur['cpa']) if cur['conversions'] else '—'} vs {money(prev['cpa']) if prev['conversions'] else '—'}; "
            f"value {money(cur['value'])} vs {money(prev['value'])}; ROAS {multiple(cur['roas'])} vs {multiple(prev['roas'])}."
        )
    return (
        f"Clicks {integer(cur['clicks'])} vs {integer(prev['clicks'])}; CTR {percent(cur['ctr'])} vs {percent(prev['ctr'])}; "
        f"CPC {money(cur['cpc']) if cur['clicks'] else '—'} vs {money(prev['cpc']) if prev['clicks'] else '—'}; "
        f"impressions {integer(cur['impressions'])} vs {integer(prev['impressions'])}."
    )


def make_decision(cur, prev, status, objective):
    ev = evidence(cur, prev, objective)
    if status and status != "ENABLED":
        return "HOLD", "hold", ev + " Source status is not enabled; confirm that state is intentional before changing anything."
    if cur["spend"] == 0 and cur["impressions"] == 0:
        return "NO DELIVERY", "watch", ev + " No current delivery; check eligibility, dates, targeting and budget if delivery was expected."
    if objective == "CONVERSION":
        if cur["conversions"] == 0:
            return "INVESTIGATE", "watch", ev + " Spend produced no recorded conversions; validate tracking and traffic quality before budget changes."
        conv_d = change(cur["conversions"], prev["conversions"])
        cpa_d = change(cur["cpa"], prev["cpa"]) if prev["conversions"] else None
        roas_d = change(cur["roas"], prev["roas"]) if prev["roas"] else None
        if prev["spend"] == 0:
            return "LEARNING", "learn", ev + " This is a new comparison baseline; keep stable until more comparable history is available."
        if conv_d is not None and conv_d < -25 and cpa_d is not None and cpa_d > 25:
            return "WATCH", "watch", ev + " Conversion volume fell while CPA rose; inspect conversion mix, assets and audience signals."
        if roas_d is not None and roas_d < -30:
            return "WATCH", "watch", ev + " Recorded return fell materially; inspect conversion-value quality before changing spend."
        return "MAINTAIN", "maintain", ev + " No target CPA or ROAS was supplied, so hold and assess against the business target."
    if prev["spend"] == 0:
        return "LEARNING", "learn", ev + " New delivery has no prior-period baseline; avoid reacting to a short first week."
    ctr_d = change(cur["ctr"], prev["ctr"])
    cpc_d = change(cur["cpc"], prev["cpc"]) if prev["clicks"] else None
    if (ctr_d is not None and ctr_d < -25) or (cpc_d is not None and cpc_d > 30):
        return "WATCH", "watch", ev + " Traffic efficiency weakened; inspect queries, geography, assets and landing-page relevance."
    return "MAINTAIN", "maintain", ev + " Traffic efficiency is broadly stable; keep collecting comparable data."


def first_last(rows):
    delivered = [r["date"] for r in rows if num(r.get("spend")) > 0 or num(r.get("impressions")) > 0]
    return (min(delivered), max(delivered)) if delivered else (None, None)


def entity(rows, first, id_key, name_key, status_key, channel=None, parent=None):
    cur = aggregate([r for r in rows if within(r, CURRENT)])
    prev = aggregate([r for r in rows if within(r, PREVIOUS)])
    first_seen, last_seen = first_last(rows)
    name = first.get(name_key) or "Not provided"
    channel = channel or first.get("advertising_channel_type") or "UNKNOWN"
    objective = objective_for(channel, first.get("campaign") or name)
    label, cls, why = make_decision(cur, prev, first.get(status_key), objective)
    return {
        "id": first.get(id_key), "name": name, "status": first.get(status_key), "channel": channel,
        "objective": objective, "parent": parent, "cur": cur, "prev": prev, "first": first_seen,
        "last": last_seen, "decision": label, "decision_class": cls, "why": why,
    }


def group_entities(rows, key, name_key, status_key, parent_key=None):
    groups = defaultdict(list)
    for row in rows:
        if row.get(key) is not None:
            groups[str(row.get(key))].append(row)
    out = []
    for _, group in groups.items():
        f = group[0]
        out.append(entity(group, f, key, name_key, status_key, parent=f.get(parent_key) if parent_key else None))
    return sorted(out, key=lambda x: (x["cur"]["spend"], x["cur"]["impressions"]), reverse=True)


def badge(entity):
    cls, text = status_info(entity["status"])
    timing = f"Observed {entity['first'] or '—'} to {entity['last'] or '—'}"
    return f'<span class="status {cls}"><b>{esc(text)}</b><small>{esc(timing)}</small></span>'


def decision_box(entity):
    return f'<div class="decision"><span class="decision-tag {entity["decision_class"]}">{esc(entity["decision"])}</span><p>{esc(entity["why"])}</p></div>'


def table_row(e, kind):
    c, p = e["cur"], e["prev"]
    sub = f'{e["channel"]} · {e["objective"]}' if kind == "campaign" else e.get("parent") or ""
    return f'''<tr>
      <td class="entity"><b>{esc(e["name"])}</b><small>{esc(sub)}</small><code>{esc(e["id"])}</code></td>
      <td>{badge(e)}</td>
      <td>{metric_pair(c,p,"spend",money)}</td>
      <td>{metric_pair(c,p,"impressions",integer)}</td>
      <td>{metric_pair(c,p,"clicks",integer)}</td>
      <td>{metric_pair(c,p,"ctr",percent)}</td>
      <td>{metric_pair(c,p,"cpc",money)}</td>
      <td>{metric_pair(c,p,"conversions",decimal)}</td>
      <td>{metric_pair(c,p,"cpa",lambda v: money(v) if v else "—")}</td>
      <td>{metric_pair(c,p,"value",money)}</td>
      <td>{metric_pair(c,p,"roas",multiple)}</td>
      <td>{decision_box(e)}</td>
    </tr>'''


def chart_tick(value, value_format):
    if value_format == "money":
        return f"฿{value:,.0f}"
    if value_format == "percent":
        return f"{value:.1f}%"
    if value_format == "multiple":
        return f"{value:.1f}×"
    return f"{value:,.0f}"


def svg_chart(campaigns, key, label, value_format="number"):
    width, height, left, top, bottom = 760, 220, 68, 18, 34
    inner_w, inner_h = width - left - 14, height - top - bottom
    values = [c["daily"][date][key] for c in campaigns for date in CURRENT_DATES]
    numeric = [value for value in values if value is not None]
    vmax = max(numeric + [1.0])
    out = [f'<svg viewBox="0 0 {width} {height}" role="img" aria-label="Daily {esc(label)}">']
    for step in range(4):
        y = top + inner_h * step / 3
        val = vmax * (1 - step / 3)
        out.append(f'<line x1="{left}" y1="{y:.1f}" x2="{width-14}" y2="{y:.1f}"/><text x="{left-7}" y="{y+4:.1f}" text-anchor="end">{esc(chart_tick(val, value_format))}</text>')
    for index, campaign in enumerate(campaigns):
        color = GOOGLE[index % len(GOOGLE)]
        segments = []
        points = []
        circles = []
        for day_index, date in enumerate(CURRENT_DATES):
            value = campaign["daily"][date][key]
            x = left + inner_w * day_index / max(len(CURRENT_DATES) - 1, 1)
            if value is None:
                if points:
                    segments.append(points)
                    points = []
                continue
            y = top + inner_h - value / vmax * inner_h
            points.append(f"{x:.1f},{y:.1f}")
            circles.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="2.6" fill="{color}" data-campaign="{esc(campaign["name"])}" data-date="{date}" data-metric="{esc(key)}" data-value="{value:.10g}"><title>{esc(campaign["name"])} · {date} · {esc(label)}: {value:.10g}</title></circle>')
        if points:
            segments.append(points)
        for segment in segments:
            if len(segment) > 1:
                out.append(f'<polyline points="{" ".join(segment)}" fill="none" stroke="{color}" stroke-width="2.3"/>')
        out.extend(circles)
    for day_index, date in enumerate(CURRENT_DATES):
        x = left + inner_w * day_index / max(len(CURRENT_DATES) - 1, 1)
        out.append(f'<text x="{x:.1f}" y="{height-9}" text-anchor="middle">{date[8:]}</text>')
    return "".join(out) + "</svg>"


def unavailable_chart(label, reason):
    return f'<div class="chart unavailable"><h4>{esc(label)}</h4><div class="na">N/A</div><p>{esc(reason)}</p></div>'


def render(account_rows, account_name, account_id):
    campaigns = group_entities(account_rows, "campaign_id", "campaign", "campaign_status")
    adgroups = group_entities(account_rows, "ad_group_id", "ad_group_name", "ad_group_status", "campaign")
    campaign_source = defaultdict(list)
    for row in account_rows:
        if row.get("campaign_id") is not None:
            campaign_source[str(row.get("campaign_id"))].append(row)
    for campaign in campaigns:
        campaign["daily"] = {
            date: daily_metrics([row for row in campaign_source[campaign["id"]] if row.get("date") == date])
            for date in CURRENT_DATES
        }

    # The source has no ad_id; each unique ad-group + RSA text is one exact responsive search ad.
    rsa_groups = defaultdict(list)
    for row in account_rows:
        headline = row.get("ad_responsive_search_ad_headlines_combined_text")
        if row.get("ad_group_id") and headline:
            rsa_groups[(str(row.get("ad_group_id")), headline, row.get("ad_responsive_search_ad_descriptions_combined_text") or "")].append(row)
    ads = []
    for idx, ((group_id, headline, description), group) in enumerate(rsa_groups.items(), 1):
        f = dict(group[0])
        f["synthetic_ad_key"] = f"rsa-{group_id}-{idx}"
        f["rsa_name"] = f.get("ad_group_ad_name") or "Responsive search ad"
        ad = entity(group, f, "synthetic_ad_key", "rsa_name", "ad_group_ad_status", parent=f.get("ad_group_name"))
        ad["headline"] = headline
        ad["description"] = description
        ad["url"] = f.get("ad_final_urls") or ""
        ads.append(ad)
    ads.sort(key=lambda x: x["cur"]["spend"], reverse=True)

    cur = aggregate([r for r in account_rows if within(r, CURRENT)])
    prev = aggregate([r for r in account_rows if within(r, PREVIOUS)])
    account_decision = {
        "id": account_id, "name": account_name, "status": "ENABLED", "channel": "MIXED", "objective": "MIXED",
        "parent": None, "cur": cur, "prev": prev, "first": min(r["date"] for r in account_rows),
        "last": max(r["date"] for r in account_rows),
    }
    label, cls, why = make_decision(cur, prev, "ENABLED", "CONVERSION")
    account_decision.update(decision=label, decision_class=cls, why=why)

    logo_uri = "data:image/png;base64," + base64.b64encode(LOGO.read_bytes()).decode("ascii")
    accents = "".join(f'<i style="background:{c}"></i>' for c in GOOGLE)
    campaign_rows = "".join(table_row(e, "campaign") for e in campaigns)
    adgroup_rows = "".join(table_row(e, "adgroup") for e in adgroups)
    legend = "".join(f'<span><i style="background:{GOOGLE[index % len(GOOGLE)]}"></i>{esc(campaign["name"])}</span>' for index, campaign in enumerate(campaigns))
    trend_groups = [
        ("Delivery", [
            f'<div class="chart"><h4>Spend (THB)</h4>{svg_chart(campaigns, "spend", "Spend", "money")}</div>',
            f'<div class="chart"><h4>Impressions</h4>{svg_chart(campaigns, "impressions", "Impressions")}</div>',
            unavailable_chart("Reach", "N/A — Reach is not supplied in the Google Ads source export."),
            unavailable_chart("Frequency", "N/A — Frequency cannot be calculated because Reach is not supplied."),
        ]),
        ("Click efficiency", [
            f'<div class="chart"><h4>Clicks</h4>{svg_chart(campaigns, "clicks", "Clicks")}</div>',
            f'<div class="chart"><h4>CTR</h4>{svg_chart(campaigns, "ctr", "CTR", "percent")}</div>',
            f'<div class="chart"><h4>CPC</h4>{svg_chart(campaigns, "cpc", "CPC", "money")}</div>',
            f'<div class="chart"><h4>CPM</h4>{svg_chart(campaigns, "cpm", "CPM", "money")}</div>',
        ]),
        ("Objective result efficiency", [
            f'<div class="chart"><h4>Conversions</h4>{svg_chart(campaigns, "conversions", "Conversions")}</div>',
            f'<div class="chart"><h4>CPA</h4>{svg_chart(campaigns, "cpa", "CPA", "money")}</div>',
            f'<div class="chart"><h4>Conversion value (THB)</h4>{svg_chart(campaigns, "value", "Conversion value", "money")}</div>',
            f'<div class="chart"><h4>ROAS</h4>{svg_chart(campaigns, "roas", "ROAS", "multiple")}</div>',
        ]),
    ]
    trend_html = "".join(f'<section class="trend-group"><h3>{esc(title)}</h3><div class="charts">{"".join(cards)}</div></section>' for title, cards in trend_groups)
    ad_cards = []
    for ad in ads:
        ad_cards.append(f'''<article class="ad-card">
          <div class="g-accent">{accents}</div>
          <div class="ad-copy"><span>RESPONSIVE SEARCH AD · {esc(ad["parent"])}</span><h3>{esc(ad["headline"])}</h3><p>{esc(ad["description"])}</p><code>{esc(ad["url"])}</code></div>
          <div>{badge(ad)}</div>
          <div class="ad-metrics">
            <span>{metric_pair(ad["cur"],ad["prev"],"spend",money)}<small>Spend</small></span>
            <span>{metric_pair(ad["cur"],ad["prev"],"impressions",integer)}<small>Impressions</small></span>
            <span>{metric_pair(ad["cur"],ad["prev"],"clicks",integer)}<small>Clicks</small></span>
            <span>{metric_pair(ad["cur"],ad["prev"],"ctr",percent)}<small>CTR</small></span>
            <span>{metric_pair(ad["cur"],ad["prev"],"cpc",money)}<small>CPC</small></span>
            <span>{metric_pair(ad["cur"],ad["prev"],"conversions",decimal)}<small>Conversions</small></span>
            <span>{metric_pair(ad["cur"],ad["prev"],"cpa",lambda v:money(v) if v else "—")}<small>CPA</small></span>
            <span>{metric_pair(ad["cur"],ad["prev"],"roas",multiple)}<small>ROAS</small></span>
          </div>{decision_box(ad)}
        </article>''')

    def kpi(label, key, formatter):
        return f'<div class="kpi"><span>{esc(label)}</span><b>{formatter(cur[key])}</b><small>Previous {formatter(prev[key])} · {delta_text(cur[key],prev[key])}</small></div>'

    cur_campaign_count = sum(1 for e in campaigns if e["cur"]["spend"] > 0 or e["cur"]["impressions"] > 0)
    prev_campaign_count = sum(1 for e in campaigns if e["prev"]["spend"] > 0 or e["prev"]["impressions"] > 0)
    campaign_kpi = f'<div class="kpi"><span>Campaigns delivering</span><b>{cur_campaign_count}</b><small>Previous {prev_campaign_count} · {delta_text(cur_campaign_count,prev_campaign_count)}</small></div>'

    css = r'''
:root{--bg:#050708;--surface:#11161a;--surface2:#171d21;--ink:#faf9f6;--muted:#959a9c;--line:#2a3135;--copper:#ca743e;--copper-soft:#e0a17a;--blue:#72a8b9;--blue-deep:#173e50}*{box-sizing:border-box}html{background:var(--bg)}body{margin:0;background:var(--bg);color:var(--ink);font-family:-apple-system,BlinkMacSystemFont,"SF Pro Display","SF Pro Text","Helvetica Neue",Arial,sans-serif}.page{max-width:1680px;margin:auto}.topline{height:4px;display:grid;grid-template-columns:repeat(4,1fr)}.topline i,.g-accent i{display:block}.hero{padding:38px 48px 32px;display:grid;grid-template-columns:170px 1fr auto;gap:30px;align-items:center;border-bottom:1px solid var(--line)}.hero img{width:150px;height:auto}.eyebrow{font-size:11px;letter-spacing:.16em;color:var(--copper-soft);font-weight:800}.hero h1{font-size:44px;line-height:1;margin:8px 0 10px}.hero p,.period{color:var(--muted);margin:0}.period{text-align:right;font-size:13px;line-height:1.7}.period b{display:block;color:var(--ink);font-size:18px}main{padding:28px 36px 70px}.kpis{display:grid;grid-template-columns:repeat(5,1fr);gap:12px}.kpi,.panel,.ad-card,.callout{background:var(--surface);border:1px solid var(--line);border-radius:14px}.kpi{padding:18px}.kpi>span{display:block;color:var(--muted);font-size:11px;text-transform:uppercase;letter-spacing:.08em}.kpi>b{display:block;font-size:25px;margin:6px 0}.kpi small,.prior{color:var(--muted)}.account-call{display:grid;grid-template-columns:150px 1fr;gap:18px;align-items:start;margin:16px 0 28px;padding:20px;background:var(--surface2);border-left:4px solid var(--copper);border-radius:8px}.section-head{display:flex;justify-content:space-between;gap:20px;align-items:end;margin:32px 0 12px}.section-head h2{font-size:28px;margin:0}.section-head p{margin:0;color:var(--muted);font-size:12px}.panel{overflow:hidden}.table-wrap{overflow-x:auto}table{width:100%;min-width:1540px;border-collapse:collapse}th{padding:13px 10px;text-align:left;background:var(--surface2);color:var(--muted);font-size:10px;text-transform:uppercase;letter-spacing:.05em}td{padding:14px 10px;border-top:1px solid var(--line);vertical-align:top;font-size:12px}.entity{min-width:225px}.entity b,.entity small,.entity code{display:block}.entity small{color:var(--muted);margin:5px 0}.entity code,.ad-copy code{color:var(--blue);font-size:10px;white-space:normal}.now{display:block;font-weight:800;white-space:nowrap}.prior{display:block;font-size:9px;margin-top:5px;white-space:nowrap}.status{display:inline-block;padding:7px 9px;border:1px solid var(--line);border-radius:8px;min-width:120px}.status b,.status small{display:block}.status small{font-size:9px;color:var(--muted);margin-top:4px}.status.active{border-left:4px solid var(--blue)}.status.paused{border-left:4px solid var(--copper)}.status.limited{border-left:4px solid var(--muted)}.decision{min-width:260px}.decision-tag{display:inline-block;border:1px solid var(--line);border-radius:999px;padding:4px 8px;font-size:9px;font-weight:900;letter-spacing:.08em}.decision-tag.maintain{color:var(--blue);border-color:var(--blue-deep)}.decision-tag.watch{color:var(--copper-soft);border-color:var(--copper)}.decision-tag.learn{color:var(--muted)}.decision-tag.hold{color:var(--ink)}.decision p{font-size:10px;line-height:1.45;color:var(--muted);margin:7px 0 0}.ads{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}.ad-card{padding:18px;position:relative;overflow:hidden}.g-accent{position:absolute;left:0;top:0;right:0;height:3px;display:grid;grid-template-columns:repeat(4,1fr)}.ad-copy>span{color:var(--muted);font-size:9px;letter-spacing:.1em}.ad-copy h3{font-size:16px;line-height:1.35;margin:8px 0;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}.ad-copy p{color:var(--muted);font-size:11px;line-height:1.45;display:-webkit-box;-webkit-line-clamp:4;-webkit-box-orient:vertical;overflow:hidden}.ad-card>.status{margin:12px 0}.ad-metrics{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin:10px 0}.ad-metrics>span{padding:9px;background:var(--surface2);border-radius:7px}.ad-metrics small{display:block;color:var(--muted);font-size:8px;margin-top:7px;text-transform:uppercase}.notes{margin-top:30px;padding:22px}.notes h2{margin-top:0}.notes li{color:var(--muted);line-height:1.55;margin:7px 0}.notes b{color:var(--ink)}@media(max-width:1050px){.hero{grid-template-columns:120px 1fr}.hero img{width:110px}.period{grid-column:1/-1;text-align:left}.kpis{grid-template-columns:repeat(2,1fr)}.ads{grid-template-columns:1fr}}@media(max-width:620px){.hero{padding:26px 20px;grid-template-columns:1fr}.hero h1{font-size:34px}.hero img{width:120px}main{padding:20px 12px 50px}.kpis{grid-template-columns:1fr}.account-call{grid-template-columns:1fr}.section-head{display:block}.section-head p{margin-top:7px}.ad-metrics{grid-template-columns:repeat(2,1fr)}}@media print{body{background:var(--bg)}.page{max-width:none}table{min-width:1300px}}
'''
    trend_css = r'''
html,body{max-width:100%;overflow-x:hidden}.trend-panel{padding:25px}.trend-group{margin-top:22px}.trend-group:first-of-type{margin-top:8px}.trend-group>h3{margin:0 0 10px;color:var(--copper-soft);font-size:16px}.charts{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.chart{min-width:0;background:var(--surface2);border:1px solid var(--line);border-radius:10px;padding:14px;overflow:hidden}.chart h4{margin:0 0 8px;font-size:13px}.chart svg{display:block;width:100%;height:auto}.chart svg text{fill:var(--muted);font-size:10px}.chart svg line{stroke:var(--line)}.legend{display:flex;flex-wrap:wrap;gap:8px 16px;margin-top:15px;color:var(--muted);font-size:10px}.legend span{display:flex;align-items:center;gap:6px;min-width:0;overflow-wrap:anywhere}.legend i{width:14px;height:3px;flex:0 0 auto}.unavailable{min-height:220px;display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center}.unavailable .na{font-size:34px;font-weight:800;color:var(--muted)}.unavailable p{max-width:360px;color:var(--muted);font-size:12px;margin:8px 0}.ad-copy{min-width:0}.ad-copy h3,.ad-copy p,.ad-copy code,.entity b,.entity small{overflow-wrap:anywhere;word-break:break-word}@media(max-width:760px){.charts{grid-template-columns:1fr}.trend-panel{padding:16px}.unavailable{min-height:170px}.legend span{width:100%}}
'''
    doc = f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{esc(account_name)} · Google Ads · {CUR_LABEL}</title><style>{css}{trend_css}</style></head><body>{back_link()}<div class="page">
<div class="topline">{accents}</div><header class="hero"><img src="{logo_uri}" alt="GROOV official logo"><div><div class="eyebrow">GOOGLE ADS · SINGLE ACCOUNT · READ ONLY</div><h1>{esc(account_name)}</h1><p>Account {esc(account_id)} · campaign, ad group and responsive search ad performance</p></div><div class="period"><b>{CUR_UPPER}</b>Equal comparison: {PREV_LABEL}<br>Daily source data · THB</div></header><main>
<section class="kpis">{kpi('Spend','spend',money)}{kpi('Impressions','impressions',integer)}{kpi('Clicks','clicks',integer)}{kpi('CTR','ctr',percent)}{kpi('CPC','cpc',money)}{kpi('Conversions','conversions',decimal)}{kpi('CPA','cpa',lambda v:money(v) if v else '—')}{kpi('Conversion value','value',money)}{kpi('ROAS','roas',multiple)}{campaign_kpi}</section>
<div class="account-call"><span class="decision-tag {account_decision['decision_class']}">{esc(account_decision['decision'])}</span><div><b>Account-level decision</b><p>{esc(account_decision['why'])}</p></div></div>
<section class="panel trend-panel"><div class="section-head"><h2>Daily current-period trends</h2><p>{CUR_SHORT} · campaign-level daily aggregation · source-supported fields only</p></div>{trend_html}<div class="legend">{legend}</div><p class="trend-note">Undefined zero-denominator efficiency metrics are left as chart gaps, not treated as zero. Reach and Frequency are N/A because the source does not supply Reach.</p></section>
<div class="section-head"><h2>Campaigns · {len(campaigns)}</h2><p>Current value shown first; previous equal 7-day value and change beneath.</p></div><section class="panel table-wrap"><table><thead><tr><th>Campaign</th><th>Delivery</th><th>Spend</th><th>Impr.</th><th>Clicks</th><th>CTR</th><th>CPC</th><th>Conv.</th><th>CPA</th><th>Value</th><th>ROAS</th><th>Decision</th></tr></thead><tbody>{campaign_rows}</tbody></table></section>
<div class="section-head"><h2>Ad groups · {len(adgroups)}</h2><p>Search ad groups present in the source; Performance Max has no ad-group rows in this export.</p></div><section class="panel table-wrap"><table><thead><tr><th>Ad group</th><th>Delivery</th><th>Spend</th><th>Impr.</th><th>Clicks</th><th>CTR</th><th>CPC</th><th>Conv.</th><th>CPA</th><th>Value</th><th>ROAS</th><th>Decision</th></tr></thead><tbody>{adgroup_rows}</tbody></table></section>
<div class="section-head"><h2>Responsive search ads · {len(ads)}</h2><p>Exact combined source assets; current and previous results at ad level.</p></div><section class="ads">{''.join(ad_cards)}</section>
<section class="callout notes"><h2>Reading notes & timing limitations</h2><ul><li><b>Fixed windows:</b> current {CUR_LABEL}; comparison {PREV_LABEL}. Both are seven calendar days.</li><li><b>Timing:</b> the source ends on {CUR_WIN['end']}. The export does not include pull time or day-completeness metadata, so the last day may be partial if extracted before account day close.</li><li><b>Status:</b> delivery labels reproduce source status. “Observed” dates are the first/last dates with spend or impressions in this 14-day file, not campaign start/end dates.</li><li><b>Decisions:</b> Performance Max is assessed as conversion-led using conversions, CPA, value and ROAS. Search is assessed as traffic-led using impressions, clicks, CTR and CPC, while conversion fields remain visible. No business targets, attribution settings or conversion definitions were supplied; decisions are diagnostic, not platform changes.</li><li><b>Unavailable KPIs:</b> Reach and Frequency are visibly marked N/A because no Reach field is present. Messaging results are not shown because no messaging field is supplied.</li><li><b>Creative representation:</b> no image URL or image asset field is supplied. Responsive Search ads therefore use the exact returned combined headlines, descriptions and final URL; no portrait image or other visual was invented.</li><li><b>Granularity:</b> source is daily and includes no ad ID, budget, search terms, asset-level Performance Max data, auction insights or approval detail. Daily charts aggregate source rows at exact campaign + date level. Responsive search ads are uniquely represented by ad group plus exact combined headline/description text.</li><li><b>Access:</b> this standalone report is read-only and was built only from the local JSON export.</li></ul></section>
</main></div></body></html>'''
    return doc, {
        "campaigns": len(campaigns), "ad_groups": len(adgroups), "responsive_search_ads": len(ads),
        "current": cur, "previous": prev, "source_rows": len(account_rows),
        "current_rows": sum(within(row, CURRENT) for row in account_rows),
        "comparison_rows": sum(within(row, PREVIOUS) for row in account_rows),
        "daily_trend_groups": 3, "daily_trend_charts": 12,
        "image_creatives": 0, "responsive_search_text_representations": len(ads),
        "unavailable_kpis": {
            "reach": "N/A — field not supplied by source export",
            "frequency": "N/A — cannot calculate without Reach",
            "messaging": "Not shown — no messaging result field supplied",
        },
    }


def main():
    rows = json.loads(SOURCE.read_text(encoding="utf-8"))
    accounts = defaultdict(list)
    for row in rows:
        accounts[(str(row.get("account_id")), row.get("account_name") or "Unnamed account")].append(row)
    active = []
    for key, account_rows in accounts.items():
        current = [r for r in account_rows if within(r, CURRENT)]
        totals = aggregate(current)
        if totals["spend"] > 0 or totals["impressions"] > 0:
            active.append((key, account_rows))
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    expected = set()
    entries = []
    for (account_id, account_name), account_rows in sorted(active, key=lambda x: x[0][1].lower()):
        filename = slugify(account_name) + ".html"
        expected.add(filename)
        output = OUT_DIR / filename
        doc, summary = render(account_rows, account_name, account_id)
        output.write_text(doc, encoding="utf-8")
        entries.append({
            "account_id": account_id, "account_name": account_name, "file": str(output.relative_to(ROOT)),
            "current_window": list(CURRENT), "comparison_window": list(PREVIOUS), **summary,
            "html_bytes": output.stat().st_size,
            "html_sha256": hashlib.sha256(output.read_bytes()).hexdigest(),
        })
    for old in OUT_DIR.glob("*.html"):
        if old.name not in expected:
            old.unlink()
    manifest = {
        "platform": "google_ads", "read_only": True, "source": str(SOURCE.relative_to(ROOT)),
        "source_total_rows": len(rows),
        "current_window": list(CURRENT), "comparison_window": list(PREVIOUS),
        "active_account_rule": "current spend > 0 OR current impressions > 0",
        "daily_trend_standard": {
            "basis": "exact campaign + date aggregation from source/google-ad-daily.json",
            "delivery": ["spend", "impressions", "reach (N/A)", "frequency (N/A)"],
            "click_efficiency": ["clicks", "ctr", "cpc", "cpm"],
            "objective_result_efficiency": ["conversions", "cpa", "conversion_value", "roas"],
            "undefined_ratios": "chart gaps; never coerced to zero",
        },
        "creative_standard": "No image fields supplied; responsive Search ads represented with exact combined text and final URL; no imagery invented.",
        "accounts": entries, "account_count": len(entries), "dashboard_count": len(entries),
    }
    MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"accounts": len(entries), "dashboards": len(entries), "manifest": str(MANIFEST), "html_dir": str(OUT_DIR), "entries": entries}))


if __name__ == "__main__":
    main()
