# Windsor → Google Sheets: setup guide (3 Sheets)

Finn sets these up once in Windsor. The column lists and rules live in `Ads/dashboard/DATA_CONTRACT.md` §1, which is authoritative; this page covers only how to enter them.

**Windsor:** https://onboard.windsor.ai/app/destinations/overview#googlesheets. Each export needs Google sign-in, so it can't be created from chat.

## 1. Create three empty Google Sheets (one tab each)
1. `GROOV Ads · Meta`
2. `GROOV Ads · TikTok`
3. `GROOV Ads · Google`

## 2. One Windsor task per Sheet
| Setting | Meta | TikTok | Google |
|---|---|---|---|
| Connector | Facebook Ads | TikTok Ads | Google Ads |
| Accounts | all | all | all |
| Fields (in this order) | DATA_CONTRACT §1, Sheet 1 (22 fields) | Sheet 2 (22 fields) | Sheet 3 (15 fields) |
| Date range | last 28 days | last 28 days | last 28 days |
| Upsert / match columns | `date, ad_id` | `date, ad_id` | `date, campaign_id, ad_group_id` |
| Schedule | daily 06:00 Bangkok | daily 06:00 Bangkok | daily 06:00 Bangkok |
| Backfill (first run) | as far as the plan allows | same | same |
| Task name | `GROOV Ads · Meta` | `GROOV Ads · TikTok` | `GROOV Ads · Google` |

## 2b. Optional: two Meta breakdown exports (placement and audience)
These power the dashboard's "where results happen" panels: % of conversions by placement and by age × gender inside every ad set. Create two more spreadsheets with one tab each, `GROOV Ads · Meta placements` and `GROOV Ads · Meta audience`, and one Windsor task for each:

| Setting | Meta placements | Meta audience |
|---|---|---|
| Connector | Facebook Ads | Facebook Ads |
| Accounts | all | all |
| Fields (in this order) | DATA_CONTRACT §1, Sheet 4 (12 fields) | Sheet 5 (12 fields) |
| Filter | spend > 0 | spend > 0 |
| Date range / schedule / backfill | last 28 days · daily 06:00 Bangkok · as far as the plan allows | same |
| Upsert / match columns | `date, adset_id, publisher_platform, platform_position` | `date, adset_id, age, gender` |

## 3. Check while setting up (tell Claude what you see)
- **Upsert / match columns.** If the form doesn't offer them, use "yesterday" plus append mode instead. The dashboard de-duplicates identical rows, but late conversions on older days would then be missed.
- **Meta `effective_status` alongside `date`.** If Windsor refuses it, drop that one field. Statuses then show as UNKNOWN until a fix.
- **Backfill depth** on your plan.

## 4. After the first run
Send Claude the three Sheet links. Next steps: a service account gets Viewer access, the Netlify data job is pointed at the Sheets, and the numbers are checked against Windsor.

*Older exports `FB Ads Ai`, `Tiktok Ads Ai`, `ธาราริช-FB Ads Ai` and `อาศัย-FB Ads Ai` are deactivated and unrelated. Leave them or delete them.*
