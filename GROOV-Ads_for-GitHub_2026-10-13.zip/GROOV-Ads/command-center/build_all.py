#!/usr/bin/env python3
"""Rebuild every account dashboard, then the Command Center that links to them.

    python3 build_all.py                            # latest 7 completed Bangkok days vs prior 7
    GROOV_PERIOD_END=2026-09-20 python3 build_all.py  # rebuild a specific window
"""
from __future__ import annotations
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
for name in ("creatives.py", "build_meta.py", "build_tiktok.py", "build_google.py", "build_command_center.py"):
    print(f"RUN {name}", flush=True)
    subprocess.run([sys.executable, str(ROOT / name)], cwd=ROOT, check=True, stdout=subprocess.DEVNULL)
sys.path.insert(0, str(ROOT))
from period import CUR_LABEL, PREV_LABEL, HTML_DIR  # noqa: E402
pages = sorted(p.relative_to(HTML_DIR) for p in HTML_DIR.rglob("*.html"))
print(f"BUILD COMPLETE · {CUR_LABEL} vs {PREV_LABEL} · {len(pages) - 1} account dashboards + command center")
print(HTML_DIR / "index.html")
