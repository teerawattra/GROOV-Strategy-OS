#!/usr/bin/env python3
"""Read-only Windsor.ai REST pull for every connected Meta, TikTok and Google Ads account.

Writes the five source/*.json snapshots the builders read, covering the comparison + current
window from period.py (14 completed Bangkok days). Reporting endpoint only: nothing here can
change an ad platform or Windsor configuration.

Key: MCP_WINDSOR_API_KEY, from the environment or Ads/.env (never commit, print or paste it).
"""
from __future__ import annotations

import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

from period import ADS_ROOT, FETCH_FROM, FETCH_TO, SOURCE, CUR_LABEL, PREV_LABEL

BASE = "https://connectors.windsor.ai/"

META_AD_FIELDS = [
    "date", "account_id", "account_name", "campaign", "campaign_id", "campaign_objective", "adset_name", "adset_id", "ad_name", "ad_id",
    "spend", "impressions", "reach", "frequency", "cpm", "clicks", "link_clicks", "ctr", "cpc", "actions_video_view",
    "video_p25_watched_actions_video_view", "video_p50_watched_actions_video_view", "video_p75_watched_actions_video_view",
    "video_p100_watched_actions_video_view", "actions_onsite_conversion_messaging_conversation_started_7d",
    "cost_per_action_type_onsite_conversion_messaging_conversation_started_7d", "actions_lead", "cost_per_action_type_lead",
    "purchase_roas_omni_purchase", "website_purchase_roas_offsite_conversion_fb_pixel_purchase", "image_url", "thumbnail_url",
    "ad_preview_shareable_link", "body", "title", "carousel_card_media_urls"]
META_CAMPAIGN_FIELDS = [
    "date", "account_id", "account_name", "campaign", "campaign_id", "campaign_objective", "spend", "impressions", "reach", "frequency",
    "cpm", "clicks", "link_clicks", "ctr", "cpc", "actions_onsite_conversion_messaging_conversation_started_7d",
    "cost_per_action_type_onsite_conversion_messaging_conversation_started_7d"]
META_STATUS_FIELDS = [
    "account_id", "account_name", "campaign", "campaign_id", "campaign_status", "campaign_configured_status", "campaign_effective_status",
    "campaign_created_time", "campaign_start_date", "campaign_start_time", "campaign_stop_time", "adset_name", "adset_id", "adset_status",
    "adset_effective_status", "adset_created_time", "adset_start_time", "adset_end_time", "ad_name", "ad_id", "status", "effective_status",
    "ad_created_time"]
TIKTOK_FIELDS = [
    "date", "account_id", "account_name", "campaign", "campaign_id", "campaign_status", "campaign_operation_status", "opt_status",
    "objective", "objective_type", "adgroup_id", "adgroup_name", "ad_id", "ad_name", "spend", "impressions", "reach", "frequency",
    "clicks", "ctr", "cpc", "cpm", "conversions", "cost_per_conversion", "total_sales_lead", "cost_per_total_sales_lead",
    "messaging_total_conversation_tiktok_direct_message", "messaging_cost_per_conversation_tiktok_direct_message", "total_play",
    "play_duration_6s", "play_over", "complete_payment_roas", "onsite_purchases_roas", "video_thumbnail_url", "video_url"]
GOOGLE_FIELDS = [
    "date", "account_id", "account_name", "campaign", "campaign_id", "campaign_status", "advertising_channel_type", "ad_group_id",
    "ad_group_name", "ad_group_status", "ad_group_ad_name", "ad_group_ad_status", "ad_group_ad_primary_status",
    "ad_responsive_search_ad_headlines_combined_text", "ad_responsive_search_ad_descriptions_combined_text", "ad_final_urls",
    "spend", "impressions", "clicks", "ctr", "cpc", "conversions", "cost_per_conversion", "conversion_value"]


def api_key() -> str:
    env_file = ADS_ROOT / ".env"
    if env_file.exists():
        for line in env_file.read_text(encoding="utf-8").splitlines():
            if "=" in line and not line.lstrip().startswith("#"):
                key, value = line.split("=", 1)
                os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))
    key = os.environ.get("MCP_WINDSOR_API_KEY", "")
    if not key or key.startswith("replace_with"):
        sys.exit("MCP_WINDSOR_API_KEY is not set. Copy Ads/.env.example to Ads/.env and add the key privately.")
    return key


def request(key: str, connector: str, fields: list[str], date_from=None, date_to=None) -> list[dict]:
    params = {"api_key": key, "fields": ",".join(fields), "_max_rows": "100000"}
    if date_from:
        params.update(date_from=str(date_from), date_to=str(date_to))
    req = urllib.request.Request(BASE + connector + "?" + urllib.parse.urlencode(params),
                                 headers={"Accept": "application/json", "User-Agent": "GROOV-ReadOnly-Reporting/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=300) as response:
            payload = json.load(response)
    except urllib.error.HTTPError as exc:  # message never contains the key or URL
        raise RuntimeError(f"Windsor {connector} HTTP {exc.code}: {exc.read().decode('utf-8', 'replace')[:500]}") from None
    except urllib.error.URLError as exc:
        raise RuntimeError(f"Windsor {connector} network error: {exc.reason}") from None
    rows = payload.get("data", payload) if isinstance(payload, dict) else payload
    if not isinstance(rows, list):
        raise RuntimeError(f"Windsor {connector}: response data is not a list")
    return [r for r in rows if r.get("account_id")]


def save(name: str, rows: list[dict]) -> None:
    (SOURCE / name).write_text(json.dumps(rows, ensure_ascii=False, indent=1), encoding="utf-8")
    accounts = len({r.get("account_id") for r in rows})
    print(f"  {name:<26} {len(rows):>6} rows · {accounts} accounts")


def main() -> None:
    key = api_key()
    SOURCE.mkdir(exist_ok=True)
    print(f"Windsor read-only pull {FETCH_FROM} → {FETCH_TO} (current {CUR_LABEL}, comparison {PREV_LABEL})")
    meta_ads = request(key, "facebook", META_AD_FIELDS, FETCH_FROM, FETCH_TO)
    for row in meta_ads:
        if row.get("objective") is None and "campaign_objective" in row:
            row["objective"] = row.pop("campaign_objective")
    save("meta-ad-daily.json", meta_ads)
    save("meta-campaign-daily.json", request(key, "facebook", META_CAMPAIGN_FIELDS, FETCH_FROM, FETCH_TO))
    save("meta-status.json", request(key, "facebook", META_STATUS_FIELDS, FETCH_TO, FETCH_TO))
    save("tiktok-ad-daily.json", request(key, "tiktok", TIKTOK_FIELDS, FETCH_FROM, FETCH_TO))
    save("google-ad-daily.json", request(key, "google_ads", GOOGLE_FIELDS, FETCH_FROM, FETCH_TO))
    (SOURCE / "_pulled.json").write_text(json.dumps({"from": str(FETCH_FROM), "to": str(FETCH_TO)}), encoding="utf-8")


if __name__ == "__main__":
    main()
