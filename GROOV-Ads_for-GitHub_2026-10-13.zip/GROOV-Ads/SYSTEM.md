# GROOV Ads system: how it fits together

Read this first in any new session. `CLAUDE.md` holds the rules; this file holds the map and the current state. Update **Status** whenever something is set up or changes.

## Principle
The system runs on its own; Claude doesn't need to be online for it. Claude's job is to **read, analyse and set up ads**:
- **Read:** the 3 Google Sheets, or the dashboard's own API data.
- **Analyse:** apply the decision rules and `learnings/PLAYBOOK.md`, then write new learnings to `learnings/LOG.md`, and to `rules.json` when a rule can be checked automatically.
- **Set up:** write launch specs and make live changes through Meta Ads MCP, only after Finn confirms each change. Every change is logged.

## Architecture
```
Meta Ads ─┐
TikTok ───┼─► Windsor.ai ──(daily 06:00, re-pulls 28 days)──► 3 Google Sheets (full history, one tab each)
Google ───┘                                                           │
                                                                      ▼
            Netlify (cloud, runs without Claude or the Mac):  refresh-data job 07:15 Bangkok
              • reads the Sheets (service account) → normalises → caches in Netlify Blobs
              • saves new ad images (links expire) → Blobs "creatives"
              • serves the dashboard behind Google sign-in (@groovstrategy.co + allow-list)
                                                                      │
                                                                      ▼
                     GROOV Ads Command Center (dashboard/public): Overview · Action queue · Client
                     view · Creatives · Playbook · Data health; sidebar periods 7/14/30/60/90d,
                     MTD, last month, QTD, last quarter, custom; filters; editable decision rules

Claude ── reads data + learnings ─► analysis, LOG.md / rules.json entries, launch specs
       └─ Meta Ads MCP (write, confirm-first) ─► live changes ─► clients/<c>/changelog.md
```

| Component | Where | Source of truth for |
|---|---|---|
| Account registry | `accounts/registry.json` | client → ad account IDs, vertical, optional owner, budget, targets |
| Data contract | `dashboard/DATA_CONTRACT.md` | the 3 Sheets' columns and the dashboard's JSON |
| Windsor export guide | `command-center/sheets-export.md` | how to set up the 3 exports |
| Dashboard spec | `dashboard/SPEC.md` | every feature and how it operates |
| Dashboard code | `dashboard/public/` (frontend), `dashboard/lib` + `netlify/` (API, login, jobs) | |
| Deploy guide | `dashboard/DEPLOY.md` | Google Cloud, OAuth and Netlify setup, step by step |
| Learnings | `learnings/PLAYBOOK.md` (rules), `LOG.md` (evidence), `rules.json` (live checks + benchmarks) | what works and what doesn't |
| Creative library (seed) | `command-center/creatives/<platform>/<ad_id>.jpg` | images saved before Netlify; seeded once into Blobs |
| Older tools (kept) | `command-center/` (Hermes static build, live Windsor artifact) | regression check and fallback |
| Client working files | `clients/<client>/brief.md`, `changelog.md` | goals, targets, live-change history |

## VPS package (Hermes)
- **Source:** `dashboard/` (one codebase). `server/` is the VPS backend, `deploy/` holds systemd and Tailscale, and `dashboard/hermes/` holds HERMES.md, MODULES.md and README.md for the package.
- **Build the zip:** `cd dashboard && npm run package:hermes` → `hermes-package/GROOV_Command_Center_<date>.zip`. It strips sample data, the Google login and the Netlify code, and ships the seed creatives.
- **Future modules** (KOL, Content, CRM) follow `dashboard/hermes/MODULES.md`. Only Meta Ads, Google Ads and TikTok Ads are connected in Windsor today.
- **Recommended:** move the code to a private Git repo, so Hermes (VPS) and Claude (Mac) share one copy.

## Working on the dashboard
- **Local preview with sample data** (real Sep 2026 snapshot):
  ```
  cd dashboard
  npm run build:sample
  npm run build:static
  ```
  Then open `public/index.html`. Sample mode is used only on `file:` or localhost.
- **Tests:** `cd dashboard && npm test` runs the normaliser, the backend and the frontend engine.
  - Parity check: 14–20 Sep 2026 vs 7–13 Sep 2026 has 21 delivering accounts and ฿91,303.10.
- **After editing learnings or the registry:** run `npm run build:static`, then redeploy (`npm run deploy`).

## Status (update this section)
| Item | State | Next step |
|---|---|---|
| Account registry | ✅ 27 clients mapped (2026-10-05) | Confirm Kin Toshi, AdWise and Kagonoya ownership; add owner, budget and targets per client |
| Dashboard (frontend) | ✅ Built 2026-10-12, all 6 pages; 2026-10-13: trend line on every KPI, plus placement and age × gender panels per ad set and client (534 tests) | Real-data check once the Sheets exist |
| **VPS deployment for Hermes (chosen 2026-10-13)** | ✅ Built and packaged: `hermes-package/GROOV_Command_Center_2026-10-13.zip` (Node server, Windsor REST → files on the VPS, Tailscale-only access, systemd daily refresh). 628 repo tests; 468 inside the package | Finn sends the zip to Hermes, who follows HERMES.md |
| Netlify API + Google login + jobs | ✅ Built 2026-10-12; now the **alternative** (not used while the VPS runs) | — |
| 3 Google Sheets exports | ⏳ Not created; Finn sets them up in Windsor | Finn sends the 3 Sheet links |
| Google Cloud service account + OAuth client | ⏳ Not created | Finn, following DEPLOY.md §1–2 |
| Netlify site + env vars + creative seed | ⏳ Not created | After the above |
| Meta breakdown exports (placement, audience), optional | ⏳ Not created; the dashboard shows splits once they exist (sample built from real Windsor data for 16 of 19 accounts) | Finn adds the 2 exports (sheets-export.md §2b) |
| Learning log | ✅ 5 observations (L-001 to L-005); L-005 corrected to all-click CTR on 2026-10-12 | Re-check against real Sheets history |
| Live Windsor artifact (claude.ai) | ✅ Still works; superseded by the Netlify dashboard once deployed | Retire after go-live |

## Known gaps
- **Windsor connection gap (found 2026-10-13):** Birdiepoolvilla (2329133337532593), Rena Yakiniku Meta (1342233060015249) and Vistro Bangkok (1638002137420134) return "Account … is not available" in this Windsor connection. They must be (re)connected in Windsor, or the Sheets will miss them entirely. MIRA Restaurant (25058686157074368) does spend in Windsor but wasn't in Hermes's snapshot.
- 4 Bake Bread Digital Meta accounts can't be changed through Meta Ads MCP yet (rollout). They're read-only via Windsor.
- Kalamansi Kitchen's Meta account was in a billing grace period on 2026-10-05. Account billing status is not in the Sheets (a "later" field).
- Google stops at ad-group level (no ad IDs); search ads are text-only.
- Messages and lead actions are platform-reported events; no CRM or booking data is connected yet.
- Meta `link_clicks` is often blank in exports, so link CTR can be understated. The dashboard shows "—" when link clicks aren't reported.
