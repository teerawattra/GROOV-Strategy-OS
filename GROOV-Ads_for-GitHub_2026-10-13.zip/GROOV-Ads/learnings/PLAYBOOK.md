# GROOV ads playbook: what works, what doesn't

The distilled, current view, which Claude reads **before** analysing an account or proposing a campaign. Each rule cites its evidence in `LOG.md`. When new evidence contradicts a rule, Claude updates it here and marks the old log entry `Superseded`. Claude never quietly deletes a rule.

**Confidence bar**
- **Observation:** seen once, in one account or one period. Use it as a hypothesis, never as a promise to a client.
- **Tested:** a deliberate comparison (A/B, or before/after with similar spend) of at least 2 weeks and at least 20 results per arm, or repeated in at least 2 accounts.
- **Proven:** holds across at least 3 accounts or at least 3 separate months, with no contradicting test. Finn confirms before a rule is marked Proven.

**Metric honesty** (applies to every rule): messages and lead actions are platform-reported events, not qualified leads, bookings or sales. A rule judged on cost per message says nothing about patient or diner quality until CRM data backs it up.

---

## Clinic
| Rule | Confidence | Evidence |
|---|---|---|
| Message ads under ~1.5% CTR (all clicks ÷ impressions) after about ฿500 spend rarely produce conversations. Fix the creative hook before adding budget. | Observation | L-005 |
| A broad, clinic-level message ad (Advantage+) can beat single-treatment ads on cost per message by 2–3×. Check enquiry quality before moving budget. | Observation | L-004 |

## F&B
| Rule | Confidence | Evidence |
|---|---|---|
| Lookalike audience + price-led offer + message objective produced the portfolio's lowest cost per message (฿16 for a buffet). Worth testing for other buffet and yakiniku clients. | Observation | L-002 |

## Real estate
*No rules yet. Benchmark only: ฿95–117 per message for the Tharaville projects (L-003).*

## Hotel
*No rules yet. Benchmark only: ฿241–373 per message for Birdie Pool Villa (L-003).*

## Cross-vertical
| Rule | Confidence | Evidence |
|---|---|---|
| Set cost-per-message targets per vertical. The spread is more than 10×: F&B about ฿16–115, real estate about ฿95–117, clinic about ฿87–1,200. | Observation | L-003 |
| Judge awareness and reach on frequency and lift in message or lead volume, not on CPM (Meta about ฿9, TikTok about ฿12). | Observation | L-001 |

## Open questions to test
- Does the clinic CTR threshold (L-005) hold at The Peak Clinic and SOWELL?
- Do treatment-specific clinic ads bring better-quality enquiries than broad ones? This needs CRM or LINE OA booking data.
- Does lookalike + price-led messaging work outside Rena (Anchor Buffet, 5 YEN)?
