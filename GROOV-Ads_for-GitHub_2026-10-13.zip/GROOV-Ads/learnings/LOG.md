# Ads learning log: evidence

Newest first. Every entry is written by Claude after an analysis, a finished test, or a live change whose result is now known. The distilled rules live in `PLAYBOOK.md`. This file holds the evidence behind them.

**Entry format**
```
## L-NNN · YYYY-MM-DD · <one-line learning>
- Scope: client(s) · vertical · platform · objective
- Evidence: period vs comparison · campaign/ad names + IDs · spend · results · cost/result · CTR (exact numbers)
- Sample: n campaigns/ads, days, spend; and what would make it unreliable
- Confidence: Observation | Tested | Proven      (see PLAYBOOK.md for the bar)
- Status: Active | Superseded by L-NNN | Rejected
- Applies to: tags for reuse (e.g. clinic, messages, advantage+, bangkok)
- Next: what to test or do because of it
```

---

## L-005 · 2026-10-12 · Clinic message ads with CTR (all clicks) under ~1.5% almost never produced conversations
- **Scope:** AT EASE Clinic · Clinic · Meta · Messages
- **Evidence (14–20 Sep 2026 vs 7–13 Sep):**
  - Low-CTR campaigns:
    - `TOF_MSG_9.9`: ฿1,205 spend, 1 message, CTR 1.02%
    - `TOF_MSG_AdvProAcne`: ฿1,124, 1 message, CTR 0.93%
    - `TOF_MSG_CellecV`: ฿1,078, 1 message, CTR 1.38%
    - `TOF_MSG_OliUF`: ฿1,106, 3 messages, CTR 0.54%
  - Higher-CTR campaigns in the same account:
    - `TOF_MSG_Juvelook`: CTR 2.09%, 9 messages at ฿121
    - `MOF_Re_MSG`: CTR 2.84%, 5 messages at ฿233
- **Metric:** CTR here means **all clicks ÷ impressions** (the Hermes definition), not link CTR. For example, Juvelook's 2.09% is 153 clicks / 7,333 impressions; its link CTR was 0.56%. *Corrected 2026-10-12: first written as link CTR, which would wrongly flag strong ads such as The Peak Clinic's ฿87-per-message ad (link CTR 1.13%).*
- **Sample:** 7 campaigns, one account, one week, about ฿8.2k spend. Possible confounders are offer, audience size and creative format.
- **Confidence:** Observation
- **Status:** Active
- **Applies to:** clinic, messages, creative-hook, early-warning
- **Next:** treat clinic message ads below 1.5% CTR (all clicks) after about ฿500 as a creative problem and swap the hook before adding budget. Check whether the same holds at The Peak Clinic.

## L-004 · 2026-10-12 · At The Peak Clinic, the broad clinic-level ad beat the single-treatment ads on cost per message
- **Scope:** The Peak Clinic · Clinic · Meta · Messages · Advantage+
- **Evidence (14–20 Sep 2026):**
  - Broad ad, `GROOV_TPC3_MSG New_Advantage+_location clinic`: ฿2,855, 33 messages, ฿87 each, CTR 4.79%
  - Single-treatment ads:
    - Olígio: ฿2,078, 8 messages, ฿260
    - Filler: ฿2,036, 7 messages, ฿291
    - Weight-loss pen: ฿1,683, 8 messages, ฿210
    - Botox: ฿1,390, 8 messages, ฿174
    - Picolaser: ฿1,409, 13 messages, ฿108
    - Morpheus: ฿1,040, 6 messages, ฿173
    - Ultraformer: ฿1,001, 6 messages, ฿167
  - Retargeting `New_Re 45day`: ฿2,134, 18 messages, ฿119
- **Sample:** 9 campaigns, one week, about ฿15.6k spend. These are platform-reported conversations, not booked patients. Treatment ads may bring higher-value enquiries.
- **Confidence:** Observation
- **Status:** Active
- **Applies to:** clinic, messages, advantage+, broad-vs-specific
- **Next:** before cutting treatment ads, compare booking or quality rates from the clinic's CRM. If quality is similar, shift budget toward the broad clinic-level ad.

## L-003 · 2026-10-12 · Message cost differs by more than 10× across verticals, so set targets per vertical and never use one GROOV-wide target
- **Scope:** all Meta message campaigns with ≥ ฿300 spend
- **Evidence (14–20 Sep 2026, cost per message):**
  - F&B: Rena Yakiniku `TOF_Message lookalike` ฿16 (87 messages, CTR 9.41%)
  - GROOV in-house F&B: ฿115
  - Real estate: Tharaville Rayong ฿117 (66 messages), Tharaville Chumphon ฿95 (36 messages)
  - Clinic: The Peak ฿87–291, AT EASE ฿121–1,205
  - Hotel: Birdie Pool Villa ฿241–373
  - The median across all 36 Meta message campaigns was ฿250, which is meaningless as a single number.
- **Sample:** 36 campaigns, one week.
- **Confidence:** Observation
- **Status:** Active
- **Applies to:** benchmarks, messages, targets, f&b, real-estate, clinic, hotel
- **Next:** build per-vertical cost-per-message bands once 8+ weeks are in the Sheets, and use them in client briefs (`clients/<c>/brief.md`).

## L-002 · 2026-10-12 · Rena Yakiniku's lookalike message campaign is the strongest message campaign in the portfolio
- **Scope:** Rena Yakiniku · F&B · Meta · Messages · Lookalike
- **Evidence (14–20 Sep 2026):** `TOF_Message lookalike` spent ฿1,411 for 87 messages at ฿16 each, with CTR 9.41%. The decision engine rated it Ready to Scale.
- **Sample:** 1 campaign, one week. A strong buffet price offer is likely part of the effect.
- **Confidence:** Observation
- **Status:** Active
- **Applies to:** f&b, buffet, messages, lookalike, offer-led
- **Next:** test a lookalike message structure with a price-led offer for another buffet or yakiniku client, such as Anchor Buffet or Niku Machi if signed. Compare against the client's interest-targeted campaign.

## L-001 · 2026-10-12 · Reach CPM is very cheap on both platforms, so awareness spend is judged on frequency and downstream lift, not CPM
- **Scope:** all awareness campaigns
- **Evidence (14–20 Sep 2026):**
  - Meta awareness: median CPM ฿9 across 14 campaigns, median CTR 0.30%
  - TikTok reach: median CPM ฿12 across 2 campaigns
  - Meta message campaigns: median CPM ฿168, by comparison
- **Sample:** one week. Awareness clicks are not a goal metric.
- **Confidence:** Observation
- **Status:** Active
- **Applies to:** awareness, reach, cpm, tiktok, meta
- **Next:** when a client runs awareness alongside messages, check whether message volume rises in the same weeks before calling awareness worthwhile.

*Source for L-001 to L-005: Hermes's frozen 7–20 Sep 2026 Windsor snapshot (`command-center/source/`, reproduced as `command-center-data.json`). Re-check each against the Sheets history once it exists.*
